#!/usr/bin/env python3
"""End-to-end self-test of the notebook on CPU with a tiny randomly initialised DiT.

Builds the notebook from the script, executes every cell with AOQM_SELF_TEST=1 and fails on
the first cell error. It exercises the whole code path (wrapping, profiling, allocation,
in-pass error measurement, generation, metrics, every statistical analysis, figures,
tables, stimulus pack and zip) but its numbers are meaningless. It downloads the Inception
FID weights (~91 MB) and CLIP ViT-B/32 (~600 MB) on first use. Takes about 8-12 minutes.

Usage:  python tests/run_self_test.py [working_dir]
"""
import os
import sys
import tempfile
import time
from pathlib import Path

import nbformat
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from build_notebook import build  # noqa: E402


def main() -> int:
    work = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(tempfile.mkdtemp(prefix="aoqm_selftest_"))
    work.mkdir(parents=True, exist_ok=True)
    nb_path = work / "AOQM_self_test.ipynb"
    build(dst=nb_path)
    nb = nbformat.read(str(nb_path), as_version=4)
    os.environ["AOQM_SELF_TEST"] = "1"
    os.environ.setdefault("MPLBACKEND", "Agg")
    t0 = time.time()
    client = NotebookClient(nb, timeout=3600, kernel_name="python3", resources={"metadata": {"path": str(work)}})
    try:
        client.execute()
    finally:
        nbformat.write(nb, str(work / "AOQM_self_test_executed.ipynb"))
    out = work / "aoqm_selftest_outputs"
    n_tab = len(list((out / "tables").glob("*.csv")))
    n_fig = len(list((out / "figures").glob("*.png")))
    print(f"Self-test passed in {time.time() - t0:.0f} s: {n_tab} tables, {n_fig} figures in {out}")
    return 0 if n_tab >= 30 and n_fig >= 9 else 1


if __name__ == "__main__":
    sys.exit(main())
