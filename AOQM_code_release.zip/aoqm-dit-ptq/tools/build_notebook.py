#!/usr/bin/env python3
"""Regenerate notebooks/AOQM_DiT_PTQ_Colab.ipynb from scripts/aoqm_experiment.py.

The script is the single source of truth. Cells are delimited by "# %%" (code) and
"# %% [markdown]" (markdown, each line prefixed with "# "). The notebook is written
without outputs and with Colab GPU metadata.

Usage:  python tools/build_notebook.py
"""
import re
import sys
from pathlib import Path

import nbformat

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "scripts" / "aoqm_experiment.py"
DST = ROOT / "notebooks" / "AOQM_DiT_PTQ_Colab.ipynb"


def build(src: Path = SRC, dst: Path = DST) -> int:
    text = src.read_text(encoding="utf-8")
    parts = re.split(r"^# %%(.*)$", text, flags=re.M)
    cells = []
    for i in range(1, len(parts), 2):
        kind, body = parts[i].strip(), parts[i + 1].strip("\n")
        if kind == "[markdown]":
            md = "\n".join(l[2:] if l.startswith("# ") else l.lstrip("#") for l in body.splitlines())
            cells.append(nbformat.v4.new_markdown_cell(md))
        else:
            cells.append(nbformat.v4.new_code_cell(body))
    nb = nbformat.v4.new_notebook(cells=cells)
    nb.metadata = {"accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4"},
                   "kernelspec": {"name": "python3", "display_name": "Python 3"},
                   "language_info": {"name": "python"}}
    dst.parent.mkdir(parents=True, exist_ok=True)
    nbformat.write(nb, str(dst))
    return len(cells)


if __name__ == "__main__":
    n = build()
    print(f"{n} cells -> {DST.relative_to(ROOT)}")
    sys.exit(0)
