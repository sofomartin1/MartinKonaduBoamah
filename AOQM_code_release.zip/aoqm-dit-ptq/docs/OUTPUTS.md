# Output reference

Every file below is written by `notebooks/AOQM_DiT_PTQ_Colab.ipynb` (or `scripts/aoqm_experiment.py`)
into `aoqm_outputs/` (Colab: `/content/aoqm_outputs/`; locally: the working directory). Nothing in
this list is committed to the repository. All CSV files are UTF-8 with a byte-order mark so that
Excel displays χ, Δ and ² correctly; `AOQM_all_tables.xlsx` holds every table as one sheet each.

Conventions used throughout:

* **Run**: one allocation map (policy × budget × seed block) applied to the checkpoint, with 256
  generated images (standard preset). **Block**: seed block; blocks differ in calibration batch,
  sensitivity estimate and image noise seeds.
* **Policies**: `uniform`, `sensitivity`, `outlier` (outlier-preserving), `anti_targeted`,
  `perturb_outlier_withheld`, `perturb_nonoutlier_withheld`.
* **AOE / NOE / WOE**: activation-outlier, non-outlier activation and weight-outlier error indices
  (Eq. 3 of the paper). `log_*` columns are log-transformed with a floor of 1% of the median.
* **q_\***: log-degradation relative to the block's FP16 reference, oriented so higher is better.
  **z_\***: the same standardised over the primary runs. **composite**: standardised mean of the four
  z-scores (Eq. 5).
* Effects are in standard deviations of the primary runs unless stated otherwise.

## Top-level files

| File | Content |
|---|---|
| `analysis_plan.json` | Every setting, the hypotheses and the confirmatory family, with a SHA-256 hash, written **before** any run executes. If settings change later, the cache is cleared and a new plan is written. |
| `provenance.json` | Checkpoint and CLIP Hub revisions, GPU, CUDA and library versions, preset, plan hash, run count, finish time. |
| `AOQM_all_tables.xlsx` | All tables below in one workbook. |
| `human_ratings.csv` | *Not produced.* Place real ratings here (see README) to enable T28. |

## Tables (`tables/`)

| File | Rows | Content and key columns |
|---|---|---|
| `T01_provenance.csv` | item/value | Same content as `provenance.json`. |
| `T02_module_inventory.csv` | module type | Quantized vs FP16 modules read from the loaded architecture: count, in/out features, parameters (M). |
| `T02b_module_list_full.csv` | Linear module | Every `nn.Linear` with name, type, shape, parameters, `quantized`. |
| `T03_outlier_profile_by_module.csv` | block × module | `chi_max` (largest channel max / median channel max), `n_outlier` (channels with χ ≥ χ*), `outlier_energy_share`, `n_protected`, `phi` (protected fraction), `sensitivity` (output MSE when the module alone is quantized at 4 bits, relative to output energy). |
| `T03b_outlier_profile_by_type.csv` | block × type | Aggregates of T03. |
| `T04_run_inventory_manipulation_check.csv` | run | Target and `realized_bits` (Eq. 4), `abs_dev`, `check_pass` (≤ 0.05 bits), `share_at_floor`, `share_at_8bit`, `protected_channels`, `map_sha1`, `n_moved` (perturbation). |
| `T05_map_dissimilarity.csv` | block × budget × pair | Parameter-weighted mean absolute bit difference and share of modules assigned differently. |
| `T06_full_precision_reference_and_noise_floor.csv` | block | FID and CMMD between two independent FP16 sets (noise floor), FP16 CLIP score, FP16 seconds per image and peak memory. |
| `T07_run_level_dataset.csv` | run | The analysis dataset: design columns, AOE/NOE/WOE, FID, CMMD, CLIP, SSIM, PSNR, timing, q_\*, z_\*, composite, log mediators. |
| `T07b_sample_level_dataset.csv` | run × image | `class_id`, `sample_id` (block-specific noise identity), `ssim`, `psnr`, `clip`, `dclip` (CLIP change vs the paired FP16 image). |
| `T08_descriptives_by_cell.csv` | policy × budget | Mean and SD over blocks of bits, mediators, metrics and composite. |
| `T09_total_effects_run_level_HC3.csv` | outcome × term | OLS with HC3: estimate, SE, 95% CI, p, joint Wald test of the policy terms, R². |
| `T10_paired_strategy_contrasts.csv` | contrast | Paired (budget × block) differences on the composite, Hedges' g_z, t, p. |
| `T11_total_effects_sample_level_crossed_mixed.csv` | outcome × term | Linear mixed models on run × class means with crossed random intercepts for run and class: fixed effects, `var_run`, `var_class`, `var_residual`, convergence. |
| `T12_mediation_parallel_outlier_vs_uniform.csv` | quantity | Parallel three-mediator model: a, b, indirect, direct, total, contrasts of absolute indirect effects, share and proportion mediated; bootstrap SE, BCa and percentile CIs, bootstrap p; identity check. |
| `T12b_mediation_sensitivity_vs_uniform.csv` | quantity | The same decomposition for the sensitivity-aware contrast. |
| `T13_collinearity_VIF.csv` | predictor | Variance inflation factors and the condition number of the standardised design. |
| `T13b_mediator_correlations.csv` | matrix | Run-level correlations of mediators, bits and composite. |
| `T14_ridge_path.csv` | λ | Ridge (mediator coefficients only) b-paths, indirect and direct effects, whether the AOE pathway is largest. |
| `T15_dominance_analysis.csv` | mediator | General dominance R², share, ΔR² entered first/last, base and full R². |
| `T16_single_mediator_and_budget_FE.csv` | model | Single-mediator models and the parallel model with budget fixed effects. |
| `T17_outlier_rule_sensitivity.csv` | rule | Decomposition re-derived for χ* ∈ {4, 6, 8, 12, 16, 24} and a top-1% rule. |
| `T18_robust_conclusion_checks.csv` | check | Pass/fail of the pre-specified robustness checks of the "AOE is the dominant pathway" conclusion. |
| `T19_H2_AOE_by_strategy.csv` | term | log AOE on policy and bits (HC3). |
| `T20_H5_anti_vs_uniform.csv` | block × budget | Composite difference, anti-targeted minus uniform. |
| `T21_H6_perturbation.csv` | perturbation run | Δlog AOE/NOE/WOE and Δcomposite/ΔSSIM relative to uniform 5-bit in the same block. |
| `T22_H7_moderated_mediation.csv` | quantity | Index of moderated mediation and conditional indirect effects by budget. |
| `T23_RQ3_sensitivity_advantage_TOST.csv` | budget × outcome | Paired per-sample sensitivity − uniform differences, 90% CI, TOST p, equivalence, run-level composite advantage. |
| `T24_RQ3_breakpoint_exploratory.csv` | 1 | Segmented-regression breakpoint with residual-bootstrap CI (descriptive). |
| `T25_H8_metric_agreement_kendallW.csv` | budget | Kendall's W, χ², p and best policy per indicator. |
| `T25b_indicator_spearman.csv` | matrix | Spearman correlations of the four indicators. |
| `T26_hypothesis_summary.csv` | hypothesis | Raw, Holm and Benjamini–Hochberg p-values and decisions. |
| `T27_efficiency.csv` | policy × budget | Analytic model size (MiB, × FP16), metadata, simulated seconds per image, peak GPU memory, GPU name and kernel note. |
| `T28_human_preference_crossed_GLMM.csv` | parameter | Only when `human_ratings.csv` exists: Bayesian binomial mixed model with crossed rater and prompt effects. |

## Figures (`figures/`, PNG at 300 dpi and PDF)

| File | Content |
|---|---|
| `F01_outlier_profile_and_sensitivity` | χ_max, outlier energy share and module sensitivity by block and module type. |
| `F02_allocation_maps` | Bit-width maps of the four policies at 4.5 bits; white ticks mark FP16 branches. |
| `F03_mediators_by_strategy_and_budget` | AOE, NOE and WOE by policy and budget. |
| `F04_quality_by_strategy_and_budget` | FID, CMMD, CLIP, SSIM and composite by policy and budget, with FP16 references. |
| `F05_sample_grid` | Images with identical class and noise under each policy at 4.5, 4 and 3.5 bits. |
| `F06_mediation_collinearity_ridge` | Decomposition with BCa CIs, correlation heatmap, ridge path. |
| `F07_dominance_analysis` | Share of mediator-explained R². |
| `F08_perturbation` | Mediator and quality response to the constant-budget perturbation. |
| `F09_RQ3_sensitivity_advantage` | Run-level and paired per-sample sensitivity-aware advantage with the equivalence band. |

## Other folders

| Folder | Content |
|---|---|
| `samples/` | Reserved; sample images are kept inside the cache and the figure F05. |
| `human_study_pack/` | Blinded left/right pairs (`<pair_id>.png`, quantized vs FP16, same class and noise) for budgets 3.5–5 bits, `presentation_list.csv` (shuffled, safe to show raters) and `KEY_do_not_show_raters.csv`. |
| `cache/` | Per-run `.npz` files (error accumulators, features, metrics, a few images) and per-block profiles; lets an interrupted session resume. Excluded from the zip. |
