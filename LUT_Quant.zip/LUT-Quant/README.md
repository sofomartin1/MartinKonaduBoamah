# LUT-Quant: Data-Driven Look-Up Table Quantization for Cross-Attention in Text-to-Image Diffusion Models

[![Python](https://img.shields.io/badge/python-3.9%E2%80%933.11-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

Code, experiment pipeline and record tooling for the paper

> **LUT-Quant: Data-Driven Look-Up Table Quantization for Cross-Attention in Text-to-Image Diffusion Models**
> Prince Clement Addo, Oliver Kufuor Boansi, Martin Konadu Boamah, Rosemond Asianoa, Samuel Kofi Akpatsa, Samuel Adu-Gyimah

Post-training quantization lets text-to-image diffusion models run on constrained hardware, but the cross-attention score quantizers in use rely on fixed logarithmic or uniform grids, which match the skewed, layer-dependent distribution of post-softmax scores poorly. **LUT-Quant** replaces the logarithmic score quantizer of [DGQ](https://github.com/ugonfor/DGQ) with a **per-layer 256-level look-up table** whose levels are fitted by **Lloyd's algorithm** to profiled scores. Everything else in DGQ's W8A8 pipeline stays as it is, so LUT-Quant and DGQ differ in the cross-attention score quantizer alone.

Every number in the paper is produced by the tools of this repository as a JSON record, and every table is rendered from those records by `lutq-report`. In its publication mode the report requires a valid record for every table cell, refuses incomplete or inconsistent runs, and requires every value printed in the paper to be reproduced; the release script builds nothing unless that check passes.

---

## Contents

1. [Method](#1-method)
2. [Repository structure](#2-repository-structure)
3. [Requirements](#3-requirements)
4. [Installation](#4-installation)
5. [Model weights](#5-model-weights)
6. [Datasets and prompt protocols](#6-datasets-and-prompt-protocols)
7. [Reproducing the paper](#7-reproducing-the-paper)
8. [Experimental protocol](#8-experimental-protocol)
9. [Metrics](#9-metrics)
10. [Latency, memory and calibration cost](#10-latency-memory-and-calibration-cost)
11. [Records, validation and the tables of the paper](#11-records-validation-and-the-tables-of-the-paper)
12. [Reproducibility and determinism](#12-reproducibility-and-determinism)
13. [Notebook](#13-notebook)
14. [Tests and continuous integration](#14-tests-and-continuous-integration)
15. [Troubleshooting](#15-troubleshooting)
16. [Citation](#16-citation)
17. [Licence and acknowledgements](#17-licence-and-acknowledgements)

---

## 1. Method

For each of the 16 cross-attention layers *l* (the `attn2` modules of the SD v1.4 U-Net), following Algorithm 1 of the paper:

```
Phase 1 - offline attention-score profiling (FP16 model, N_cal captions, 25 DDIM steps)
  A   <- post-softmax cross-attention probabilities (padding mask applied inside the softmax)
  a   <- A[:, 1:] / max(A[:, 1:])                  drop the <start> column, normalize (float32)
  S_l <- S_l ∪ sample(a)                            2,000 scores per attention call (seeded)

Phase 2 - per-layer codebook construction (float64)
  S_l <- 200,000 scores of S_l, drawn without replacement (seeded)
  C_l <- L = 256 levels spaced uniformly on [0, max S_l]
  repeat 50 times:
      assign every score to its nearest level
      move every level to the mean of its scores     (a level with no scores keeps its position)

Phase 3 - inference, per layer and per call
  s          <- max(A[:, 1:])                       dynamic per-call scale
  e_l        <- midpoints(C_l)                      bin edges
  idx        <- bucketize(A[:, 1:] / s, e_l)        nearest level
  Â[:, 1:]   <- C_l[idx] · s                        dequantize
  Â[:, 0]    <- A[:, 0]                             <start> kept in full precision
  O          <- Â V
```

Every fit records the empty cells, zero-width bins (coincident levels), finiteness and the first iteration at which the relative codebook change fell below 10⁻⁴.

**Variants (Table VI).** `standard` (one table per cross-attention layer), `tsadaptive` (one table per layer and denoising phase: steps 0–8, 9–16, 17–24 of the 25 DDIM steps; the phase is read from the timestep the U-Net receives) and `selfcross` (tables on the self-attention `attn1` layers as well, every column quantized). The score precision is varied with `--levels` / `--score-levels` (256, 64 and 16 levels).

**Placement rules (Table III).** From the same profiled scores: ACIQ analytic clipping, histogram / percentile range selection (99.9th percentile), a learned parametric log scale (levels 2<sup>−βn</sup> with β fitted to the MSE), the Lloyd codebook, and DGQ's log₂ quantizer. The first four are applied exactly like LUT-Quant, so they differ in the placement of the levels alone.

**Precision and storage.** The probabilities arrive in the dtype of the model (FP16 on a GPU). Normalization, bucketization and dequantization run in float32 and the result is cast back to the model dtype before it multiplies *V*. A 256-level table of float32 levels occupies 1 KiB, 16 KiB for the 16 layers; the 255 float32 bin edges of each table add 1,020 bytes at run time. `torch.bucketize` returns int64 indices that are dequantized at once: the implementation simulates 8-bit scores (256 representable values per call) and does not store packed 8-bit attention maps.

| Component | Code |
|---|---|
| Lloyd fitting, codebook statistics | [`src/lutq/codebook.py`](src/lutq/codebook.py) |
| Placement rules of Table III | [`src/lutq/quantizers.py`](src/lutq/quantizers.py) |
| Attention processors, step tracking, error measurement | [`src/lutq/attention.py`](src/lutq/attention.py) |
| LUT-Quant inside DGQ's quantized U-Net | [`src/lutq/integrations/dgq.py`](src/lutq/integrations/dgq.py) |

---

## 2. Repository structure

```
LUT-Quant/
├── src/lutq/
│   ├── codebook.py          Lloyd fitting (uniform start, 50 iterations), codebook statistics and I/O
│   ├── quantizers.py        ACIQ, histogram, learned log, Lloyd, DGQ log2
│   ├── attention.py         score-quantizing attention processors, phases, error measurement
│   ├── profiling.py         calibration score sampler, quantization-error log
│   ├── pipeline.py          SD v1.4 loading, methods on the DGQ back-end, seeded generation, timing
│   ├── integrations/dgq.py  DGQ back-end: configuration, pinned weights, LUT installation
│   ├── models.py            SD v1.4 at a locked Hugging Face revision
│   ├── data.py              prompt protocols, locked dataset sources, FID reference
│   ├── locks.py             lock files of models and datasets (locks/*.json)
│   ├── metrics.py           FID, IS, CLIP, LPIPS, PSNR, CMMD, paired bootstrap
│   ├── stats.py             Welch and paired t, ranks, Kendall's W, bootstrap
│   ├── records.py           run records, provenance, the validated results ledger
│   ├── report.py            Tables I–VIII and S1–S3, comparison with the paper
│   ├── figures.py           Figures 1–9
│   ├── bundle.py            record archive with a SHA-256 manifest
│   └── cli.py               the lutq-* command-line tools
├── baselines/
│   ├── common.py            image protocol shared by the baseline generators; shard merging
│   ├── qdiffusion/run.py    Q-Diffusion calibration and generation (official code base)
│   └── tfmqdm/run.py        TFMQ-DM calibration and generation (official code base)
├── scripts/
│   ├── fetch_models.py      SD v1.4 (diffusers) and sd-v1-4.ckpt, locked
│   ├── fetch_data.py        prompt lists of every protocol (+ SHA256SUMS), FID reference, verification
│   ├── setup_dgq.sh         DGQ at the pinned commit + its environment
│   ├── dgq_env.sh           puts DGQ on PYTHONPATH
│   ├── dgq_quantize.sh      merged DGQ checkpoint (W, A, calibration captions) with its record and timings
│   ├── setup_baselines.sh   Q-Diffusion and TFMQ-DM at pinned commits + their environments
│   ├── run_baselines.sh     baseline images of one protocol
│   ├── run_experiments.sh   one sub-command per table of the paper
│   └── make_release.sh      release assets of a paper version
├── paper/reported_values.json   the values printed in Tables I–VIII (for the comparison)
├── notebooks/lutquant_walkthrough.ipynb
├── tests/                   pytest suite (CPU, no downloads); DGQ tests run against DGQ's own modules
├── envs/                    conda environments: DGQ, Q-Diffusion, TFMQ-DM
├── requirements.txt         main environment, every package pinned
├── requirements-lock.txt    main environment, fully resolved (Linux x86_64, Python 3.11)
├── pyproject.toml           package metadata and the lutq-* entry points
├── CITATION.cff  LICENSE  Makefile
└── .github/workflows/tests.yml
```

Created at run time (not tracked, except `locks/`): `data/` (datasets and prompt lists), `locks/` (resolved revisions; committed with the paper version), `checkpoints/` (DGQ and baseline checkpoints, `sd-v1-4.ckpt` link), `third_party/` (DGQ, Q-Diffusion, TFMQ-DM), `outputs/baselines/`, `runs/` (images and records), `release/`.

| Tool | Purpose | Environment |
|---|---|---|
| `lutq-calibrate` | profile scores; fit the look-up tables of one or more placement rules | main |
| `lutq-generate` | images of a protocol with one method | DGQ |
| `lutq-latency` | latency per image, peak memory, optional CUDA kernel profile (Table II) | DGQ |
| `lutq-eval` | FID, IS, CLIP; LPIPS and PSNR against full precision | main |
| `lutq-shift` | FID and CMMD to full precision with paired bootstrap, CLIP (Table IV) | main |
| `lutq-intrinsic` | quantization MSE per layer and phase at the normalized scale (Table V) | main |
| `lutq-digest` | compare the image digests of two runs; import baseline images | any |
| `lutq-report` | validated ledger, Tables I–VIII and S1–S3, comparison with the paper | any |
| `lutq-figures` | Figures 1–9 | main |
| `lutq-bundle` | record archive with a SHA-256 manifest; verification | any |

---

## 3. Requirements

| | Minimum | Used for the paper |
|---|---|---|
| GPU | CUDA GPU with ≥ 16 GB for generation; more for DGQ's and the baselines' weight reconstruction | one NVIDIA A100-SXM4-80GB |
| System | Linux x86_64, conda, git, ≈ 30 GB for weights and data | |
| Storage for images | roughly 10–15 GB per 30,000-image run at 512 px (PNG) | |
| Accounts | a Hugging Face account that has accepted the SD v1.4 licence | |

The test suite and most of the notebook run on a CPU.

| Environment | Used for | Stack | File |
|---|---|---|---|
| **main** | downloads, profiling and look-up tables, Table V, all metrics, report, figures, notebook, tests | Python 3.9–3.11, PyTorch 2.4.0, diffusers 0.27.0 | [`requirements.txt`](requirements.txt), [`requirements-lock.txt`](requirements-lock.txt) |
| **DGQ** (`lutq-dgq`) | every generated image of FP16, DGQ and the look-up-table methods, every latency, DGQ checkpoints | Python 3.9, PyTorch 2.2.2 (CUDA 11.8), DGQ's fork of diffusers 0.26 | [`envs/environment-dgq.yml`](envs/environment-dgq.yml) |
| **Q-Diffusion** (`lutq-qdiff`) | Q-Diffusion calibration and images | Python 3.8, PyTorch 1.13.1 (CUDA 11.7), CompVis `ldm` | [`envs/environment-qdiffusion.yml`](envs/environment-qdiffusion.yml) |
| **TFMQ-DM** (`lutq-tfmq`) | TFMQ-DM calibration and images | Python 3.8, PyTorch 1.13.1 (CUDA 11.7), CompVis `ldm` | [`envs/environment-tfmqdm.yml`](envs/environment-tfmqdm.yml) |

DGQ's quantized U-Net is a rewritten module tree that runs only with DGQ's own fork of diffusers, whose attention modules expose no processor interface; score profiling therefore uses the standard diffusers pipeline of the main environment. All images of FP16, DGQ and the look-up-table methods go through DGQ's pipeline, so these methods differ only in their quantizers and the three latencies of Table II share one software stack. Every package of every environment is pinned; `runs/env/` keeps the `pip freeze` of every machine that ran an experiment.

---

## 4. Installation

From the root of the repository:

```bash
# main environment
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # or requirements-lock.txt for the fully resolved set
pip install -e . --no-deps                 # registers the lutq-* tools

# DGQ environment: clones DGQ at the pinned commit into third_party/DGQ, creates "lutq-dgq"
scripts/setup_dgq.sh
conda activate lutq-dgq && source scripts/dgq_env.sh

# baseline environments: clones Q-Diffusion and TFMQ-DM at pinned commits, creates "lutq-qdiff", "lutq-tfmq"
scripts/setup_baselines.sh
```

`pip install -e .` alone installs the NumPy/SciPy core (codebooks, placement rules, statistics, records, report). On Linux, `torch==2.4.0` from PyPI is the CUDA 12.1 build; for another CUDA version or a CPU-only machine install `torch` and `torchvision` from `https://download.pytorch.org/whl/<cu118|cpu>` first.

| Code base | Repository | Commit |
|---|---|---|
| DGQ (Ryu, Park and Shim, ICLR 2025) | [ugonfor/DGQ](https://github.com/ugonfor/DGQ) | `f449f6ad8052105c72e0bdf5a1cd05bbb98ae037` |
| Q-Diffusion (Li et al., ICCV 2023) | [Xiuyu-Li/q-diffusion](https://github.com/Xiuyu-Li/q-diffusion) | `715783da70baa267321d6700ceb8941400c309d1` |
| TFMQ-DM (Huang et al., CVPR 2024) | [ModelTC/TFMQ-DM](https://github.com/ModelTC/TFMQ-DM) | `66c2d61a4f4cb0df2b56a9f82a276f04f1e84a9b` |
| taming-transformers (baseline environments) | [CompVis/taming-transformers](https://github.com/CompVis/taming-transformers) | `3ba01b241669f5ade541ce990f7650a3b8f65318` |
| CLIP (baseline environments) | [openai/CLIP](https://github.com/openai/CLIP) | `d05afc436d78f1c48dc0dbf8e5980a9d471f35f6` |

---

## 5. Model weights

| Model | Source | Format | Used by | Licence |
|---|---|---|---|---|
| Stable Diffusion v1.4 | [CompVis/stable-diffusion-v1-4](https://huggingface.co/CompVis/stable-diffusion-v1-4) | diffusers (safetensors) | profiling, FP16 / DGQ / look-up-table generation, notebook | [CreativeML OpenRAIL-M](https://huggingface.co/spaces/CompVis/stable-diffusion-license) |
| Stable Diffusion v1.4 | [CompVis/stable-diffusion-v-1-4-original](https://huggingface.co/CompVis/stable-diffusion-v-1-4-original) | `sd-v1-4.ckpt` | Q-Diffusion, TFMQ-DM | CreativeML OpenRAIL-M |
| Inception-v3 (FID) | clean-fid (`legacy_pytorch`, pytorch-fid weights) | | FID | Apache 2.0 |
| Inception-v3 (IS) | torch-fidelity (`inception-v3-compat`) | | IS | Apache 2.0 |
| CLIP ViT-L/14, ViT-L/14@336px | open_clip, `pretrained="openai"` | | CLIP score, CMMD | MIT |
| AlexNet LPIPS v0.1 | lpips 0.1.4 | | LPIPS | BSD-2-Clause |

```bash
huggingface-cli login                       # account that has accepted the SD v1.4 licence
python scripts/fetch_models.py --original   # SD v1.4 snapshot, and sd-v1-4.ckpt -> checkpoints/sd/
```

The first download writes the Hugging Face commit and the SHA-256 of every file the pipelines load (configurations, tokenizer and weights) to `locks/models.json`; every later load recomputes these digests and stops on any difference (`sd-v1-4.ckpt` likewise). DGQ's rewritten copy of SD v1.4 (`third_party/DGQ/pretrained/stable-diffusion-v1-4`) is built from the locked snapshot with DGQ's own conversion and carries the commit it was built from. The metric networks are fetched by their packages from fixed URLs at the pinned package versions.

---

## 6. Datasets and prompt protocols

| Dataset | Content | Used for | Source | Licence |
|---|---|---|---|---|
| MS-COCO 2014 captions | captions of the 40,504 val2014 images (5 per image); the first caption per image is used | calibration captions | [cocodataset.org](https://cocodataset.org/#download) · [annotations_trainval2014.zip](http://images.cocodataset.org/annotations/annotations_trainval2014.zip) (241 MB) | CC BY 4.0 |
| MS-COCO 30K caption list | 30,000 (val2014 image, caption) pairs: the evaluation benchmark of DGQ and BK-SDM | evaluation prompts | [metadata.csv](https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/data/mscoco_val2014_30k/metadata.csv) (from DGQ's `scripts/get_mscoco_files.sh`) | as MS-COCO |
| FID reference | Inception statistics of the 40,504 val2014 images resized to 256 px ([val2014.zip](http://images.cocodataset.org/zips/val2014.zip)) | FID | [real_im256.npz](https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/data/mscoco_val2014_41k_full/real_im256.npz) (from DGQ) | as MS-COCO |
| PartiPrompts | 1,632 prompts in 12 categories and 11 challenge aspects | domain shift | [google-research/parti](https://github.com/google-research/parti) at commit `5a65797` · [PartiPrompts.tsv](https://raw.githubusercontent.com/google-research/parti/5a657978134374ce28973948331b319adef164bd/PartiPrompts.tsv) (SHA-256 `fab29e41…40eb`) | Apache 2.0 |
| DiffusionDB | prompts written by users of Stable Diffusion; the metadata of the 2M subset | domain shift | [poloclub/diffusiondb](https://huggingface.co/datasets/poloclub/diffusiondb) · `metadata.parquet` | CC0 1.0 |
| DrawBench | 200 prompts in 11 categories, from the Imagen paper | domain shift | [imagen.research.google](https://imagen.research.google/) · Hugging Face mirror [sayakpaul/drawbench](https://huggingface.co/datasets/sayakpaul/drawbench) | as published by the Imagen authors |

```bash
python scripts/fetch_data.py --reference   # every prompt list, the SHA256SUMS file and the FID reference
python scripts/fetch_data.py --verify      # rebuild every list from its sources and compare
cd data/prompts && sha256sum -c SHA256SUMS
```

Downloads go to `$LUTQ_DATA` (default `data/` of the repository) and lock files to `$LUTQ_LOCKS` (default `locks/` of the repository); both defaults are independent of the working directory, so scripts that run inside a third-party checkout still read the frozen inputs of this repository. The URL or Hugging Face commit and the SHA-256 of every source file are written to `locks/data.json`, and a later download that differs is refused. Every prompt list is written once to `data/prompts/<protocol>.txt` (one prompt per line, whitespace collapsed to single spaces), every record stores the SHA-256 of the list it used, and the lists travel in the record archive of the paper version.

| Protocol | Prompts | Definition | Used in |
|---|---|---|---|
| `coco30k` | 30,000 | the 30K list, in file order | Tables I, VIII |
| `coco10k` | 10,000 | its first 10,000 | Table III, large-N rows of Table VI, Table S2, Figs. 1, 2, 9 |
| `coco1k` | 1,000 | its first 1,000 | Table VII, Figs. 3, 4 |
| `coco200` | 200 | its first 200 | Table VI, Table S3 |
| `coco_calib64` | 64 | seeded sample (seed 0) of the first captions of val2014 images **outside** the 30K list | look-up tables and DGQ / baseline calibration of Tables I–IV, VII |
| `coco_calib4/8/16/32` | 4–32 | the first 4, 8, 16, 32 of `coco_calib64` | Table V (4), Table VI (8 is the ablation reference), Table VIII (4, 8) |
| `parti500` | 500 | seeded sample (seed 42) of PartiPrompts | Table IV |
| `diffusiondb500` | 500 | seeded sample (seed 42) of distinct, non-empty DiffusionDB prompts of ≤ 300 characters | Table IV |
| `drawbench200` | 200 | all DrawBench prompts | Table IV |

The evaluation lists are nested (200 ⊂ 1K ⊂ 10K ⊂ 30K), the calibration lists are nested (4 ⊂ 8 ⊂ … ⊂ 64), and no calibration caption belongs to an evaluated image. The domain-shift look-up tables and DGQ checkpoint are those calibrated on the 64 MS-COCO captions; no recalibration is done on the target prompts (the calibration budget of every Table IV run is printed under the table by `lutq-report`).

---

## 7. Reproducing the paper

The order of the steps, from a clean checkout (the environment of each step in brackets):

```bash
# 0. weights, data, prompt lists                                                   [main]
python scripts/fetch_models.py --original && python scripts/fetch_data.py --reference

# 1. look-up tables of every table (one profile per calibration budget and variant) [main]
scripts/run_experiments.sh calibrate

# 2. DGQ weight/activation checkpoints for 64, 8 and 4 calibration captions          [DGQ]
scripts/dgq_quantize.sh 8 8 64 && scripts/dgq_quantize.sh 8 8 8 && scripts/dgq_quantize.sh 8 8 4

# 3. Q-Diffusion and TFMQ-DM images (calibration on the 64 captions, then generation) [baselines]
for m in qdiffusion tfmqdm; do for p in coco30k coco1k; do scripts/run_baselines.sh $m $p; done; done

# 4. images, then metrics, table by table                                           [DGQ] then [main]
for t in table1 table3 table4 table6 table7 table8 seeds determinism; do EVAL=0 scripts/run_experiments.sh $t; done
scripts/run_experiments.sh table2                                                  # [DGQ]
for t in table1 table3 table4 table6 table7 table8 seeds determinism; do ONLY_EVAL=1 scripts/run_experiments.sh $t; done
scripts/run_experiments.sh table5                                                  # [main]

# 5. validated ledger, tables, comparison with the paper, figures, record archive  [main]
scripts/run_experiments.sh report
```

| Paper | Sub-command | Runs |
|---|---|---|
| — | `calibrate` | one profile of 64 captions → Lloyd, ACIQ, histogram and learned-log tables; Lloyd tables on 4, 8, 16, 32 captions; timestep-adaptive and self + cross tables on 8 captions; 64- and 16-level tables on 8 captions |
| Table I | `table1` | 30K: FP16, DGQ, LUT-Quant (FID with 1,000 bootstrap resamples); Q-Diffusion and TFMQ-DM imported from `outputs/baselines` |
| Table II | `table2` | 5 warm-up and 20 timed images: FP16, DGQ, LUT-Quant, with a CUDA kernel profile |
| Table III | `table3` | 10K: ACIQ, histogram, learned log, Lloyd (LUT-Quant), DGQ, from one profile |
| Table IV | `table4` | PartiPrompts 500, DiffusionDB 500, DrawBench 200: FP16, DGQ, LUT-Quant; FID and CMMD to FP16, CLIP |
| Table V | `table5` | quantization MSE of log₂ and LUT on the 4 calibration captions, per layer and per 5-step phase |
| Table VI | `table6` | 200 prompts: reference (standard, cross-only, 8 captions, 256 levels), timestep-adaptive, self + cross, 4 and 16 captions, 64 and 16 levels; 10K: the three variants; 32-caption stability from the codebook records |
| Table VII | `table7` | 1K: all five methods; LPIPS and PSNR to the FP16 images |
| Table VIII | `table8` | 30K: DGQ and LUT-Quant with 4 and 8 calibration captions (64 comes from `table1`) |
| Table S1 | from the records | calibration cost by stage (Section 10) |
| Table S2 | `seeds` | 10K: DGQ and LUT-Quant with base seeds 1042 and 2042 (42 comes from `table3`) |
| Table S3 | `determinism` | 200 prompts: FP16, DGQ and LUT-Quant generated twice, digests compared |
| all | `report` | strict ledger, Tables I–VIII and S1–S3, comparison with `paper/reported_values.json`, Figures 1–9, record archive |

Environment variables of `scripts/run_experiments.sh`: `RUNS` (default `runs`), `DGQ_CKPTS` (default `checkpoints/dgq`), `BASELINES` (default `outputs/baselines`), and `SHARDS` / `SHARD` to split generation over GPUs:

```bash
for i in 0 1 2 3; do CUDA_VISIBLE_DEVICES=$i SHARDS=4 SHARD=$i EVAL=0 scripts/run_experiments.sh table1 & done; wait
```

A missing look-up table or DGQ checkpoint stops a sub-command (exit code 3); missing baseline images stop `table1` and `table7` (exit code 4). Single runs with the tools directly:

```bash
lutq-calibrate --protocol coco_calib64 --rules lloyd aciq histogram learned_log --out-dir runs/codebooks/L256_c64_standard
lutq-generate  --method lut --protocol coco1k --dgq-ckpt checkpoints/dgq/sd14_w8a8_c64.pth_merged \
               --codebooks runs/codebooks/L256_c64_standard/lloyd.npz --out runs/example/lut
lutq-eval all  --images runs/example/lut/images --protocol coco1k --bootstrap 1000
```

`lutq-generate` refuses inconsistent settings: a table fitted by another rule than the method uses, a table of another variant, a table whose size differs from `--score-levels`, or a checkpoint whose bit-widths differ from `--wbits` / `--abits`. Relative paths are resolved against the directory the tool is started from.

### DGQ checkpoints

All quantized methods except the two baselines use the official DGQ implementation at W8A8: channel-wise weights refined by block reconstruction with learned rounding, DGQ's outlier-preserving group-wise activation quantizer (8 groups) with time-aware ranges, and DGQ's logarithmic, real-time, start-peak score quantizer at 8 bits. LUT-Quant, and each placement rule of Table III, replaces only `attn2.aqtizer_w` of every DGQ transformer block (`lutq.integrations.dgq.install_lut`).

`scripts/dgq_quantize.sh W A N` calibrates DGQ's weights and activations on the first *N* calibration captions and writes `checkpoints/dgq/sd14_w<W>a<A>_c<N>.pth_merged` with a record beside it (bit-widths, captions, DGQ commit, SHA-256, wall-clock seconds of both stages); `lutq-generate` stores that record with every run. In Table VIII both methods use the checkpoint calibrated on *N* captions and LUT-Quant's tables are fitted on the same *N* captions, so the budget holds for the whole pipeline. DGQ's calibration trajectories are sampled with the pipeline's default PNDM scheduler at 25 steps, whose 26 U-Net calls visit the same timesteps (t = 961, 921, …, 1) as the 25-step DDIM sampler used for every image; DGQ's time-aware ranges are indexed by `(1000 − t) // 40`.

### Q-Diffusion and TFMQ-DM

Both baselines run with their official code bases at the pinned commits, in their own environments, at W8A8 with 8-bit post-softmax attention scores, calibrated on the trajectories of the 64 calibration captions under 25-step DDIM sampling:

| | Q-Diffusion (`baselines/qdiffusion/run.py`) | TFMQ-DM (`baselines/tfmqdm/run.py`) |
|---|---|---|
| Calibration | settings of the code base's `scripts/txt2img.py` for SD (`--quant_mode qdiff --quant_act --split --running_stat --cond`): MSE weight quantizers with block reconstruction and learned rounding (20,000 iterations), MSE activation quantizers with running statistics and LSQ refinement (5,000 iterations, lr 4·10⁻⁴, p = 2.4) | settings of the code base's `txt2img.py --cali --use_aq --cond`: temporal information aware reconstruction and finite set calibration, MSE weight quantizers with block reconstruction (20,000 iterations), running-statistics activation ranges, one range set per timestep |
| Calibration set | denoiser inputs (latent, timestep, conditional and unconditional embeddings) at all 25 steps of the 64 captions (`cali_st = 25`, `cali_n = 64`), collected by `collect()` | the code base's own collector over the 64 captions, `interval = 2 × 64` |

Generation follows the protocol of every other row: 25 DDIM steps (η = 0), guidance 7.5, 512 × 512, image *i* starting from the same float32 latent as every other row (seed 42 + *i*), conversion with `round(255·x)`, no watermark and no safety checker. Each run writes `<index:05d>.png` and a `provenance.json` (code base and commit, checkpoint digests, settings, prompt-list digest, environment, the SHA-256 of every image); `lutq-digest hash` imports a folder only when that record matches the protocol, and the images are evaluated with the same metric code as every other row.

---

## 8. Experimental protocol

| Setting | Value |
|---|---|
| Model | Stable Diffusion v1.4 at the locked revision; DDIM, 25 steps, η = 0, classifier-free guidance 7.5, 512 × 512 |
| Precision of the reference ("full precision") | FP16 weights and activations (text encoder, U-Net, VAE); in the quantized pipelines the text encoder and the VAE are FP16 and the U-Net is DGQ's simulated W8A8 model in FP16 |
| Profiling | FP16 model on a GPU (`--dtype fp32` available); scores normalized in float32, stored in float32, Lloyd fit in float64 |
| Score sampling for the fit | 2,000 scores per attention call, drawn uniformly with replacement; then at most 200,000 per layer without replacement |
| Generation seed | image *i* of every run uses the generator seed 42 + *i* (42 is the base seed; Table S2 adds 1042 and 2042) |
| Initial noise | `torch.randn((1, 4, 64, 64), dtype=float32)` from a CUDA generator seeded 42 + *i* (`lutq.pipeline.initial_latents`); the diffusers pipelines cast the draw to their FP16 dtype before the first step, the baseline code bases use it in float32 under autocast, so every method starts image *i* from the same draw |
| Profiling and error-measurement seed | prompt *i* uses seed 0 + *i*; the score subsampling generators are seeded with 0 |
| Bootstrap seed | 0 (1,000 resamples) |
| Safety checker | disabled for every method, as in DGQ's evaluation, so that no image is replaced before the metrics |
| Determinism settings | cuDNN benchmarking and TF32 disabled in every tool |

---

## 9. Metrics

Following DGQ's MS-COCO protocol, FID and IS are computed on 256 × 256 bicubic copies of the generated images (`<run>/im256`); CLIP, LPIPS, PSNR and CMMD use the 512 × 512 images. The 256-px copies are checked against the SHA-256 of their originals on every evaluation: a changed original is resized again and a copy without an original is removed.

| Metric | Implementation |
|---|---|
| FID | Inception-v3 pool features in the pytorch-fid convention (clean-fid, mode `legacy_pytorch`) against DGQ's statistics of the 40,504 val2014 images at 256 px; 95% percentile bootstrap over generated images (1,000 resamples) |
| IS | Inception-v3 of torch-fidelity (unbiased logits), 10 splits with a fixed assignment (image *i* in split *i* mod 10); `is_sd` is the SD over splits; the bootstrap resamples images and recomputes the same 10-split estimate |
| CLIP | mean cosine similarity of open_clip ViT-L/14 (OpenAI weights) image and prompt embeddings |
| LPIPS, PSNR | AlexNet LPIPS (95% bootstrap interval) and PSNR in dB against the FP16 image of the same prompt and seed |
| FID to FP | FID of a method's images against the FP16 images of the same prompts; the bootstrap resamples prompt indices jointly for all sets, so the LUT − DGQ difference keeps its pairing |
| CMMD | the estimator of Jayasumana et al. (CVPR 2024) as implemented in the reference code ([google-research/cmmd](https://github.com/google-research/google-research/tree/master/cmmd)), step by step: square center crop and PIL bicubic resize to 336 × 336 (`io_util._center_crop_and_resize`), scaling to [0, 1], CLIP mean/std normalization (`embedding._clip_preprocess`; its bicubic resize to the same size is the identity), CLIP ViT-L/14@336px image embeddings with the original OpenAI weights, L2-normalized as the reference CLIP model returns them; squared MMD, minimum-variance (V-statistic) estimator, Gaussian RBF kernel σ = 10, ×1000. `tests/test_metrics.py` checks the preprocessing and the estimator against transcriptions of the reference code. Every image is used; the reference drops the images of an incomplete last batch, so the two agree when its batch size divides the number of images |
| Quantization MSE | squared error at the normalized scale *a* = A[:, 1:]/max(A[:, 1:]) of log₂ and LUT on identical full-precision scores, per layer, prompt and step; pooled as the equal-weight mean of the 16 layers |

Every metric reads the images of a run through one validated list: exactly `00000.png` … `<n−1>.png`, with no other image file of any name, extension or letter case in the folder. `lutq-eval` evaluates a folder only when that list is exactly the set of images its generation records name, with the recorded SHA-256, and only with the prompt list the images were generated from (the SHA-256 of the evaluation prompt list is recorded and must equal the generation's); `lutq-shift` applies the same checks to the three runs it compares. Statistics ([`src/lutq/stats.py`](src/lutq/stats.py)): Welch's t test on latency, paired t intervals over seeds, metric ranks, mean rank and Kendall's W (Table III).

---

## 10. Latency, memory and calibration cost

**Latency (Table II).** `lutq-latency` times 20 images after 5 warm-up images, batch size 1, on one GPU. The timed region is text encoding, the 25 DDIM steps with classifier-free guidance and VAE decoding, between two CUDA synchronizations (`output_type="pt"`); conversion to PIL, PNG encoding and hashing are outside it. DGQ's quantized U-Net simulates W8A8 quantization: weights, activations and attention scores are quantized and dequantized in FP16, and every matrix multiplication runs as an FP16 kernel; there are no integer kernels. The latency of the quantized methods therefore measures this simulation, and `--profile` (used by `table2`) writes the CUDA kernel summary (`<method>.kernels.txt`) and a Chrome trace of one image, from which the time spent in each kernel can be read.

**Memory.** The latency record holds the peak GPU memory allocated, the float32 codebook payload (16 KiB for 16 × 256 levels) and the resident size of the tables with their bin edges (31.9 KiB).

**Calibration cost (Table S1).** Wall-clock seconds on one GPU, recorded stage by stage:

| Stage | Timed region | Record |
|---|---|---|
| LUT profiling | 25-step FP16 generation of the calibration captions with score recording, between CUDA synchronizations; model loading excluded (recorded separately as `model_load_seconds`) | `codebook` record, `profile_seconds` |
| Lloyd fitting | 50 Lloyd iterations for each of the 16 codebooks on the 200,000-score populations, on the CPU | `codebook` record, `fit_seconds` |
| DGQ weight calibration | DGQ's calibration-trajectory generation and block reconstruction with learned rounding (`src/quantize_weight.py`) | `dgq_checkpoint` record, `weight_seconds` |
| DGQ activation calibration | group-wise and time-aware activation range calibration (`src/quantize_act.py`) | `dgq_checkpoint` record, `activation_seconds` |

LUT-Quant's tables replace one quantizer of a calibrated DGQ model: its own calibration is the two LUT stages, and the calibration of the complete LUT-Quant W8A8 pipeline is the sum of all four.

---

## 11. Records, validation and the tables of the paper

Every tool writes a self-describing JSON record ([`src/lutq/records.py`](src/lutq/records.py)):

| Record | Written by | Contents |
|---|---|---|
| `codebook` | `lutq-calibrate` → `<rule>.json` | rule, captions, variant, levels; per layer: distortion trajectory, empty cells, zero-width bins, finiteness, stabilization iteration; payload and resident bytes; precision; sampling (scores seen and kept per layer); model-load, profiling and fit seconds; SHA-256 of the table and the score file |
| `dgq_checkpoint` | `scripts/dgq_quantize.sh` → `<checkpoint>.json` | bit-widths, calibration captions, DGQ commit, SHA-256, seconds of both calibration stages |
| `generation` | `lutq-generate` → `generate_<start>.json` | condition, SHA-256 of tables / checkpoint (with its record) / prompt list, precision and execution mode, SHA-256 of **every image** |
| `metrics` | `lutq-eval` → `metrics.json` | FID, IS, CLIP (with intervals), LPIPS, PSNR, digest of the evaluated image set and of the FP16 reference set |
| `domain_shift`, `intrinsic`, `latency`, `digest_comparison` | the matching tools | Table IV, Table V (+ error sample for Fig. 6), Table II (+ kernel profile), Table S3 |

Each record also holds the provenance: command line, git commit of this repository and whether the working tree had uncommitted changes, Python and package versions, CUDA and cuDNN versions, GPU, determinism settings, the locked SD v1.4 commit and UTC time.

**Validation.** `lutq-report` builds a ledger with one row per run and marks a run invalid when

* an image index of the prompt list is missing, duplicated with different digests in overlapping shards, or outside the list;
* the prompt list has another length than the protocol, or runs of one protocol used different prompt lists;
* its shards differ in configuration or input files (look-up tables, DGQ checkpoint, prompt list);
* its metrics were computed on another image set or another number of images, or LPIPS / PSNR against images that are not the FP16 run of the same prompts and seed.

Two valid runs of one condition must have identical images and metrics, and domain-shift and latency records must refer to valid runs.

**Publication check.** In the default strict mode `lutq-report` additionally requires

* a valid record for **every cell** of Tables I–VIII and S1–S3 (an empty or partial run folder fails), and
* with `--expected paper/reported_values.json`, that **every value printed in the paper** is reproduced by its regenerated cell to the printed precision.

Any violation stops the report with a non-zero exit status: `problems.md` lists every missing record, invalid run and mismatch, `comparison.md` lists every printed value against its regenerated cell, and no table is written. `--allow-incomplete` renders the valid runs and lists the rest (a progress view, never used for publication). Printed rows that report the same experimental condition under different labels are all compared with that condition's single run (the `_row` entries of `paper/reported_values.json`), so a table cannot print two different values for one run and pass.

```bash
lutq-report runs --expected paper/reported_values.json   # runs/report/{ledger.csv, ledger.json, tables.md, table*.csv, comparison.md}
lutq-figures runs                                         # runs/report/figures/fig1..fig9
lutq-bundle create runs --out lutq-records.tar.gz --include data/prompts locks checkpoints/dgq
lutq-bundle verify lutq-records.tar.gz
```

Every table cell is selected by configuration (protocol, method, bit-widths, calibration budgets, variant, score levels, seed), never by folder name. `comparison.md` lists every value printed in the paper next to the regenerated cell and marks it `match` when all its numbers agree to the printed precision (textual cells such as "stable" or "Baseline" must be identical).

**Releasing a paper version.** `scripts/make_release.sh v1.0.0` (on a clean, tagged commit) runs the strict report and the comparison and stops if either fails; otherwise it draws the figures, writes the record archive (every record, look-up table, score population, log and environment snapshot, the report, the frozen prompt lists, `locks/` and the DGQ checkpoint records, with a SHA-256 manifest), verifies it, and prints the `gh release create` command that attaches the assets to the GitHub release of that version. The generated images are identified by their digests in the archive.

---

## 12. Reproducibility and determinism

* **Pinned code and environments.** This repository, DGQ, Q-Diffusion, TFMQ-DM, CLIP and taming-transformers at fixed commits; every package of every environment pinned; the resolved main environment in `requirements-lock.txt`; a `pip freeze` of every machine in `runs/env/`.
* **Locked inputs.** Model revisions and weight digests in `locks/models.json`, dataset sources in `locks/data.json`, prompt lists with `SHA256SUMS`, and every input digest in every record.
* **Seeds.** Image *i* uses seed 42 + *i*, so sharded and resumed runs reproduce a single pass.
* **Determinism.** Seeding and disabled cuDNN benchmarking and TF32 remove the known sources of run-to-run variation in these pipelines; bit-identical reruns are not guaranteed across GPU models, drivers or library versions. `scripts/run_experiments.sh determinism` regenerates 200 images of FP16, DGQ and LUT-Quant and records how many PNGs are bit-identical (Table S3); `lutq-digest compare RUN_A RUN_B` checks any two runs image by image.

---

## 13. Notebook

[`notebooks/lutquant_walkthrough.ipynb`](notebooks/lutquant_walkthrough.ipynb) (stored without outputs) goes through the method on SD v1.4: the locked model and prompt lists, profiling of the 16 cross-attention layers and their score statistics, Lloyd fitting and codebook statistics, the placement rules of Table III, bucketization and storage, the quantization error inside the model (Table V), generation with log₂ and LUT score quantization against full precision, and the path from run records to the tables. With `runs/codebooks/L256_c64_standard/scores.npz` from `lutq-calibrate` it uses the exact score populations of the paper's look-up tables. A GPU runs it in a few minutes; `make notebook` executes it headless.

---

## 14. Tests and continuous integration

```bash
pytest                                            # main environment (CPU, no downloads)
source scripts/dgq_env.sh && pytest -m dgq -v     # DGQ environment: tests against DGQ's own modules
```

The suite covers Lloyd fitting (uniform start, 50 iterations, non-increasing distortion, empty cells, zero-width bins); the placement rules and the equivalence of bucketizing with nearest-level assignment; the processors on a small randomly initialized diffusers U-Net (step tracking, the three variants, the Table V measurement, storage accounting, sampling bookkeeping); the metric estimators, including the CMMD preprocessing and estimator against the reference code, the paired FID bootstrap, the freshness of the 256-px copies and the single validated image list every metric reads (extra files, other extensions, non-canonical names, index gaps); the ledger validation (incomplete runs, conflicting shards, mismatched image or prompt-list hashes, different prompt lists, ambiguous conditions, stale domain-shift records, rerun records); the publication check (an empty run folder, a missing table and a value that differs from the paper each fail it; printed rows of one condition are compared with one run); Tables I–VIII and S1–S3, the figures and the record archive; the locks of models and datasets (every model file re-hashed on every use) and their repository-relative locations; that `scripts/make_release.sh` builds nothing when the publication check fails; resolution of relative checkpoint paths before DGQ's loader runs; the experiment plan of `scripts/run_experiments.sh` with the tools replaced by stubs (protocol, method, checkpoint, table and variant of every run, two-pass execution, failure on missing inputs and baselines); and the notebook format. The DGQ tests build DGQ's `QuantBasicTransformerBlock` with the configuration of `load_dgq_pipeline` and check that `log2_quant` equals DGQ's `T2ILogQuantizer`, that LUT-Quant inside DGQ's attention forward receives the scores without the `<start>` column, and the variants.

CI ([`.github/workflows/tests.yml`](.github/workflows/tests.yml)) runs the core suite on Python 3.9–3.11, the full suite in the main environment, the shell-script syntax check, and the DGQ tests against DGQ at the pinned commit.

---

## 15. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| `ImportError: cannot import name 'cached_download'` | huggingface_hub ≥ 0.26 with diffusers 0.27; use the pinned `huggingface_hub==0.25.2` |
| `401` / `GatedRepoError` on the first model download | log in with an account that has accepted the SD v1.4 licence (`huggingface-cli login`) |
| `LockMismatch: ... the lock records ...` | a model or data file differs from the locked revision; restore the locked file or start a new paper version with a new `locks/` |
| `DGQ is not importable` | `conda activate lutq-dgq && source scripts/dgq_env.sh` |
| `.../pretrained/stable-diffusion-v1-4 was not built from SD v1.4 commit ...` | DGQ's copy of the weights comes from another revision; remove the folder, it is rebuilt from the locked snapshot |
| `DGQ checkpoint not found: /abs/path` | the path is resolved against the directory the tool was started from; run `scripts/dgq_quantize.sh` or correct the path |
| `missing runs/codebooks/...` (exit 3) | `scripts/run_experiments.sh calibrate` in the main environment |
| `missing outputs/baselines/...` (exit 4) | `scripts/run_baselines.sh <qdiffusion|tfmqdm> <protocol>` |
| `refusing to evaluate: ... differ from their record` | images were changed or added after generation; regenerate the run |
| `the records cannot produce publication tables` | `runs/report/problems.md` lists every missing record, invalid run and value that differs from the paper; run the missing experiments, remove invalid runs, or correct the paper and `paper/reported_values.json` |
| `refusing to evaluate: the prompt list differs ...` | `--protocol` / `--prompts` names another prompt list than the images were generated from |
| `manifest mismatch` from `lutq-bundle verify` | the archive was modified after it was written; recreate it |

---

## 16. Citation

```bibtex
@article{addo2026lutquant,
  title  = {{LUT-Quant}: Data-Driven Look-Up Table Quantization for Cross-Attention
            in Text-to-Image Diffusion Models},
  author = {Addo, Prince Clement and Boansi, Oliver Kufuor and Boamah, Martin Konadu and
            Asianoa, Rosemond and Akpatsa, Samuel Kofi and Adu-Gyimah, Samuel},
  year   = {2026}
}
```

See also [`CITATION.cff`](CITATION.cff).

---

## 17. Licence and acknowledgements

The code of this repository is released under the [MIT License](LICENSE). Model weights and datasets are subject to their own licences (Sections 5 and 6).

The quantized pipeline uses [DGQ](https://github.com/ugonfor/DGQ) (Ryu, Park and Shim, ICLR 2025) and the baselines use [Q-Diffusion](https://github.com/Xiuyu-Li/q-diffusion) and [TFMQ-DM](https://github.com/ModelTC/TFMQ-DM); all three are cloned at pinned commits and not redistributed here. The MS-COCO 30K list and FID reference statistics are those distributed with DGQ and BK-SDM. Pipelines come from [diffusers](https://github.com/huggingface/diffusers); FID features from [clean-fid](https://github.com/GaParmar/clean-fid); the Inception Score network from [torch-fidelity](https://github.com/toshas/torch-fidelity); CLIP models from [open_clip](https://github.com/mlfoundations/open_clip); LPIPS from [lpips](https://github.com/richzhang/PerceptualSimilarity); the CMMD estimator follows the [reference implementation](https://github.com/google-research/google-research/tree/master/cmmd).
