"""Run records: provenance, file hashes and the results ledger.

Every ``lutq-*`` tool writes one self-describing JSON record next to its
outputs.  A record carries

``kind``        what it describes (``codebook``, ``generation``, ``metrics``,
                ``intrinsic``, ``domain_shift``, ``latency``, ``digest_comparison``);
``config``      the experimental condition (model, protocol, method,
                bit-widths, score levels, calibration budget, variant, seed ...);
``provenance``  the command line, the git commit of this repository (and of the
                DGQ checkout when it was used), package versions, GPU and UTC time;
``inputs``      SHA-256 digests of the files the tool read (codebooks, DGQ
                checkpoint, prompt list);

plus its results.  :func:`build_ledger` walks a run folder, joins the
generation and metric records of every run into one row, validates it
(complete image indices, consistent shards and inputs, metrics computed on
the generated images), and collects every other record by kind;
``lutq-report`` renders the paper's tables from the valid rows of that ledger
and nothing else, and ``lutq-bundle`` packages the records with a SHA-256
manifest for publication.
"""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

SCHEMA = 1
PACKAGES = ("numpy", "scipy", "torch", "torchvision", "diffusers", "transformers", "huggingface_hub",
            "accelerate", "safetensors", "Pillow", "clean-fid", "torch-fidelity", "open_clip_torch", "lpips")


def sha256_file(path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def sha256_text(lines) -> str:
    return hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()


def _git(*args, path=None) -> str:
    try:
        cmd = ["git"] + (["-C", str(path)] if path else []) + list(args)
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return ""


def _git_commit(path=None) -> str:
    return _git("rev-parse", "HEAD", path=path) or "unknown"


def provenance(args=None) -> dict:
    """Command line, code version, environment, hardware and time of a tool invocation.

    Package versions are read from the installed distributions (nothing is
    imported); ``dirty`` is true when the working tree had uncommitted changes.
    """
    from importlib import metadata

    vers = {}
    for dist in PACKAGES:
        try:
            vers[dist] = metadata.version(dist)
        except metadata.PackageNotFoundError:
            pass
    hw = {}
    if "torch" in sys.modules:
        torch = sys.modules["torch"]
        try:
            hw["cuda"] = torch.version.cuda
            hw["cudnn"] = torch.backends.cudnn.version()
            if torch.cuda.is_available():
                hw["gpu"] = torch.cuda.get_device_name(0)
                hw["deterministic"] = {"cudnn_benchmark": torch.backends.cudnn.benchmark,
                                       "tf32_matmul": torch.backends.cuda.matmul.allow_tf32,
                                       "tf32_cudnn": torch.backends.cudnn.allow_tf32}
        except Exception:
            pass
    from . import __version__
    from .models import sd14_identity

    status = _git("status", "--porcelain", "--untracked-files=no")
    return {"argv": sys.argv, "args": vars(args) if args is not None else {}, "lutq": __version__,
            "commit": _git_commit(), "dirty": bool(status), "python": platform.python_version(),
            "platform": platform.platform(), "versions": vers, "gpu": hw.get("gpu", ""), "hardware": hw,
            "model": sd14_identity(), "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}


def write_record(path, kind: str, config: dict, args=None, inputs: dict | None = None, **results) -> Path:
    rec = {"schema": SCHEMA, "kind": kind, "config": config, "provenance": provenance(args),
           "inputs": inputs or {}}
    rec.update(results)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(rec, indent=2, default=float), encoding="utf-8")
    print(f"wrote {path}")
    return path


def read_record(path) -> dict | None:
    try:
        rec = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    return rec if isinstance(rec, dict) and "kind" in rec and "config" in rec else None


# ------------------------------------------------------------------------------ ledger
RUN_KEYS = ("model", "protocol", "method", "wbits", "abits", "score_levels", "wa_calib_prompts",
            "calib_prompts", "variant", "seed")
INPUT_KEYS = ("prompts_sha256", "codebooks", "dgq_ckpt", "checkpoint")


def _input_digest(inputs: dict) -> dict:
    out = {}
    for k, v in (inputs or {}).items():
        out[k] = v.get("sha256") if isinstance(v, dict) else v
    return out


def _expected_count(cfg: dict):
    from .data import PROTOCOLS

    n = cfg.get("n_prompts")
    proto = cfg.get("protocol")
    return n, (PROTOCOLS.get(proto) if proto else None)


def run_row(folder: Path, parts: list, metrics: tuple | None, root: Path) -> dict:
    """Ledger row of one run folder, with every problem that disqualifies it from a publication table.

    ``parts`` holds ``(generation record, relative path)`` for every shard,
    ``metrics`` the ``(metrics record, relative path)`` of the folder or ``None``.
    """
    problems = []
    cfgs = {json.dumps(r["config"], sort_keys=True) for r, _ in parts}
    if len(cfgs) != 1:
        problems.append("shards were generated with different configurations")
    ins = {json.dumps(_input_digest(r.get("inputs", {})), sort_keys=True) for r, _ in parts}
    if len(ins) != 1:
        problems.append("shards read different input files (prompt list, look-up tables or DGQ checkpoint)")
    digests, conflicts = {}, []
    for r, _ in parts:
        start = int(r.get("shard", {}).get("start", 0))
        for i, h in enumerate(r.get("digests", [])):
            j = start + i
            if j in digests and digests[j] != h:
                conflicts.append(j)
            digests.setdefault(j, h)
    if conflicts:
        problems.append(f"overlapping shards disagree on {len(conflicts)} image(s), first index {min(conflicts)}")
    order = sorted(digests)
    cfg = dict(parts[0][0]["config"])
    n_prompts, n_protocol = _expected_count(cfg)
    if n_protocol is not None and n_prompts is not None and n_prompts != n_protocol:
        problems.append(f"prompt list has {n_prompts} prompts, protocol {cfg.get('protocol')} has {n_protocol}")
    expected = n_prompts if n_prompts is not None else n_protocol
    if expected is None:
        problems.append("the number of prompts is not recorded")
    elif order != list(range(expected)):
        missing = expected - len([i for i in order if 0 <= i < expected])
        problems.append(f"{len(order)} of {expected} images recorded" + (f" ({missing} missing)" if missing else "")
                        + ("" if all(0 <= i < expected for i in order) else ", indices outside the prompt list"))
    row = dict(cfg)
    row.update(run=folder.relative_to(root).as_posix(), n_images=len(order),
               contiguous=order == list(range(len(order))),
               image_set_sha256=sha256_text(digests[i] for i in order),
               inputs=_input_digest(parts[0][0].get("inputs", {})),
               files=[rel for _, rel in parts], evaluated=False)
    if metrics is not None:
        mrec, rel = metrics
        m = mrec.get("metrics", {})
        row.update(m)
        row.update(metrics_file=rel, evaluated=True, evaluated_set_sha256=mrec.get("image_set_sha256"),
                   fp_image_set_sha256=m.get("fp_image_set_sha256"))
        if mrec.get("image_set_sha256") != row["image_set_sha256"]:
            problems.append("the evaluated images differ from the generated ones (image-set SHA-256 mismatch)")
        if m.get("n_images") is not None and int(m["n_images"]) != len(order):
            problems.append(f"metrics cover {m['n_images']} images, {len(order)} were generated")
        mproto = mrec.get("config", {}).get("protocol")
        if mproto and cfg.get("protocol") and mproto != cfg["protocol"]:
            problems.append(f"metrics were computed with the prompts of {mproto}, not {cfg['protocol']}")
        mprompts = mrec.get("inputs", {}).get("prompts_sha256")
        if "clip" in m and mprompts != row["inputs"].get("prompts_sha256"):
            problems.append("the CLIP score was computed with another prompt list than the images were generated from")
    row["problems"] = problems
    row["valid"] = not problems
    return row


def build_ledger(root) -> dict:
    """Every record under ``root``: ``{"runs": [...], "<kind>": [...], "problems": [...]}``.

    A run is a folder with generation records (one per shard).  Its row holds
    the generation config, the number of generated images, the digest of the
    whole image set (SHA-256 over the per-image digests in index order), the
    SHA-256 of its inputs, the metrics of the ``metrics.json`` in the same
    folder, and ``problems``: incomplete or non-contiguous image indices,
    overlapping shards that disagree, shards with different configurations or
    inputs, a prompt list whose length differs from the protocol, and metrics
    computed on another image set.  ``problems`` at the top level lists the
    conflicts between runs: runs of one protocol that read different prompt
    lists, and LPIPS / PSNR computed against images other than the
    full-precision run of the same prompts.  A run with a problem has
    ``valid = False`` and never reaches a publication table.
    """
    root = Path(root)
    gens = defaultdict(list)
    other = defaultdict(list)
    metrics = {}
    for f in sorted(root.rglob("*.json")):
        rel_parts = f.relative_to(root).parts
        if "report" in rel_parts or "im256" in rel_parts:
            continue
        rec = read_record(f)
        if rec is None:
            continue
        rel = f.relative_to(root).as_posix()
        if rec["kind"] == "generation" and rec.get("purpose") == "rerun":
            other["rerun"].append({k: v for k, v in rec.items() if k != "digests"} | {"file": rel})
        elif rec["kind"] == "generation":
            gens[f.parent].append((rec, rel))
        elif rec["kind"] == "metrics":
            metrics[f.parent] = (rec, rel)
        else:
            other[rec["kind"]].append(dict(rec, file=rel))
    runs = [run_row(folder, parts, metrics.get(folder), root) for folder, parts in sorted(gens.items())]
    cross = []
    by_proto = defaultdict(set)
    for r in runs:
        if r.get("protocol") and r["inputs"].get("prompts_sha256"):
            by_proto[r["protocol"]].add(r["inputs"]["prompts_sha256"])
    for proto, hashes in sorted(by_proto.items()):
        if len(hashes) > 1:
            cross.append(f"runs of {proto} were generated from {len(hashes)} different prompt lists")
            for r in runs:
                if r.get("protocol") == proto:
                    r["problems"].append(f"{proto} runs disagree on the prompt list")
                    r["valid"] = False
    fp_sets = defaultdict(set)
    for r in runs:
        if r.get("method") == "fp16":
            fp_sets[(r.get("protocol"), r.get("seed"))].add(r["image_set_sha256"])
    for r in runs:
        ref = r.get("fp_image_set_sha256")
        if ref and ref not in fp_sets.get((r.get("protocol"), r.get("seed")), set()):
            r["problems"].append("LPIPS / PSNR were computed against images that are not the full-precision run "
                                 "of the same prompts and seed")
            r["valid"] = False
    out = {"runs": runs, "problems": cross}
    out.update(other)
    return out


def run_summary(folder) -> dict:
    """Ledger row of a single run folder (raises if the folder has no generation record)."""
    folder = Path(folder).resolve()
    parts = []
    for f in sorted(folder.glob("generate_*.json")):
        rec = read_record(f)
        if rec is not None and rec["kind"] == "generation":
            parts.append((rec, f.name))
    if not parts:
        raise FileNotFoundError(f"{folder} holds no generation record (generate_*.json)")
    return run_row(folder, parts, None, folder.parent)


def recorded_digests(folder) -> dict:
    """``{index: sha256}`` of every image recorded by the generation records in ``folder``."""
    ds = {}
    for f in sorted(Path(folder).glob("generate_*.json")):
        rec = read_record(f) or {}
        start = int(rec.get("shard", {}).get("start", 0))
        for i, h in enumerate(rec.get("digests", [])):
            ds[start + i] = h
    return ds


def verify_images(images, run_folder=None) -> tuple[str, int]:
    """Check the image folder of a run against its generation records; return the image-set digest and count.

    The folder must hold exactly the recorded files ``00000.png`` ... with the
    recorded SHA-256 and no other image file of any name, extension or letter
    case (the metric code reads every image file of the folder through
    :func:`lutq.metrics._images`).  Raises ``ValueError`` listing the mismatches.
    """
    from .metrics import IMAGE_SUFFIXES

    images = Path(images)
    run_folder = Path(run_folder) if run_folder else images.resolve().parent
    rec = recorded_digests(run_folder)
    if not rec:
        raise ValueError(f"no generation record in {run_folder}: the images cannot be matched to a run")
    expected = {f"{i:05d}.png": h for i, h in rec.items()}
    present = {p.name: p for p in images.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES}
    missing = sorted(set(expected) - set(present))
    extra = sorted(set(present) - set(expected))
    changed = [n for n in sorted(set(expected) & set(present)) if sha256_file(present[n]) != expected[n]]
    bad = []
    if missing:
        bad.append(f"{len(missing)} recorded image(s) missing, first {missing[0]}")
    if extra:
        bad.append(f"{len(extra)} image file(s) without a record: {', '.join(extra[:5])}")
    if changed:
        bad.append(f"{len(changed)} image(s) differ from their record, first {changed[0]}")
    if sorted(rec) != list(range(len(rec))):
        bad.append("the recorded indices are not 0 .. n-1")
    if bad:
        raise ValueError(f"{images}: " + "; ".join(bad))
    return sha256_text(rec[i] for i in sorted(rec)), len(rec)


def select(rows, **criteria) -> list:
    """Rows whose fields equal every given criterion (``None`` criteria are ignored)."""
    return [r for r in rows if all(v is None or r.get(k) == v for k, v in criteria.items())]


def image_set_digest(folder) -> tuple[str, int]:
    """SHA-256 over the SHA-256 of every PNG in ``folder`` (file-name order) and the count."""
    files = sorted(p for p in Path(folder).iterdir() if p.suffix.lower() == ".png")
    return sha256_text(sha256_file(p) for p in files), len(files)
