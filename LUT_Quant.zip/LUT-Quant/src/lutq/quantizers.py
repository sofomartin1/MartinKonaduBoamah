"""Bin-placement rules for cross-attention scores (Table III and the error analysis).

Every rule acts on the normalized score population of one layer (values in
``[0, 1]``) and returns ``L`` sorted reconstruction levels.  All rules except
``log2`` are applied as look-up tables exactly like LUT-Quant (nearest level,
found by bucketizing against the midpoints), so the controlled comparison of
Table III differs in the placement of the levels alone.

log2         DGQ's logarithmic quantizer: levels ``2**-n``, n = 0 .. L-1, with rounding
             of ``-log2(a)`` (Eq. 2 with the dynamic scale ``max(A[:, 1:])``)
aciq         analytic clipping (ACIQ): uniform levels on ``[0, alpha]``, with alpha
             minimizing the clipping + rounding error of a Laplace model fitted to the scores
histogram    percentile range selection: uniform levels on ``[0, p99.9]``
learned_log  learned parametric log scale: levels ``2**(-beta * n)``, n = 0 .. L-1,
             with the octave step ``beta`` fitted to minimize the MSE
lloyd        the Lloyd codebook of LUT-Quant (``codebook.fit_lloyd``)
"""

from __future__ import annotations

import numpy as np
from scipy import optimize

from .codebook import fit_lloyd, mse, quantize

HISTOGRAM_PERCENTILE = 99.9


def place_log2(x, k):
    return np.sort(float(np.max(x)) * 2.0 ** -np.arange(k, dtype=np.float64))


def place_aciq(x, k):
    a = np.asarray(x, dtype=np.float64)
    b = float(np.mean(np.abs(a - a.mean())))  # Laplace scale by moment matching
    hi = float(a.max())

    def err(alpha):
        return alpha ** 2 / (12.0 * (k - 1) ** 2) + (2.0 * b * b * np.exp(-alpha / b) if b > 0 else 0.0)

    alpha = float(optimize.minimize_scalar(err, bounds=(1e-9, hi), method="bounded").x)
    return np.linspace(0.0, alpha, k)


def place_histogram(x, k, percentile: float = HISTOGRAM_PERCENTILE):
    hi = float(np.percentile(x, percentile)) or float(np.max(x))
    return np.linspace(0.0, hi, k)


def place_learned_log(x, k):
    a = np.asarray(x, dtype=np.float64)
    hi = float(a.max())
    n = np.arange(k, dtype=np.float64)
    res = optimize.minimize_scalar(lambda lb: mse(a, hi * 2.0 ** (-np.exp(lb) * n)),
                                   bounds=(np.log(1e-3), np.log(2.0)), method="bounded")
    return np.sort(hi * 2.0 ** (-float(np.exp(res.x)) * n))


def place_lloyd(x, k):
    return fit_lloyd(x, k=k).levels


RULES = {
    "aciq": place_aciq,
    "histogram": place_histogram,
    "learned_log": place_learned_log,
    "lloyd": place_lloyd,
    "log2": place_log2,
}
LUT_RULES = ("aciq", "histogram", "learned_log", "lloyd")


def levels_for(rule: str, x, k: int = 256) -> np.ndarray:
    if rule not in RULES:
        raise KeyError(f"unknown placement rule {rule!r}; choose from {sorted(RULES)}")
    return np.sort(np.asarray(RULES[rule](x, k), dtype=np.float64))


def log2_quantize(x, k: int = 256) -> np.ndarray:
    """DGQ's logarithmic quantizer on normalized scores (scale = their maximum)."""
    a = np.asarray(x, dtype=np.float64)
    s = float(a.max())
    with np.errstate(divide="ignore"):
        n = np.clip(np.rint(-np.log2(a / s)), 0, k - 1)
    return s * 2.0 ** -n


def apply(rule: str, x, k: int = 256, levels: np.ndarray | None = None) -> np.ndarray:
    """Quantized values of ``x`` under ``rule``."""
    if rule == "log2":
        return log2_quantize(x, k)
    return quantize(x, levels_for(rule, x, k) if levels is None else levels)


def quantization_mse(rule: str, x, k: int = 256, levels: np.ndarray | None = None) -> float:
    a = np.asarray(x, dtype=np.float64)
    return float(np.mean((a - apply(rule, a, k, levels)) ** 2))
