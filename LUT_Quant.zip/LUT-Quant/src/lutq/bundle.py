"""Packaging of run records for publication.

``create`` collects, from a run folder,

* look-up tables (``*.npz``) and their fit records, the profiled score populations
  (``scores.npz``) and the error samples of the intrinsic analysis;
* every JSON record (generation records with per-image SHA-256 digests,
  metrics, intrinsic, domain-shift, latency and digest-comparison records);
* run logs (``*.log``) and environment snapshots (``env/*.txt``);
* the report (ledger, tables, figures' data) when ``lutq-report`` has been run;
* further folders given with ``extra`` (the frozen prompt lists, ``locks/``,
  the DGQ checkpoint records), stored under ``extra/<folder name>/``;

but not the generated images, which are identified by their digests.  The
archive contains ``MANIFEST.sha256`` (``sha256sum`` format), so it can be
checked with ``lutq-bundle verify`` or, after unpacking, ``sha256sum -c``.
"""

from __future__ import annotations

import hashlib
import io
import tarfile
from pathlib import Path

from .records import sha256_file

SUFFIXES = {".json", ".npz", ".log", ".txt", ".csv", ".md", ".jsonl"}


def collect(root, include_scores: bool = True) -> list:
    root = Path(root)
    out = []
    for f in sorted(root.rglob("*")):
        if not f.is_file() or f.suffix not in SUFFIXES:
            continue
        rel = f.relative_to(root)
        if "images" in rel.parts or "im256" in rel.parts or rel.name.endswith(".tar.gz"):
            continue
        if not include_scores and f.name == "scores.npz":
            continue
        out.append(rel)
    return out


def create(root, out, include_scores: bool = True, extra=()) -> tuple:
    root, out = Path(root), Path(out)
    files = [(root / rel, rel.as_posix()) for rel in collect(root, include_scores)]
    for folder in extra:
        folder = Path(folder)
        if not folder.is_dir():
            raise FileNotFoundError(f"{folder} does not exist")
        for f in sorted(folder.rglob("*")):
            if f.is_file() and f.suffix in SUFFIXES | {""} and f.suffix != ".part":
                files.append((f, f"extra/{folder.name}/{f.relative_to(folder).as_posix()}"))
    if not files:
        raise FileNotFoundError(f"no records under {root}")
    prefix = out.name.split(".tar")[0]
    manifest = "".join(f"{sha256_file(src)}  {name}\n" for src, name in files)
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, "w:gz") as tar:
        for src, name in files:
            tar.add(src, arcname=f"{prefix}/{name}")
        data = manifest.encode()
        info = tarfile.TarInfo(f"{prefix}/MANIFEST.sha256")
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
    return out, len(files)


def verify(archive) -> list:
    """Names of the files whose digest differs from the manifest (empty list = all match)."""
    bad = []
    with tarfile.open(archive, "r:gz") as tar:
        members = {m.name: m for m in tar.getmembers() if m.isfile()}
        man = [n for n in members if n.endswith("/MANIFEST.sha256")]
        if len(man) != 1:
            return ["MANIFEST.sha256 missing"]
        prefix = man[0][: -len("MANIFEST.sha256")]
        listed = set()
        for line in tar.extractfile(members[man[0]]).read().decode().splitlines():
            digest, name = line.split(maxsplit=1)
            listed.add(prefix + name)
            m = members.get(prefix + name)
            if m is None or hashlib.sha256(tar.extractfile(m).read()).hexdigest() != digest:
                bad.append(name)
        bad += [n[len(prefix):] + " (not in manifest)" for n in members if n not in listed and n != man[0]]
    return bad
