"""Collection of normalized attention scores and of per-call score-quantization error.

``ScoreProfiler`` keeps, per layer (or per layer and phase), a seeded random
subsample of the normalized scores of every processor call (2,000 per call by
default, drawn uniformly with replacement), so that the calibration
population is reproducible and bounded in memory.  ``lutq-calibrate`` then
draws at most 200,000 scores per layer without replacement for the fit.

``ErrorLog`` accumulates the squared error between the normalized scores and
their quantized values per prompt, layer and denoising step, and keeps a
seeded sample of the signed errors; ``lutq-intrinsic`` reports both (Table V,
Figs. 6 and 7).
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np


class ScoreProfiler:
    """Seeded subsample of ``per_call`` normalized scores from every processor call."""

    def __init__(self, per_call: int = 2000, seed: int = 0):
        import torch

        self.per_call = per_call
        self.gen = torch.Generator(device="cpu").manual_seed(seed)
        self.samples = defaultdict(list)
        self.calls = defaultdict(int)
        self.seen = defaultdict(int)
        self.source_dtypes: set = set()

    def record(self, key: str, a, source_dtype=None) -> None:
        """Keep ``per_call`` scores of one call, drawn uniformly with replacement from all of them."""
        import torch

        if source_dtype is not None:
            self.source_dtypes.add(str(source_dtype).replace("torch.", ""))
        flat = a.detach().reshape(-1).float().cpu()
        self.calls[key] += 1
        self.seen[key] += int(flat.numel())
        if flat.numel() > self.per_call:
            idx = torch.randint(0, flat.numel(), (self.per_call,), generator=self.gen)
            flat = flat[idx]
        self.samples[key].append(flat.numpy())

    def population(self) -> dict:
        return {k: np.concatenate(v) for k, v in self.samples.items()}

    def summary(self) -> dict:
        """Calls, scores seen and scores kept per layer key, and the dtypes the scores arrived in."""
        return {"per_call": self.per_call, "source_dtypes": sorted(self.source_dtypes),
                "layers": {k: {"calls": self.calls[k], "scores_seen": self.seen[k],
                               "scores_kept": int(sum(x.size for x in self.samples[k]))} for k in self.samples}}


class ErrorLog:
    """Sum of squared error and element count per (prompt, layer, step).

    The step of a call is the number of earlier calls of the same layer for
    the same prompt: diffusers and DGQ batch the conditional and unconditional
    branches of classifier-free guidance into one call per denoising step.
    """

    def __init__(self, sample_per_call: int = 256, seed: int = 0):
        import torch

        self.prompt = 0
        self.sse = defaultdict(float)
        self.n = defaultdict(int)
        self._calls = defaultdict(int)
        self.sample_per_call = sample_per_call
        self.gen = torch.Generator(device="cpu").manual_seed(seed)
        self.errors = []

    def set_prompt(self, i: int) -> None:
        self.prompt = i

    def record(self, layer: str, x, q) -> None:
        step = self._calls[(self.prompt, layer)]
        self._calls[(self.prompt, layer)] += 1
        import torch

        d = x.double() - q.double()
        key = (self.prompt, layer, step)
        self.sse[key] += float((d * d).sum())
        self.n[key] += int(d.numel())
        if self.sample_per_call:
            flat = d.reshape(-1).cpu()
            idx = torch.randint(0, flat.numel(), (self.sample_per_call,), generator=self.gen)
            self.errors.append(flat[idx].float().numpy())

    def per_layer(self) -> dict:
        """Pooled MSE per layer, in first-call order."""
        layers = list(dict.fromkeys(k[1] for k in self.sse))
        out = {}
        for layer in layers:
            keys = [k for k in self.sse if k[1] == layer]
            out[layer] = sum(self.sse[k] for k in keys) / sum(self.n[k] for k in keys)
        return out

    def error_sample(self) -> np.ndarray:
        return np.concatenate(self.errors) if self.errors else np.zeros(0)

    def per_phase(self, phases: dict) -> dict:
        """``{phase: [equal-weight mean over layers of the per-layer MSE, per prompt]}``.

        ``phases`` maps a label to the 0-based steps it covers.
        """
        prompts = sorted({k[0] for k in self.sse})
        layers = list(dict.fromkeys(k[1] for k in self.sse))
        out = {}
        for label, steps in phases.items():
            vals = []
            for p in prompts:
                per_layer = []
                for layer in layers:
                    keys = [k for k in self.sse if k[0] == p and k[1] == layer and k[2] in steps]
                    per_layer.append(sum(self.sse[k] for k in keys) / max(1, sum(self.n[k] for k in keys)))
                vals.append(float(np.mean(per_layer)))
            out[label] = vals
        return out

    def per_prompt_layer(self) -> dict:
        """``{layer: [MSE of prompt 0, prompt 1, ...]}``."""
        prompts = sorted({k[0] for k in self.sse})
        out = {}
        for layer in dict.fromkeys(k[1] for k in self.sse):
            vals = []
            for p in prompts:
                keys = [k for k in self.sse if k[0] == p and k[1] == layer]
                vals.append(sum(self.sse[k] for k in keys) / sum(self.n[k] for k in keys))
            out[layer] = vals
        return out
