"""Per-layer Lloyd codebooks for normalized cross-attention scores (Stage 2 of the method).

The score population of one cross-attention layer is the set of normalized
post-softmax probabilities

    a = A[:, 1:] / max(A[:, 1:])            (the <start> column is excluded)

collected over all heads, all denoising steps and all calibration prompts.  An
``L``-level codebook (``L = 256`` for 8-bit scores) is fitted with Lloyd's
algorithm, as in Algorithm 1, line 10:

* initialization: ``L`` levels spaced uniformly on ``[0, max(a)]``;
* assignment:     every score goes to its nearest level;
* update:         every level moves to the mean of the scores assigned to it;
* 50 iterations.

A level to which no score is assigned keeps its position in that iteration
(the centroid of an empty set is undefined), so every level stays finite.
Every fit records how many empty cells occurred, how many levels are empty at
the end, how many bins have zero width (coincident levels), whether all
levels are finite, and the first iteration at which the relative codebook
change ``max|c_t - c_{t-1}| / max|c_{t-1}|`` fell below 1e-4 (``stabilized_at``).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

ITERATIONS = 50
STABLE_TOL = 1e-4


@dataclass
class CodebookFit:
    """Result of one Lloyd fit (see the module docstring for the fields)."""

    levels: np.ndarray
    distortion: float
    trajectory: list = field(default_factory=list)
    iterations: int = 0
    stabilized_at: int | None = None
    empty_events: int = 0
    empty_cells: int = 0
    zero_width_bins: int = 0

    @property
    def finite(self) -> bool:
        return bool(np.all(np.isfinite(self.levels)) and np.isfinite(self.distortion))

    def as_dict(self) -> dict:
        return {
            "levels": int(np.asarray(self.levels).size),
            "distortion": self.distortion,
            "iterations": self.iterations,
            "stabilized_at": self.stabilized_at,
            "empty_events": self.empty_events,
            "empty_cells": self.empty_cells,
            "zero_width_bins": self.zero_width_bins,
            "finite": self.finite,
            "trajectory": [float(v) for v in self.trajectory],
        }


# ----------------------------------------------------------------------------- basics
def uniform_init(x: np.ndarray, k: int) -> np.ndarray:
    """``k`` levels evenly spaced on ``[0, max(x)]``."""
    return np.linspace(0.0, float(np.max(x)), k)


def midpoints(levels: np.ndarray) -> np.ndarray:
    """Bin edges: midpoints of consecutive codebook entries (Algorithm 1, line 13)."""
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    return 0.5 * (lv[1:] + lv[:-1])


def assign(x: np.ndarray, levels: np.ndarray) -> np.ndarray:
    """Index of the nearest level, found by bucketizing against the bin edges."""
    return np.searchsorted(midpoints(levels), np.asarray(x, dtype=np.float64), side="right")


def quantize(x: np.ndarray, levels: np.ndarray) -> np.ndarray:
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    return lv[assign(x, lv)]


def mse(x: np.ndarray, levels: np.ndarray) -> float:
    """Mean squared error of nearest-level quantization."""
    a = np.asarray(x, dtype=np.float64)
    return float(np.mean((a - quantize(a, levels)) ** 2))


def count_empty_cells(x: np.ndarray, levels: np.ndarray) -> int:
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    return int(np.sum(np.bincount(assign(x, lv), minlength=lv.size) == 0))


def count_zero_width_bins(levels: np.ndarray) -> int:
    """Adjacent levels that coincide, i.e. bins of zero width."""
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    return int(np.sum(np.diff(lv) <= 0))


# ------------------------------------------------------------------------------ Lloyd
def fit_lloyd(x: np.ndarray, k: int = 256, iters: int = ITERATIONS) -> CodebookFit:
    """Fit a ``k``-level Lloyd codebook to ``x``: uniform start, ``iters`` iterations."""
    a = np.sort(np.asarray(x, dtype=np.float64))
    levels = uniform_init(a, k)
    traj = [mse(a, levels)]
    empty_events, stabilized = 0, None
    for it in range(1, iters + 1):
        idx = assign(a, levels)
        counts = np.bincount(idx, minlength=k)
        sums = np.bincount(idx, weights=a, minlength=k)
        occ = counts > 0
        empty_events += int(np.sum(~occ))
        new = levels.copy()
        new[occ] = sums[occ] / counts[occ]
        new = np.sort(new)
        denom = float(np.max(np.abs(levels)))
        change = float(np.max(np.abs(new - levels))) / denom if denom > 0 else 0.0
        levels = new
        traj.append(mse(a, levels))
        if stabilized is None and change < STABLE_TOL:
            stabilized = it
    return CodebookFit(levels=levels, distortion=traj[-1], trajectory=traj, iterations=iters,
                       stabilized_at=stabilized, empty_events=empty_events,
                       empty_cells=count_empty_cells(a, levels), zero_width_bins=count_zero_width_bins(levels))


def fit_layers(samples: dict, k: int = 256, iters: int = ITERATIONS) -> dict:
    """One codebook per layer; ``samples`` maps layer key -> 1-D array of normalized scores."""
    return {name: fit_lloyd(x, k=k, iters=iters) for name, x in samples.items()}


# -------------------------------------------------------------------------------- I/O
def save_codebooks(levels: dict, path, meta: dict | None = None) -> None:
    """Write ``{key: levels}`` to ``path`` (.npz, float32: 1 KB per 256-level codebook).

    Keys are canonical layer keys (see ``attention.layer_key``); a
    timestep-adaptive file stores one codebook per phase under ``<layer>@<phase>``.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **{k: np.asarray(getattr(v, "levels", v), dtype=np.float32)
                                 for k, v in levels.items()})
    if meta is not None:
        path.with_suffix(".json").write_text(json.dumps(meta, indent=2, default=float), encoding="utf-8")


def load_codebooks(path) -> dict:
    with np.load(path) as z:
        return {k: np.sort(z[k].astype(np.float64)) for k in z.files}


def codebook_levels(books: dict) -> int:
    """The common number of levels of a codebook file (raises if the sizes differ)."""
    sizes = {int(np.asarray(v).size) for v in books.values()}
    if len(sizes) != 1:
        raise ValueError(f"codebooks of different sizes in one file: {sorted(sizes)}")
    return sizes.pop()
