"""Prompt protocols, their sources and the FID reference set.

Every source file is downloaded to ``$LUTQ_DATA`` (default ``<repository>/data``) and its
identity (URL or Hugging Face commit, SHA-256, size) is written to
``locks/data.json`` on first download and checked on every later use
(:mod:`lutq.locks`).  ``scripts/fetch_data.py`` writes the prompt list of every
protocol to ``data/prompts/<protocol>.txt`` with a ``SHA256SUMS`` file; the
lists are packaged in the record archive of the paper version.

Sources
-------
MS-COCO 2014 captions      annotations_trainval2014.zip (captions_val2014.json), CC BY 4.0
                           http://images.cocodataset.org/annotations/annotations_trainval2014.zip
MS-COCO 30K caption list   the 30,000 (image, caption) pairs of val2014 used by DGQ and BK-SDM
                           https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/
                           data/mscoco_val2014_30k/metadata.csv
PartiPrompts               1,632 prompts, google-research/parti at commit 5a65797, Apache 2.0
DiffusionDB                poloclub/diffusiondb, metadata.parquet (2M subset), CC0 1.0
DrawBench                  200 prompts, Hugging Face mirror sayakpaul/drawbench

Protocols
---------
coco30k          the 30K caption list in file order                  Tables I, VIII
coco10k          its first 10,000 captions                           Table III, large-N ablation, seed study
coco1k           its first 1,000 captions                            Table VII
coco200          its first 200 captions                              Table VI, score precision, determinism
coco_calib64     64 calibration captions: seeded sample (seed 0) of the first caption of
                 every val2014 image outside the 30K list            look-up tables and DGQ calibration
coco_calib{4,8,16,32}   the first 4, 8, 16, 32 of those 64           Tables V, VI, VIII
parti500         500 PartiPrompts, seeded sample (seed 42)            Table IV
diffusiondb500   500 distinct DiffusionDB prompts of at most 300 characters,
                 seeded sample (seed 42)                             Table IV
drawbench200     the 200 DrawBench prompts                           Table IV

The evaluation lists are nested (200 in 1K in 10K in 30K), the calibration
lists are nested (4 in 8 in ... in 64), and no calibration caption belongs to
an image of the evaluation lists.  Whitespace inside a prompt is collapsed to
single spaces, so every prompt occupies exactly one line of its list.
"""

from __future__ import annotations

import csv
import hashlib
import json
import random
import re
import zipfile
from pathlib import Path

from . import locks

PARTI_COMMIT = "5a657978134374ce28973948331b319adef164bd"
URLS = {
    "coco_ann": "http://images.cocodataset.org/annotations/annotations_trainval2014.zip",
    "coco30k": "https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/data/"
               "mscoco_val2014_30k/metadata.csv",
    "parti": f"https://raw.githubusercontent.com/google-research/parti/{PARTI_COMMIT}/PartiPrompts.tsv",
    "fid_reference": "https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/data/"
                     "mscoco_val2014_41k_full/real_im256.npz",
}
HF_DATASETS = {
    "diffusiondb": ("poloclub/diffusiondb", "metadata.parquet"),
    "drawbench": ("sayakpaul/drawbench", None),
}
# digests known independently of any download (checked in addition to the lock)
KNOWN_SHA256 = {"parti": "fab29e41bb512a169b56acab4cf2a41dcb675e285df2efcde6640c7dd3c440eb"}

CALIB_SEED = 0
CALIB_POOL = 64
OOD_SEED = 42
DIFFUSIONDB_MAX_CHARS = 300

PROTOCOLS = {
    "coco_calib4": 4, "coco_calib8": 8, "coco_calib16": 16, "coco_calib32": 32, "coco_calib64": 64,
    "coco30k": 30000, "coco10k": 10000, "coco1k": 1000, "coco200": 200,
    "parti500": 500, "diffusiondb500": 500, "drawbench200": 200,
}
OOD = ("parti500", "diffusiondb500", "drawbench200")


def data_root() -> Path:
    """``$LUTQ_DATA``, default ``<repository>/data`` (see :mod:`lutq.paths`)."""
    from .paths import data_root as _data_root

    return _data_root()


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def download(key: str, dest: Path) -> Path:
    """Download ``URLS[key]`` to ``dest`` once and check it against ``locks/data.json``."""
    import requests

    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        with requests.get(URLS[key], stream=True, timeout=60) as r:
            r.raise_for_status()
            tmp = dest.with_suffix(dest.suffix + ".part")
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(1 << 20):
                    f.write(chunk)
            tmp.replace(dest)
    digest = _sha256(dest)
    if key in KNOWN_SHA256 and digest != KNOWN_SHA256[key]:
        raise locks.LockMismatch(f"{dest} has SHA-256 {digest}, expected {KNOWN_SHA256[key]}")
    locks.check_or_write("data", key, {"url": URLS[key], "sha256": digest, "bytes": dest.stat().st_size},
                         compare=("url", "sha256"))
    return dest


def _hf_revision(key: str) -> str:
    return (locks.entry("data", key) or {}).get("commit") or "main"


def _image_id(file_name: str) -> int:
    m = re.search(r"(\d+)(?:\.\w+)?$", file_name)
    if not m:
        raise ValueError(f"cannot read an image id from {file_name!r}")
    return int(m.group(1))


def clean(prompt: str) -> str:
    return " ".join(str(prompt).split())


# --------------------------------------------------------------------------- sources
def coco30k_pairs() -> list:
    """(image_id, caption) pairs of the 30K benchmark list, in file order."""
    p = download("coco30k", data_root() / "coco" / "mscoco_val2014_30k_metadata.csv")
    with open(p, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    header, rows = rows[0], rows[1:]
    fi = header.index("file_name") if "file_name" in header else 0
    ti = header.index("text") if "text" in header else 1
    return [(_image_id(r[fi]), r[ti].strip()) for r in rows]


def coco_captions() -> list:
    """(image_id, caption) of MS-COCO val2014: the first caption (lowest annotation id) of every image."""
    z = download("coco_ann", data_root() / "coco" / "annotations_trainval2014.zip")
    with zipfile.ZipFile(z) as zf:
        ann = json.loads(zf.read("annotations/captions_val2014.json"))
    first = {}
    for a in sorted(ann["annotations"], key=lambda a: a["id"]):
        first.setdefault(a["image_id"], a["caption"].strip().replace("\n", " "))
    return sorted(first.items())


def parti_prompts() -> list:
    p = download("parti", data_root() / "parti" / "PartiPrompts.tsv")
    with open(p, newline="", encoding="utf-8") as f:
        return [row["Prompt"].strip() for row in csv.DictReader(f, delimiter="\t")]


def diffusiondb_prompts() -> list:
    """Distinct, non-empty DiffusionDB prompts of at most 300 characters, sorted."""
    import pandas as pd
    from huggingface_hub import hf_hub_download

    repo, name = HF_DATASETS["diffusiondb"]
    p = Path(hf_hub_download(repo, name, repo_type="dataset", revision=_hf_revision("diffusiondb")))
    locks.check_or_write("data", "diffusiondb", {"repo": repo, "file": name, "commit": p.parent.name,
                                                 "sha256": _sha256(p)}, compare=("repo", "commit", "sha256"))
    s = pd.read_parquet(p, columns=["prompt"])["prompt"].dropna().astype(str).map(clean)
    s = s[(s.str.len() > 0) & (s.str.len() <= DIFFUSIONDB_MAX_CHARS)].drop_duplicates()
    return sorted(s.tolist())


def drawbench_prompts() -> list:
    from datasets import load_dataset
    from huggingface_hub import HfApi

    repo, _ = HF_DATASETS["drawbench"]
    commit = HfApi().dataset_info(repo, revision=_hf_revision("drawbench")).sha
    locks.check_or_write("data", "drawbench", {"repo": repo, "commit": commit}, compare=("repo", "commit"))
    ds = load_dataset(repo, split="train", revision=commit)
    col = "Prompts" if "Prompts" in ds.column_names else ds.column_names[0]
    return [str(p).strip() for p in ds[col]]


def calibration_captions(eval_ids: set, pairs: list, n: int = CALIB_POOL, seed: int = CALIB_SEED) -> list:
    """Seeded sample of ``n`` captions of images outside ``eval_ids``."""
    pool = [c for i, c in pairs if i not in eval_ids]
    return random.Random(seed).sample(pool, n)


def sample(protocol: str) -> list:
    """The prompt list of a protocol, built from its sources (deterministic)."""
    if protocol not in PROTOCOLS:
        raise KeyError(f"unknown protocol {protocol!r}; choose from {sorted(PROTOCOLS)}")
    n = PROTOCOLS[protocol]
    if protocol in OOD:
        pool = {"parti500": parti_prompts, "diffusiondb500": diffusiondb_prompts,
                "drawbench200": drawbench_prompts}[protocol]()
        out = list(pool) if n >= len(pool) else random.Random(OOD_SEED).sample(pool, n)
    else:
        pairs30k = coco30k_pairs()
        if protocol.startswith("coco_calib"):
            out = calibration_captions({i for i, _ in pairs30k}, coco_captions())[:n]
        else:
            out = [c for _, c in pairs30k[:n]]
    out = [clean(p) for p in out]
    if len(out) != n:
        raise ValueError(f"{protocol}: {len(out)} prompts, expected {n}")
    return out


def prompt_file(protocol: str) -> Path:
    return data_root() / "prompts" / f"{protocol}.txt"


def prompts_for(protocol: str) -> list:
    """The prompt list of a protocol: ``data/prompts/<protocol>.txt`` when fetched, else built from its sources."""
    local = prompt_file(protocol)
    prompts = read_prompts(local) if local.exists() else sample(protocol)
    if protocol in PROTOCOLS and len(prompts) != PROTOCOLS[protocol]:
        raise ValueError(f"{local}: {len(prompts)} prompts, protocol {protocol} has {PROTOCOLS[protocol]}")
    return prompts


def read_prompts(path) -> list:
    with open(path, encoding="utf-8") as f:
        return [ln.rstrip("\n") for ln in f if ln.strip()]


def write_prompts(prompts, path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(clean(p) for p in prompts) + "\n")
