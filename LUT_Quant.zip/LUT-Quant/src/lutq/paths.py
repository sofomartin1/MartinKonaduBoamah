"""Default locations of the downloaded data and the lock files.

``data/`` and ``locks/`` belong to the repository, not to the directory a tool
is started from: with the package installed from a checkout (``pip install -e .``)
they resolve to ``<repository>/data`` and ``<repository>/locks`` whatever the
working directory, so code that changes directory (DGQ's scripts must run
inside the DGQ checkout) still reads the frozen inputs of the release.
``$LUTQ_DATA`` and ``$LUTQ_LOCKS`` override them.
"""

from __future__ import annotations

import os
from pathlib import Path


def repo_root() -> Path:
    """The repository of this package when installed from a checkout, else the working directory."""
    here = Path(__file__).resolve().parents[2]
    return here if (here / "pyproject.toml").is_file() and (here / "src" / "lutq").is_dir() else Path.cwd()


def data_root() -> Path:
    return Path(os.environ.get("LUTQ_DATA") or repo_root() / "data").resolve()


def lock_dir() -> Path:
    return Path(os.environ.get("LUTQ_LOCKS") or repo_root() / "locks").resolve()
