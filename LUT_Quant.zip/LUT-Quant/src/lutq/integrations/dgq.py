"""LUT-Quant inside the official DGQ quantized U-Net.

DGQ (Ryu, Park and Shim, ICLR 2025; https://github.com/ugonfor/DGQ) quantizes
the weights and activations of Stable Diffusion v1.4 (outlier-preserving
group-wise activations) and applies its own logarithmic quantizer to the
post-softmax attention probabilities.  In DGQ's rewritten attention forward
the probabilities pass through ``aqtizer_w``; for cross-attention (``attn2``)
the ``<start>`` column is split off first (``t2i_start_peak``), so only
``A[..., 1:]`` reaches the quantizer.

LUT-Quant keeps every DGQ quantizer (weights, activations, queries, keys,
values, self-attention probabilities) and replaces ``attn2.aqtizer_w`` with
:class:`LUTScoreQuantizer`, which applies the per-layer codebook by
bucketizing against its midpoints.  The two methods therefore differ in the
cross-attention score quantizer alone.  The placement rules of Table III are
installed the same way, each with its own levels.

Score precision
---------------
DGQ's own scripts tie the precision of the score quantizer to the activation
bit-width (``softmax_a_bit = a_bits``).  Here it is set by ``score_levels``
(``softmax_a_bit = log2(score_levels)``, 256 levels = 8 bits) and applies to
both methods; at W8A8 the two coincide.  DGQ's score quantizer is the
real-time ``T2ILogQuantizer`` (scale = per-call maximum), so its precision
carries no calibrated state.

Environment
-----------
DGQ pins its own software stack (Python 3.9, PyTorch 2.2.2, a fork of
diffusers 0.26); ``envs/environment-dgq.yml`` and ``scripts/setup_dgq.sh``
create it and clone DGQ at :data:`DGQ_COMMIT`.  ``scripts/dgq_quantize.sh``
makes the merged weight + activation checkpoints.

Usage::

    from lutq.codebook import load_codebooks
    from lutq.integrations import dgq

    pipe = dgq.load_dgq_pipeline("checkpoints/dgq/sd14_w8a8_c64.pth_merged", w_bits=8, a_bits=8)
    dgq.install_lut(pipe.unet, load_codebooks("runs/codebooks/L256_c64_standard/lloyd.npz"))
"""

from __future__ import annotations

import contextlib
import math
import os
import subprocess
from pathlib import Path
from typing import Optional

import numpy as np
import torch

from ..attention import LUT, StepTracker, layer_key, split_codebooks

DGQ_REPO = "https://github.com/ugonfor/DGQ"
DGQ_COMMIT = "f449f6ad8052105c72e0bdf5a1cd05bbb98ae037"
STEPS = 25
PRETRAINED = Path("pretrained") / "stable-diffusion-v1-4"   # relative to the DGQ checkout, as DGQ expects
EXECUTION = ("simulated W{w}A{a} quantization (DGQ QuantModel): quantize-dequantize in FP16, FP16 matrix "
             "multiplications; no integer kernels")


def score_bits(score_levels: int) -> int:
    """``log2(score_levels)``; the level count must be a power of two."""
    b = int(round(math.log2(score_levels)))
    if score_levels < 2 or 2 ** b != score_levels:
        raise ValueError(f"score levels must be a power of two, got {score_levels}")
    return b


def quant_params(w_bits: int = 8, a_bits: int = 8, score_levels: int = 256):
    """DGQ's ``(wq_params, aq_params, softmax_aq_params)`` for one setting.

    The full DGQ configuration: channel-wise min-max weights, min-max
    activations (grouped when the checkpoint holds groups), and the
    logarithmic, real-time, start-peak score quantizer at ``log2(score_levels)`` bits.
    """
    from quant.quant_layer import Scaler

    wq = {"bits": w_bits, "channel_wise": True, "scaler": Scaler.MINMAX}
    aq = {"bits": a_bits, "channel_wise": False, "scaler": Scaler.MINMAX, "leaf_param": True}
    sq = {"softmax_a_bit": score_bits(score_levels), "t2i_log_quant": True, "t2i_real_time": True,
          "t2i_start_peak": True, "log_max_1": False}
    return wq, aq, sq


class LUTScoreQuantizer(torch.nn.Module):
    """Drop-in replacement for DGQ's ``aqtizer_w``.

    Receives the attention probabilities (for ``attn2`` without the
    ``<start>`` column), normalizes them by their maximum, bucketizes them
    against the codebook midpoints, and restores the scale (Algorithm 1,
    lines 12-15).  ``luts`` maps a phase (``None``, or
    ``"early"``/``"mid"``/``"late"`` with a ``tracker``) to a :class:`~lutq.attention.LUT`.
    """

    def __init__(self, name: str, luts: dict, tracker: Optional[StepTracker] = None):
        super().__init__()
        if None not in luts and tracker is None:
            raise ValueError("timestep-adaptive codebooks need a StepTracker")
        self.name, self.luts, self.tracker = name, luts, tracker
        self.level = next(iter(luts.values())).levels.numel()  # read by DGQ's reconstruction code
        self.use_aq = True
        self.running_stat = False

    def forward(self, w: torch.Tensor) -> torch.Tensor:
        lut = self.luts[None] if None in self.luts else self.luts[self.tracker.phase]
        w = w.float()
        s = w.amax().clamp_min(torch.finfo(torch.float32).tiny)
        return lut(w / s) * s

    def extra_repr(self) -> str:
        return f"name={self.name}, levels={self.level}, codebooks={'single' if None in self.luts else '/'.join(self.luts)}"


def attention_blocks(unet) -> dict:
    """Canonical ``attn2`` key -> DGQ ``QuantBasicTransformerBlock``, for every transformer block."""
    out = {}
    for name, module in unet.named_modules():
        attn2 = getattr(module, "attn2", None)
        if attn2 is not None and hasattr(attn2, "aqtizer_w"):
            out[layer_key(f"{name}.attn2")] = module
    return out


def install_lut(unet, codebooks: dict, levels: int = 256, self_attention: bool = False,
                tracker: Optional[StepTracker] = None) -> int:
    """Replace the score quantizers of a DGQ U-Net with look-up tables; return the count replaced.

    ``attn2.aqtizer_w`` of every block is replaced; ``attn1.aqtizer_w`` too
    when ``self_attention`` is set.  Every replaced module needs a codebook of
    ``levels`` levels; a timestep-adaptive file needs ``tracker`` attached to the U-Net.
    """
    blocks = attention_blocks(unet)
    if not blocks:
        raise RuntimeError("no DGQ attention blocks found: is this a DGQ QuantModel?")
    books, phased = split_codebooks(codebooks)
    if phased and tracker is None:
        raise ValueError("timestep-adaptive codebooks need a StepTracker attached to the U-Net")
    targets = []
    for key, block in blocks.items():
        targets.append((key, block.attn2))
        if self_attention:
            targets.append((key[: -len("attn2")] + "attn1", block.attn1))
    missing = [k for k, _ in targets if k not in books]
    if missing:
        raise KeyError(f"no codebook for {len(missing)} of {len(targets)} layers, e.g. {missing[0]}")
    for k, _ in targets:
        if any(np.asarray(v).size != levels for v in books[k].values()):
            raise ValueError(f"codebook of {k} does not have {levels} levels")
    device = next(unet.parameters()).device
    for key, attn in targets:
        attn.aqtizer_w = LUTScoreQuantizer(key, {p: LUT(v, device=device) for p, v in books[key].items()}, tracker)
    return len(targets)


@contextlib.contextmanager
def _cwd(path: Path):
    prev = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev)


def dgq_root() -> Path:
    """The DGQ checkout on ``PYTHONPATH``."""
    try:
        import quant  # DGQ's package
    except ImportError as exc:
        raise ImportError("DGQ is not importable. Run scripts/setup_dgq.sh, activate the DGQ environment and "
                          "source scripts/dgq_env.sh (README, 'Environments').") from exc
    return Path(quant.__file__).resolve().parents[1]


def dgq_commit() -> str:
    try:
        return subprocess.check_output(["git", "-C", str(dgq_root()), "rev-parse", "HEAD"],
                                       stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "unknown"


def resolve_checkpoint(cali_ckpt) -> Path:
    """Absolute path of a DGQ checkpoint, resolved against the caller's working directory."""
    if not cali_ckpt:
        raise ValueError("a quantized pipeline needs the merged DGQ checkpoint")
    path = Path(cali_ckpt).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"DGQ checkpoint not found: {path}")
    return path


def ensure_pretrained(root: Optional[Path] = None) -> Path:
    """DGQ's rewritten SD v1.4 folder (``<DGQ>/pretrained/stable-diffusion-v1-4``) built from the locked snapshot.

    DGQ's ``prepare_pipe`` loads this folder and creates it from the Hub head
    revision when it is missing.  Building it here from the snapshot in
    ``locks/models.json`` (with DGQ's own conversion: the rewritten
    ``UNet2DConditionModel`` receives the state dict of the diffusers U-Net)
    pins the weights of every DGQ run; ``LUTQ_SOURCE.json`` inside the folder
    records the commit, and a folder made from another commit is refused.
    """
    import json

    from ..models import sd14_snapshot

    root = root or dgq_root()
    target = root / PRETRAINED
    snapshot, commit = sd14_snapshot()
    marker = target / "LUTQ_SOURCE.json"
    if target.exists():
        made_from = json.loads(marker.read_text()).get("commit") if marker.exists() else None
        if made_from != commit:
            raise RuntimeError(f"{target} was not built from SD v1.4 commit {commit} (found {made_from}); "
                               "remove the folder and run again")
        return target
    os.environ["DIFFUSERS_REWRITE"] = "sd"
    with _cwd(root):
        from diffusers import StableDiffusionPipeline
        from diffusers_rewrite import UNet2DConditionModel

        pipe = StableDiffusionPipeline.from_pretrained(str(snapshot), safety_checker=None, feature_extractor=None,
                                                       requires_safety_checker=False)
        unet = UNet2DConditionModel()
        unet.load_state_dict(pipe.unet.state_dict())
        pipe.unet = unet
        pipe.save_pretrained(str(PRETRAINED))
    marker.write_text(json.dumps({"repo": "CompVis/stable-diffusion-v1-4", "commit": commit}, indent=2))
    return target


def load_dgq_pipeline(cali_ckpt: Optional[str], w_bits: int = 8, a_bits: int = 8, score_levels: int = 256,
                      *, quantized: bool = True, device: str = "cuda"):
    """SD v1.4 through DGQ's pipeline: quantized with a merged DGQ checkpoint, or FP16 (``quantized=False``).

    Mirrors DGQ's ``src/inference_qmodel.py`` with the full DGQ configuration
    (group-wise activations, time-aware activation ranges, log2 start-peak
    score quantizer); sampling uses 25 DDIM steps.  Call :func:`install_lut`
    on ``pipe.unet`` afterwards to switch the cross-attention score quantizer
    to LUT-Quant.  The text encoder and the VAE run in FP16 in both cases and
    the quantized U-Net is cast to FP16, so the latencies of Table II differ
    in the U-Net alone.

    The checkpoint path is resolved against the caller's working directory
    before DGQ's code runs (DGQ's loader must run inside the DGQ checkout).
    """
    import torch

    ckpt = resolve_checkpoint(cali_ckpt) if quantized else None
    os.environ["DIFFUSERS_REWRITE"] = "sd"  # read by DGQ at import time
    root = dgq_root()
    ensure_pretrained(root)
    with _cwd(root):
        from diffusers import DDIMScheduler
        from utils import prepare_pipe  # DGQ's src/utils.py

        pipe = prepare_pipe("sd", fp16=False)
        # 25 DDIM steps (t = 961, 921, ..., 1); DGQ's time-aware activation
        # ranges are indexed by (1000 - t) // 40, one set per step.
        pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
        if quantized:
            from quant.load_qmodel_util import get_qmodel

            wq, aq, sq = quant_params(w_bits, a_bits, score_levels)
            qnn = get_qmodel("sd", pipe, str(ckpt), wq, True, aq, sq, True,
                             num_inference_steps=STEPS, time_aware_aqtizer=True)
            pipe.unet = qnn.half().to(device)
            pipe.unet.disable_out_quantization()
    pipe.text_encoder.to(device, torch.float16)
    pipe.vae.to(device, torch.float16)
    if not quantized:
        pipe.unet.to(device, torch.float16)
    pipe = pipe.to(device)
    pipe.safety_checker = None
    pipe.requires_safety_checker = False
    pipe.set_progress_bar_config(disable=True)
    return pipe
