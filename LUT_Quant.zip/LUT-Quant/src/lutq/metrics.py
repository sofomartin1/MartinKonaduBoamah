"""Evaluation metrics, following the MS-COCO protocol of DGQ.

Image preparation
    FID and IS are computed on 256 x 256 copies of the generated images
    (PIL bicubic resize, in ``<run>/im256``), as in DGQ's evaluation scripts;
    the copies are validated against the SHA-256 of their originals on every
    evaluation (:func:`resized`); CLIP, LPIPS, PSNR and CMMD use the 512 x 512 originals.
FID
    Inception-v3 pool features in the pytorch-fid convention (clean-fid,
    mode ``legacy_pytorch``) against the statistics of the 40,504 MS-COCO
    val2014 images at 256 px that DGQ distributes (``real_im256.npz``).  The
    95% interval resamples the generated images (1,000 resamples) with the
    reference statistics fixed.
FID to FP (Table IV)
    FID between the images of a method and the full-precision images of the
    same prompts and seeds.  The interval and the paired LUT - DGQ difference
    resample prompt indices jointly for all sets, so a resample keeps the
    pairing of images across methods.
IS
    Inception-v3 (torch-fidelity ``inception-v3-compat``, unbiased logits), 10
    splits with a FIXED assignment (image i in split i mod 10), so the same
    images always give the same score; ``is_sd`` is the SD over splits and the
    bootstrap interval recomputes the same 10-split estimate on every resample.
CLIP
    mean cosine similarity of open_clip ViT-L/14 (OpenAI weights) image and
    prompt embeddings.
LPIPS, PSNR (Table VII)
    AlexNet LPIPS and PSNR (dB) of each image against the full-precision image
    of the same prompt and seed; LPIPS with a 95% bootstrap interval over images.
CMMD (Table IV)
    The estimator of Jayasumana et al. (CVPR 2024) as implemented in the
    reference code (google-research/google-research, ``cmmd/``): images are
    center-cropped to a square and resized to 336 x 336 with PIL bicubic
    resampling (with anti-aliasing), scaled to [0, 1], normalized with the
    CLIP mean and standard deviation (:func:`cmmd_preprocess`, the reference
    steps in the reference order), and embedded with CLIP ViT-L/14@336px
    (OpenAI weights); the embeddings are L2-normalized, as the reference CLIP
    model returns them.  The squared MMD is the minimum-variance (V-statistic)
    estimator with a Gaussian RBF kernel, sigma = 10, scaled by 1000
    (``distance.mmd`` of the reference code).  Every image is used; the
    reference drops the images of an incomplete last batch, so the two agree
    when its batch size divides the number of images.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np

IS_SPLITS = 10
EVAL_SIZE = 256


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff"}
_NAME = re.compile(r"^\d{5}\.png$")


def _any_images(folder) -> list:
    return sorted(p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES)


def _images(folder) -> list:
    """The images of a run folder in index order: exactly ``00000.png`` ... ``<n-1>.png``.

    Every metric reads its images through this list.  Any other image file in
    the folder (another name, extension or letter case, a gap in the indices)
    raises ``ValueError`` instead of being read or skipped silently.
    """
    files = _any_images(folder)
    bad = [p.name for p in files if not _NAME.match(p.name)]
    if bad:
        raise ValueError(f"{folder}: image files outside the run's naming scheme: {', '.join(bad[:5])}")
    if [p.name for p in files] != [f"{i:05d}.png" for i in range(len(files))]:
        raise ValueError(f"{folder}: image indices are not 0 .. {len(files) - 1}")
    return files


def _device():
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


def resized(folder, size: int = EVAL_SIZE) -> Path:
    """``<folder>/../im<size>``: bicubic ``size`` x ``size`` copies of the images, kept in step with the originals.

    ``MANIFEST.json`` in the output folder maps every copy to the SHA-256 of
    the original it was made from.  On every call a copy is rebuilt when its
    original changed, copies without an original are removed, and the
    manifest is rewritten, so the copies always correspond to the current
    originals.
    """
    import json

    from PIL import Image

    from .records import sha256_file

    src = Path(folder)
    out = src.parent / f"im{size}"
    out.mkdir(parents=True, exist_ok=True)
    man_path = out / "MANIFEST.json"
    try:
        manifest = json.loads(man_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        manifest = {}
    if manifest.get("size") != size or manifest.get("method") != "PIL bicubic":
        manifest = {}
    old = manifest.get("files", {})
    files = _images(src)
    new = {}
    for f in files:
        digest = sha256_file(f)
        target = out / f.name
        if old.get(f.name) != digest or not target.exists():
            tmp = out / f".{f.name}.part"
            Image.open(f).convert("RGB").resize((size, size), Image.BICUBIC).save(tmp, format="PNG")
            tmp.replace(target)
        new[f.name] = digest
    for stale in _any_images(out):
        if stale.name not in new:
            stale.unlink()
    man_path.write_text(json.dumps({"size": size, "method": "PIL bicubic", "files": new}, indent=0),
                        encoding="utf-8")
    return out


# ----------------------------------------------------------------------------- FID
def _stats(feats):
    return np.mean(feats, axis=0), np.cov(feats, rowvar=False)


def fid_features(folder, batch_size: int = 64) -> np.ndarray:
    """Inception-v3 pool features (pytorch-fid convention) of the run images of ``folder``, in index order."""
    import torch
    from cleanfid import fid as cf
    from cleanfid.features import build_feature_extractor

    dev = torch.device(_device())
    model = build_feature_extractor("legacy_pytorch", device=dev)
    files = [str(p) for p in _images(folder)]
    return cf.get_files_features(files, model, num_workers=0, batch_size=batch_size, device=dev,
                                 mode="legacy_pytorch", description=f"FID features {Path(folder).name}: ")


def reference_stats(path=None):
    """``(mu, sigma)`` of the MS-COCO val2014 reference (DGQ's ``real_im256.npz``, locked in ``locks/data.json``)."""
    from .data import data_root, download

    p = Path(path) if path else download("fid_reference", data_root() / "coco" / "real_im256.npz")
    with np.load(p) as z:
        return z["mu"], z["sigma"]


def fid(gen_dir, reference=None, n_boot: int = 0, seed: int = 0) -> dict:
    """FID of a folder against the COCO reference, with an optional 95% bootstrap interval."""
    from cleanfid.fid import frechet_distance

    mu_r, s_r = reference_stats(reference)
    g = fid_features(resized(gen_dir))
    out = {"fid": float(frechet_distance(*_stats(g), mu_r, s_r)), "n_images": int(len(g))}
    if n_boot:
        rng = np.random.default_rng(seed)
        boots = [frechet_distance(*_stats(g[rng.integers(0, len(g), len(g))]), mu_r, s_r) for _ in range(n_boot)]
        out["fid_lo"], out["fid_hi"] = (float(v) for v in np.percentile(boots, [2.5, 97.5]))
    return out


def fid_to_reference_paired(features: dict, reference: np.ndarray, n_boot: int = 1000, seed: int = 0,
                            pairs=(("lut", "dgq"),)) -> dict:
    """FID of every feature set against ``reference`` (same prompts), with paired bootstrap intervals.

    All arrays are indexed by prompt; each resample draws one set of prompt
    indices and applies it to every array, so differences stay paired.
    """
    from cleanfid.fid import frechet_distance

    n = len(reference)
    if any(len(f) != n for f in features.values()):
        raise ValueError("every feature set must have one row per prompt of the reference")

    def fids(idx):
        mu_r, s_r = _stats(reference[idx])
        return {k: float(frechet_distance(*_stats(f[idx]), mu_r, s_r)) for k, f in features.items()}

    point = fids(np.arange(n))
    rng = np.random.default_rng(seed)
    boots = [fids(rng.integers(0, n, n)) for _ in range(n_boot)]
    out = {}
    for k in features:
        lo, hi = np.percentile([b[k] for b in boots], [2.5, 97.5])
        out[k] = {"fid": point[k], "lo": float(lo), "hi": float(hi)}
    for a, b in pairs:
        if a in features and b in features:
            lo, hi = np.percentile([x[a] - x[b] for x in boots], [2.5, 97.5])
            out[f"{a}-{b}"] = {"diff": point[a] - point[b], "lo": float(lo), "hi": float(hi)}
    return out


# ------------------------------------------------------------------------------ IS
def class_probs(gen_dir, batch_size: int = 64) -> np.ndarray:
    """Inception-v3 softmax class probabilities (N, 1008) of the 256-px images, in file order."""
    import torch
    from PIL import Image
    from torch_fidelity.feature_extractor_inceptionv3 import FeatureExtractorInceptionV3

    dev = _device()
    fe = FeatureExtractorInceptionV3("inception-v3-compat", ["logits_unbiased"]).to(dev).eval()
    files = _images(resized(gen_dir))
    out = []
    for i in range(0, len(files), batch_size):
        x = np.stack([np.asarray(Image.open(f).convert("RGB")) for f in files[i:i + batch_size]])
        x = torch.from_numpy(x).permute(0, 3, 1, 2).to(dev)  # uint8, resized to 299 inside
        with torch.no_grad():
            logits = fe(x)[0]
        out.append(torch.softmax(logits.double(), dim=1).cpu().numpy())
    return np.concatenate(out)


def inception_score(p: np.ndarray, splits: int = IS_SPLITS) -> tuple[float, float]:
    """Mean and SD of the per-split IS; image i belongs to split i mod ``splits``."""
    scores = []
    for s in range(splits):
        part = p[s::splits]
        py = part.mean(axis=0, keepdims=True)
        kl = (part * (np.log(part + 1e-12) - np.log(py + 1e-12))).sum(axis=1)
        scores.append(np.exp(kl.mean()))
    return float(np.mean(scores)), float(np.std(scores))


def inception_score_bootstrap(p: np.ndarray, n_boot: int = 1000, seed: int = 0,
                              splits: int = IS_SPLITS) -> tuple[float, float, float]:
    """The 10-split IS and a 95% percentile-bootstrap interval of the same estimator."""
    point, _ = inception_score(p, splits)
    rng = np.random.default_rng(seed)
    boots = [inception_score(p[rng.integers(0, len(p), len(p))], splits)[0] for _ in range(n_boot)]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return point, float(lo), float(hi)


# ---------------------------------------------------------------------------- CLIP
def clip_score(gen_dir, prompts, batch_size: int = 64) -> float:
    """Mean image-prompt cosine similarity, open_clip ViT-L/14 (OpenAI weights)."""
    import open_clip
    import torch
    from PIL import Image

    dev = _device()
    model, _, pre = open_clip.create_model_and_transforms("ViT-L-14", pretrained="openai", device=dev)
    model.eval()
    tok = open_clip.get_tokenizer("ViT-L-14")
    files = _images(gen_dir)
    if len(files) != len(prompts):
        raise ValueError(f"{len(files)} images but {len(prompts)} prompts: one prompt per image, in file order")
    sims = []
    for i in range(0, len(files), batch_size):
        x = torch.stack([pre(Image.open(f).convert("RGB")) for f in files[i:i + batch_size]]).to(dev)
        with torch.no_grad():
            v = model.encode_image(x)
            w = model.encode_text(tok(prompts[i:i + batch_size]).to(dev))
        v = v / v.norm(dim=-1, keepdim=True)
        w = w / w.norm(dim=-1, keepdim=True)
        sims.append((v * w).sum(dim=-1).float().cpu().numpy())
    return float(np.concatenate(sims).mean())


# ---------------------------------------------------------------- fidelity to FP16
def psnr(x: np.ndarray, y: np.ndarray) -> float:
    m = float(np.mean((np.asarray(x, np.float64) - np.asarray(y, np.float64)) ** 2))
    return 10.0 * np.log10(1.0 / max(m, 1e-12))


def lpips_psnr(gen_dir, ref_dir, n_boot: int = 1000, seed: int = 0) -> dict:
    """Mean LPIPS (AlexNet, 95% bootstrap interval) and mean PSNR against paired FP16 images."""
    import lpips
    import torch
    from PIL import Image

    dev = _device()
    net = lpips.LPIPS(net="alex", verbose=False).to(dev).eval()
    g, r = _images(gen_dir), _images(ref_dir)
    if [p.name for p in g] != [p.name for p in r]:
        raise ValueError("images must be paired by file name")
    lp, ps = [], []
    for a, b in zip(g, r):
        x = np.asarray(Image.open(a).convert("RGB"), dtype=np.float32) / 255.0
        y = np.asarray(Image.open(b).convert("RGB"), dtype=np.float32) / 255.0
        ps.append(psnr(x, y))
        tx = torch.from_numpy(x).permute(2, 0, 1)[None].to(dev) * 2 - 1
        ty = torch.from_numpy(y).permute(2, 0, 1)[None].to(dev) * 2 - 1
        with torch.no_grad():
            lp.append(float(net(tx, ty)))
    lp = np.asarray(lp)
    rng = np.random.default_rng(seed)
    lo, hi = np.percentile([lp[rng.integers(0, len(lp), len(lp))].mean() for _ in range(n_boot)], [2.5, 97.5])
    return {"lpips": float(lp.mean()), "lpips_lo": float(lo), "lpips_hi": float(hi), "psnr": float(np.mean(ps))}


# ---------------------------------------------------------------------------- CMMD
CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD = (0.26862954, 0.26130258, 0.27577711)
CMMD_SIZE = 336


def cmmd_preprocess(img) -> np.ndarray:
    """The image preparation of the CMMD reference code, as a (3, 336, 336) float32 array.

    ``io_util._center_crop_and_resize`` (square center crop, PIL bicubic resize
    with anti-aliasing), scaling to [0, 1], then ``embedding._clip_preprocess``:
    a bicubic resize to the same size (the identity) and the CLIP normalization.
    """
    from PIL import Image

    im = img.convert("RGB")
    w, h = im.size
    side = min(w, h)
    top, left = (h - side) // 2, (w - side) // 2
    im = im.crop((left, top, left + side, top + side)).resize((CMMD_SIZE, CMMD_SIZE), resample=Image.BICUBIC)
    x = np.asarray(im).astype(np.float32) / 255.0
    x = (x - np.asarray(CLIP_MEAN, np.float32)) / np.asarray(CLIP_STD, np.float32)
    return x.transpose(2, 0, 1)


def clip_embeddings(folder, batch_size: int = 64) -> np.ndarray:
    """L2-normalized CLIP ViT-L/14@336px image embeddings (OpenAI weights) of the run images, in index order."""
    import open_clip
    import torch
    from PIL import Image

    dev = _device()
    model, _, _ = open_clip.create_model_and_transforms("ViT-L-14-336", pretrained="openai", device=dev)
    model.eval()
    files = _images(folder)
    out = []
    for i in range(0, len(files), batch_size):
        x = torch.from_numpy(np.stack([cmmd_preprocess(Image.open(f)) for f in files[i:i + batch_size]])).to(dev)
        with torch.no_grad():
            v = model.encode_image(x).float()
        out.append((v / v.norm(dim=-1, keepdim=True)).cpu().numpy())
    return np.concatenate(out)


def cmmd(x: np.ndarray, y: np.ndarray, sigma: float = 10.0, scale: float = 1000.0) -> float:
    """``scale`` x squared MMD (V-statistic) with a Gaussian RBF kernel of bandwidth ``sigma``.

    Term for term the reference ``distance.mmd``:
    ``k(a, b) = exp(-||a - b||^2 / (2 sigma^2))`` and
    ``MMD^2 = mean k(x, x') + mean k(y, y') - 2 mean k(x, y)``, diagonals included.
    """
    x, y = np.asarray(x, np.float64), np.asarray(y, np.float64)
    gamma = 1.0 / (2 * sigma ** 2)

    def k(a, b):
        d = (a * a).sum(1)[:, None] + (b * b).sum(1)[None, :] - 2 * a @ b.T
        return np.exp(-gamma * d)

    return float(scale * (k(x, x).mean() + k(y, y).mean() - 2 * k(x, y).mean()))
