"""Lock files: the immutable identity of every external model and dataset.

The first download of a model snapshot or a dataset file writes its resolved
identity (Hugging Face commit, URL, SHA-256, size) to ``locks/<name>.json``;
every later use compares what it loads with the lock and stops on a mismatch.
The ``locks/`` folder is committed with the paper version and packaged in the
record archive, so a reproduction resolves exactly the same revisions.

The folder is ``$LUTQ_LOCKS`` (default ``<repository>/locks``, see :mod:`lutq.paths`).
"""

from __future__ import annotations

import json
from pathlib import Path


class LockMismatch(RuntimeError):
    """A model or dataset differs from the revision recorded in ``locks/``."""


def lock_dir() -> Path:
    from .paths import lock_dir as _lock_dir

    return _lock_dir()


def read(name: str) -> dict:
    path = lock_dir() / f"{name}.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def entry(name: str, key: str) -> dict | None:
    return read(name).get(key)


def check_or_write(name: str, key: str, value: dict, compare: tuple) -> dict:
    """Compare ``value`` with the locked entry on the fields ``compare``; write it when absent.

    Returns the locked entry.  Raises :class:`LockMismatch` when a compared
    field differs, naming the field, the locked value and the observed value.
    """
    data = read(name)
    locked = data.get(key)
    if locked is None:
        data[key] = value
        path = lock_dir() / f"{name}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        tmp.replace(path)
        return value
    for field in compare:
        if field in locked and field in value and locked[field] != value[field]:
            a, b = locked[field], value[field]
            if isinstance(a, dict) and isinstance(b, dict):
                diff = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
                raise LockMismatch(f"{name}/{key}: {field} differs from the lock in "
                                   f"{lock_dir() / (name + '.json')} for {', '.join(diff)}")
            raise LockMismatch(f"{name}/{key}: {field} is {b!r}, the lock in "
                               f"{lock_dir() / (name + '.json')} records {a!r}")
    return locked
