"""Model weights, resolved to immutable Hugging Face revisions.

``sd14_snapshot()`` downloads (or finds in the Hugging Face cache) the files of
Stable Diffusion v1.4 that the pipelines load and returns the snapshot folder,
whose name is the commit hash of the model repository.  The commit and the
SHA-256 of every loaded file are written to ``locks/models.json`` on first use;
every later use recomputes the digests and compares them with the lock
(:mod:`lutq.locks`).

``sd14_original_ckpt()`` does the same for ``sd-v1-4.ckpt``, the original
CompVis checkpoint that the Q-Diffusion and TFMQ-DM code bases load.

A revision can be forced with ``$LUTQ_SD14_REVISION`` and
``$LUTQ_SD14_CKPT_REVISION``; otherwise the locked commit is used, and
``main`` when there is no lock yet.
"""

from __future__ import annotations

import os
from pathlib import Path

from . import locks

SD14_REPO = "CompVis/stable-diffusion-v1-4"
SD14_CKPT_REPO = "CompVis/stable-diffusion-v-1-4-original"
SD14_CKPT_FILE = "sd-v1-4.ckpt"
SD14_FILES = [
    "model_index.json",
    "feature_extractor/preprocessor_config.json",
    "scheduler/scheduler_config.json",
    "text_encoder/config.json",
    "text_encoder/model.safetensors",
    "tokenizer/merges.txt",
    "tokenizer/special_tokens_map.json",
    "tokenizer/tokenizer_config.json",
    "tokenizer/vocab.json",
    "unet/config.json",
    "unet/diffusion_pytorch_model.safetensors",
    "vae/config.json",
    "vae/diffusion_pytorch_model.safetensors",
]


def _revision(env: str, key: str) -> str:
    locked = locks.entry("models", key) or {}
    return os.environ.get(env) or locked.get("commit") or "main"


_VERIFIED: dict = {}


def _digest(path: Path) -> str:
    """SHA-256 of a file, computed once per process for an unchanged file (path, size, mtime)."""
    from .records import sha256_file

    st = path.stat()
    key = (str(path.resolve()), st.st_size, st.st_mtime_ns)
    if key not in _VERIFIED:
        _VERIFIED[key] = sha256_file(path)
    return _VERIFIED[key]


def sd14_snapshot() -> tuple[Path, str]:
    """``(folder, commit)`` of the locked Stable Diffusion v1.4 snapshot.

    The SHA-256 of every file the pipelines load (configurations, tokenizer and
    weights) is compared with ``locks/models.json`` on every use; the first use
    writes the lock.
    """
    from huggingface_hub import snapshot_download

    path = Path(snapshot_download(SD14_REPO, revision=_revision("LUTQ_SD14_REVISION", "sd14"),
                                  allow_patterns=SD14_FILES))
    missing = [f for f in SD14_FILES if not (path / f).is_file()]
    if missing:
        raise locks.LockMismatch(f"{SD14_REPO} snapshot {path.name} lacks {', '.join(missing)}")
    value = {"repo": SD14_REPO, "commit": path.name, "sha256": {f: _digest(path / f) for f in SD14_FILES}}
    locks.check_or_write("models", "sd14", value, compare=("repo", "commit", "sha256"))
    return path, path.name


def sd14_original_ckpt() -> tuple[Path, str, str]:
    """``(file, commit, sha256)`` of the locked ``sd-v1-4.ckpt``."""
    from huggingface_hub import hf_hub_download

    path = Path(hf_hub_download(SD14_CKPT_REPO, SD14_CKPT_FILE,
                                revision=_revision("LUTQ_SD14_CKPT_REVISION", "sd14_original")))
    commit = path.parent.name
    value = {"repo": SD14_CKPT_REPO, "file": SD14_CKPT_FILE, "commit": commit, "sha256": _digest(path)}
    locked = locks.check_or_write("models", "sd14_original", value, compare=("repo", "commit", "sha256"))
    return path, commit, locked["sha256"]


def sd14_identity() -> dict:
    """The locked identity of SD v1.4 for run records (empty before the first download)."""
    return {k: v for k, v in (locks.entry("models", "sd14") or {}).items() if k in ("repo", "commit")}
