"""LUT-Quant: data-driven look-up table quantization of cross-attention scores.

LUT-Quant replaces the fixed logarithmic cross-attention score quantizer of a
low-bit text-to-image diffusion model with a per-layer, 256-level look-up
table whose levels are fitted by Lloyd's algorithm to the profiled
post-softmax score distribution.  At inference every score is normalized by
the per-call maximum, bucketized against the midpoints of the table, and
replaced by its level.

Modules
-------
Numerical core (NumPy / SciPy only)
    codebook     Lloyd fitting (uniform initialization, 50 iterations), codebook I/O
    quantizers   placement rules: ACIQ, histogram, learned log, Lloyd, DGQ log2
    stats        paired / Welch t tests, ranks, Kendall's W, bootstrap
    records      run records, provenance, the validated results ledger
    report       Tables I-VIII and S1-S3 rendered from valid runs; comparison with the paper
    bundle       SHA-256-manifested archive of the run records
    locks        locked revisions and digests of models and datasets

Diffusion pipeline (PyTorch / diffusers, imported lazily)
    attention    score-quantizing attention processors, step tracking, error measurement
    profiling    calibration score sampler and quantization-error log
    pipeline     SD v1.4, method assembly on the DGQ back-end, seeded generation
    models       Stable Diffusion v1.4 at a locked Hugging Face revision
    data         prompt protocols, their locked sources and the FID reference
    metrics      FID, IS, CLIP, LPIPS, PSNR, CMMD
    figures      Figures 1-9
    cli          the ``lutq-*`` command-line tools
    integrations.dgq   LUT-Quant inside the official DGQ quantized U-Net
"""

__version__ = "1.0.0"
