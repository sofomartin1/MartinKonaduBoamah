"""Figures 1-9 of the paper, drawn from the ledger, the records and the generated images.

Fig. 1   FID versus CLIP of the placement rules (Table III protocol)
Fig. 2   FID, IS and CLIP of the placement rules (Table III protocol)
Fig. 3   qualitative grid: the same prompts across methods (Table VII runs)
Fig. 4   pixel-level difference to the full-precision image (Table VII runs)
Fig. 5   per-layer LUT-Quant codebooks (headline look-up tables)
Fig. 6   distribution of the quantization error, LUT versus log2 (Table V record)
Fig. 7   per-layer quantization MSE, LUT versus log2 (Table V record)
Fig. 8   zero-width bins and empty cells versus calibration prompts (codebook records)
Fig. 9   ablation at 10,000 prompts (Table VI, large-N rows)

A figure whose inputs have no valid record is skipped.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from .records import build_ledger
from .report import NAMES, pick

RULES = ("aciq", "histogram", "learned_log", "lut", "dgq")
QUAL = ("fp16", "qdiffusion", "tfmqdm", "dgq", "lut")
COLORS = {"aciq": "#9467bd", "histogram": "#8c564b", "learned_log": "#ff7f0e", "lut": "#1f77b4", "dgq": "#d62728",
          "fp16": "#7f7f7f", "qdiffusion": "#2ca02c", "tfmqdm": "#bcbd22"}


def _plt():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({"figure.dpi": 150, "axes.spines.top": False, "axes.spines.right": False,
                         "font.size": 9})
    return plt


def _save(fig, out: Path, name: str, files: list):
    path = out / f"{name}.png"
    fig.savefig(path, bbox_inches="tight")
    files.append(path)


def build_figures(runs, out, n_qualitative: int = 6) -> list:
    plt = _plt()
    runs, out = Path(runs), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    led = build_ledger(runs)
    led["runs"] = [r for r in led["runs"] if r["valid"]]
    files: list = []

    # Figs. 1 and 2 -------------------------------------------------------------
    got = {m: pick(led["runs"], "coco10k", m) for m in RULES}
    if all(got[m] and all(got[m].get(q) is not None for q in ("fid", "is", "clip")) for m in RULES):
        fig, ax = plt.subplots(figsize=(4.6, 3.4))
        for m in RULES:
            ax.scatter(got[m]["clip"], got[m]["fid"], s=40, color=COLORS[m], label=NAMES[m] if m != "lut" else "LUT-Quant")
        ax.set(xlabel="CLIP ↑", ylabel="FID ↓", title="W8A8, 10,000 prompts")
        ax.legend(fontsize=7)
        _save(fig, out, "fig1_fid_vs_clip", files)
        fig, axes = plt.subplots(1, 3, figsize=(10, 3))
        for ax, (q, label) in zip(axes, (("fid", "FID ↓"), ("is", "IS ↑"), ("clip", "CLIP ↑"))):
            ax.bar(range(len(RULES)), [got[m][q] for m in RULES], color=[COLORS[m] for m in RULES])
            ax.set_xticks(range(len(RULES)), ["ACIQ", "Hist.", "L-log", "LUT", "DGQ"])
            ax.set_title(label)
            lo = min(got[m][q] for m in RULES)
            ax.set_ylim(lo * 0.97, None)
        _save(fig, out, "fig2_method_comparison", files)

    # Figs. 3 and 4 -------------------------------------------------------------
    folders = {m: runs / r["run"] / "images" for m in QUAL if (r := pick(led["runs"], "coco1k", m))}
    folders = {m: f for m, f in folders.items() if f.is_dir()}
    names = sorted(p.name for p in folders["fp16"].glob("*.png"))[:n_qualitative] if "fp16" in folders else []
    if names and len(folders) > 1:
        from PIL import Image

        methods = [m for m in QUAL if m in folders]
        fig, axes = plt.subplots(len(names), len(methods), figsize=(1.9 * len(methods), 1.9 * len(names)), squeeze=False)
        for i, n in enumerate(names):
            for j, m in enumerate(methods):
                axes[i, j].imshow(Image.open(folders[m] / n))
                axes[i, j].set_xticks([]); axes[i, j].set_yticks([])
                if i == 0:
                    axes[i, j].set_title(NAMES[m], fontsize=8)
        _save(fig, out, "fig3_qualitative", files)
        quant = [m for m in methods if m != "fp16"]
        fig, axes = plt.subplots(len(names), len(quant), figsize=(1.9 * len(quant), 1.9 * len(names)), squeeze=False)
        for i, n in enumerate(names):
            ref = np.asarray(Image.open(folders["fp16"] / n).convert("RGB"), dtype=np.float32) / 255
            for j, m in enumerate(quant):
                x = np.asarray(Image.open(folders[m] / n).convert("RGB"), dtype=np.float32) / 255
                axes[i, j].imshow(np.abs(x - ref).mean(axis=2), cmap="inferno", vmin=0, vmax=0.5)
                axes[i, j].set_xticks([]); axes[i, j].set_yticks([])
                if i == 0:
                    axes[i, j].set_title(NAMES[m], fontsize=8)
        _save(fig, out, "fig4_difference_maps", files)

    # Fig. 5 ----------------------------------------------------------------------
    fits = [r for r in led.get("codebook", []) if r["config"].get("rule") == "lloyd"
            and r["config"].get("variant") == "standard" and r["config"].get("n_prompts") == 64
            and r["config"].get("levels") == 256]
    if fits:
        from .attention import short_name
        from .codebook import load_codebooks

        books = load_codebooks(runs / Path(fits[-1]["file"]).with_suffix(".npz"))
        keys = [k for k in books if "@" not in k and ".attn2" in k]
        fig, axes = plt.subplots(4, 4, figsize=(10, 7.5), sharex=True)
        for ax, k in zip(axes.ravel(), keys):
            lv = books[k]
            ax.plot(np.arange(lv.size), lv, color=COLORS["lut"], lw=1)
            ax.set_yscale("log")
            ax.set_title(short_name(k), fontsize=8)
        fig.supxlabel("level index"); fig.supylabel("normalized score (log)")
        _save(fig, out, "fig5_codebooks", files)

    # Figs. 6 and 7 -------------------------------------------------------------
    intr = led.get("intrinsic", [])
    if intr:
        rec = intr[-1]
        err_path = runs / Path(rec["file"]).with_suffix(".errors.npz")  # written next to the record
        if err_path.exists():
            with np.load(err_path) as z:
                fig, ax = plt.subplots(figsize=(5, 3.2))
                hi = float(np.quantile(np.abs(z["log2"]), 0.999))
                for r, label in (("log2", "log2 (DGQ)"), ("lut", "LUT-Quant")):
                    ax.hist(z[r], bins=200, range=(-hi, hi), histtype="step", log=True,
                            color=COLORS["dgq" if r == "log2" else "lut"], label=label)
                ax.set(xlabel="quantization error (normalized scale)", ylabel="count")
                ax.legend()
                _save(fig, out, "fig6_error_distribution", files)
        rows = rec["layers"]
        fig, ax = plt.subplots(figsize=(8, 3.2))
        x = np.arange(len(rows))
        ax.bar(x - 0.2, [r["log2"] for r in rows], 0.4, color=COLORS["dgq"], label="log2 (DGQ)")
        ax.bar(x + 0.2, [r["lut"] for r in rows], 0.4, color=COLORS["lut"], label="LUT-Quant")
        ax.set_yscale("log")
        ax.set_xticks(x, [r["short"] for r in rows], rotation=45)
        ax.set(ylabel="MSE (normalized scale)")
        ax.legend()
        _save(fig, out, "fig7_per_layer_mse", files)

    # Fig. 8 ----------------------------------------------------------------------
    fits = sorted((r for r in led.get("codebook", []) if r["config"].get("rule") == "lloyd"
                   and r["config"].get("variant") == "standard" and r["config"].get("n_prompts") in (4, 8, 16, 32)
                   and r["config"].get("levels") == 256),
                  key=lambda r: r["config"]["n_prompts"])
    if fits:
        n = [r["config"]["n_prompts"] for r in fits]
        fig, ax = plt.subplots(figsize=(4.6, 3))
        ax.plot(n, [r["summary"]["zero_width_bins"] for r in fits], "o-", label="zero-width bins")
        ax.plot(n, [r["summary"]["nonfinite"] for r in fits], "s--", label="non-finite codebooks")
        ax.set(xscale="log", xticks=n, xticklabels=[str(v) for v in n], xlabel="calibration prompts", ylabel="count")
        ax.legend()
        _save(fig, out, "fig8_codebook_stability", files)

    # Fig. 9 ----------------------------------------------------------------------
    abl = {v: pick(led["runs"], "coco10k", "lut", calib=8, variant=v) for v in ("standard", "tsadaptive", "selfcross")}
    if all(r and r.get("fid") is not None for r in abl.values()):
        fig, ax = plt.subplots(figsize=(4.2, 3))
        ax.bar(range(3), [abl[v]["fid"] for v in abl], color=COLORS["lut"])
        ax.set_xticks(range(3), ["Standard", "TS-adaptive", "Self + cross"])
        ax.set(ylabel="FID ↓", title="Ablation, 10,000 prompts")
        ax.set_ylim(min(abl[v]["fid"] for v in abl) * 0.97, None)
        _save(fig, out, "fig9_ablation_large_n", files)

    plt.close("all")
    return files
