"""Model loading, method assembly and seeded generation for Stable Diffusion v1.4.

Model: ``CompVis/stable-diffusion-v1-4``, 25 DDIM steps, guidance 7.5, 512 px.

Methods
-------
fp16         no quantization
dgq          DGQ W8A8 with DGQ's logarithmic cross-attention score quantizer
lut          DGQ W8A8 with LUT-Quant's per-layer Lloyd codebooks (the method of the paper)
aciq, histogram, learned_log
             DGQ W8A8 with a look-up table placed by that rule (Table III)
qdiffusion, tfmqdm
             generated with the official Q-Diffusion / TFMQ-DM code and imported
             with ``lutq-digest hash`` (Tables I and VII)

Every generated image, full precision included, goes through DGQ's pipeline
(``lutq.integrations.dgq``) in the DGQ environment, so the methods differ in
their quantizers alone.  DGQ's quantized U-Net simulates W8A8 quantization:
weights, activations and attention scores are quantized and dequantized in
FP16, and every matrix multiplication runs as an FP16 kernel; there are no
integer GEMM kernels in this pipeline.  Score profiling for the codebooks runs on the
diffusers pipeline in the main environment (:func:`load_fp_pipeline`), whose
attention processors expose the post-softmax scores.

Variants (Table VI)
-------------------
standard     one codebook per cross-attention layer
tsadaptive   one codebook per cross-attention layer and phase (steps 0-8, 9-16, 17-24)
selfcross    codebooks on the self-attention (attn1) layers as well
"""

from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass

MODEL = dict(repo="CompVis/stable-diffusion-v1-4", steps=25, guidance=7.5, size=512)
LUT_METHODS = ("lut", "aciq", "histogram", "learned_log")
RULE_OF = {"lut": "lloyd", "aciq": "aciq", "histogram": "histogram", "learned_log": "learned_log"}
METHODS = ("fp16", "dgq") + LUT_METHODS
EXTERNAL = ("qdiffusion", "tfmqdm")
VARIANTS = ("standard", "tsadaptive", "selfcross")


@dataclass
class GenConfig:
    steps: int = MODEL["steps"]
    guidance: float = MODEL["guidance"]
    size: int = MODEL["size"]


def load_fp_pipeline(device: str | None = None, dtype: str | None = None):
    """Full-precision SD v1.4 with diffusers (main environment): the profiling model.

    The weights come from the locked snapshot (:func:`lutq.models.sd14_snapshot`).
    ``dtype`` is ``"fp16"`` (default on a GPU) or ``"fp32"`` (default on a CPU).
    """
    import torch
    from diffusers import DDIMScheduler, StableDiffusionPipeline

    from .models import sd14_snapshot

    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    dtype = dtype or ("fp16" if str(device).startswith("cuda") else "fp32")
    torch_dtype = {"fp16": torch.float16, "fp32": torch.float32}[dtype]
    path, _ = sd14_snapshot()
    pipe = StableDiffusionPipeline.from_pretrained(path, torch_dtype=torch_dtype, safety_checker=None,
                                                   feature_extractor=None, requires_safety_checker=False)
    pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
    pipe.set_progress_bar_config(disable=True)
    return pipe.to(device)


def precision_of(pipe) -> dict:
    """Dtypes of the pipeline components, for run records."""
    out = {}
    for name in ("unet", "text_encoder", "vae"):
        m = getattr(pipe, name, None)
        p = next(m.parameters(), None) if m is not None else None
        if p is not None:
            out[name] = str(p.dtype).replace("torch.", "")
    return out


def build(method: str, *, dgq_ckpt: str | None = None, codebooks: dict | None = None, variant: str = "standard",
          w_bits: int = 8, a_bits: int = 8, score_levels: int = 256):
    """The DGQ pipeline of one method (DGQ environment); returns ``(pipe, info)``."""
    from .attention import StepTracker
    from .integrations import dgq

    if method not in METHODS:
        raise ValueError(f"unknown method {method!r}; choose from {METHODS}")
    if variant not in VARIANTS:
        raise ValueError(f"unknown variant {variant!r}")
    if method != "fp16" and not dgq_ckpt:
        raise ValueError(f"method {method!r} needs the merged DGQ checkpoint")
    if method in LUT_METHODS and not codebooks:
        raise ValueError(f"method {method!r} needs codebooks")
    pipe = dgq.load_dgq_pipeline(dgq_ckpt, w_bits, a_bits, score_levels, quantized=method != "fp16")
    info = {"replaced": 0, "dgq_commit": dgq.dgq_commit(), "precision": precision_of(pipe),
            "execution": dgq.EXECUTION.format(w=w_bits, a=a_bits) if method != "fp16" else "FP16 inference, no quantizers"}
    if method in LUT_METHODS:
        tracker = StepTracker(pipe.scheduler).attach(pipe.unet) if variant == "tsadaptive" else None
        info["replaced"] = dgq.install_lut(pipe.unet, codebooks, levels=score_levels,
                                           self_attention=variant == "selfcross", tracker=tracker)
    return pipe, info


# ----------------------------------------------------------------------- generation
def initial_latents(pipe, seed: int, index: int, cfg: "GenConfig" = None):
    """The starting latent of image ``index``: float32 noise from a generator seeded ``seed + index``.

    ``torch.randn`` draws the (1, 4, size/8, size/8) latent in float32 with a
    generator on the pipeline's device, and the draw is then cast to the dtype
    of the pipeline (FP16 on a GPU) before the first denoising step.  Every
    method, the Q-Diffusion and TFMQ-DM baselines included
    (``baselines/common.py``), starts image i from the same float32 draw.
    """
    import torch

    cfg = cfg or GenConfig()
    device = getattr(pipe, "device", "cpu")
    encoder = getattr(pipe, "text_encoder", None)
    dtype = next(encoder.parameters()).dtype if encoder is not None else torch.float32   # dtype of the prompt embeddings
    g = torch.Generator(device=device).manual_seed(int(seed) + int(index))
    shape = (1, 4, cfg.size // 8, cfg.size // 8)
    return torch.randn(shape, generator=g, device=device, dtype=torch.float32).to(dtype)


def sample(pipe, prompt: str, latents, cfg: "GenConfig" = None, output_type: str = "pil"):
    """One image from ``latents``: text encoding, ``cfg.steps`` DDIM steps with classifier-free guidance, VAE decoding."""
    import torch

    cfg = cfg or GenConfig()
    with torch.inference_mode():
        return pipe(prompt=prompt, num_inference_steps=cfg.steps, guidance_scale=cfg.guidance,
                    height=cfg.size, width=cfg.size, latents=latents, output_type=output_type).images[0]


def png_digest(img) -> tuple[str, bytes]:
    """SHA-256 of the PNG encoding of an image, and the PNG bytes."""
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    data = buf.getvalue()
    return hashlib.sha256(data).hexdigest(), data


def generate(pipe, prompts, cfg: GenConfig = GenConfig(), seed: int = 42, save_dir=None, start_index: int = 0,
             on_prompt=None) -> list:
    """Generate one image per prompt (image i uses seed + i); return the SHA-256 digests of the PNG bytes."""
    import os

    digests = []
    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
    for i, prompt in enumerate(prompts):
        if on_prompt is not None:
            on_prompt(start_index + i)
        img = sample(pipe, prompt, initial_latents(pipe, seed, start_index + i, cfg), cfg)
        h, data = png_digest(img)
        digests.append(h)
        if save_dir:
            path = os.path.join(save_dir, f"{start_index + i:05d}.png")
            tmp = path + ".part"
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, path)
    return digests


def timed_sample(pipe, prompt: str, latents, cfg: GenConfig = GenConfig()) -> float:
    """Wall-clock milliseconds of :func:`sample` with ``output_type="pt"``, between two CUDA synchronizations.

    The timed region is text encoding, the denoising steps and VAE decoding;
    conversion to PIL, PNG encoding and hashing are outside it.
    """
    import time

    import torch

    torch.cuda.synchronize()
    t0 = time.perf_counter()
    sample(pipe, prompt, latents, cfg, output_type="pt")
    torch.cuda.synchronize()
    return 1000.0 * (time.perf_counter() - t0)
