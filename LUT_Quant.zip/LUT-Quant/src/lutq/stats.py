"""Statistical procedures for comparing quantizers across seeds and settings.

Every function is deterministic given its inputs (and, for the bootstrap, an
explicit seed), so every derived statistic produced by ``lutq-report`` can be
regenerated exactly from the run outputs.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Sequence

import numpy as np
from scipy import stats as sps


@dataclass(frozen=True)
class TestResult:
    statistic: float
    df: float
    p_value: float


def mean(x: Sequence[float]) -> float:
    return float(np.mean(np.asarray(x, dtype=float)))


def sd(x: Sequence[float], ddof: int = 1) -> float:
    """Standard deviation (``ddof=1`` sample form; ``ddof=0`` population form)."""
    a = np.asarray(x, dtype=float)
    return float(np.std(a, ddof=ddof))


def paired_t(x: Sequence[float], y: Sequence[float]) -> TestResult:
    """Paired t test of mean(x - y) = 0."""
    d = np.asarray(x, float) - np.asarray(y, float)
    n = d.size
    t = d.mean() / (d.std(ddof=1) / np.sqrt(n))
    p = 2.0 * sps.t.sf(abs(t), n - 1)
    return TestResult(float(t), float(n - 1), float(p))


def paired_t_ci(x: Sequence[float], y: Sequence[float], conf: float = 0.95) -> tuple[float, float]:
    """Student-t confidence interval on the mean paired difference x - y."""
    d = np.asarray(x, float) - np.asarray(y, float)
    n = d.size
    half = sps.t.ppf(0.5 + conf / 2.0, n - 1) * d.std(ddof=1) / np.sqrt(n)
    return float(d.mean() - half), float(d.mean() + half)


def welch_t(m1: float, s1: float, n1: int, m2: float, s2: float, n2: int) -> TestResult:
    """Welch's unequal-variance t test from summary statistics."""
    v1, v2 = s1 ** 2 / n1, s2 ** 2 / n2
    t = (m1 - m2) / np.sqrt(v1 + v2)
    df = (v1 + v2) ** 2 / (v1 ** 2 / (n1 - 1) + v2 ** 2 / (n2 - 1))
    p = 2.0 * sps.t.sf(abs(t), df)
    return TestResult(float(t), float(df), float(p))


def sign_test(n_negative: int, n: int) -> float:
    """Two-sided exact binomial sign test against p = 0.5."""
    return float(sps.binomtest(n_negative, n, 0.5, alternative="two-sided").pvalue)


def clopper_pearson(k: int, n: int, conf: float = 0.95) -> tuple[float, float]:
    a = 1.0 - conf
    lo = 0.0 if k == 0 else float(sps.beta.ppf(a / 2, k, n - k + 1))
    hi = 1.0 if k == n else float(sps.beta.ppf(1 - a / 2, k + 1, n - k))
    return lo, hi


def percentile_bootstrap(x: Sequence[float], stat: Callable = np.mean, n_resamples: int = 1000,
                         conf: float = 0.95, seed: int = 0) -> tuple[float, float]:
    """Percentile bootstrap interval of ``stat`` over the rows of ``x``."""
    a = np.asarray(x)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, a.shape[0], size=(n_resamples, a.shape[0]))
    vals = np.array([stat(a[i]) for i in idx])
    lo, hi = np.quantile(vals, [(1 - conf) / 2, 1 - (1 - conf) / 2])
    return float(lo), float(hi)


def mdd_paired(sd_paired: float, n: int, alpha: float = 0.05, power: float = 0.80) -> float:
    """Minimum detectable mean paired difference, solved on the non-central t."""
    from scipy.optimize import brentq

    df = n - 1
    tcrit = sps.t.ppf(1 - alpha / 2, df)

    def f(delta: float) -> float:
        lam = delta / (sd_paired / np.sqrt(n))
        pw = sps.nct.sf(tcrit, df, lam) + sps.nct.cdf(-tcrit, df, lam)
        return pw - power

    hi = sd_paired
    while f(hi) < 0:  # expand until the power target is bracketed
        hi *= 1.5
    return float(brentq(f, 1e-9 * sd_paired, hi))


def ranks_desc(values: Sequence[float]) -> np.ndarray:
    """Rank 1 = largest (for IS and CLIP)."""
    return sps.rankdata(-np.asarray(values, float), method="min")


def ranks_asc(values: Sequence[float]) -> np.ndarray:
    """Rank 1 = smallest (for FID)."""
    return sps.rankdata(np.asarray(values, float), method="min")


def kendall_w(rank_matrix: np.ndarray) -> float:
    """Kendall's coefficient of concordance for an (m raters x n items) rank matrix."""
    r = np.asarray(rank_matrix, float)
    m, n = r.shape
    s = np.sum((r.sum(axis=0) - m * (n + 1) / 2.0) ** 2)
    return float(12.0 * s / (m ** 2 * (n ** 3 - n)))
