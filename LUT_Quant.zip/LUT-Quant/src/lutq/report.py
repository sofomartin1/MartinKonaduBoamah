"""The results ledger, Tables I-VIII and Tables S1-S4, rendered from run records only.

``build_report(runs, out)`` writes

``ledger.csv``       one row per run: condition, image count, image-set digest, validity, metrics
``ledger.json``      the same rows plus every other record (look-up table fits,
                     quantization MSE, domain shift, latency, digest comparisons),
                     without per-image digests
``tables.md``        Tables I-VIII and S1-S4
``table<ID>.csv``    each table as CSV
``comparison.md``    every regenerated cell against the value printed in the paper
                     (only with ``expected=``, see :func:`compare`)

Validation
----------
Rows are selected by configuration (protocol, method, bit-widths, calibration
budgets, variant, score levels, seed), never by folder names, and only from
runs that pass :func:`lutq.records.build_ledger`'s checks: every image of the
prompt list recorded exactly once, consistent shards and inputs, metrics
computed on the generated image set, one prompt list per protocol, LPIPS /
PSNR against the matching full-precision run.  Two valid runs of the same
condition must agree, and a domain-shift or latency record must refer to
valid runs.  With ``strict=True`` (the default, used for publication) the
report also requires a valid record for every cell of Tables I-VIII and
S1-S3 and, with ``expected=``, agreement of every printed value; any
violation raises :class:`ReportError`, writes the complete list to
``problems.md`` (and ``comparison.md``) and no table.  With ``strict=False``
(a progress view) invalid runs are left out, their cells read ``no record``,
and ``tables.md`` lists them.
"""

from __future__ import annotations

import csv
import json
import math
import re
from collections import defaultdict
from pathlib import Path

import numpy as np

from . import stats
from .records import build_ledger, select

MISSING = "no record"   # a cell whose condition has no valid record
NA = "—"                # a cell that does not apply (e.g. LPIPS of the full-precision reference)
NAMES = {"fp16": "Full precision", "qdiffusion": "Q-Diffusion", "tfmqdm": "TFMQ-DM", "dgq": "DGQ",
         "lut": "LUT-Quant", "aciq": "ACIQ (analytic clipping)", "histogram": "Histogram / percentile",
         "learned_log": "Learned parametric log"}
ATTN = {"fp16": "None", "qdiffusion": "Uniform", "tfmqdm": "Timestep-aware", "dgq": "Log (Eq. 2)",
        "lut": "Data-driven LUT"}
METRIC_KEYS = ("fid", "is", "clip", "lpips", "psnr")


class ReportError(RuntimeError):
    """The records cannot produce publication tables; the message lists every reason."""


class _Context:
    """The ledger plus the problems found while rendering (ambiguous conditions, stale references)."""

    def __init__(self, led: dict):
        self.led = led
        self.runs = [r for r in led["runs"] if r["valid"]]
        self.problems: list = []

    def __getitem__(self, k):
        return self.led[k] if k != "runs" else self.runs

    def get(self, k, default=None):
        return self.led.get(k, default) if k != "runs" else self.runs


def _ctx(led) -> _Context:
    return led if isinstance(led, _Context) else _Context(led)


def pick(runs, protocol, method, *, calib=64, wa_calib=64, variant="standard", levels=256, seed=42, problems=None):
    """The valid run of one condition, or ``None``.

    Several valid runs of one condition must have generated the same images
    and report the same metrics; otherwise the condition is ambiguous, which
    is added to ``problems`` (and ``None`` returned).
    """
    crit = dict(protocol=protocol, method=method, seed=seed)
    if method in ("qdiffusion", "tfmqdm"):
        crit.update(wbits=8, abits=8, wa_calib_prompts=wa_calib)
    elif method != "fp16":
        crit.update(wbits=8, abits=8, score_levels=levels, wa_calib_prompts=wa_calib)
        if method != "dgq":
            crit.update(calib_prompts=calib, variant=variant)
    rows = [r for r in select(runs, **crit) if r.get("valid", True)]
    if not rows:
        return None
    evaluated = [r for r in rows if r.get("evaluated")]
    sig = {r["image_set_sha256"] for r in rows} | {tuple(r.get(k) for k in METRIC_KEYS) for r in evaluated}
    if len(sig) > 1 + (1 if evaluated else 0):
        msg = (f"condition {crit} has {len(rows)} runs that disagree: " + ", ".join(r["run"] for r in rows))
        if problems is None:
            raise ReportError(msg)
        problems.append(msg)
        return None
    return (evaluated or rows)[-1]


def _v(row, key):
    return None if row is None or row.get(key) is None else float(row[key])


def f(v, nd=2, signed=False):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return MISSING
    s = f"{v:+.{nd}f}" if signed else f"{v:.{nd}f}"
    return s.replace("-", "−")


def ci(row, key, nd=2, sep=", "):
    lo, hi = _v(row, f"{key}_lo"), _v(row, f"{key}_hi")
    return f(_v(row, key), nd) if lo is None else f"{f(_v(row, key), nd)} [{f(lo, nd)}{sep}{f(hi, nd)}]"


def _table(cols, rows):
    head = "| " + " | ".join(cols) + " |\n|" + "|".join("---" for _ in cols) + "|\n"
    return head + "".join("| " + " | ".join(str(c) for c in r) + " |\n" for r in rows)


def _p(c, protocol, method, **kw):
    return pick(c.runs, protocol, method, problems=c.problems, **kw)


# ---------------------------------------------------------------------------- tables
def table1(led):
    c = _ctx(led)
    rows = []
    for m in ("fp16", "qdiffusion", "tfmqdm", "dgq", "lut"):
        r = _p(c, "coco30k", m)
        cal = NA if m == "fp16" else ("Timestep-sampled, " if m in ("qdiffusion", "tfmqdm") else "") + \
            (f"{int(r['wa_calib_prompts'])} captions" if r and r.get("wa_calib_prompts") else "64 captions")
        rows.append([NAMES[m], "FP16" if m == "fp16" else "W8A8", ATTN[m], f(_v(r, "fid")), f(_v(r, "is")),
                     f(_v(r, "clip"), 4), cal])
    return ["Method", "Precision", "Attn. quant.", "FID ↓", "IS ↑", "CLIP ↑", "Calibration"], rows, []


def _lat(c, method):
    recs = [r for r in c.get("latency", []) if r["config"].get("method") == method
            and (method == "fp16" or (r["config"].get("wbits"), r["config"].get("abits")) == (8, 8))
            and r["config"].get("score_levels", 256) in (256, None)]
    if len(recs) > 1:
        c.problems.append(f"{len(recs)} latency records for {method}: " + ", ".join(r["file"] for r in recs))
        return None
    return recs[0] if recs else None


def table2(led):
    c = _ctx(led)
    fp, base, u = _lat(c, "fp16"), _lat(c, "dgq"), _lat(c, "lut")
    rows, notes = [], []
    for m, label, r in (("fp16", "FP16 (baseline)", fp), ("dgq", "DGQ log W8A8", base), ("lut", "LUT W8A8 (ours)", u)):
        if r is None:
            rows.append([label, MISSING, MISSING, MISSING])
            continue
        slow = "1.00×" if m == "fp16" else (f"{r['mean_ms'] / fp['mean_ms']:.2f}×" if fp else MISSING)
        over = NA if m == "fp16" else ("Baseline" if m == "dgq" else
                                            (f"{100 * (r['mean_ms'] / base['mean_ms'] - 1):+.1f}%" if base else MISSING))
        rows.append([label, f"{r['mean_ms']:,.0f} ± {r['sd_ms']:,.0f}", slow, over])
    if u and base:
        w = stats.welch_t(u["mean_ms"], u["sd_ms"], len(u["ms"]), base["mean_ms"], base["sd_ms"], len(base["ms"]))
        notes.append(f"LUT-Quant vs DGQ: {u['mean_ms'] - base['mean_ms']:+.0f} ms, Welch t({w.df:.1f}) = "
                     f"{w.statistic:.2f}, p = {w.p_value:.3g}.")
    recs = [r for r in (fp, base, u) if r]
    if recs:
        r0 = recs[0]
        notes.append(f"{len(r0['ms'])} timed images after {r0['config']['warmup']} warm-up images, "
                     f"{r0['config'].get('steps', 25)} DDIM steps, batch size 1; timed region: "
                     f"{r0.get('timed_region', 'end-to-end generation')}. GPU: "
                     f"{', '.join(sorted({r['provenance'].get('gpu', '') for r in recs}))}.")
        ex = {r["config"]["method"]: r.get("installed", {}).get("execution") for r in recs}
        if ex.get("dgq"):
            notes.append(f"Quantized pipelines: {ex['dgq']}.")
        mem = [f"{NAMES.get(r['config']['method'], r['config']['method'])} "
               f"{r['peak_memory_bytes'] / 2 ** 20:,.0f} MiB" for r in recs if r.get("peak_memory_bytes")]
        if mem:
            notes.append("Peak GPU memory allocated: " + "; ".join(mem) + ".")
    if u and u.get("lut_bytes") is not None:
        notes.append(f"Look-up tables: {u['lut_bytes'] / 1024:.0f} KiB of float32 codebook levels; "
                     f"{u.get('lut_runtime_bytes', u['lut_bytes']) / 1024:.2f} KiB resident with the float32 bin edges.")
    return ["Method", "Mean latency (ms) ± SD", "Slowdown vs. FP16", "Overhead vs. DGQ"], rows, notes


def table3(led):
    c = _ctx(led)
    methods = ("aciq", "histogram", "learned_log", "lut", "dgq")
    got = {m: _p(c, "coco10k", m) for m in methods}
    vals = {q: [_v(got[m], q) for m in methods] for q in ("fid", "is", "clip")}
    complete = all(v is not None for q in vals for v in vals[q])
    ranks = {}
    if complete:
        ranks = {"fid": stats.ranks_asc(vals["fid"]), "is": stats.ranks_desc(vals["is"]),
                 "clip": stats.ranks_desc(vals["clip"])}
    rows = []
    for i, m in enumerate(methods):
        rk = (lambda q: f" ({int(ranks[q][i])})") if complete else (lambda q: "")
        mean_rank = f"{np.mean([ranks[q][i] for q in ranks]):.2f}" if complete else MISSING
        label = "Lloyd codebook (ours)" if m == "lut" else ("DGQ log" if m == "dgq" else NAMES[m])
        rows.append([label, f(vals["fid"][i]) + rk("fid"), f(vals["is"][i]) + rk("is"),
                     f(vals["clip"][i], 4) + rk("clip"), mean_rank])
    notes = []
    if complete:
        w = stats.kendall_w(np.vstack([ranks["fid"], ranks["is"], ranks["clip"]]))
        notes.append(f"Kendall's W across the three metric rankings = {w:.3f}.")
    return ["Method", "FID ↓ (rank)", "IS ↑ (rank)", "CLIP ↑ (rank)", "Mean rank"], rows, notes


def table4(led):
    c = _ctx(led)
    names = {"parti500": "PartiPrompts", "diffusiondb500": "DiffusionDB", "drawbench200": "DrawBench"}
    rows, budgets = [], set()
    for proto, label in names.items():
        recs = [r for r in c.get("domain_shift", []) if r["config"].get("protocol") == proto]
        if len(recs) > 1:
            c.problems.append(f"{len(recs)} domain-shift records for {proto}")
            recs = []
        rec = recs[0] if recs else None
        if rec is not None:
            sets = rec["results"].get("image_sets", {})
            for m, h in sets.items():
                match = [r for r in c.runs if r.get("protocol") == proto and r.get("method") == m
                         and r["image_set_sha256"] == h]
                if not match:
                    c.problems.append(f"{rec['file']}: the {m} images it evaluated are not a valid {proto} run")
                    rec = None
                    break
                if m != "fp16":
                    budgets.add((m, match[0].get("wa_calib_prompts"), match[0].get("calib_prompts")))
        if rec is None:
            rows.append([label] + [MISSING] * 9)
            continue
        res = rec["results"]
        fd = res["fid_to_fp"]
        rows.append([label, res["n_images"], f(res["clip"]["fp16"], 4), f(res["clip"]["dgq"], 4),
                     f(res["clip"]["lut"], 4),
                     f"{f(fd['dgq']['fid'])} [{f(fd['dgq']['lo'])}, {f(fd['dgq']['hi'])}]",
                     f"{f(fd['lut']['fid'])} [{f(fd['lut']['lo'])}, {f(fd['lut']['hi'])}]",
                     f"{f(fd['lut-dgq']['diff'], signed=True)} [{f(fd['lut-dgq']['lo'], signed=True)}, "
                     f"{f(fd['lut-dgq']['hi'], signed=True)}]",
                     f(res["cmmd"]["dgq"], 3), f(res["cmmd"]["lut"], 3)])
    notes = []
    wa = sorted({b[1] for b in budgets if b[1] is not None})
    lut = sorted({b[2] for b in budgets if b[0] == "lut" and b[2] is not None})
    if wa or lut:
        notes.append("Calibration of these runs: DGQ weight/activation checkpoint on "
                     f"{' / '.join(str(v) for v in wa)} MS-COCO captions; LUT-Quant look-up tables on "
                     f"{' / '.join(str(v) for v in lut)} MS-COCO captions; no recalibration on the target prompts.")
    cols = ["Prompt set", "N", "CLIP (FP)", "CLIP (DGQ)", "CLIP (LUT)", "FID-to-FP (DGQ)", "FID-to-FP (LUT)",
            "Δ (LUT − DGQ)", "CMMD (DGQ)", "CMMD (LUT)"]
    return cols, rows, notes


def table5(led):
    c = _ctx(led)
    recs = c.get("intrinsic", [])
    cols = ["Layer / phase", "Log-quant MSE (×10⁻⁶)", "LUT MSE (×10⁻⁷)", "Log / LUT"]
    if not recs:
        return cols, [], []
    if len(recs) > 1:
        c.problems.append(f"{len(recs)} intrinsic records: " + ", ".join(r["file"] for r in recs))
        return cols, [], []
    rec = recs[0]
    sig = lambda v: f"{v:.3g}"  # noqa: E731
    rows = [[r["short"], f"{sig(r['log2'] * 1e6)} ± {sig(r['log2_sd'] * 1e6)}",
             f"{sig(r['lut'] * 1e7)} ± {sig(r['lut_sd'] * 1e7)}", f"{r['ratio']:.1f}×"] for r in rec["layers"]]
    p = rec["pooled"]
    rows.append([f"Pooled (equal-weight mean of {len(rec['layers'])} layers)", sig(p["log2"] * 1e6),
                 sig(p["lut"] * 1e7), f"{p['ratio']:.1f}×"])
    rows += [[r["phase"], f"{sig(r['log2'] * 1e6)} ± {sig(r['log2_sd'] * 1e6)}",
              f"{sig(r['lut'] * 1e7)} ± {sig(r['lut_sd'] * 1e7)}", f"{r['ratio']:.1f}×"] for r in rec["phases"]]
    cfg = rec["config"]
    notes = [f"Normalized scale a = A[:, 1:]/max(A[:, 1:]); mean ± SD over the {cfg['n_prompts']} prompts "
             f"({cfg.get('protocol') or 'prompt file'}); model {cfg.get('model_dtype', 'fp16')}, "
             f"scores normalized and quantized in float32, errors accumulated in float64 ({rec['file']})."]
    return cols, rows, notes


def _stability(c, n_prompts, levels=256):
    fits = [r for r in c.get("codebook", []) if r["config"].get("rule") == "lloyd"
            and r["config"].get("variant") == "standard" and r["config"].get("n_prompts") == n_prompts
            and r["config"].get("levels") == levels]
    return fits[-1] if fits else None


TABLE6_REFERENCE = "Reference / Standard LUT, cross-attention only, 8 prompts, 256 levels"


def table6(led):
    c = _ctx(led)
    rows = []

    def row(axis, label, proto="coco200", **kw):
        r = _p(c, proto, "lut", **kw)
        rows.append([axis, label, f(_v(r, "fid")), f(_v(r, "is")), f(_v(r, "clip"), 4)])

    def stable(axis, label, n, levels=256):
        rec = _stability(c, n, levels)
        if rec is None:
            rows.append([axis, label, MISSING, MISSING, MISSING])
            return
        s = rec["summary"]
        ok = s["nonfinite"] == 0 and s["zero_width_bins"] == 0
        rows.append([axis, label, "stable" if ok else "unstable", f"non-finite {s['nonfinite']}",
                     f"zero-width bins {s['zero_width_bins']}"])

    row(*TABLE6_REFERENCE.split(" / "), calib=8)
    row("Timestep", "TS-adaptive", calib=8, variant="tsadaptive")
    row("Attention", "Self + cross", calib=8, variant="selfcross")
    for n in (4, 16):
        row("Calibration", f"{n} prompts", calib=n)
    stable("Calibration", "32 prompts (codebook stability)", 32)
    for levels, bits in ((64, 6), (16, 4)):
        row("LUT size", f"{levels} levels ({bits}-bit scores)", calib=8, levels=levels)
    row("Large-N", "Standard (10K)", proto="coco10k", calib=8)
    row("Large-N", "TS-adaptive (10K)", proto="coco10k", calib=8, variant="tsadaptive")
    row("Large-N", "Self + cross (10K)", proto="coco10k", calib=8, variant="selfcross")
    notes = ["The reference row is one run: it is the Standard setting of the Timestep axis, the Cross-only "
             "setting of the Attention axis, the 8-prompt setting of the Calibration axis and the 256-level "
             "setting of the LUT-size axis; each other row changes one factor."]
    fits = sorted((r for r in c.get("codebook", []) if r["config"].get("rule") == "lloyd"
                   and r["config"].get("variant") == "standard"),
                  key=lambda r: (r["config"]["levels"], r["config"]["n_prompts"]))
    if fits:
        notes.append("Lloyd codebooks: " + "; ".join(
            f"{r['config']['levels']} levels, {r['config']['n_prompts']} prompts: non-finite "
            f"{r['summary']['nonfinite']}, zero-width bins {r['summary']['zero_width_bins']}, empty cells "
            f"{r['summary']['empty_cells']}, stabilized by iteration {r['summary']['stabilized_at_max']}"
            for r in fits) + ".")
    return ["Ablation", "Configuration", "FID ↓", "IS ↑", "CLIP ↑"], rows, notes


def table7(led):
    c = _ctx(led)
    rows = []
    for m in ("fp16", "qdiffusion", "tfmqdm", "dgq", "lut"):
        r = _p(c, "coco1k", m)
        lp = NA if m == "fp16" else (f"{f(_v(r, 'lpips'), 3)} [{f(_v(r, 'lpips_lo'), 3)}, "
                                          f"{f(_v(r, 'lpips_hi'), 3)}]" if _v(r, "lpips") is not None else MISSING)
        rows.append([NAMES[m] + (" (ours)" if m == "lut" else ""), "FP16" if m == "fp16" else "W8A8",
                     f(_v(r, "fid")), f(_v(r, "is")), f"±{f(_v(r, 'is_sd'))}" if _v(r, "is_sd") is not None else MISSING,
                     f(_v(r, "clip"), 4), lp, NA if m == "fp16" else f(_v(r, "psnr")),
                     f"{int(r['n_images']):,}" if r else MISSING])
    cols = ["Method", "Precision", "FID ↓", "IS ↑", "IS std", "CLIP ↑", "LPIPS to FP16 ↓ (95% CI)",
            "PSNR to FP16 (dB) ↑", "# Images"]
    return cols, rows, []


def table8(led):
    c = _ctx(led)
    rows = []
    for n in (4, 8, 64):
        d = _p(c, "coco30k", "dgq", wa_calib=n)
        u = _p(c, "coco30k", "lut", wa_calib=n, calib=n)
        rows.append([n, ci(d, "fid"), f(_v(d, "clip"), 4), ci(u, "fid"), f(_v(u, "clip"), 4)])
    notes = ["At every budget both methods use DGQ weight/activation checkpoints calibrated on the same "
             "number of captions, and LUT-Quant's look-up tables are fitted on those captions."]
    return ["Calibration images", "DGQ FID ↓", "DGQ CLIP ↑", "LUT-Quant FID ↓", "LUT-Quant CLIP ↑"], rows, notes


# ------------------------------------------------------------------- supplementary
def table_s1(led):
    """Calibration cost, stage by stage."""
    c = _ctx(led)
    ckpts = {}
    for r in c.get("generation_inputs", []):
        ckpts.setdefault(r.get("calib_prompts"), r)
    rows = []
    for n in (4, 8, 64):
        fits = [r for r in c.get("codebook", []) if r["config"].get("rule") == "lloyd" and
                r["config"].get("variant") == "standard" and r["config"].get("n_prompts") == n and
                r["config"].get("levels") == 256]
        fit = fits[-1] if fits else None
        ck = ckpts.get(n)
        prof = fit["summary"].get("profile_seconds") if fit else None
        lloyd = fit["summary"].get("fit_seconds") if fit else None
        wt = ck.get("weight_seconds") if ck else None
        at = ck.get("activation_seconds") if ck else None
        tot = lambda *v: None if any(x is None for x in v) else sum(v)  # noqa: E731
        rows.append([n, f(prof, 1), f(lloyd, 1), f(tot(prof, lloyd), 1), f(wt, 0), f(at, 0), f(tot(wt, at), 0)])
    gpus = sorted({r["provenance"].get("gpu", "") for r in c.get("codebook", [])} - {""})
    notes = ["Seconds of wall-clock time. LUT profiling: 25-step generation of the calibration prompts with "
             "score recording (model loading excluded); Lloyd fitting: the 16 per-layer codebooks. DGQ weight "
             "calibration includes DGQ's calibration-trajectory generation and block reconstruction; DGQ "
             "activation calibration includes the group-wise and time-aware range calibration. LUT-Quant adds the "
             "LUT columns to the DGQ columns: its tables replace one quantizer of the calibrated DGQ model."]
    if gpus:
        notes.append("GPU: " + ", ".join(gpus) + ".")
    return ["Calibration prompts", "LUT profiling (s)", "Lloyd fitting (s)", "LUT total (s)",
            "DGQ weights (s)", "DGQ activations (s)", "DGQ total (s)"], rows, notes


def table_s2(led):
    """Variation over generator seeds (10,000 prompts)."""
    c = _ctx(led)
    seeds = sorted({r["seed"] for r in c.runs if r.get("protocol") == "coco10k"
                    and r.get("method") in ("dgq", "lut") and r.get("seed") is not None})
    per = {m: {s: _p(c, "coco10k", m, seed=s) for s in seeds} for m in ("dgq", "lut")}
    both = [s for s in seeds if all(per[m][s] is not None and per[m][s].get("fid") is not None for m in per)]
    rows = []
    for s in both:
        rows.append([s, f(_v(per["dgq"][s], "fid")), f(_v(per["lut"][s], "fid")),
                     f(_v(per["lut"][s], "fid") - _v(per["dgq"][s], "fid"), signed=True),
                     f(_v(per["dgq"][s], "clip"), 4), f(_v(per["lut"][s], "clip"), 4)])
    notes = []
    if len(both) >= 2:
        d = np.array([_v(per["dgq"][s], "fid") for s in both])
        u = np.array([_v(per["lut"][s], "fid") for s in both])
        lo, hi = stats.paired_t_ci(u, d)
        rows.append(["mean ± SD", f"{d.mean():.2f} ± {d.std(ddof=1):.2f}", f"{u.mean():.2f} ± {u.std(ddof=1):.2f}",
                     f((u - d).mean(), signed=True), NA, NA])
        notes.append(f"Base seeds {', '.join(str(s) for s in both)} (image i uses base seed + i). Paired LUT − DGQ "
                     f"FID difference {(u - d).mean():+.2f}, 95% t interval [{lo:+.2f}, {hi:+.2f}] over "
                     f"{len(both)} seeds.")
    return ["Base seed", "DGQ FID ↓", "LUT-Quant FID ↓", "Δ FID (LUT − DGQ)", "DGQ CLIP ↑", "LUT-Quant CLIP ↑"], rows, notes


def table_s3(led):
    """Bit-identity of reruns."""
    c = _ctx(led)
    rows = []
    for r in c.get("digest_comparison", []):
        rows.append([r["config"]["run_a"], r["config"]["run_b"], r["compared"], r["identical"],
                     "yes" if r["all_identical"] else "no"])
    notes = ["A rerun regenerates every image of a run with the same code, environment, inputs and GPU model and "
             "compares the SHA-256 of every PNG with the first run."] if rows else []
    return ["Run", "Rerun", "Images compared", "Bit-identical", "All identical"], rows, notes


TABLES = [
    ("I", "Table I. Comparison with state-of-the-art quantization methods on SD v1.4, MS-COCO (30K, seed 42)", table1),
    ("II", "Table II. Inference latency", table2),
    ("III", "Table III. Non-uniform baselines under a matched protocol (W8A8; 10,000 prompts, seed 42)", table3),
    ("IV", "Table IV. Domain-shift robustness without recalibration (W8A8; 95% bootstrap CIs)", table4),
    ("V", "Table V. Cross-attention quantization MSE at the normalized scale", table5),
    ("VI", "Table VI. Ablation study (W8A8; 200 images unless noted)", table6),
    ("VII", "Table VII. All methods at W8A8 on a common 1,000-prompt protocol (seed 42)", table7),
    ("VIII", "Table VIII. Calibration budget on the 30,000-prompt protocol (W8A8, seed 42; FID with 95% bootstrap CI)",
     table8),
    ("S1", "Table S1. Calibration cost by stage", table_s1),
    ("S2", "Table S2. Variation over generator seeds (W8A8; 10,000 prompts)", table_s2),
    ("S3", "Table S3. Bit-identity of reruns", table_s3),
]
KEY_COLUMNS = {"VI": 2}


# ------------------------------------------------------------------- paper values
_NUM = re.compile(r"[−-]?\d[\d,]*\.?\d*")


def _numbers(cell) -> list:
    return [(float(m.replace(",", "").replace("−", "-")), m) for m in _NUM.findall(str(cell))]


def _close(regen: float, reported: str) -> bool:
    txt = reported.replace(",", "").replace("−", "-")
    decimals = len(txt.split(".")[1]) if "." in txt else 0
    return abs(regen - float(txt)) <= 0.5 * 10 ** -decimals + 1e-9


def compare(rendered: dict, expected: dict) -> tuple[list, int]:
    """Every value printed in the paper (``expected``) against the regenerated cell.

    ``expected`` maps a table id to ``{row key: {column: printed value}}``;
    the row key is the first cell of the row (the first two for Table VI,
    joined by `` / ``), or the ``"_row"`` entry of a printed row that reports a
    condition under another label (several printed rows may name one run).
    A value matches when every number in the regenerated cell equals the
    printed number to the printed precision; a printed value without numbers
    ("stable", "Baseline", "—") must equal the regenerated cell.  Returns the
    comparison rows and the number of values that do not match.
    """
    out, bad = [], 0
    for tid, rows in expected.items():
        cols, body, _ = rendered.get(tid, ([], [], []))
        k = KEY_COLUMNS.get(tid, 1)
        index = {" / ".join(str(x) for x in r[:k]): r for r in body}
        for key, cells in rows.items():
            r = index.get(cells.get("_row", key))
            for col, printed in cells.items():
                if col.startswith("_"):
                    continue
                regen = r[cols.index(col)] if r is not None and col in cols else MISSING
                got, want = _numbers(regen), _numbers(printed)
                if MISSING in str(regen):
                    status = "no record"
                elif not want:
                    status = "match" if str(regen).strip() == str(printed).strip() else "MISMATCH"
                elif not got:
                    status = "MISMATCH"
                elif len(got) == len(want):
                    status = "match" if all(_close(g, w) for (g, _), (_, w) in zip(got, want)) else "MISMATCH"
                else:
                    status = "match" if _close(got[0][0], want[0][1]) else "MISMATCH"
                bad += status != "match"
                out.append([tid, key, col, printed, regen, status])
    return out, bad


# ---------------------------------------------------------------------------- output
def _strip(rec):
    return {k: v for k, v in rec.items() if k not in ("digests", "per_prompt", "layers", "ms")}


def _generation_inputs(runs_root: Path, led: dict) -> list:
    """The DGQ checkpoint records embedded in the generation records (for Table S1)."""
    out, seen = [], set()
    for r in led["runs"]:
        for rel in r.get("files", []):
            rec = json.loads((runs_root / rel).read_text(encoding="utf-8"))
            ck = rec.get("inputs", {}).get("dgq_ckpt", {})
            info = ck.get("record") if isinstance(ck, dict) else None
            if info and ck.get("sha256") not in seen:
                seen.add(ck.get("sha256"))
                out.append(dict(info.get("config", {}), **info.get("timings", {})))
            break
    return out


REQUIRED = ("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "S1", "S2", "S3")


def completeness(rendered: dict) -> list:
    """Every cell of the publication tables that has no valid record."""
    out = []
    for tid in REQUIRED:
        cols, rows, _ = rendered[tid]
        if not rows:
            out.append(f"Table {tid}: no valid record")
            continue
        k = KEY_COLUMNS.get(tid, 1)
        for r in rows:
            for col, cell in zip(cols, r):
                if MISSING in str(cell):
                    out.append(f"Table {tid}, {' / '.join(str(x) for x in r[:k])} / {col}: no valid record")
    if len(rendered["S2"][1]) < 3:
        out.append("Table S2: fewer than two base seeds with DGQ and LUT-Quant runs")
    return out


def _write_comparison(out: Path, expected, comparison) -> Path:
    counts = defaultdict(int)
    for row in comparison:
        counts[row[-1]] += 1
    head = (f"# Regenerated tables against the paper\n\nSource of printed values: `{Path(expected).as_posix()}`. "
            + ", ".join(f"{v} {k}" for k, v in sorted(counts.items())) + ".\n\n")
    path = out / "comparison.md"
    path.write_text(head + _table(["Table", "Row", "Column", "Printed", "Regenerated", "Status"], comparison),
                    encoding="utf-8")
    return path


def build_report(runs, out, strict: bool = True, expected=None) -> list:
    runs, out = Path(runs), Path(out)
    led = build_ledger(runs)
    led["generation_inputs"] = _generation_inputs(runs, led)
    c = _Context(led)
    rendered = {}
    for tid, title, fn in TABLES:
        rendered[tid] = fn(c)
    invalid = [r for r in led["runs"] if not r["valid"]]
    problems = list(led["problems"]) + [f"{r['run']}: {p}" for r in invalid for p in r["problems"]] + c.problems
    comparison, n_bad = None, 0
    if expected is not None:
        exp = json.loads(Path(expected).read_text(encoding="utf-8"))
        comparison, n_bad = compare(rendered, {k: v for k, v in exp.items() if not k.startswith("_")})
    if strict:
        problems += completeness(rendered)
        if comparison is not None:
            problems += [f"Table {t}, {row} / {col}: printed {p}, regenerated {g} ({st})"
                         for t, row, col, p, g, st in comparison if st != "match"]
    if strict and problems:
        out.mkdir(parents=True, exist_ok=True)
        for stale in [*out.glob("table*.csv"), *out.glob("tables.md"), *out.glob("ledger.*"),
                      *out.glob("comparison.md")]:
            stale.unlink()
        (out / "problems.md").write_text("# The records cannot produce the publication tables\n\n"
                                         + "".join(f"* {p}\n" for p in problems), encoding="utf-8")
        if comparison is not None:
            _write_comparison(out, expected, comparison)
        raise ReportError(f"the records cannot produce publication tables ({len(problems)} problems, "
                          f"listed in {out / 'problems.md'}):\n  " + "\n  ".join(problems[:40])
                          + ("\n  ..." if len(problems) > 40 else ""))

    out.mkdir(parents=True, exist_ok=True)
    files = []
    cols = ["run", "protocol", "method", "wbits", "abits", "score_levels", "wa_calib_prompts", "calib_prompts",
            "variant", "seed", "n_prompts", "n_images", "valid", "fid", "fid_lo", "fid_hi", "is", "is_sd", "is_lo",
            "is_hi", "clip", "lpips", "lpips_lo", "lpips_hi", "psnr", "image_set_sha256", "evaluated_set_sha256"]
    with open(out / "ledger.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in led["runs"]:
            w.writerow({k: r.get(k, "") for k in cols})
    files.append(out / "ledger.csv")
    compact = {k: (v if k in ("runs", "problems", "generation_inputs") else [_strip(r) for r in v])
               for k, v in led.items()}
    (out / "ledger.json").write_text(json.dumps(compact, indent=1, default=float), encoding="utf-8")
    files.append(out / "ledger.json")

    md = [f"# Results\n\nRendered by `lutq-report` from the records under `{runs.as_posix()}`. "
          f"{NA} marks a cell that does not apply.\n"]
    if problems:
        md.append("\n## Excluded records\n\n" + "".join(f"* {p}\n" for p in problems))
    for tid, title, _ in TABLES:
        cols_, rows, notes = rendered[tid]
        md.append(f"\n## {title}\n\n" + (_table(cols_, rows) if rows else f"{MISSING}\n"))
        md += [f"\n{n}\n" for n in notes]
        with open(out / f"table{tid}.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(cols_)
            w.writerows(rows)
        files.append(out / f"table{tid}.csv")
    (out / "tables.md").write_text("".join(md), encoding="utf-8")
    files.append(out / "tables.md")

    if comparison is not None:
        files.append(_write_comparison(out, expected, comparison))
    stale = out / "problems.md"
    if stale.exists():
        stale.unlink()
    return files
