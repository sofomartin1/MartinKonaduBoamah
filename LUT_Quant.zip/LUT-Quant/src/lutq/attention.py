"""Cross-attention score quantization for the Stable Diffusion v1.4 U-Net (Stage 3).

The processor replaces the post-softmax probabilities ``A`` of an attention
module before they multiply ``V`` (Algorithm 1, lines 12-17):

    s            = max(A[..., 1:])                  dynamic per-call scale
    idx          = bucketize(A[..., 1:] / s, e_l)   e_l = midpoints of the codebook C_l
    Â[..., 1:]   = C_l[idx] * s                     dequantize
    Â[..., 0]    = A[..., 0]                        <start> column kept in full precision
    O            = Â V

Self-attention (``attn1``, quantized only in the self + cross variant) has no
``<start>`` column, so every column is quantized.

Precision and storage
---------------------
The probabilities arrive in the dtype of the model (FP16 on a GPU); the
normalization, the bucketization and the dequantization run in float32, and
the result is cast back to the model dtype before it multiplies ``V``.
``torch.bucketize`` returns int64 level indices that are consumed at once:
the processor simulates 8-bit scores (256 representable values per call) and
does not store packed 8-bit attention maps.  A 256-level table occupies 1 KiB
(float32 levels); its 255 float32 bin edges add 1,020 bytes at run time
(:meth:`LUT.runtime_nbytes`).

``mode`` selects the quantizer:

* ``"fp"``    no quantization (full precision; used for profiling);
* ``"lut"``   a look-up table: LUT-Quant's Lloyd codebook, or the levels of any
              LUT placement rule of Table III;
* ``"log2"``  DGQ's logarithmic score quantizer, see :func:`log2_quant`.

Timestep-adaptive codebooks
---------------------------
The timestep-adaptive variant keeps one codebook per denoising phase: early
(steps 0-8), mid (steps 9-16) and late (steps 17-24) of the 25 DDIM steps.
:class:`StepTracker` reads the timestep passed to the U-Net and converts it to
the step index with the scheduler's list of timesteps.
"""

from __future__ import annotations

from typing import Optional

import numpy as np

PHASES = ("early", "mid", "late")
PHASE_BOUNDS = (9, 17)  # first step of "mid" and of "late" for 25 steps
MODES = ("fp", "lut", "log2")


def _torch():
    import torch

    return torch


def phase_of_step(step: int, n_steps: int = 25) -> str:
    """Phase of a 0-based step: early 0-8, mid 9-16, late 17-24 (scaled for other step counts)."""
    mid, late = (round(b * n_steps / 25) for b in PHASE_BOUNDS)
    return "early" if step < mid else ("mid" if step < late else "late")


def phase_key(layer: str, phase: str) -> str:
    """Codebook key of one phase of a timestep-adaptive codebook file."""
    return f"{layer}@{phase}"


class StepTracker:
    """Records the denoising step of every U-Net call (forward pre-hook).

    The step is the position of the received timestep in
    ``scheduler.timesteps``, which the pipeline sets before sampling.
    """

    def __init__(self, scheduler):
        self.scheduler = scheduler
        self.t: Optional[float] = None
        self.handle = None

    def attach(self, denoiser) -> "StepTracker":
        self.handle = denoiser.register_forward_pre_hook(self._hook, with_kwargs=True)
        return self

    def detach(self) -> None:
        if self.handle is not None:
            self.handle.remove()
            self.handle = None

    def _hook(self, module, args, kwargs):
        torch = _torch()
        t = kwargs.get("timestep", kwargs.get("timesteps"))
        if t is None and len(args) > 1:
            t = args[1]
        self.t = float(t.reshape(-1)[0]) if isinstance(t, torch.Tensor) else float(t)

    @property
    def step(self) -> int:
        if self.t is None:
            raise RuntimeError("StepTracker has not seen a U-Net call")
        ts = np.asarray(self.scheduler.timesteps.cpu() if hasattr(self.scheduler.timesteps, "cpu")
                        else self.scheduler.timesteps, dtype=np.float64)
        return int(np.argmin(np.abs(ts - self.t)))

    @property
    def phase(self) -> str:
        return phase_of_step(self.step, len(self.scheduler.timesteps))


class LUT:
    """Torch-side codebook with its bin edges (midpoints of consecutive entries)."""

    def __init__(self, levels: np.ndarray, device="cuda"):
        torch = _torch()
        from .codebook import midpoints

        lv = np.sort(np.asarray(levels, dtype=np.float64))
        self.levels = torch.tensor(lv, device=device, dtype=torch.float32)
        self.edges = torch.tensor(midpoints(lv), device=device, dtype=torch.float32)

    def __call__(self, a):
        torch = _torch()
        return self.levels[torch.bucketize(a, self.edges, right=True)]

    def nbytes(self) -> int:
        """Codebook payload: ``L`` float32 levels (1 KiB for 256 levels)."""
        return int(self.levels.numel() * self.levels.element_size())

    def runtime_nbytes(self) -> int:
        """Resident tensors at inference: the levels plus the ``L - 1`` float32 bin edges."""
        return self.nbytes() + int(self.edges.numel() * self.edges.element_size())


def log2_quant(a, levels: int = 256):
    """DGQ's logarithmic score quantizer on normalized scores ``a`` in [0, 1].

    Identical to DGQ's real-time ``T2ILogQuantizer`` (https://github.com/ugonfor/DGQ,
    ``quant/quant_layer_text.py``) with ``2**bits = levels``, applied after
    normalization by the maximum: ``-log2(a)`` is rounded and clamped to
    ``[0, levels - 1]``, so the levels are ``2**-n``.
    """
    torch = _torch()
    n = torch.clamp(torch.round(-torch.log2(a.float())), 0, levels - 1)
    return torch.pow(2.0, -n)


class LUTAttnProcessor:
    """Drop-in replacement for ``diffusers.models.attention_processor.AttnProcessor``.

    ``luts`` maps a phase (``None`` for a single codebook, or ``"early"``,
    ``"mid"``, ``"late"``) to a :class:`LUT`; a phase-keyed set needs a
    ``tracker``.  ``keep_first`` keeps column 0 (the ``<start>`` token of
    cross-attention) in full precision.
    """

    def __init__(self, name: str, mode: str = "lut", luts: Optional[dict] = None, levels: int = 256,
                 keep_first: bool = True, tracker: Optional[StepTracker] = None, profiler=None):
        if mode not in MODES:
            raise ValueError(f"unknown mode {mode!r}; choose from {MODES}")
        if mode == "lut" and not luts:
            raise ValueError(f"mode 'lut' needs a codebook for layer {name}")
        if luts and None not in luts and tracker is None:
            raise ValueError("timestep-adaptive codebooks need a StepTracker")
        self.name, self.mode, self.luts, self.levels = name, mode, luts or {}, levels
        self.keep_first, self.tracker, self.profiler = keep_first, tracker, profiler

    def _lut(self) -> LUT:
        return self.luts[None] if None in self.luts else self.luts[self.tracker.phase]

    def quantize_probs(self, probs):
        torch = _torch()
        body = probs[..., 1:].float() if self.keep_first else probs.float()
        s = body.amax().clamp_min(torch.finfo(torch.float32).tiny)
        a = body / s
        if self.profiler is not None:
            key = self.name if self.tracker is None else phase_key(self.name, self.tracker.phase)
            self.profiler.record(key, a, source_dtype=probs.dtype)
        if self.mode == "fp":
            return probs
        q = self._lut()(a) if self.mode == "lut" else log2_quant(a, self.levels)
        out = probs.clone()
        if self.keep_first:
            out[..., 1:] = (q * s).to(probs.dtype)
        else:
            out[...] = (q * s).to(probs.dtype)
        return out

    def __call__(self, attn, hidden_states, encoder_hidden_states=None, attention_mask=None,
                 temb=None, *args, **kwargs):
        torch = _torch()
        residual = hidden_states
        if attn.spatial_norm is not None:
            hidden_states = attn.spatial_norm(hidden_states, temb)
        input_ndim = hidden_states.ndim
        if input_ndim == 4:
            b, c, h, w = hidden_states.shape
            hidden_states = hidden_states.view(b, c, h * w).transpose(1, 2)
        batch_size, seq_len, _ = (hidden_states.shape if encoder_hidden_states is None
                                  else encoder_hidden_states.shape)
        attention_mask = attn.prepare_attention_mask(attention_mask, seq_len, batch_size)
        if attn.group_norm is not None:
            hidden_states = attn.group_norm(hidden_states.transpose(1, 2)).transpose(1, 2)
        query = attn.to_q(hidden_states)
        if encoder_hidden_states is None:
            encoder_hidden_states = hidden_states
        elif attn.norm_cross:
            encoder_hidden_states = attn.norm_encoder_hidden_states(encoder_hidden_states)
        key = attn.to_k(encoder_hidden_states)
        value = attn.to_v(encoder_hidden_states)
        query = attn.head_to_batch_dim(query)
        key = attn.head_to_batch_dim(key)
        value = attn.head_to_batch_dim(value)

        probs = attn.get_attention_scores(query, key, attention_mask)  # mask applied inside softmax
        probs = self.quantize_probs(probs)
        hidden_states = torch.bmm(probs, value)

        hidden_states = attn.batch_to_head_dim(hidden_states)
        hidden_states = attn.to_out[0](hidden_states)
        hidden_states = attn.to_out[1](hidden_states)
        if input_ndim == 4:
            hidden_states = hidden_states.transpose(-1, -2).reshape(b, c, h, w)
        if attn.residual_connection:
            hidden_states = hidden_states + residual
        return hidden_states / attn.rescale_output_factor


class MeasureProcessor(LUTAttnProcessor):
    """Leaves the scores in full precision and logs what each quantizer would do (Table V).

    For each call the normalized scores ``a`` are quantized with DGQ's log2
    quantizer and with the look-up table; the squared error of each, at the
    normalized scale, goes to that quantizer's :class:`~lutq.profiling.ErrorLog`
    (together with a seeded sample of the signed errors for Fig. 6).  The
    trajectory stays the full-precision one, so both quantizers see identical scores.
    """

    def __init__(self, name: str, lut: LUT, levels: int, logs: dict):
        super().__init__(name, "fp", levels=levels)
        self.lut, self.logs = lut, logs

    def quantize_probs(self, probs):
        torch = _torch()
        body = probs[..., 1:].float()
        a = body / body.amax().clamp_min(torch.finfo(torch.float32).tiny)
        for rule, log in self.logs.items():
            log.record(self.name, a, log2_quant(a, self.levels) if rule == "log2" else self.lut(a))
        return probs


# ----------------------------------------------------------------------- installation
def layer_key(name: str) -> str:
    """Canonical codebook key of an attention module.

    Strips a trailing ``.processor`` (diffusers processor keys) and a leading
    ``model.`` (DGQ's ``QuantModel``), so one codebook file serves both.
    """
    key = name[: -len(".processor")] if name.endswith(".processor") else name
    return key[len("model."):] if key.startswith("model.") else key


def attention_names(unet, kind: str = "cross") -> list:
    """Processor keys of the cross-attention (``attn2``) or self-attention (``attn1``) modules."""
    tag = {"cross": ".attn2.", "self": ".attn1."}[kind]
    return [k for k in unet.attn_processors.keys() if tag in k]


def short_name(key: str) -> str:
    """Layer label of Table V, e.g. ``up_blocks.1.attentions.2...attn2`` -> ``U1.A2``, mid block -> ``Mid``."""
    parts = layer_key(key).split(".")
    if parts[0] == "mid_block":
        return "Mid"
    block = {"down_blocks": "D", "up_blocks": "U"}[parts[0]] + parts[1]
    return f"{block}.A{parts[3]}" if len(parts) > 3 and parts[2] == "attentions" else block


def split_codebooks(books: dict) -> tuple[dict, bool]:
    """``{layer: {phase or None: levels}}`` from a codebook file, and whether it is phase-keyed."""
    out: dict = {}
    phased = False
    for k, v in books.items():
        if "@" in k:
            layer, phase = k.rsplit("@", 1)
            if phase not in PHASES:
                raise KeyError(f"unknown phase {phase!r} in codebook key {k!r}")
            phased = True
        else:
            layer, phase = k, None
        out.setdefault(layer_key(layer), {})[phase] = v
    return out, phased


def install(pipe, mode: str = "lut", codebooks: Optional[dict] = None, levels: int = 256,
            self_attention: bool = False, tracker: Optional[StepTracker] = None, profiler=None) -> int:
    """Install score quantizers on the attention modules of the U-Net; return the count replaced."""
    denoiser = pipe.unet
    names = attention_names(denoiser, "cross") + (attention_names(denoiser, "self") if self_attention else [])
    books, phased = split_codebooks(codebooks or {})
    if mode == "lut":
        missing = [n for n in names if layer_key(n) not in books]
        if missing:
            raise KeyError(f"no codebook for {len(missing)} of {len(names)} layers, e.g. {layer_key(missing[0])}")
        wrong = [n for n in names if any(np.asarray(v).size != levels for v in books[layer_key(n)].values())]
        if wrong:
            raise ValueError(f"codebooks do not have {levels} levels (e.g. {layer_key(wrong[0])})")
    if phased and tracker is None:
        raise ValueError("timestep-adaptive codebooks need a StepTracker attached to the U-Net")
    device = denoiser.device
    procs = dict(denoiser.attn_processors)
    for n in names:
        luts = ({p: LUT(v, device=device) for p, v in books[layer_key(n)].items()} if mode == "lut" else None)
        procs[n] = LUTAttnProcessor(layer_key(n), mode, luts, levels, keep_first=".attn2." in n,
                                    tracker=tracker, profiler=profiler)
    denoiser.set_attn_processor(procs)
    return len(names)


def install_measurement(pipe, logs: dict, codebooks: dict, levels: int = 256) -> int:
    """Install :class:`MeasureProcessor` on every cross-attention module; return the count."""
    denoiser = pipe.unet
    books, _ = split_codebooks(codebooks)
    procs = dict(denoiser.attn_processors)
    names = attention_names(denoiser, "cross")
    for n in names:
        procs[n] = MeasureProcessor(layer_key(n), LUT(books[layer_key(n)][None], device=denoiser.device), levels, logs)
    denoiser.set_attn_processor(procs)
    return len(names)


def lut_processors(pipe) -> list:
    return [p for p in pipe.unet.attn_processors.values() if isinstance(p, LUTAttnProcessor)]
