"""Protocol shared by the Q-Diffusion and TFMQ-DM generators (Python 3.8, no dependency on ``lutq``).

Both baselines run in their own code bases (the CompVis ``ldm`` implementation
of Stable Diffusion v1.4 loaded from ``sd-v1-4.ckpt``) and follow the image
protocol of every other row of the paper:

* 25 DDIM steps (eta = 0; timesteps 961, 921, ..., 1), classifier-free guidance
  7.5 with the empty prompt as the unconditional input, 512 x 512 pixels;
* image i starts from the same latent as every other method:
  ``torch.randn((1, 4, 64, 64), generator=<CUDA generator seeded 42 + i>,
  dtype=float32)`` (``lutq.pipeline.initial_latents``);
* the decoded image is clamped to [0, 1] and converted with ``round(255 x)``
  (the diffusers convention); no watermark, no safety checker;
* the file of image i is ``<index:05d>.png``.

Each generation call writes ``shard_<start>.json``; ``python baselines/common.py
merge <folder>`` joins the shards into ``provenance.json`` once every image is
present.  ``provenance.json`` records the code base and its commit,
the SD checkpoint and calibrated checkpoint digests, the quantization and
sampling settings, the prompt-list digest, the environment and the SHA-256 of
every PNG.  ``lutq-digest hash`` imports the folder only when this record
matches the protocol.
"""

import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

STEPS = 25
GUIDANCE = 7.5
SIZE = 512
LATENT = (1, 4, 64, 64)
ETA = 0.0
SEED = 42
CALIB_SEED = 0


def read_prompts(path):
    with open(path, encoding="utf-8") as f:
        return [ln.rstrip("\n") for ln in f if ln.strip()]


def sha256_text(lines):
    return hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def initial_latent(seed, index, device="cuda"):
    """The starting latent of image ``index``: float32 noise from a CUDA generator seeded seed + index.

    The same float32 draw as ``lutq.pipeline.initial_latents`` for the diffusers pipelines.
    """
    import torch

    g = torch.Generator(device=device).manual_seed(int(seed) + int(index))
    return torch.randn(LATENT, generator=g, device=device, dtype=torch.float32)


def to_png(x, path):
    """Decoded sample in [-1, 1] (1 x 3 x H x W) -> PNG at ``path``; returns the SHA-256 of the file."""
    import numpy as np
    import torch
    from PIL import Image

    x = torch.clamp((x.float() + 1.0) / 2.0, 0.0, 1.0)[0].permute(1, 2, 0).cpu().numpy()
    img = Image.fromarray(np.round(x * 255.0).astype(np.uint8))
    tmp = str(path) + ".part"
    img.save(tmp, format="PNG")
    os.replace(tmp, path)
    return sha256_file(path)


def git_commit(path):
    try:
        return subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"],
                                       stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "unknown"


def environment():
    try:
        freeze = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], stderr=subprocess.DEVNULL).decode()
    except Exception:
        freeze = ""
    gpu = ""
    try:
        import torch

        if torch.cuda.is_available():
            gpu = torch.cuda.get_device_name(0)
    except Exception:
        pass
    return {"python": platform.python_version(), "platform": platform.platform(), "gpu": gpu,
            "packages": sorted(freeze.split())}


def check_checkpoint(path, expected_sha256=None):
    digest = sha256_file(path)
    if expected_sha256 and digest != expected_sha256:
        sys.exit(f"{path}: SHA-256 {digest}, the lock records {expected_sha256}")
    return digest


def locked_sd_sha256(locks_dir):
    p = Path(locks_dir) / "models.json"
    if not p.exists():
        return None
    return json.loads(p.read_text()).get("sd14_original", {}).get("sha256")


def common_args(ap):
    ap.add_argument("--repo", required=True, help="checkout of the code base (third_party/<name>)")
    ap.add_argument("--sd-ckpt", required=True, help="sd-v1-4.ckpt (scripts/fetch_models.py --original)")
    ap.add_argument("--locks", default="locks", help="lock folder of this repository (checks sd-v1-4.ckpt)")
    ap.add_argument("--wbits", type=int, default=8)
    ap.add_argument("--abits", type=int, default=8)
    ap.add_argument("--softmax-bits", type=int, default=8, help="bits of the post-softmax attention scores")


def parser(description):
    ap = argparse.ArgumentParser(description=description)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("calibrate", help="calibrate the quantized U-Net on the calibration captions")
    common_args(c)
    c.add_argument("--calib-prompts", required=True, help="data/prompts/coco_calib64.txt")
    c.add_argument("--seed", type=int, default=CALIB_SEED, help="seed of the calibration trajectories")
    c.add_argument("--out", required=True, help="calibrated checkpoint (.pth); a .json record is written beside it")
    g = sub.add_parser("generate", help="generate one image per prompt with a calibrated checkpoint")
    common_args(g)
    g.add_argument("--cali-ckpt", required=True, help="checkpoint written by 'calibrate'")
    g.add_argument("--prompts", required=True, help="data/prompts/<protocol>.txt")
    g.add_argument("--protocol", required=True)
    g.add_argument("--seed", type=int, default=SEED, help="image i uses seed + i")
    g.add_argument("--start", type=int, default=0)
    g.add_argument("--count", type=int, default=None)
    g.add_argument("--out", required=True, help="output folder: <index:05d>.png and provenance.json")
    return ap


def write_calibration_record(args, method, repo, prompts, extra):
    rec = {"method": method, "code_base": method, "repository": extra.pop("repository"),
           "commit": git_commit(repo), "wbits": args.wbits, "abits": args.abits,
           "softmax_bits": args.softmax_bits, "calib_prompts": len(prompts),
           "calib_prompts_sha256": sha256_text(prompts), "calib_seed": args.seed, "steps": STEPS,
           "sampler": f"DDIM, eta {ETA}", "guidance": GUIDANCE,
           "sd_checkpoint": {"file": Path(args.sd_ckpt).name, "sha256": extra.pop("sd_sha256")},
           "checkpoint_sha256": sha256_file(args.out), "command": sys.argv, "environment": environment(),
           "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    rec.update(extra)
    Path(str(args.out) + ".json").write_text(json.dumps(rec, indent=2))


def generation_loop(args, method, repo, model, sampler, prompts, extra):
    """Generate images ``start .. start+count-1`` and write ``shard_<start>.json`` with their digests."""
    import torch
    from contextlib import nullcontext

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    end = len(prompts) if args.count is None else min(len(prompts), args.start + args.count)
    digests = []
    with torch.no_grad(), torch.autocast("cuda"), (model.ema_scope() if hasattr(model, "ema_scope") else nullcontext()):
        uc = model.get_learned_conditioning([""])
        for i in range(args.start, end):
            c = model.get_learned_conditioning([prompts[i]])
            z, _ = sampler.sample(S=STEPS, conditioning=c, batch_size=1, shape=list(LATENT[1:]), verbose=False,
                                  unconditional_guidance_scale=GUIDANCE, unconditional_conditioning=uc,
                                  eta=ETA, x_T=initial_latent(args.seed, i))
            digests.append(to_png(model.decode_first_stage(z), out / f"{i:05d}.png"))
    calib = json.loads(Path(str(args.cali_ckpt) + ".json").read_text())
    rec = {"method": method, "code_base": method, "repository": extra["repository"], "commit": git_commit(repo),
           "wbits": args.wbits, "abits": args.abits, "softmax_bits": args.softmax_bits,
           "calib_prompts": calib["calib_prompts"], "calib_prompts_sha256": calib["calib_prompts_sha256"],
           "checkpoint_sha256": sha256_file(args.cali_ckpt), "sd_checkpoint": calib["sd_checkpoint"],
           "protocol": args.protocol, "prompts_sha256": sha256_text(prompts), "n_prompts": len(prompts),
           "seed": args.seed, "steps": STEPS, "guidance": GUIDANCE, "size": SIZE, "sampler": "DDIM, eta %s" % ETA,
           "initial_latent": "torch.randn((1, 4, 64, 64), CUDA generator seeded seed + i, float32)",
           "conversion": "clamp((x + 1) / 2, 0, 1), round(255 x); no watermark, no safety checker",
           "precision": "torch.autocast('cuda'), as in the code base's txt2img.py",
           "environment": environment(), "command": sys.argv,
           "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "shard": {"start": args.start, "count": end - args.start}, "digests": digests}
    (out / ("shard_%05d.json" % args.start)).write_text(json.dumps(rec, indent=1))
    print("%d images written to %s" % (end - args.start, out))


SHARD_ONLY = ("shard", "digests", "command", "time_utc", "environment")


def merge(folder):
    """Join the shard records of a folder into ``provenance.json`` once every image is present."""
    folder = Path(folder)
    shards = [json.loads(p.read_text()) for p in sorted(folder.glob("shard_*.json"))]
    if not shards:
        sys.exit("no shard_*.json in %s" % folder)
    fixed = [{k: v for k, v in r.items() if k not in SHARD_ONLY} for r in shards]
    if any(f != fixed[0] for f in fixed[1:]):
        sys.exit("the shards of %s were generated with different settings" % folder)
    n = fixed[0]["n_prompts"]
    digests = [None] * n
    for r in shards:
        for j, h in enumerate(r["digests"]):
            i = r["shard"]["start"] + j
            if digests[i] not in (None, h):
                sys.exit("shards disagree on image %05d" % i)
            digests[i] = h
    missing = [i for i, h in enumerate(digests) if h is None]
    if missing:
        sys.exit("%d of %d images missing in %s, first %05d" % (len(missing), n, folder, missing[0]))
    for i, h in enumerate(digests):
        if sha256_file(folder / ("%05d.png" % i)) != h:
            sys.exit("%05d.png differs from its shard record" % i)
    prov = dict(fixed[0], digests=digests, shards=[{k: r[k] for k in SHARD_ONLY if k != "digests"} for r in shards])
    (folder / "provenance.json").write_text(json.dumps(prov, indent=1))
    print("wrote %s (%d images)" % (folder / "provenance.json", n))


def load_ldm(repo, config_rel, ckpt):
    """The CompVis LatentDiffusion model of a code base, loaded from ``sd-v1-4.ckpt`` (as its txt2img.py does)."""
    import torch
    from omegaconf import OmegaConf
    from ldm.util import instantiate_from_config

    config = OmegaConf.load(str(Path(repo) / config_rel))
    sd = torch.load(ckpt, map_location="cpu")["state_dict"]
    model = instantiate_from_config(config.model)
    model.load_state_dict(sd, strict=False)
    return model.cuda().eval()


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "merge":
        merge(sys.argv[2])
    else:
        sys.exit("usage: python baselines/common.py merge <image folder>")
