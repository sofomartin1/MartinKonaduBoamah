"""Q-Diffusion (Li et al., ICCV 2023) at W8A8 on SD v1.4, under the protocol of the paper.

Runs in the ``lutq-qdiff`` environment with the official code base on
``PYTHONPATH`` (``scripts/setup_baselines.sh``, ``scripts/run_baselines.sh``):

    python baselines/qdiffusion/run.py calibrate --repo third_party/q-diffusion --sd-ckpt <sd-v1-4.ckpt> \\
        --calib-prompts data/prompts/coco_calib64.txt --out checkpoints/qdiffusion/w8a8_c64.pth
    python baselines/qdiffusion/run.py generate --repo third_party/q-diffusion --sd-ckpt <sd-v1-4.ckpt> \\
        --cali-ckpt checkpoints/qdiffusion/w8a8_c64.pth --prompts data/prompts/coco1k.txt --protocol coco1k \\
        --out outputs/baselines/coco1k/qdiffusion

Calibration follows ``scripts/txt2img.py`` of the code base (``--ptq --quant_mode qdiff --quant_act
--split --running_stat --no_grad_ckpt --cond``, channel-wise MSE weight quantizers with block
reconstruction and learned rounding, MSE activation quantizers with LSQ refinement) with two
settings of the paper: the calibration set is the trajectories of the 64 calibration captions
under 25-step DDIM sampling (every step, ``cali_st = 25``, ``cali_n = 64``), and the
post-softmax attention scores use 8 bits like every other W8A8 row.  The code base does not ship
the script that collects SD calibration trajectories; :func:`collect` records the inputs of the
denoiser (latent, timestep, conditional and unconditional text embeddings) at every step.
"""

import gc
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import common  # noqa: E402

REPOSITORY = "https://github.com/Xiuyu-Li/q-diffusion"
COMMIT = "715783da70baa267321d6700ceb8941400c309d1"
CONFIG = "configs/stable-diffusion/v1-inference.yaml"
CALI = dict(batch_size=8, iters_w=20000, iters_a=5000, lr=4e-4, p=2.4)


def _model(args):
    from ldm.models.diffusion.ddim import DDIMSampler

    model = common.load_ldm(args.repo, CONFIG, args.sd_ckpt)
    return model, DDIMSampler(model)


def _qnn(sampler, args, resume):
    from qdiff import QuantModel

    setattr(sampler.model.model.diffusion_model, "split", True)
    wq = {"n_bits": args.wbits, "channel_wise": True, "scale_method": "max" if resume else "mse"}
    aq = {"n_bits": args.abits, "channel_wise": False, "scale_method": "max" if resume else "mse", "leaf_param": True}
    qnn = QuantModel(model=sampler.model.model.diffusion_model, weight_quant_params=wq, act_quant_params=aq,
                     act_quant_mode="qdiff", sm_abit=args.softmax_bits)
    qnn.cuda().eval()
    qnn.set_grad_ckpt(False)
    return qnn


def collect(model, sampler, prompts, seed):
    """Denoiser inputs at every DDIM step for every prompt: {"xs", "ts", "cs", "ucs"}, one tensor per step."""
    import torch

    steps = [{"xs": [], "ts": [], "cs": [], "ucs": []} for _ in range(common.STEPS)]
    orig = sampler.p_sample_ddim

    def hook(x, c, t, index=None, **kw):
        s = steps[common.STEPS - 1 - index]
        s["xs"].append(x.detach().float().cpu())
        s["ts"].append(t.detach().cpu())
        s["cs"].append(c.detach().float().cpu())
        s["ucs"].append(kw["unconditional_conditioning"].detach().float().cpu())
        return orig(x, c, t, index=index, **kw)

    sampler.p_sample_ddim = hook
    with torch.no_grad(), torch.autocast("cuda"), model.ema_scope():
        uc = model.get_learned_conditioning([""])
        for i, p in enumerate(prompts):
            c = model.get_learned_conditioning([p])
            sampler.sample(S=common.STEPS, conditioning=c, batch_size=1, shape=list(common.LATENT[1:]), verbose=False,
                           unconditional_guidance_scale=common.GUIDANCE, unconditional_conditioning=uc,
                           eta=common.ETA, x_T=common.initial_latent(seed, i))
    sampler.p_sample_ddim = orig
    return {k: [torch.cat(s[k]) for s in steps] for k in ("xs", "ts", "cs", "ucs")}


def calibrate(args):
    import numpy as np
    import torch
    from pytorch_lightning import seed_everything
    from qdiff import BaseQuantBlock, QuantModule, block_reconstruction, layer_reconstruction
    from qdiff.adaptive_rounding import AdaRoundQuantizer
    from qdiff.quant_layer import UniformAffineQuantizer
    from qdiff.utils import get_train_samples

    seed_everything(args.seed)
    sd_sha = common.check_checkpoint(args.sd_ckpt, common.locked_sd_sha256(args.locks))
    prompts = common.read_prompts(args.calib_prompts)
    t0 = time.time()
    model, sampler = _model(args)
    sample_data = collect(model, sampler, prompts, args.seed)
    opt = SimpleNamespace(cali_n=len(prompts), cali_st=common.STEPS, cond=True)
    cali_data = get_train_samples(opt, sample_data, common.STEPS)
    del sample_data
    gc.collect()
    cali_xs, cali_ts, cali_cs = cali_data
    t_data = time.time() - t0

    qnn = _qnn(sampler, args, resume=False)
    qnn.set_quant_state(True, False)
    with torch.no_grad():
        qnn(cali_xs[:8].cuda(), cali_ts[:8].cuda(), cali_cs[:8].cuda())

    def recon_model(module, **kwargs):
        for name, child in module.named_children():
            if isinstance(child, QuantModule):
                if not child.ignore_reconstruction:
                    layer_reconstruction(qnn, child, **kwargs)
            elif isinstance(child, BaseQuantBlock):
                if not child.ignore_reconstruction:
                    block_reconstruction(qnn, child, **kwargs)
            else:
                recon_model(child, **kwargs)

    recon_model(qnn, cali_data=cali_data, batch_size=CALI["batch_size"], iters=CALI["iters_w"], weight=0.01,
                asym=True, b_range=(20, 2), warmup=0.2, act_quant=False, opt_mode="mse", cond=True)
    qnn.set_quant_state(weight_quant=True, act_quant=False)
    t_w = time.time() - t0 - t_data

    qnn.set_quant_state(True, True)
    rng = np.random.RandomState(args.seed)
    with torch.no_grad():
        inds = rng.choice(cali_xs.shape[0], 16, replace=False)
        qnn(cali_xs[inds].cuda(), cali_ts[inds].cuda(), cali_cs[inds].cuda())
        inds = np.arange(cali_xs.shape[0])
        rng.shuffle(inds)
        qnn.set_running_stat(True, False)
        for i in range(int(cali_xs.size(0) / 16)):
            b = inds[i * 16:(i + 1) * 16]
            qnn(cali_xs[b].cuda(), cali_ts[b].cuda(), cali_cs[b].cuda())
        qnn.set_running_stat(False, False)
    recon_model(qnn, cali_data=cali_data, batch_size=CALI["batch_size"], iters=CALI["iters_a"], act_quant=True,
                opt_mode="mse", lr=CALI["lr"], p=CALI["p"], cond=True)
    qnn.set_quant_state(weight_quant=True, act_quant=True)
    for m in qnn.model.modules():
        if isinstance(m, AdaRoundQuantizer):
            m.zero_point = torch.nn.Parameter(m.zero_point)
            m.delta = torch.nn.Parameter(m.delta)
        elif isinstance(m, UniformAffineQuantizer) and m.zero_point is not None:
            zp = m.zero_point if torch.is_tensor(m.zero_point) else torch.tensor(float(m.zero_point))
            m.zero_point = torch.nn.Parameter(zp)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    torch.save(qnn.state_dict(), args.out)
    common.write_calibration_record(args, "qdiffusion", args.repo, prompts, {
        "repository": REPOSITORY, "sd_sha256": sd_sha, "calibration": dict(CALI, cali_st=common.STEPS,
                                                                           cali_n=len(prompts), running_stat=True,
                                                                           split=True, quant_mode="qdiff"),
        "timings": {"trajectory_seconds": t_data, "weight_seconds": t_w,
                    "activation_seconds": time.time() - t0 - t_data - t_w}})


def generate(args):
    import torch
    from qdiff.utils import resume_cali_model

    common.check_checkpoint(args.sd_ckpt, common.locked_sd_sha256(args.locks))
    model, sampler = _model(args)
    qnn = _qnn(sampler, args, resume=True)
    shapes = (torch.randn(1, 4, 64, 64), torch.randint(0, 1000, (1,)), torch.randn(1, 77, 768))
    resume_cali_model(qnn, args.cali_ckpt, shapes, True, "qdiff", cond=True)
    sampler.model.model.diffusion_model = qnn
    common.generation_loop(args, "qdiffusion", args.repo, model, sampler, common.read_prompts(args.prompts),
                           {"repository": REPOSITORY})


if __name__ == "__main__":
    a = common.parser(__doc__.splitlines()[0]).parse_args()
    if common.git_commit(a.repo) != COMMIT:
        sys.exit(f"{a.repo} is not at commit {COMMIT} (scripts/setup_baselines.sh)")
    {"calibrate": calibrate, "generate": generate}[a.cmd](a)
