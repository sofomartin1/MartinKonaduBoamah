"""TFMQ-DM (Huang et al., CVPR 2024) at W8A8 on SD v1.4, under the protocol of the paper.

Runs in the ``lutq-tfmq`` environment with the official code base on
``PYTHONPATH`` (the repository root for ``quant`` and ``ddim``, ``stable-diffusion/``
for ``ldm``; ``scripts/setup_baselines.sh``, ``scripts/run_baselines.sh``):

    python baselines/tfmqdm/run.py calibrate --repo third_party/TFMQ-DM --sd-ckpt <sd-v1-4.ckpt> \\
        --calib-prompts data/prompts/coco_calib64.txt --out checkpoints/tfmqdm/w8a8_c64.pth
    python baselines/tfmqdm/run.py generate --repo third_party/TFMQ-DM --sd-ckpt <sd-v1-4.ckpt> \\
        --cali-ckpt checkpoints/tfmqdm/w8a8_c64.pth --prompts data/prompts/coco1k.txt --protocol coco1k \\
        --out outputs/baselines/coco1k/tfmqdm

Calibration follows ``txt2img.py --ptq --cali --use_aq --cond --no_grad_ckpt`` of the code base
(temporal information aware reconstruction and finite set calibration, channel-wise MSE weight
quantizers with block reconstruction, running-statistics activation ranges, one activation
range set per timestep) with the settings of the paper: 25-step DDIM trajectories of the 64
calibration captions from the code base's own collector (``generate_cali_text_guided_data``),
hence ``interval = 2 x 64`` samples per timestep, and 8-bit post-softmax attention scores.
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import common  # noqa: E402

REPOSITORY = "https://github.com/ModelTC/TFMQ-DM"
COMMIT = "66c2d61a4f4cb0df2b56a9f82a276f04f1e84a9b"
CONFIG = "stable-diffusion/configs/stable-diffusion/v1-inference.yaml"
CALI = dict(iters=20000, batch_size=8, w=0.01, warmup=0.2, asym=True, running_stat=True)


def _model(args):
    from ldm.models.diffusion.ddim import DDIMSampler

    model = common.load_ldm(args.repo, CONFIG, args.sd_ckpt)
    return model, DDIMSampler(model)


def _params(args, cali):
    from quant.quant_layer import Scaler

    wq = {"bits": args.wbits, "channel_wise": True, "scaler": Scaler.MSE if cali else Scaler.MINMAX}
    aq = {"bits": args.abits, "channel_wise": False, "scaler": Scaler.MSE if cali else Scaler.MINMAX,
          "leaf_param": True}
    return wq, aq


def calibrate(args):
    import torch
    from pytorch_lightning import seed_everything
    from quant.calibration import cali_model
    from quant.data_generate import generate_cali_text_guided_data
    from quant.quant_layer import QMODE
    from quant.quant_model import QuantModel
    from quant.reconstruction_util import RLOSS

    seed_everything(args.seed)
    sd_sha = common.check_checkpoint(args.sd_ckpt, common.locked_sd_sha256(args.locks))
    prompts = common.read_prompts(args.calib_prompts)
    t0 = time.time()
    model, sampler = _model(args)
    with model.ema_scope():
        cali_data = generate_cali_text_guided_data(model, sampler, T=common.STEPS, c=1, batch_size=1,
                                                   prompts=prompts, shape=list(common.LATENT[1:]),
                                                   precision_scope=torch.autocast)
    t_data = time.time() - t0
    torch.cuda.empty_cache()
    setattr(sampler.model.model.diffusion_model, "split", True)
    wq, aq = _params(args, cali=True)
    qnn = QuantModel(model=sampler.model.model.diffusion_model, wq_params=wq, aq_params=aq,
                     softmax_a_bit=args.softmax_bits, aq_mode=[QMODE.NORMAL.value, QMODE.QDIFF.value])
    qnn.to("cuda").eval()
    qnn.set_grad_ckpt(False)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    interval = 2 * len(prompts)
    cali_model(qnn=qnn, use_aq=True, path=args.out, running_stat=CALI["running_stat"], interval=interval,
               w_cali_data=cali_data, a_cali_data=cali_data, iters=CALI["iters"], batch_size=CALI["batch_size"],
               w=CALI["w"], asym=CALI["asym"], warmup=CALI["warmup"], opt_mode=RLOSS.MSE, multi_gpu=False)
    common.write_calibration_record(args, "tfmqdm", args.repo, prompts, {
        "repository": REPOSITORY, "sd_sha256": sd_sha,
        "calibration": dict(CALI, interval=interval, timesteps=common.STEPS, trajectories="code base collector"),
        "timings": {"trajectory_seconds": t_data, "calibration_seconds": time.time() - t0 - t_data}})


def generate(args):
    import torch
    from quant.calibration import load_cali_model
    from quant.quant_layer import QMODE
    from quant.quant_model import QuantModel

    common.check_checkpoint(args.sd_ckpt, common.locked_sd_sha256(args.locks))
    model, sampler = _model(args)
    setattr(sampler.model.model.diffusion_model, "split", True)
    wq, aq = _params(args, cali=False)
    qnn = QuantModel(model=sampler.model.model.diffusion_model, wq_params=wq, aq_params=aq, cali=False,
                     softmax_a_bit=args.softmax_bits, aq_mode=[QMODE.NORMAL.value, QMODE.QDIFF.value])
    qnn.to("cuda").eval()
    qnn.set_grad_ckpt(False)
    shapes = (torch.randn(1, 4, 64, 64), torch.randint(0, 1000, (1,)), torch.randn(1, 77, 768))
    load_cali_model(qnn, shapes, use_aq=True, path=args.cali_ckpt)
    sampler.model.model.diffusion_model = qnn
    ckpt = torch.load(args.cali_ckpt)                   # one activation range set per timestep
    tot = len(list(ckpt.keys())) - 1
    sampler.model.model.tot = 1000 // tot
    model.model.t_max = tot - 1
    sampler.model.model.ckpt = ckpt
    sampler.model.model.iter = 0
    common.generation_loop(args, "tfmqdm", args.repo, model, sampler, common.read_prompts(args.prompts),
                           {"repository": REPOSITORY})


if __name__ == "__main__":
    a = common.parser(__doc__.splitlines()[0]).parse_args()
    if common.git_commit(a.repo) != COMMIT:
        sys.exit(f"{a.repo} is not at commit {COMMIT} (scripts/setup_baselines.sh)")
    {"calibrate": calibrate, "generate": generate}[a.cmd](a)
