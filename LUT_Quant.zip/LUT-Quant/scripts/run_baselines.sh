#!/usr/bin/env bash
# Q-Diffusion and TFMQ-DM images of one protocol, in their own environments.
#
#   scripts/run_baselines.sh qdiffusion coco30k      calibrates once (64 captions), then generates
#   scripts/run_baselines.sh tfmqdm coco1k
#   scripts/run_baselines.sh tfmqdm coco1k merge     after sharded generation: join the shard records
#
# writes outputs/baselines/<protocol>/<method>/<index:05d>.png and provenance.json, which
# `scripts/run_experiments.sh table1` / `table7` import with `lutq-digest hash`.  The prompt
# lists come from data/prompts (scripts/fetch_data.py), sd-v1-4.ckpt from
# scripts/fetch_models.py --original.  SHARDS / SHARD split generation over GPUs.
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT=$PWD

method=${1:?method: qdiffusion or tfmqdm}; protocol=${2:?protocol, e.g. coco30k}; step=${3:-all}
BASELINES=$(realpath -m "${BASELINES:-outputs/baselines}")
SHARDS=${SHARDS:-1}; SHARD=${SHARD:-0}
SD_CKPT=$ROOT/checkpoints/sd/sd-v1-4.ckpt
[[ -f $SD_CKPT ]] || { echo "missing $SD_CKPT: python scripts/fetch_models.py --original" >&2; exit 3; }

case $method in
  qdiffusion) env=lutq-qdiff; repo=$ROOT/third_party/q-diffusion; pp=$repo ;;
  tfmqdm)     env=lutq-tfmq;  repo=$ROOT/third_party/TFMQ-DM;     pp=$repo:$repo/stable-diffusion ;;
  *) echo "unknown method $method" >&2; exit 2 ;;
esac
for f in data/prompts/coco_calib64.txt "data/prompts/$protocol.txt"; do
  [[ -f $f ]] || { echo "missing $f: python scripts/fetch_data.py" >&2; exit 3; }
done

CKPT=$ROOT/checkpoints/$method/w8a8_c64.pth
run() { (cd "$repo" && PYTHONPATH="$pp" conda run --no-capture-output -n "$env" python "$ROOT/baselines/$method/run.py" "$@"); }
common=(--repo "$repo" --sd-ckpt "$SD_CKPT" --locks "$ROOT/locks")

if [[ ! -f $CKPT ]]; then
  mkdir -p "$(dirname "$CKPT")"
  run calibrate "${common[@]}" --calib-prompts "$ROOT/data/prompts/coco_calib64.txt" --out "$CKPT" \
      2>&1 | tee "$CKPT.log"
fi
n=$(wc -l < "data/prompts/$protocol.txt"); per=$(( (n + SHARDS - 1) / SHARDS ))
out=$BASELINES/$protocol/$method
mkdir -p "$out"
if [[ $step == merge ]]; then python baselines/common.py merge "$out"; exit 0; fi
run generate "${common[@]}" --cali-ckpt "$CKPT" --prompts "$ROOT/data/prompts/$protocol.txt" --protocol "$protocol" \
    --start $(( SHARD * per )) --count "$per" --out "$out" 2>&1 | tee -a "$out/generate.log"
[[ $SHARDS == 1 ]] && python baselines/common.py merge "$out"
