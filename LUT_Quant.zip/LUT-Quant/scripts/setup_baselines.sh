#!/usr/bin/env bash
# Clone Q-Diffusion and TFMQ-DM at the commits used for the experiments and create their environments.
#
#   scripts/setup_baselines.sh            third_party/q-diffusion, third_party/TFMQ-DM; conda envs lutq-qdiff, lutq-tfmq
#
# sd-v1-4.ckpt, which both code bases load, is fetched in the main environment:
#   python scripts/fetch_models.py --original
set -euo pipefail
cd "$(dirname "$0")/.."

clone() {  # url commit dest
  [[ -d $3/.git ]] || git clone "$1" "$3"
  git -C "$3" fetch --quiet origin
  git -C "$3" checkout --quiet "$2"
  echo "$3 at $(git -C "$3" rev-parse HEAD)"
}

clone https://github.com/Xiuyu-Li/q-diffusion 715783da70baa267321d6700ceb8941400c309d1 third_party/q-diffusion
clone https://github.com/ModelTC/TFMQ-DM 66c2d61a4f4cb0df2b56a9f82a276f04f1e84a9b third_party/TFMQ-DM

for env in qdiff:envs/environment-qdiffusion.yml tfmq:envs/environment-tfmqdm.yml; do
  name="lutq-${env%%:*}"
  conda env list | grep -q "^$name " || conda env create -f "${env#*:}"
done
echo "next: python scripts/fetch_models.py --original   (main environment), then scripts/run_baselines.sh"
