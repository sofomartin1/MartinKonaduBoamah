#!/usr/bin/env bash
# Merged DGQ weight + activation checkpoint of SD v1.4 for one setting.
#
#   scripts/dgq_quantize.sh W A N          W weight bits, A activation bits, N calibration captions (4, 8 or 64)
#
# writes checkpoints/dgq/sd14_w<W>a<A>_c<N>.pth_merged and, next to it, a JSON
# record (bit-widths, calibration captions, DGQ commit, SHA-256) that
# `lutq-generate` reads and stores with every run.
#
# Steps, all with DGQ's own code (third_party/DGQ, pinned by scripts/setup_dgq.sh):
#   1. weight quantization: channel-wise weights refined by block reconstruction with
#      learned rounding (DGQ's src/quantize_weight.py with its SD v1.4 settings);
#   2. activation calibration: outlier-preserving group-wise activations (8 groups),
#      time-aware activation ranges, and the logarithmic real-time start-peak score
#      quantizer at 8 bits (256 levels);
#   3. DGQ's results/merge.py.
# The record holds the wall-clock seconds of steps 1 and 2 (Table S1).  DGQ's
# calibration trajectories are sampled with the pipeline's default scheduler
# (PNDM, 25 steps): its 26 U-Net calls visit the 25 timesteps t = 961, 921, ..., 1
# of the 25-step DDIM sampler used for every image (921 twice).
# Both calibration steps use the first N captions of data/prompts/coco_calib64.txt,
# passed to DGQ as a COCO-format caption file, so a budget of N captions holds for
# the whole pipeline (Table VIII).
#
# Run inside the lutq-dgq environment with DGQ on PYTHONPATH (source scripts/dgq_env.sh).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

W=${1:?weight bits}; A=${2:?activation bits}; N=${3:?calibration captions}
# data/ and locks/ of this repository, whatever directory DGQ's scripts run in
export LUTQ_DATA=$(realpath -m "${LUTQ_DATA:-$ROOT/data}")
export LUTQ_LOCKS=$(realpath -m "${LUTQ_LOCKS:-$ROOT/locks}")
SCORE_BITS=8
DGQ="$ROOT/third_party/DGQ"
CKPTS="$ROOT/checkpoints/dgq"
WORK="$CKPTS/work/c$N"
mkdir -p "$WORK"
export DIFFUSERS_REWRITE=sd

CAPTIONS="$WORK/calibration_captions.json"
python - "$ROOT" "$CAPTIONS" "$N" <<'PY'
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / "src"))
from lutq.data import prompts_for
caps = prompts_for("coco_calib64")[: int(sys.argv[3])]
json.dump({"annotations": [{"id": i, "image_id": i, "caption": c} for i, c in enumerate(caps)]},
          open(sys.argv[2], "w"))
PY

# DGQ's rewritten SD v1.4 folder, built from the locked snapshot (locks/models.json)
python -c "import sys; sys.path.insert(0, '$ROOT/src'); from lutq.integrations.dgq import ensure_pretrained; print(ensure_pretrained())"

newest() { ls -t $1 2>/dev/null | head -1; }
cd "$DGQ"

# 1. weights
WCKPT="$CKPTS/sd14_w${W}_c${N}.pth_weight_only"
T0=$(date +%s)
if [[ ! -f $WCKPT ]]; then
  python src/quantize_weight.py --wq "$W" --cali_prompt_data_n "$N" --coco_path "$CAPTIONS" \
         --cali_data_path "$WORK/cali_data_25steps" --step_size 25 \
         --tib_recon False --no_recon False --fast False --outdir "$WORK/weight_w${W}" \
         2>&1 | tee "$WORK/weight_w${W}.log"
  cp "$(newest "$WORK/weight_w${W}/*/cali_ckpt.pth_weight_only")" "$WCKPT"
fi

T1=$(date +%s)
[[ -f $WORK/weight_seconds ]] || echo $(( T1 - T0 )) > "$WORK/weight_seconds"

# 2. activations and the score quantizer
OUT="$WORK/act_w${W}a${A}"
python src/quantize_act.py --outdir "$OUT" --weight_only_ckpt "$WCKPT" \
       --wq "$W" --aq "$A" --softmax_a_bit "$SCORE_BITS" \
       --time_aware_aqtizer True --t2i_log_quant True --t2i_real_time True --t2i_start_peak True \
       --group_num 8 --group_mode minmax --cali_prompt_data_n "$N" --coco_path "$CAPTIONS" \
       --cali_data_path "$WORK/cali_data_25steps" --step_size 25 \
       2>&1 | tee "$OUT.log"
ACKPT=$(newest "$OUT/*/cali_ckpt_activation_w${W}a${A}g8.pth")
T2=$(date +%s)
echo $(( T2 - T1 )) > "$WORK/act_w${W}a${A}_seconds"

# 3. merge and record
python results/merge.py "$WCKPT" "$ACKPT"
FINAL="$CKPTS/sd14_w${W}a${A}_c${N}.pth_merged"
mv "${ACKPT}_merged" "$FINAL"
python - "$ROOT" "$FINAL" "$CAPTIONS" "$W" "$A" "$N" "$SCORE_BITS" "$(cat "$WORK/weight_seconds")" \
         "$(cat "$WORK/act_w${W}a${A}_seconds")" <<'PY'
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / "src"))
import torch  # noqa: F401  (GPU name in the provenance)
from lutq import records
from lutq.integrations.dgq import dgq_commit
final, captions_file = sys.argv[2], sys.argv[3]
w, a, n, sb, tw, ta = map(int, sys.argv[4:10])
# the captions DGQ was calibrated on, exactly as passed to its scripts
captions = [x["caption"] for x in json.load(open(captions_file))["annotations"]]
assert len(captions) == n, (len(captions), n)
records.write_record(final + ".json", "dgq_checkpoint",
                     {"model": "sd14", "wbits": w, "abits": a, "calib_prompts": n, "score_bits": sb,
                      "groups": 8, "time_aware": True, "steps": 25, "dgq_commit": dgq_commit()},
                     inputs={"prompts_sha256": records.sha256_text(captions),
                             "captions_file": {"file": Path(captions_file).name,
                                               "sha256": records.sha256_file(captions_file)}},
                     outputs={"checkpoint": {"file": Path(final).name, "sha256": records.sha256_file(final)}},
                     timings={"weight_seconds": tw, "activation_seconds": ta})
PY
