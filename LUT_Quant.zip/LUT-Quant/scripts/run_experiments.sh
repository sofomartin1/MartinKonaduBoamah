#!/usr/bin/env bash
# Experiment driver: one sub-command per table of the paper.
#
#   scripts/run_experiments.sh calibrate     look-up tables of every table                         main env
#   scripts/run_experiments.sh table1        30K MS-COCO: FP16, Q-Diffusion, TFMQ-DM, DGQ, LUT-Quant
#   scripts/run_experiments.sh table2        latency and kernel profile: FP16, DGQ, LUT-Quant          DGQ env
#   scripts/run_experiments.sh table3        10K: ACIQ, histogram, learned log, Lloyd (LUT-Quant), DGQ
#   scripts/run_experiments.sh table4        PartiPrompts, DiffusionDB, DrawBench: FP16, DGQ, LUT-Quant
#   scripts/run_experiments.sh table5        quantization MSE per layer and phase                      main env
#   scripts/run_experiments.sh table6        ablations: 200 prompts (incl. 64 and 16 levels) and 10K rows
#   scripts/run_experiments.sh table7        1K: all methods, LPIPS / PSNR to FP16
#   scripts/run_experiments.sh table8        30K: DGQ and LUT-Quant calibrated on 4 and 8 captions
#   scripts/run_experiments.sh seeds         10K: DGQ and LUT-Quant with base seeds 1042 and 2042 (Table S2)
#   scripts/run_experiments.sh determinism   200 prompts: FP16, DGQ and LUT-Quant generated twice, digests compared (S3)
#   scripts/run_experiments.sh report        strict ledger, tables, comparison with the paper, figures, archive
#
# Generation runs in the DGQ environment and evaluation in the main one, so a
# table is produced in two passes:
#
#   conda activate lutq-dgq && source scripts/dgq_env.sh
#   EVAL=0 scripts/run_experiments.sh table1          # generate
#   source .venv/bin/activate
#   ONLY_EVAL=1 scripts/run_experiments.sh table1     # evaluate
#
# Q-Diffusion and TFMQ-DM images are generated beforehand in their own
# environments (scripts/run_baselines.sh); a missing baseline stops table1 and table7.
#
# Environment variables
#   RUNS        output root                                                   default runs
#   DGQ_CKPTS   merged DGQ checkpoints sd14_w8a8_c<N>.pth_merged              default checkpoints/dgq
#   BASELINES   Q-Diffusion / TFMQ-DM images, <protocol>/<method>/NNNNN.png   default outputs/baselines
#   SHARDS, SHARD   split generation over GPUs (every shard with EVAL=0)       default 1, 0
set -euo pipefail
cd "$(dirname "$0")/.."

RUNS=${RUNS:-runs}
DGQ_CKPTS=$(realpath -m "${DGQ_CKPTS:-checkpoints/dgq}")
BASELINES=$(realpath -m "${BASELINES:-outputs/baselines}")
SHARDS=${SHARDS:-1}
SHARD=${SHARD:-0}
SEED=42
WA_CALIB=64      # captions of the DGQ weight/activation calibration
CALIB=64         # captions of the look-up tables
VARIANT=standard
LEVELS=256       # score quantizer levels (8 bits)

what=${1:?usage: see the header of this script}

# ------------------------------------------------------------------ helpers
logged() {  # logfile command... : run a command, appending its output to logfile
  local log=$1; shift
  mkdir -p "$(dirname "$log")"
  echo "# $(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$log"
  "$@" 2>&1 | tee -a "$log"
}

snapshot_env() {
  local d="$RUNS/env" name
  name="$(python -c 'import sys; print(sys.prefix.rstrip("/").split("/")[-1])')-$(hostname -s)"
  mkdir -p "$d"
  { echo "python $(python -V 2>&1)"; echo "repository $(git rev-parse HEAD 2>/dev/null || echo unknown)"
    echo "uncommitted changes: $(git status --porcelain --untracked-files=no 2>/dev/null | wc -l)"
    python -m pip freeze; command -v nvidia-smi > /dev/null && nvidia-smi -q | head -60; } > "$d/$name.txt" 2>&1 || true
}

rule_of() { case $1 in lut) echo lloyd ;; *) echo "$1" ;; esac; }
is_lut() { [[ $1 == lut || $1 == aciq || $1 == histogram || $1 == learned_log ]]; }

book_dir() { echo "$RUNS/codebooks/L${LEVELS}_c${CALIB}_${VARIANT}"; }

codebooks() {  # method -> look-up-table file (must exist: `calibrate` in the main environment)
  local f; f="$(book_dir)/$(rule_of "$1").npz"
  [[ -f $f ]] || { echo "missing $f: run 'scripts/run_experiments.sh calibrate' in the main environment" >&2; exit 3; }
  echo "$f"
}

checkpoint() {  # -> merged DGQ checkpoint of the current budget (must exist: scripts/dgq_quantize.sh)
  local f="$DGQ_CKPTS/sd14_w8a8_c${WA_CALIB}.pth_merged"
  [[ -f $f ]] || { echo "missing $f: run 'scripts/dgq_quantize.sh 8 8 $WA_CALIB' in the DGQ environment" >&2; exit 3; }
  echo "$f"
}

fit() {  # protocol rules... : profile once, fit every rule (main environment)
  local proto=$1; shift
  [[ -f "$(book_dir)/$(rule_of "$1").npz" ]] && return 0
  logged "$(book_dir)/logs/calibrate.log" \
    lutq-calibrate --protocol "$proto" --levels "$LEVELS" --variant "$VARIANT" --rules "$@" --out-dir "$(book_dir)"
}

run_dir() {  # protocol method -> output folder
  local proto=$1 method=$2 tag
  if [[ $method == fp16 ]]; then tag=fp16
  elif is_lut "$method"; then tag="w8a8_wa${WA_CALIB}_c${CALIB}_${VARIANT}"
  else tag="w8a8_wa${WA_CALIB}"; fi
  [[ $method != fp16 && $LEVELS != 256 ]] && tag="${tag}_L${LEVELS}"
  echo "$RUNS/$proto/$tag/seed$SEED/$method"
}

method_args() {  # method -> lutq-generate / lutq-latency arguments (fails when an input is missing)
  local m=$1 ck cb
  [[ $m == fp16 ]] && return 0
  ck=$(checkpoint) || return 3
  echo --dgq-ckpt "$ck" --score-levels "$LEVELS"
  if is_lut "$m"; then
    cb=$(codebooks "$m") || return 3
    echo --codebooks "$cb" --variant "$VARIANT"
  fi
  return 0
}

n_prompts() { python -c "from lutq.data import PROTOCOLS; print(PROTOCOLS['$1'])"; }

generate() {  # protocol method [extra lutq-generate arguments]
  [[ ${ONLY_EVAL:-0} == 1 ]] && return 0
  local proto=$1 m=$2 out n per args; shift 2
  out=${OUT:-$(run_dir "$proto" "$m")}
  n=$(n_prompts "$proto"); per=$(( (n + SHARDS - 1) / SHARDS ))
  args=$(method_args "$m") || exit 3
  # shellcheck disable=SC2086
  logged "$out/logs/generate_$(printf %05d $(( SHARD * per ))).log" \
    lutq-generate --method "$m" --protocol "$proto" --seed "$SEED" --start $(( SHARD * per )) --count "$per" \
                  --out "$out" $args "$@"
}

evaluate() {  # protocol method [extra lutq-eval arguments]
  [[ ${EVAL:-1} == 1 ]] || return 0
  local proto=$1 m=$2 out; shift 2
  out=$(run_dir "$proto" "$m")
  logged "$out/logs/eval.log" lutq-eval all --images "$out/images" --protocol "$proto" --out "$out/metrics.json" "$@"
}

run() { generate "$1" "$2"; evaluate "$@"; }

external() {  # protocol method [extra lutq-eval arguments]: Q-Diffusion / TFMQ-DM images from BASELINES
  local proto=$1 m=$2 out src; shift 2
  src="$BASELINES/$proto/$m"
  if [[ ! -f $src/provenance.json ]]; then
    echo "missing $src (images and provenance.json): generate them with 'scripts/run_baselines.sh $m $proto'" >&2
    exit 4
  fi
  out=$(run_dir "$proto" "$m")
  if [[ ${ONLY_EVAL:-0} != 1 ]]; then
    mkdir -p "$out/images" && cp "$src"/[0-9]*.png "$out/images/"
    lutq-digest hash "$out/images" --protocol "$proto" --method "$m" --seed "$SEED" \
                --provenance "$src/provenance.json" --out "$out"
  fi
  evaluate "$proto" "$m" "$@"
}

latency() {  # method
  [[ ${ONLY_EVAL:-0} == 1 ]] && return 0
  local m=$1 args
  args=$(method_args "$m") || exit 3
  # shellcheck disable=SC2086
  logged "$RUNS/latency/logs/$m.log" \
    lutq-latency --method "$m" --runs 20 --warmup 5 --profile --out "$RUNS/latency/$m.json" $args
}

# ------------------------------------------------------------- experiments
snapshot_env
case "$what" in
  calibrate)
    fit coco_calib64 lloyd aciq histogram learned_log                    # Tables I, III, IV, VII, VIII
    for c in 4 8 16 32; do CALIB=$c fit "coco_calib$c" lloyd; done         # Tables V, VI, VIII
    for v in tsadaptive selfcross; do CALIB=8 VARIANT=$v fit coco_calib8 lloyd; done
    for l in 64 16; do CALIB=8 LEVELS=$l fit coco_calib8 lloyd; done ;;    # Table VI, score precision

  table1)
    for m in fp16 dgq lut; do run coco30k "$m" --bootstrap 1000; done
    for m in qdiffusion tfmqdm; do external coco30k "$m" --bootstrap 1000; done ;;

  table2)
    for m in fp16 dgq lut; do latency "$m"; done ;;

  table3)
    for m in aciq histogram learned_log lut dgq; do run coco10k "$m"; done ;;

  table4)
    for p in parti500 diffusiondb500 drawbench200; do
      for m in fp16 dgq lut; do generate "$p" "$m"; done
      if [[ ${EVAL:-1} == 1 ]]; then
        logged "$RUNS/$p/logs/shift.log" lutq-shift --protocol "$p" --fp "$(run_dir "$p" fp16)" \
          --dgq "$(run_dir "$p" dgq)" --lut "$(run_dir "$p" lut)" --bootstrap 1000 --out "$RUNS/$p/domain_shift.json"
      fi
    done ;;

  table5)
    logged "$RUNS/intrinsic/logs/intrinsic.log" \
      lutq-intrinsic --protocol coco_calib4 --codebooks "$(CALIB=4 codebooks lut)" --out "$RUNS/intrinsic/sd14_c4.json" ;;

  table6)
    for v in standard tsadaptive selfcross; do
      CALIB=8 VARIANT=$v run coco200 lut
      CALIB=8 VARIANT=$v run coco10k lut
    done
    for c in 4 16; do CALIB=$c run coco200 lut; done
    for l in 64 16; do CALIB=8 LEVELS=$l run coco200 lut; done ;;

  table7)
    fp="$(run_dir coco1k fp16)/images"
    run coco1k fp16
    for m in dgq lut; do generate coco1k "$m"; evaluate coco1k "$m" --fp-images "$fp"; done
    for m in qdiffusion tfmqdm; do external coco1k "$m" --fp-images "$fp"; done ;;

  table8)
    for n in 4 8; do
      WA_CALIB=$n run coco30k dgq --bootstrap 1000
      WA_CALIB=$n CALIB=$n run coco30k lut --bootstrap 1000
    done ;;

  seeds)
    for s in 1042 2042; do
      for m in dgq lut; do SEED=$s run coco10k "$m"; done
    done ;;

  determinism)
    for m in fp16 dgq lut; do
      first=$(CALIB=8 run_dir coco200 "$m")
      if [[ ${ONLY_EVAL:-0} != 1 ]]; then
        [[ -f $first/generate_00000.json ]] || CALIB=8 generate coco200 "$m"
        CALIB=8 OUT="$RUNS/rerun/coco200/$m" generate coco200 "$m" --purpose rerun
      fi
      if [[ ${EVAL:-1} == 1 ]]; then
        logged "$RUNS/rerun/logs/compare.log" \
          lutq-digest compare "$first" "$RUNS/rerun/coco200/$m" --out "$RUNS/rerun/coco200/$m/digest_comparison.json"
      fi
    done ;;

  report)
    lutq-report "$RUNS" --expected paper/reported_values.json
    lutq-figures "$RUNS"
    extra=(data/prompts locks)
    [[ -d $DGQ_CKPTS ]] && extra+=("$DGQ_CKPTS")
    lutq-bundle create "$RUNS" --out "$RUNS/lutq-records-$(date -u +%Y%m%d).tar.gz" --include "${extra[@]}" ;;

  *) echo "unknown experiment '$what' (see the header of $0)" >&2; exit 2 ;;
esac
