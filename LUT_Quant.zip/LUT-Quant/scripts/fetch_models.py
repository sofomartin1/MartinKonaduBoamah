#!/usr/bin/env python3
"""Download the model weights and lock their revisions (main environment).

    python scripts/fetch_models.py              Stable Diffusion v1.4 (diffusers format): profiling, DGQ, metrics
    python scripts/fetch_models.py --original   also sd-v1-4.ckpt (CompVis format) for Q-Diffusion and TFMQ-DM,
                                                linked to checkpoints/sd/sd-v1-4.ckpt

The resolved Hugging Face commits and the SHA-256 of every weight file are
written to locks/models.json on the first download and checked afterwards.
The model licence (CreativeML OpenRAIL-M) must be accepted on the model page
with the Hugging Face account in use (`huggingface-cli login`).
"""

from __future__ import annotations

import argparse
from pathlib import Path

from lutq import locks, models


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--original", action="store_true", help="also fetch sd-v1-4.ckpt for the baselines")
    args = ap.parse_args()

    path, commit = models.sd14_snapshot()
    print(f"{models.SD14_REPO} @ {commit}: {path}")
    if args.original:
        ckpt, commit, digest = models.sd14_original_ckpt()
        link = Path("checkpoints/sd/sd-v1-4.ckpt")
        link.parent.mkdir(parents=True, exist_ok=True)
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(ckpt.resolve())
        print(f"{models.SD14_CKPT_REPO} @ {commit}: {link} -> {ckpt} (sha256 {digest})")
    print(f"locks: {locks.lock_dir() / 'models.json'}")


if __name__ == "__main__":
    main()
