# Source this file (bash) inside the lutq-dgq environment: puts the DGQ
# checkout and its src/ folder on PYTHONPATH.
_lutq_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$_lutq_root/third_party/DGQ:$_lutq_root/third_party/DGQ/src${PYTHONPATH:+:$PYTHONPATH}"
unset _lutq_root
