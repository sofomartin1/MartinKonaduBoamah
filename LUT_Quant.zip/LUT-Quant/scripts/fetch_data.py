#!/usr/bin/env python3
"""Download the public datasets, lock them and write the prompt list of every protocol.

    python scripts/fetch_data.py                       every prompt list
    python scripts/fetch_data.py --only coco_calib64 coco1k
    python scripts/fetch_data.py --reference           also the FID reference statistics (real_im256.npz)
    python scripts/fetch_data.py --verify              rebuild every list from its sources and compare with data/prompts

Writes <LUTQ_DATA>/prompts/<protocol>.txt (one prompt per line, UTF-8, in
generation order) for every protocol in lutq.data.PROTOCOLS and a SHA256SUMS
file (check with `cd data/prompts && sha256sum -c SHA256SUMS`).  The URL or
Hugging Face commit and the SHA-256 of every source file go to locks/data.json.
"""

from __future__ import annotations

import argparse
import hashlib
import sys

from lutq import data


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", nargs="*", metavar="PROTOCOL", help="subset of protocols")
    ap.add_argument("--reference", action="store_true", help="download the FID reference statistics")
    ap.add_argument("--verify", action="store_true", help="compare data/prompts with lists rebuilt from the sources")
    args = ap.parse_args()

    unknown = sorted(set(args.only or []) - set(data.PROTOCOLS))
    if unknown:
        ap.error(f"unknown protocol(s) {unknown}; choose from {sorted(data.PROTOCOLS)}")

    out = data.data_root() / "prompts"
    out.mkdir(parents=True, exist_ok=True)
    sums_file = out / "SHA256SUMS"
    sums = {}
    if sums_file.exists():
        for line in sums_file.read_text().splitlines():
            h, name = line.split(maxsplit=1)
            sums[name] = h
    bad = []
    for proto in args.only or data.PROTOCOLS:
        prompts = data.sample(proto)
        path = out / f"{proto}.txt"
        if args.verify:
            ok = path.exists() and data.read_prompts(path) == prompts
            bad += [] if ok else [proto]
            print(f"{proto:16s} {'identical' if ok else 'DIFFERS'}")
            continue
        data.write_prompts(prompts, path)
        h = hashlib.sha256(path.read_bytes()).hexdigest()
        sums[path.name] = h
        sums_file.write_text("".join(f"{v}  {k}\n" for k, v in sorted(sums.items())))
        print(f"{proto:16s} {len(prompts):6d} prompts  sha256 {h[:16]}")
    if args.reference:
        from lutq.metrics import reference_stats

        mu, _ = reference_stats()
        print(f"FID reference statistics: {mu.size}-dimensional")
    if bad:
        sys.exit(f"prompt lists differ from their sources: {', '.join(bad)}")


if __name__ == "__main__":
    main()
