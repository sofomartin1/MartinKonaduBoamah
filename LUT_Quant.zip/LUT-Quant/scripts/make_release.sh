#!/usr/bin/env bash
# Release assets of one paper version, built from the run records (main environment).
#
#   scripts/make_release.sh v1.0.0            -> release/v1.0.0/
#
# 1. refuses a working tree with uncommitted changes and a version that is not a git tag;
# 2. lutq-report in strict mode (every table cell from a valid run) and the comparison
#    with the values printed in the paper (paper/reported_values.json);
# 3. lutq-figures;
# 4. the record archive: every record, look-up table, score population, log and
#    environment snapshot, the report, the frozen prompt lists, locks/ and the DGQ
#    checkpoint records, with a SHA-256 manifest (lutq-bundle), verified after writing;
# 5. SHA256SUMS of the assets, and the command that attaches them to the GitHub release.
set -euo pipefail
cd "$(dirname "$0")/.."

V=${1:?version tag, e.g. v1.0.0}
RUNS=${RUNS:-runs}
OUT=release/$V

[[ -z $(git status --porcelain --untracked-files=no) ]] || { echo "commit your changes first" >&2; exit 1; }
git rev-parse -q --verify "refs/tags/$V" > /dev/null || { echo "tag $V does not exist: git tag -a $V" >&2; exit 1; }
[[ $(git rev-parse "$V^{commit}") == $(git rev-parse HEAD) ]] || { echo "HEAD is not at $V" >&2; exit 1; }

lutq-report "$RUNS" --expected paper/reported_values.json
lutq-figures "$RUNS"
mkdir -p "$OUT"
extra=(data/prompts locks)
[[ -d checkpoints/dgq ]] && extra+=(checkpoints/dgq)
lutq-bundle create "$RUNS" --out "$OUT/lutq-records-$V.tar.gz" --include "${extra[@]}"
lutq-bundle verify "$OUT/lutq-records-$V.tar.gz"
cp "$RUNS/report/tables.md" "$OUT/tables-$V.md"
cp "$RUNS/report/comparison.md" "$OUT/comparison-$V.md"
(cd "$OUT" && sha256sum -- * > SHA256SUMS)
echo
echo "assets in $OUT:"; ls -l "$OUT"
echo
echo "publish with:"
echo "  git push origin $V"
echo "  gh release create $V $OUT/* --title \"LUT-Quant $V\" --notes-file $OUT/tables-$V.md"
