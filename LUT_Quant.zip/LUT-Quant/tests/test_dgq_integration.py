"""LUT-Quant inside DGQ's quantized transformer blocks.

The tests marked ``dgq`` build DGQ's own ``QuantBasicTransformerBlock`` from
the DGQ checkout (scripts/setup_dgq.sh, DGQ on PYTHONPATH) and run DGQ's
rewritten attention forward with LUT-Quant installed.  They are skipped when DGQ
is not importable; the CI job "dgq" runs them in DGQ's environment.
"""

from pathlib import Path

import numpy as np
import pytest

torch = pytest.importorskip("torch")

from lutq.attention import LUT, StepTracker, log2_quant  # noqa: E402
from lutq.codebook import fit_lloyd  # noqa: E402
from lutq.integrations import dgq  # noqa: E402


def _probs(seed=0, shape=(2, 8, 64, 77)):
    g = torch.Generator().manual_seed(seed)
    return torch.softmax(torch.randn(*shape, generator=g) * 3, dim=-1)


def _levels(k=64, seed=0, first=True):
    p = _probs(seed)
    body = p[..., 1:] if first else p
    a = (body / body.amax()).reshape(-1).numpy()
    return fit_lloyd(np.sort(a), k=k).levels


def test_score_bits_follow_score_levels():
    assert [dgq.score_bits(L) for L in (16, 64, 256, 1024)] == [4, 6, 8, 10]
    with pytest.raises(ValueError):
        dgq.score_bits(100)


def test_lut_score_quantizer_maps_to_scaled_levels():
    lv = _levels()
    q = dgq.LUTScoreQuantizer("x", {None: LUT(lv, device="cpu")})
    w = _probs(1)[..., 1:]
    out = q(w)
    s = w.amax()
    assert out.dtype == torch.float32 and out.shape == w.shape
    assert torch.isin(out, torch.tensor(np.sort(lv), dtype=torch.float32) * s).all()
    assert q.level == 64


# ------------------------------------------------------------ DGQ's own modules


def _dgq():
    return pytest.importorskip("quant.quant_block", reason="DGQ is not on PYTHONPATH")


def _block(a_bits=8, score_levels=256, hidden=64):
    """A DGQ QuantBasicTransformerBlock with the configuration of load_dgq_pipeline."""
    quant_block = _dgq()
    import diffusers_rewrite as dr

    torch.manual_seed(0)
    _, aq, sq = dgq.quant_params(8, a_bits, score_levels)
    blk = quant_block.QuantBasicTransformerBlock(dr.BasicTransformerBlock(hidden), aq, sq)
    blk.attn1.use_aq = blk.attn2.use_aq = True
    return blk.eval()


def _tree(blocks):
    """``QuantModel``-shaped tree: model.down_blocks.0.attentions.i.transformer_blocks.0."""
    inner = torch.nn.Module()
    inner.down_blocks = torch.nn.ModuleList([torch.nn.Module()])
    atts = torch.nn.ModuleList()
    for b in blocks:
        m = torch.nn.Module()
        m.transformer_blocks = torch.nn.ModuleList([b])
        atts.append(m)
    inner.down_blocks[0].attentions = atts
    qnn = torch.nn.Module()
    qnn.model = inner
    return qnn


def _run(blk, seed=0):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(2, 16, 64, generator=g)
    ctx = torch.randn(2, 77, 768, generator=g)
    with torch.no_grad():
        return blk(x, encoder_hidden_states=ctx)


@pytest.mark.dgq
def test_dgq_configuration_of_the_experiments():
    blk = _block()
    assert blk.attn2.aqtizer_w.level == 256 and blk.attn1.aqtizer_w.level == 256   # 8-bit scores
    assert blk.attn2.aqtizer_q.level == 256                                      # 8-bit activations
    assert blk.attn2.start_peak                                                  # <start> column split off
    assert _block(a_bits=6).attn2.aqtizer_w.level == 256    # score precision independent of activation bits


@pytest.mark.dgq
def test_log2_matches_dgq_t2i_log_quantizer():
    blk = _block(score_levels=64)
    w = _probs(2)[..., 1:]
    ref = blk.attn2.aqtizer_w(w)
    assert torch.allclose(log2_quant(w / w.max(), 64) * w.max(), ref, rtol=1e-6, atol=0)


@pytest.mark.dgq
def test_install_replaces_cross_attention_score_quantizer_only():
    blocks = [_block(), _block()]
    qnn = _tree(blocks)
    keys = sorted(dgq.attention_blocks(qnn))
    assert keys == [f"down_blocks.0.attentions.{i}.transformer_blocks.0.attn2" for i in range(2)]
    books = {k: _levels(256) for k in keys}
    log_attn1 = type(blocks[0].attn1.aqtizer_w)
    assert dgq.install_lut(qnn, books, levels=256) == 2
    for b in blocks:
        assert isinstance(b.attn2.aqtizer_w, dgq.LUTScoreQuantizer)
        assert isinstance(b.attn1.aqtizer_w, log_attn1)
    with pytest.raises(ValueError):
        dgq.install_lut(_tree([_block()]), {keys[0]: _levels(64)}, levels=256)


@pytest.mark.dgq
def test_lut_receives_scores_without_start_column_in_dgq_forward():
    blk = _block()
    key = "down_blocks.0.attentions.0.transformer_blocks.0.attn2"
    dgq.install_lut(_tree([blk]), {key: _levels(256)}, levels=256)
    seen = []
    blk.attn2.aqtizer_w.register_forward_hook(lambda m, i, o: seen.append((i[0], o)))
    out = _run(blk)
    assert torch.isfinite(out).all()
    (inp, q), = seen
    assert inp.shape[-1] == 76 and inp.dtype == torch.float32
    lv = blk.attn2.aqtizer_w.luts[None].levels * inp.amax()
    assert torch.isin(q, lv).all()


@pytest.mark.dgq
def test_self_and_cross_variant_replaces_both_quantizers():
    blk = _block()
    base = "down_blocks.0.attentions.0.transformer_blocks.0"
    books = {base + ".attn2": _levels(256), base + ".attn1": _levels(256, first=False)}
    assert dgq.install_lut(_tree([blk]), books, levels=256, self_attention=True) == 2
    assert isinstance(blk.attn1.aqtizer_w, dgq.LUTScoreQuantizer)
    assert torch.isfinite(_run(blk)).all()


@pytest.mark.dgq
def test_timestep_adaptive_variant_follows_the_tracked_timestep():
    blk = _block()
    qnn = _tree([blk])
    key = "down_blocks.0.attentions.0.transformer_blocks.0.attn2"
    books = {f"{key}@{p}": _levels(256, seed=i) for i, p in enumerate(("early", "mid", "late"))}
    with pytest.raises(ValueError):
        dgq.install_lut(qnn, books, levels=256)
    from diffusers import DDIMScheduler

    sched = DDIMScheduler(num_train_timesteps=1000, steps_offset=1)
    sched.set_timesteps(25)                           # t = 961, 921, ..., 1
    tracker = StepTracker(sched)
    dgq.install_lut(qnn, books, levels=256, tracker=tracker)
    used = []
    luts = blk.attn2.aqtizer_w.luts
    for p in list(luts):
        luts[p] = (lambda f, ph: (lambda a: used.append(ph) or f(a)))(luts[p], p)
    for t, phase in ((961.0, "early"), (561.0, "mid"), (1.0, "late")):
        tracker.t = t
        used.clear()
        _run(blk)
        assert used == [phase]


# ------------------------------------------------------- checkpoint path resolution
DGQ_UTILS_STUB = '''
import types
from diffusers import DDIMScheduler

class _M:
    def to(self, *a, **k):
        return self
    def half(self):
        return self
    def disable_out_quantization(self):
        pass

def prepare_pipe(model_type, fp16=False):
    p = types.SimpleNamespace(scheduler=DDIMScheduler(), unet=_M(), text_encoder=_M(), vae=_M())
    p.to = lambda *a, **k: p
    p.set_progress_bar_config = lambda **k: None
    return p
'''
DGQ_LOADER_STUB = '''
import os
SEEN = {}

def get_qmodel(model_type, pipe, ckpt_path, *args, **kwargs):
    SEEN.update(path=ckpt_path, cwd=os.getcwd())
    from utils import _M
    return _M()
'''


def test_relative_checkpoint_resolves_from_the_callers_directory(tmp_path, monkeypatch):
    """The checkpoint is resolved before the loader enters the DGQ checkout."""
    import sys

    root = tmp_path / "third_party" / "DGQ"
    (root / "quant").mkdir(parents=True)
    (root / "quant" / "__init__.py").write_text("")
    (root / "quant" / "load_qmodel_util.py").write_text(DGQ_LOADER_STUB)
    (root / "utils.py").write_text(DGQ_UTILS_STUB)
    work = tmp_path / "LUT-Quant"
    (work / "checkpoints" / "dgq").mkdir(parents=True)
    (work / "checkpoints" / "dgq" / "sd14_w8a8_c64.pth_merged").write_bytes(b"x")
    monkeypatch.syspath_prepend(str(root))
    for mod in ("quant", "quant.load_qmodel_util", "utils"):
        monkeypatch.delitem(sys.modules, mod, raising=False)
    monkeypatch.setattr(dgq, "dgq_root", lambda: root)
    monkeypatch.setattr(dgq, "ensure_pretrained", lambda root=None: root)
    monkeypatch.setattr(dgq, "quant_params", lambda *a: ({}, {}, {}))
    monkeypatch.chdir(work)

    dgq.load_dgq_pipeline("checkpoints/dgq/sd14_w8a8_c64.pth_merged", device="cpu")
    import quant.load_qmodel_util as loader

    assert loader.SEEN["path"] == str(work / "checkpoints" / "dgq" / "sd14_w8a8_c64.pth_merged")
    assert loader.SEEN["cwd"] == str(root)            # DGQ's code still runs inside its checkout
    assert Path.cwd() == work
    with pytest.raises(FileNotFoundError, match="DGQ checkpoint not found"):
        dgq.load_dgq_pipeline("checkpoints/dgq/missing.pth_merged", device="cpu")
