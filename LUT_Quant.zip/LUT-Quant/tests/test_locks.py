"""Locked model files and the repository-relative data and lock folders."""

import pytest

from lutq import locks, models, paths


def test_data_and_locks_do_not_depend_on_the_working_directory(tmp_path, monkeypatch):
    monkeypatch.delenv("LUTQ_DATA", raising=False)
    monkeypatch.delenv("LUTQ_LOCKS", raising=False)
    monkeypatch.chdir(tmp_path)
    root = paths.repo_root()
    assert (root / "pyproject.toml").is_file()
    assert paths.data_root() == root / "data" and paths.lock_dir() == root / "locks"


def test_every_model_file_is_checked_against_the_lock_on_every_use(tmp_path, monkeypatch):
    pytest.importorskip("huggingface_hub")
    import huggingface_hub

    snap = tmp_path / "snapshots" / "c0ffee"
    for f in models.SD14_FILES:
        (snap / f).parent.mkdir(parents=True, exist_ok=True)
        (snap / f).write_bytes(f.encode())
    monkeypatch.setenv("LUTQ_LOCKS", str(tmp_path / "locks"))
    monkeypatch.setattr(huggingface_hub, "snapshot_download", lambda *a, **k: str(snap))
    assert models.sd14_snapshot() == (snap, "c0ffee")
    assert set(locks.entry("models", "sd14")["sha256"]) == set(models.SD14_FILES)
    (snap / "unet/diffusion_pytorch_model.safetensors").write_bytes(b"other weights")
    with pytest.raises(locks.LockMismatch, match="unet/diffusion_pytorch_model.safetensors"):
        models.sd14_snapshot()
