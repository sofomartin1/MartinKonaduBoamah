"""Run records, ledger validation, Tables I-VIII and S1-S3, figures, comparison with the paper, record archive.

The records here are written by the tests with round numbers; they exercise
the path from records to tables only.
"""

import io
import json
import tarfile

import pytest

from conftest import _cfg, _run
from lutq import bundle, records, report


def test_ledger_joins_shards_and_metrics(runs):
    led = records.build_ledger(runs)
    r = records.select(led["runs"], protocol="coco30k", method="lut", wa_calib_prompts=8)
    assert len(r) == 1 and r[0]["n_images"] == 4 and r[0]["image_set_sha256"] == r[0]["evaluated_set_sha256"]
    assert all(row["valid"] for row in led["runs"]) and led["problems"] == []


def test_every_table_is_rendered_from_records(complete_runs):
    runs = complete_runs
    report.build_report(runs, runs / "report")
    md = (runs / "report" / "tables.md").read_text(encoding="utf-8")
    led = records.build_ledger(runs)
    _, t1, _ = report.table1(led)
    assert [r[3] for r in t1] == ["10.00", "11.00", "10.80", "10.50", "10.40"]
    _, t2, n2 = report.table2(led)
    assert t2[2][3] == "+0.7%" and "Welch" in n2[0]
    _, t3, n3 = report.table3(led)
    assert t3[3][0] == "Lloyd codebook (ours)" and t3[0][1] == "15.00 (1)" and "Kendall" in n3[0]
    _, t4, n4 = report.table4(led)
    assert t4[0][7] == "−3.00 [−4.00, −2.00]" and t4[1][2] == "0.3440" and "64" in n4[0]
    _, t5, _ = report.table5(led)
    assert t5[0] == ["D0.A0", "5 ± 0.5", "2 ± 0.2", "25.0×"] and t5[16][0].startswith("Pooled")
    _, t6, n6 = report.table6(led)
    assert t6[0][0] == "Reference" and t6[0][2] == "140.00" and t6[5][2] == "stable"
    assert t6[-1][2] == "15.50" and t6[6][1].startswith("64 levels") and t6[6][2] == "150.00" and "one run" in n6[0]
    _, t7, _ = report.table7(led)
    assert t7[4][6] == "0.100 [0.090, 0.110]" and t7[0][6] == report.NA
    _, t8, _ = report.table8(led)
    assert t8[0][1] == "10.60" and t8[2][1] == "10.50 [10.30, 10.70]"
    _, s1, _ = report.table_s1(led)
    assert s1[0][1] == "40.0" and s1[0][2] == "30.0" and s1[0][3] == "70.0"
    assert "Table VIII" in md and "Table S1" in md and "Excluded" not in md


# -------------------------------------------------------------------- validation
def test_incomplete_run_with_mismatched_hashes_is_rejected(tmp_path):
    """A 4-image run labelled coco30k whose metrics describe other images never reaches a table."""
    cfg = dict(_cfg("lut", "coco30k"), n_prompts=30000)
    records.write_record(tmp_path / "coco30k/lut/generate_00000.json", "generation", cfg,
                         shard={"start": 0, "count": 4}, digests=[f"d{i}" for i in range(4)])
    records.write_record(tmp_path / "coco30k/lut/metrics.json", "metrics", {"protocol": "coco30k"},
                         image_set_sha256="another image set", metrics={"fid": 13.44, "clip": 0.33, "n_images": 4})
    row, = records.build_ledger(tmp_path)["runs"]
    assert not row["valid"]
    assert any("4 of 30000 images" in p for p in row["problems"])
    assert any("evaluated images differ" in p for p in row["problems"])
    with pytest.raises(report.ReportError, match="4 of 30000"):
        report.build_report(tmp_path, tmp_path / "report")
    assert not (tmp_path / "report" / "tables.md").exists()
    report.build_report(tmp_path, tmp_path / "report", strict=False)
    md = (tmp_path / "report" / "tables.md").read_text(encoding="utf-8")
    assert "Excluded records" in md and "13.44" not in md


def test_conflicting_overlapping_shards_and_inputs(tmp_path, small_protocols):
    cfg = _cfg("dgq", "coco1k")
    records.write_record(tmp_path / "r/generate_00000.json", "generation", cfg, inputs={"prompts_sha256": "a"},
                         shard={"start": 0, "count": 3}, digests=["x0", "x1", "x2"])
    records.write_record(tmp_path / "r/generate_00002.json", "generation", cfg, inputs={"prompts_sha256": "b"},
                         shard={"start": 2, "count": 2}, digests=["DIFFERENT", "x3"])
    row, = records.build_ledger(tmp_path)["runs"]
    assert any("disagree on 1 image" in p for p in row["problems"])
    assert any("different input files" in p for p in row["problems"])


def test_protocol_size_and_prompt_lists(tmp_path, small_protocols):
    _run(tmp_path, "a", _cfg("fp16", "coco1k"))
    cfg = _cfg("dgq", "coco1k")
    records.write_record(tmp_path / "b/generate_00000.json", "generation", cfg, inputs={"prompts_sha256": "other"},
                         shard={"start": 0, "count": 4}, digests=list("wxyz"))
    led = records.build_ledger(tmp_path)
    assert any("2 different prompt lists" in p for p in led["problems"]) and not any(r["valid"] for r in led["runs"])
    bad = dict(_cfg("lut", "coco200"), n_prompts=3)
    records.write_record(tmp_path / "c/generate_00000.json", "generation", bad, shard={"start": 0, "count": 3},
                         digests=list("abc"))
    row = [r for r in records.build_ledger(tmp_path)["runs"] if r["run"] == "c"][0]
    assert any("protocol coco200 has 4" in p for p in row["problems"])


def test_disagreeing_runs_of_one_condition_are_ambiguous(complete_runs):
    runs = complete_runs
    _run(runs, "coco30k/lut_again", _cfg("lut", "coco30k"), fid=12.0, clip=0.33, **{"is": 30.0})
    with pytest.raises(report.ReportError, match="disagree"):
        report.build_report(runs, runs / "report")


def test_identical_rerun_is_not_ambiguous(complete_runs):
    runs = complete_runs
    cfg = _cfg("lut", "coco30k")
    digests = [f"coco30k/lut-{i}" for i in range(4)]
    records.write_record(runs / "coco30k/lut_rerun/generate_00000.json", "generation", cfg,
                         inputs={"prompts_sha256": "prompts-coco30k"}, shard={"start": 0, "count": 4}, digests=digests)
    report.build_report(runs, runs / "report")
    _, t1, _ = report.table1(records.build_ledger(runs))
    assert t1[4][3] == "10.40"


def test_rerun_records_stay_out_of_the_tables(complete_runs):
    runs = complete_runs
    cfg = _cfg("lut", "coco30k")
    records.write_record(runs / "rerun/lut/generate_00000.json", "generation", cfg, purpose="rerun",
                         inputs={"prompts_sha256": "prompts-coco30k"}, shard={"start": 0, "count": 4},
                         digests=list("abcd"))
    led = records.build_ledger(runs)
    assert len(led["rerun"]) == 1 and not any(r["run"].startswith("rerun") for r in led["runs"])
    report.build_report(runs, runs / "report")


def test_fidelity_must_use_the_full_precision_run(complete_runs):
    runs = complete_runs
    m = json.loads((runs / "coco1k/lut/metrics.json").read_text())
    m["metrics"]["fp_image_set_sha256"] = "images of another run"
    (runs / "coco1k/lut/metrics.json").write_text(json.dumps(m))
    with pytest.raises(report.ReportError, match="not the full-precision run"):
        report.build_report(runs, runs / "report")


def test_domain_shift_record_must_match_valid_runs(complete_runs):
    runs = complete_runs
    rec = json.loads((runs / "parti500/domain_shift.json").read_text())
    rec["results"]["image_sets"]["lut"] = "stale images"
    (runs / "parti500/domain_shift.json").write_text(json.dumps(rec))
    with pytest.raises(report.ReportError, match="not a valid parti500 run"):
        report.build_report(runs, runs / "report")


def test_verify_images(tmp_path):
    img = tmp_path / "run" / "images"
    img.mkdir(parents=True)
    for i in range(3):
        (img / f"{i:05d}.png").write_bytes(bytes([i]))
    digests = [records.sha256_file(img / f"{i:05d}.png") for i in range(3)]
    records.write_record(tmp_path / "run/generate_00000.json", "generation", {"n_prompts": 3},
                         shard={"start": 0, "count": 3}, digests=digests)
    sha, n = records.verify_images(img)
    assert n == 3 and sha == records.sha256_text(digests)
    (img / "extra.png").write_bytes(b"not generated")
    with pytest.raises(ValueError, match="without a record: extra.png"):
        records.verify_images(img)
    (img / "extra.png").unlink()
    for name in ("00001.jpg", "0001.png", "00003.png"):
        (img / name).write_bytes(b"x")
        with pytest.raises(ValueError, match=f"without a record: {name}"):
            records.verify_images(img)
        (img / name).unlink()
    (img / "00001.png").write_bytes(b"changed")
    with pytest.raises(ValueError, match="1 image.s. differ from their record, first 00001.png"):
        records.verify_images(img)


# ------------------------------------------------------------ paper, figures, bundle
def test_comparison_with_printed_values(complete_runs, tmp_path):
    runs = complete_runs
    expected = {"I": {"LUT-Quant": {"FID ↓": "10.40", "CLIP ↑": "0.3300", "Calibration": "64 captions"},
                      "DGQ": {"FID ↓": "10.6"}},
                "VI": {"Calibration / 8 prompts": {"_row": report.TABLE6_REFERENCE, "FID ↓": "140.00"}},
                "VIII": {"64": {"LUT-Quant FID ↓": "10.40 [10.20, 10.60]"}}}
    path = tmp_path / "expected.json"
    path.write_text(json.dumps(expected), encoding="utf-8")
    with pytest.raises(report.ReportError, match="printed 10.6, regenerated 10.50"):
        report.build_report(runs, runs / "report", expected=path)
    assert not (runs / "report" / "tables.md").exists()
    text = (runs / "report" / "comparison.md").read_text(encoding="utf-8")
    assert text.count("| match |") == 5 and text.count("| MISMATCH |") == 1
    expected["I"]["DGQ"]["FID ↓"] = "10.50"
    path.write_text(json.dumps(expected), encoding="utf-8")
    report.build_report(runs, runs / "report", expected=path)          # every printed value reproduced
    assert (runs / "report" / "tables.md").exists() and not (runs / "report" / "problems.md").exists()


def test_strict_report_requires_every_cell(tmp_path):
    """An empty run folder, or one table without its records, cannot pass the publication check."""
    from pathlib import Path

    empty = tmp_path / "empty"
    empty.mkdir()
    expected = Path(__file__).resolve().parents[1] / "paper" / "reported_values.json"
    with pytest.raises(report.ReportError, match="no valid record"):
        report.build_report(empty, empty / "report", expected=expected)
    problems = (empty / "report" / "problems.md").read_text(encoding="utf-8")
    assert "Table I, LUT-Quant / FID ↓: no valid record" in problems and "(no record)" in problems
    report.build_report(empty, empty / "report", strict=False, expected=expected)


def test_missing_table_stops_the_strict_report(complete_runs):
    import shutil

    shutil.rmtree(complete_runs / "seeds")
    with pytest.raises(report.ReportError, match="Table S2"):
        report.build_report(complete_runs, complete_runs / "report")


def test_printed_rows_of_one_condition_agree():
    """Table VI prints the reference run under four labels; all four carry the same values."""
    from pathlib import Path

    exp = json.loads((Path(__file__).resolve().parents[1] / "paper" / "reported_values.json").read_text("utf-8"))
    same = [tuple(sorted((k, v) for k, v in row.items() if not k.startswith("_")))
            for row in exp["VI"].values() if row.get("_row") == report.TABLE6_REFERENCE]
    assert len(same) == 4 and len(set(same)) == 1


def test_figures_from_records(runs):
    pytest.importorskip("matplotlib")
    from lutq import figures

    names = {p.stem for p in figures.build_figures(runs, runs / "figs")}
    assert {"fig1_fid_vs_clip", "fig2_method_comparison", "fig6_error_distribution", "fig7_per_layer_mse",
            "fig8_codebook_stability"} <= names


def test_bundle_round_trip_extras_and_tamper_detection(runs, tmp_path):
    (runs / "coco1k/lut/images").mkdir()
    (runs / "coco1k/lut/images/00000.png").write_bytes(b"png")
    prompts = tmp_path / "prompts"
    prompts.mkdir()
    (prompts / "coco1k.txt").write_text("a cat\n")
    (prompts / "SHA256SUMS").write_text("x  coco1k.txt\n")
    out, n = bundle.create(runs, tmp_path / "rec.tar.gz", extra=[prompts])
    assert n > 0 and bundle.verify(out) == []
    with tarfile.open(out) as tar:
        names = tar.getnames()
    assert not any("/images/" in x for x in names)
    assert "rec/extra/prompts/coco1k.txt" in names and "rec/extra/prompts/SHA256SUMS" in names
    bad = tmp_path / "bad.tar.gz"
    with tarfile.open(out) as src, tarfile.open(bad, "w:gz") as dst:
        for m in src.getmembers():
            data = src.extractfile(m).read()
            if m.name.endswith("coco1k/lut/metrics.json"):
                data = data.replace(b"22.0", b"23.0")
                m.size = len(data)
            dst.addfile(m, io.BytesIO(data))
    assert bundle.verify(bad)


def test_provenance_is_serializable():
    rec = json.loads(json.dumps(records.provenance()))
    assert rec["commit"] and rec["python"] and "dirty" in rec and "numpy" in rec["versions"]


def test_clip_must_use_the_generation_prompts(complete_runs):
    m = json.loads((complete_runs / "coco30k/lut/metrics.json").read_text())
    m["inputs"]["prompts_sha256"] = "another list of the same length"
    (complete_runs / "coco30k/lut/metrics.json").write_text(json.dumps(m))
    with pytest.raises(report.ReportError, match="another prompt list"):
        report.build_report(complete_runs, complete_runs / "report")
