"""Score-quantizing attention processors on a diffusers U-Net.

The U-Net is a small, randomly initialized ``UNet2DConditionModel`` built from
a config, so no checkpoint is downloaded.
"""

from types import SimpleNamespace

import numpy as np
import pytest

torch = pytest.importorskip("torch")
diffusers = pytest.importorskip("diffusers")

from lutq import attention  # noqa: E402
from lutq.attention import LUT, LUTAttnProcessor, StepTracker, install, layer_key, log2_quant, short_name  # noqa: E402
from lutq.codebook import fit_layers, fit_lloyd  # noqa: E402
from lutq.profiling import ErrorLog, ScoreProfiler  # noqa: E402


def _probs(seed=0):
    g = torch.Generator().manual_seed(seed)
    return torch.softmax(torch.randn(16, 64, 77, generator=g) * 3, dim=-1)


def _levels(p, k=256):
    a = (p[..., 1:] / p[..., 1:].amax()).reshape(-1).numpy()
    return fit_lloyd(np.sort(a), k=k).levels


def _proc(levels, **kw):
    return LUTAttnProcessor("x", "lut", {None: LUT(levels, device="cpu")}, levels=len(levels), **kw)


def test_start_column_kept_scale_restored_and_levels_used():
    p = _probs()
    lv = _levels(p)
    q = _proc(lv).quantize_probs(p)
    assert torch.equal(q[..., 0], p[..., 0])
    s = p[..., 1:].amax()
    assert torch.isin(q[..., 1:], (torch.tensor(np.sort(lv), dtype=torch.float32) * s).to(p.dtype)).all()


def test_bucketize_is_nearest_level():
    p = _probs(1)
    lv = np.sort(_levels(p, 64))
    a = (p[..., 1:] / p[..., 1:].amax())
    got = LUT(lv, device="cpu")(a).numpy().ravel()
    ref = lv[np.argmin(np.abs(a.numpy().ravel()[:, None] - lv[None, :]), axis=1)]
    assert np.allclose(got, ref, atol=1e-7)
    assert LUT(np.linspace(0, 1, 256), device="cpu").nbytes() == 1024


def test_self_attention_quantizes_every_column():
    p = _probs(2)
    a = (p / p.amax()).reshape(-1).numpy()
    q = _proc(fit_lloyd(np.sort(a), k=64).levels, keep_first=False).quantize_probs(p)
    assert not torch.equal(q[..., 0], p[..., 0])


def test_log2_matches_dgq_real_time_log_quantizer():
    w = _probs(3)[..., 1:]
    delta = w.max()
    x_q = torch.clamp(torch.round(-1 * torch.log2(w / delta)), 0, 255)   # DGQ T2ILogQuantizer, 8 bits
    assert torch.allclose(log2_quant(w / delta, 256) * delta, 2 ** (-1 * x_q) * delta, rtol=1e-6, atol=0)


def test_modes_are_checked():
    p = _probs(4)
    assert LUTAttnProcessor("x", "fp").quantize_probs(p) is p
    with pytest.raises(ValueError):
        LUTAttnProcessor("x", "lut")
    with pytest.raises(ValueError):
        LUTAttnProcessor("x", "grid")


def test_layer_names_of_table_v():
    assert short_name("down_blocks.0.attentions.1.transformer_blocks.0.attn2.processor") == "D0.A1"
    assert short_name("model.mid_block.attentions.0.transformer_blocks.0.attn2") == "Mid"
    assert short_name("up_blocks.3.attentions.2.transformer_blocks.0.attn2") == "U3.A2"
    assert layer_key("model.up_blocks.1.attentions.0.transformer_blocks.0.attn2.processor") == \
        "up_blocks.1.attentions.0.transformer_blocks.0.attn2"


def test_phases_are_steps_0_8_9_16_17_24():
    ph = [attention.phase_of_step(i) for i in range(25)]
    assert ph[:9] == ["early"] * 9 and ph[9:17] == ["mid"] * 8 and ph[17:] == ["late"] * 8


# ----------------------------------------------------------------- U-Net level
@pytest.fixture()
def unet():
    torch.manual_seed(0)
    return diffusers.UNet2DConditionModel(
        sample_size=8, in_channels=4, out_channels=4, layers_per_block=1,
        block_out_channels=(32, 64), down_block_types=("CrossAttnDownBlock2D", "DownBlock2D"),
        up_block_types=("UpBlock2D", "CrossAttnUpBlock2D"), cross_attention_dim=32,
        attention_head_dim=8, norm_num_groups=8).eval()


@pytest.fixture()
def scheduler():
    s = diffusers.DDIMScheduler(num_train_timesteps=1000, steps_offset=1)
    s.set_timesteps(25)
    return s


def _forward(unet, seed=0, t=481):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(2, 4, 8, 8, generator=g)
    ctx = torch.randn(2, 77, 32, generator=g)
    with torch.no_grad():
        return unet(x, torch.tensor([t, t]), encoder_hidden_states=ctx).sample


def _profile(unet, scheduler, **kw):
    prof = ScoreProfiler(per_call=20000, seed=0)
    install(SimpleNamespace(unet=unet), mode="fp", profiler=prof, **kw)
    for t in scheduler.timesteps[::4]:
        _forward(unet, t=int(t))
    return prof.population()


def test_step_tracker_reads_the_step_from_the_scheduler(unet, scheduler):
    tr = StepTracker(scheduler).attach(unet)
    for i in (0, 8, 9, 16, 17, 24):
        _forward(unet, t=int(scheduler.timesteps[i]))
        assert tr.step == i
    tr.detach()


def test_fp_processor_matches_diffusers(unet):
    from diffusers.models.attention_processor import AttnProcessor

    unet.set_attn_processor(AttnProcessor())
    ref = _forward(unet)
    assert install(SimpleNamespace(unet=unet), mode="fp") == len(attention.attention_names(unet)) == 4
    assert torch.allclose(_forward(unet), ref, atol=1e-5)


def test_profile_fit_and_install(unet, scheduler):
    pop = _profile(unet, scheduler)
    assert len(pop) == 4 and all(k.endswith(".attn2") for k in pop)
    books = {k: f.levels for k, f in fit_layers(pop, k=256).items()}
    ref = _forward(unet, seed=1)
    assert install(SimpleNamespace(unet=unet), mode="lut", codebooks=books) == 4
    out = _forward(unet, seed=1)
    assert torch.isfinite(out).all() and not torch.equal(out, ref)
    with pytest.raises(ValueError):
        install(SimpleNamespace(unet=unet), mode="lut", codebooks=books, levels=64)
    with pytest.raises(KeyError):
        install(SimpleNamespace(unet=unet), mode="lut", codebooks={})


def test_self_and_cross_variant(unet, scheduler):
    pop = _profile(unet, scheduler, self_attention=True)
    assert sum(k.endswith(".attn1") for k in pop) == 4
    books = {k: f.levels for k, f in fit_layers(pop, k=64).items()}
    assert install(SimpleNamespace(unet=unet), mode="lut", codebooks=books, levels=64, self_attention=True) == 8


def test_timestep_adaptive_variant_uses_the_codebook_of_each_phase(unet, scheduler):
    tracker = StepTracker(scheduler).attach(unet)
    pop = _profile(unet, scheduler, tracker=tracker)
    assert {k.split("@")[1] for k in pop} == set(attention.PHASES)
    books = {k: f.levels for k, f in fit_layers(pop, k=64).items()}
    with pytest.raises(ValueError):
        install(SimpleNamespace(unet=unet), mode="lut", codebooks=books, levels=64)
    install(SimpleNamespace(unet=unet), mode="lut", codebooks=books, levels=64, tracker=tracker)
    used = []
    for proc in attention.lut_processors(SimpleNamespace(unet=unet)):
        for phase, lut in proc.luts.items():
            proc.luts[phase] = (lambda f, ph: (lambda a: used.append(ph) or f(a)))(lut, phase)
    for step, phase in ((3, "early"), (12, "mid"), (20, "late")):
        used.clear()
        _forward(unet, t=int(scheduler.timesteps[step]))
        assert used and set(used) == {phase}
    tracker.detach()


def test_measurement_leaves_scores_untouched_and_logs_both_quantizers(unet, scheduler):
    from diffusers.models.attention_processor import AttnProcessor

    books = {k: f.levels for k, f in fit_layers(_profile(unet, scheduler), k=256).items()}
    unet.set_attn_processor(AttnProcessor())
    ref = _forward(unet, seed=2)
    logs = {"log2": ErrorLog(), "lut": ErrorLog()}
    attention.install_measurement(SimpleNamespace(unet=unet), logs, books)
    assert torch.allclose(_forward(unet, seed=2), ref, atol=1e-5)
    per = {r: g.per_layer() for r, g in logs.items()}
    assert all(0 < per["lut"][k] < per["log2"][k] for k in per["lut"])
    assert logs["lut"].error_sample().size == 4 * 256


def test_storage_of_a_table_and_its_runtime_footprint():
    lut = LUT(np.linspace(0, 1, 256), device="cpu")
    assert lut.nbytes() == 1024 and lut.runtime_nbytes() == 1024 + 255 * 4


def test_profiler_records_sampling_and_source_dtype():
    prof = ScoreProfiler(per_call=100, seed=0)
    p = _probs(5).half()
    _proc(_levels(_probs(5).float()), profiler=prof).quantize_probs(p)
    s = prof.summary()
    assert s["source_dtypes"] == ["float16"] and s["layers"]["x"]["scores_kept"] == 100
    assert s["layers"]["x"]["scores_seen"] == 16 * 64 * 76
