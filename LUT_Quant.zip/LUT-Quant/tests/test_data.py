"""Prompt protocols: nesting, disjointness and determinism (sources replaced by in-memory lists), locks."""

import pytest

from lutq import data


@pytest.fixture
def sources(monkeypatch):
    pairs30k = [(i, f"caption of image {i}") for i in range(0, 60000, 2)]
    monkeypatch.setattr(data, "coco30k_pairs", lambda: pairs30k)
    monkeypatch.setattr(data, "coco_captions", lambda: [(i, f"caption of image {i}") for i in range(60000)])
    monkeypatch.setattr(data, "parti_prompts", lambda: [f"parti  prompt\n{i}" for i in range(1632)])
    monkeypatch.setattr(data, "drawbench_prompts", lambda: [f"drawbench {i}" for i in range(200)])


def test_evaluation_lists_are_nested_prefixes(sources):
    full = data.sample("coco30k")
    assert len(full) == 30000
    for proto, n in (("coco10k", 10000), ("coco1k", 1000), ("coco200", 200)):
        assert data.sample(proto) == full[:n]


def test_calibration_lists_are_nested_and_disjoint_from_evaluation(sources):
    c64 = data.sample("coco_calib64")
    assert len(set(c64)) == 64
    for k in (4, 8, 16, 32):
        assert data.sample(f"coco_calib{k}") == c64[:k]
    assert not set(c64) & set(data.sample("coco30k"))


def test_out_of_domain_sets(sources):
    parti = data.sample("parti500")
    assert len(parti) == len(set(parti)) == 500 and parti == data.sample("parti500")
    assert all("\n" not in p and "  " not in p for p in parti)
    assert len(data.sample("drawbench200")) == 200


def test_prompt_file_round_trip(tmp_path):
    prompts = ["a red bicycle", "two cats on a sofa"]
    data.write_prompts(prompts, tmp_path / "p.txt")
    assert data.read_prompts(tmp_path / "p.txt") == prompts


def test_unknown_protocol_raises():
    with pytest.raises(KeyError):
        data.sample("nope")


def test_locks_record_the_first_download_and_refuse_a_different_one(tmp_path, monkeypatch):
    from lutq import locks

    monkeypatch.setenv("LUTQ_LOCKS", str(tmp_path / "locks"))
    first = {"url": "https://example.org/f.csv", "sha256": "aa", "bytes": 3}
    assert locks.check_or_write("data", "coco30k", first, compare=("url", "sha256")) == first
    assert locks.check_or_write("data", "coco30k", dict(first, bytes=4), compare=("url", "sha256")) == first
    with pytest.raises(locks.LockMismatch, match="sha256"):
        locks.check_or_write("data", "coco30k", dict(first, sha256="bb"), compare=("url", "sha256"))


def test_downloads_are_checked_against_known_digests_and_the_lock(tmp_path, monkeypatch):
    pytest.importorskip("requests")
    from lutq import locks

    monkeypatch.setenv("LUTQ_LOCKS", str(tmp_path / "locks"))
    parti = tmp_path / "PartiPrompts.tsv"
    parti.write_text("Prompt\tCategory\nnot the published file\tx\n")
    with pytest.raises(locks.LockMismatch, match="expected fab29e41"):
        data.download("parti", parti)
    other = tmp_path / "metadata.csv"
    other.write_text("file_name,text\n1.jpg,a cat\n")
    data.download("coco30k", other)
    other.write_text("file_name,text\n1.jpg,a dog\n")
    with pytest.raises(locks.LockMismatch):
        data.download("coco30k", other)


def test_prompt_lists_must_have_the_protocol_length(tmp_path, monkeypatch):
    monkeypatch.setenv("LUTQ_DATA", str(tmp_path))
    data.write_prompts(["a", "b"], data.prompt_file("coco200"))
    with pytest.raises(ValueError, match="protocol coco200 has 200"):
        data.prompts_for("coco200")
