"""Lloyd codebooks as specified in Algorithm 1: uniform start, 50 iterations."""

import numpy as np
import pytest

from lutq import codebook


def scores(n=60_000, seed=0, scale=2.0):
    """Normalized softmax scores of 76 text tokens: concentrated near 0 with a long tail."""
    rng = np.random.default_rng(seed)
    z = rng.normal(0.0, scale, (n // 76 + 1, 77))
    z[:, 0] += 4.0
    p = np.exp(z - z.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    x = p[:, 1:].ravel()[:n]
    return np.sort(x / x.max())


X = scores()


def test_initialization_is_uniform_on_zero_to_max():
    lv = codebook.uniform_init(X, 256)
    assert lv[0] == 0.0 and lv[-1] == pytest.approx(X.max())
    assert np.allclose(np.diff(lv), X.max() / 255)


def test_fifty_iterations_and_non_increasing_distortion():
    fit = codebook.fit_lloyd(X, k=256)
    assert fit.iterations == 50 and len(fit.trajectory) == 51
    t = fit.trajectory
    assert all(t[i + 1] <= t[i] * (1 + 1e-12) for i in range(len(t) - 1))
    assert fit.distortion < t[0]


def test_levels_stay_finite_sorted_and_in_range():
    fit = codebook.fit_lloyd(X, k=256)
    assert fit.finite and fit.levels.size == 256
    assert np.all(np.diff(fit.levels) >= 0)
    assert 0.0 <= fit.levels.min() and fit.levels.max() <= X.max()


def test_empty_cells_keep_their_level_and_are_counted():
    fit = codebook.fit_lloyd(X, k=256)
    assert fit.empty_events > 0                        # the uniform start leaves upper cells empty
    assert fit.empty_cells == codebook.count_empty_cells(X, fit.levels)
    assert fit.zero_width_bins == codebook.count_zero_width_bins(fit.levels)


def test_stabilization_iteration_is_recorded():
    fit = codebook.fit_lloyd(X, k=256)
    assert fit.stabilized_at is None or 1 <= fit.stabilized_at <= 50


def test_bucketize_against_midpoints_is_nearest_level():
    lv = codebook.fit_lloyd(X, k=16).levels
    q = codebook.quantize(X, lv)
    brute = lv[np.argmin(np.abs(X[:, None] - lv[None, :]), axis=1)]
    assert np.allclose(q, brute)


def test_save_and_load_round_trip(tmp_path):
    books = {"a.attn2": codebook.fit_lloyd(X, k=16), "a.attn2@early": np.linspace(0, 1, 16)}
    path = tmp_path / "cb.npz"
    codebook.save_codebooks(books, path)
    back = codebook.load_codebooks(path)
    assert set(back) == set(books)
    assert np.allclose(back["a.attn2"], books["a.attn2"].levels, atol=1e-7)
    assert codebook.codebook_levels(back) == 16
    assert np.asarray(back["a.attn2"], np.float32).nbytes == 64          # 4 bytes per level
    with pytest.raises(ValueError):
        codebook.codebook_levels({"a": np.zeros(16), "b": np.zeros(64)})
