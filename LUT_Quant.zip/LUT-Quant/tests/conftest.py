import sys
from pathlib import Path

# Allow `pytest` from a fresh checkout without `pip install -e .`.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


# ------------------------------------------------------------------ run records
# A run folder with one record of every kind, written with round numbers; used
# by the tests of the ledger, the tables, the figures and the archive.
import numpy as np  # noqa: E402
import pytest  # noqa: E402

from lutq import records  # noqa: E402


def _cfg(method, protocol="coco1k", wa=64, calib=64, variant="standard", seed=42):
    q = method != "fp16"
    ext = method in ("qdiffusion", "tfmqdm")
    lut = method in ("lut", "aciq", "histogram", "learned_log")
    return {"model": "sd14", "method": method, "wbits": 8 if q else None, "abits": 8 if q else None,
            "score_levels": 256 if q and not ext else None, "wa_calib_prompts": wa if q else None,
            "calib_prompts": calib if lut else None, "variant": variant if lut else None,
            "protocol": protocol, "n_prompts": 4, "seed": seed}


def _run(root, rel, cfg, **metrics):
    digests = [f"{rel}-{i}" for i in range(4)]
    inputs = {"prompts_sha256": f"prompts-{cfg['protocol']}"}
    wa = cfg.get("wa_calib_prompts")
    if wa and cfg["method"] not in ("qdiffusion", "tfmqdm"):
        inputs["dgq_ckpt"] = {"sha256": f"ckpt-{wa}", "record": {
            "config": {"calib_prompts": wa}, "timings": {"weight_seconds": 100 * wa, "activation_seconds": 10 * wa}}}
    records.write_record(root / rel / "generate_00000.json", "generation", cfg, inputs=inputs,
                         shard={"start": 0, "count": 2}, digests=digests[:2])
    records.write_record(root / rel / "generate_00002.json", "generation", cfg, inputs=inputs,
                         shard={"start": 2, "count": 2}, digests=digests[2:])
    if metrics:
        records.write_record(root / rel / "metrics.json", "metrics", {"images": rel, "protocol": cfg["protocol"]},
                             inputs={"prompts_sha256": inputs["prompts_sha256"]},
                             image_set_sha256=records.sha256_text(digests), metrics=metrics)
    return records.sha256_text(digests)


@pytest.fixture
def small_protocols(monkeypatch):
    """Every protocol holds 4 prompts, so the test runs below are complete."""
    from lutq import data

    monkeypatch.setattr(data, "PROTOCOLS", {k: 4 for k in data.PROTOCOLS})


@pytest.fixture
def runs(tmp_path, small_protocols):
    base = {"fp16": 10.0, "qdiffusion": 11.0, "tfmqdm": 10.8, "dgq": 10.5, "lut": 10.4}
    fp1k = records.sha256_text(f"coco1k/fp16-{i}" for i in range(4))
    for m, v in base.items():
        _run(tmp_path, f"coco30k/{m}", _cfg(m, "coco30k"), fid=v, fid_lo=v - 0.2, fid_hi=v + 0.2, clip=0.33,
             **{"is": 30.0})
        _run(tmp_path, f"coco1k/{m}", _cfg(m, "coco1k"), fid=v + 30, clip=0.33, is_sd=1.0,
             **({} if m == "fp16" else {"lpips": 0.1, "lpips_lo": 0.09, "lpips_hi": 0.11, "psnr": 22.0,
                                        "fp_image_set_sha256": fp1k}),
             **{"is": 20.0})
    for i, m in enumerate(("aciq", "histogram", "learned_log", "lut", "dgq")):
        _run(tmp_path, f"coco10k/{m}", _cfg(m, "coco10k"), fid=15.0 + i, clip=0.33 - 0.001 * i, **{"is": 30.0 + i})
    for n in (4, 8):
        _run(tmp_path, f"budget/dgq{n}", _cfg("dgq", "coco30k", wa=n), fid=11.0 - 0.1 * n, clip=0.33)
        _run(tmp_path, f"budget/lut{n}", _cfg("lut", "coco30k", wa=n, calib=n), fid=10.6, clip=0.33)
    for v in ("standard", "tsadaptive", "selfcross"):
        _run(tmp_path, f"coco200/{v}", _cfg("lut", "coco200", calib=8, variant=v), fid=140.0, clip=0.33, **{"is": 10.0})
    for n in (4, 8, 16, 32):
        records.write_record(tmp_path / f"codebooks/c{n}/lloyd.json", "codebook",
                             {"rule": "lloyd", "variant": "standard", "levels": 256, "n_prompts": n},
                             summary={"n_codebooks": 16, "nonfinite": 0, "zero_width_bins": 0, "empty_cells": 3,
                                      "stabilized_at_max": 25, "profile_seconds": 10.0 * n, "fit_seconds": 30.0})
    for m, ms in (("fp16", 1400.0), ("dgq", 2900.0), ("lut", 2920.0)):
        records.write_record(tmp_path / f"latency/{m}.json", "latency",
                             {"method": m, "wbits": None if m == "fp16" else 8, "abits": None if m == "fp16" else 8,
                              "warmup": 5}, ms=[ms] * 19 + [ms + 10], mean_ms=ms + 0.5, sd_ms=2.2, lut_bytes=16384)
    layers = [{"layer": f"l{i}", "short": f"D0.A{i}", "log2": 5e-6, "log2_sd": 5e-7, "lut": 2e-7, "lut_sd": 2e-8,
               "ratio": 25.0} for i in range(16)]
    phases = [{"phase": "Steps 1–5", "log2": 6e-6, "log2_sd": 1e-7, "lut": 2e-7, "lut_sd": 1e-8, "ratio": 30.0}]
    records.write_record(tmp_path / "intrinsic/x.json", "intrinsic", {"n_prompts": 4}, layers=layers, phases=phases,
                         pooled={"log2": 5e-6, "lut": 2e-7, "ratio": 25.0})
    np.savez(tmp_path / "intrinsic/x.errors.npz", log2=np.linspace(-0.1, 0.1, 50), lut=np.linspace(-0.01, 0.01, 50))
    sets = {m: _run(tmp_path, f"parti500/{m}", _cfg(m, "parti500")) for m in ("fp16", "dgq", "lut")}
    records.write_record(tmp_path / "parti500/domain_shift.json", "domain_shift", {"protocol": "parti500"},
                         results={"n_images": 500, "clip": {"fp16": 0.335, "dgq": 0.334, "lut": 0.334},
                                  "image_sets": sets,
                                  "fid_to_fp": {"dgq": {"fid": 38.0, "lo": 36.0, "hi": 40.0},
                                                "lut": {"fid": 35.0, "lo": 33.0, "hi": 37.0},
                                                "lut-dgq": {"diff": -3.0, "lo": -4.0, "hi": -2.0}},
                                  "cmmd": {"dgq": 0.41, "lut": 0.37}})
    return tmp_path




@pytest.fixture
def complete_runs(runs):
    """``runs`` completed so that every cell of Tables I-VIII and S1-S3 has a valid record."""
    for proto, fp, gap in (("diffusiondb500", 0.344, -4.0), ("drawbench200", 0.325, -8.0)):
        sets = {m: _run(runs, f"{proto}/{m}", _cfg(m, proto)) for m in ("fp16", "dgq", "lut")}
        records.write_record(runs / f"{proto}/domain_shift.json", "domain_shift", {"protocol": proto},
                             results={"n_images": 4, "clip": {"fp16": fp, "dgq": fp, "lut": fp}, "image_sets": sets,
                                      "fid_to_fp": {"dgq": {"fid": 40.0, "lo": 39.0, "hi": 41.0},
                                                    "lut": {"fid": 40.0 + gap, "lo": 39.0 + gap, "hi": 41.0 + gap},
                                                    "lut-dgq": {"diff": gap, "lo": gap - 1, "hi": gap + 1}},
                                      "cmmd": {"dgq": 0.45, "lut": 0.40}})
    for n in (4, 16):
        _run(runs, f"coco200/c{n}", _cfg("lut", "coco200", calib=n), fid=140.0, clip=0.33, **{"is": 10.0})
    for lv in (64, 16):
        _run(runs, f"coco200/L{lv}", dict(_cfg("lut", "coco200", calib=8), score_levels=lv), fid=150.0, clip=0.33,
             **{"is": 9.0})
    for v in ("standard", "tsadaptive", "selfcross"):
        _run(runs, f"coco10k/c8_{v}", _cfg("lut", "coco10k", calib=8, variant=v), fid=15.5, clip=0.33, **{"is": 36.0})
    for seed in (1042, 2042):
        for m, v in (("dgq", 19.0), ("lut", 18.0)):
            _run(runs, f"seeds/{m}{seed}", _cfg(m, "coco10k", seed=seed), fid=v + seed / 10000, clip=0.33,
                 **{"is": 30.0})
    records.write_record(runs / "codebooks/c64/lloyd.json", "codebook",
                         {"rule": "lloyd", "variant": "standard", "levels": 256, "n_prompts": 64},
                         summary={"n_codebooks": 16, "nonfinite": 0, "zero_width_bins": 0, "empty_cells": 3,
                                  "stabilized_at_max": 25, "profile_seconds": 640.0, "fit_seconds": 30.0})
    from lutq.codebook import save_codebooks

    save_codebooks({f"down_blocks.{i // 2}.attentions.{i % 2}.transformer_blocks.0.attn2":
                    np.geomspace(1e-4, 1.0, 256) for i in range(6)}, runs / "codebooks/c64/lloyd.npz")
    records.write_record(runs / "rerun/lut/digest_comparison.json", "digest_comparison",
                         {"run_a": "coco200/standard", "run_b": "rerun/lut"}, n_a=4, n_b=4, compared=4, identical=4,
                         all_identical=True)
    return runs
