"""Command-line tools that need no model: report, figures, bundle, digest, and the input checks of the others."""

import json

import pytest

from lutq import cli, records


def test_report_figures_and_bundle_commands(complete_runs, tmp_path, capsys):
    runs = complete_runs
    cli.report([str(runs)])
    assert (runs / "report" / "tables.md").exists() and (runs / "report" / "tableVIII.csv").exists()
    pytest.importorskip("matplotlib")
    cli.figures([str(runs)])
    assert (runs / "report" / "figures" / "fig7_per_layer_mse.png").exists()
    cli.bundle(["create", str(runs), "--out", str(tmp_path / "r.tar.gz")])
    cli.bundle(["verify", str(tmp_path / "r.tar.gz")])
    assert "all files match" in capsys.readouterr().out


def test_strict_report_exits_on_invalid_runs(runs):
    (runs / "coco30k/lut/generate_00002.json").unlink()            # half of the images unrecorded
    with pytest.raises(SystemExit, match="2 of 4 images"):
        cli.report([str(runs)])
    cli.report([str(runs), "--allow-incomplete"])


def test_levels_must_be_powers_of_two():
    with pytest.raises(SystemExit):
        cli.intrinsic(["--codebooks", "x.npz", "--levels", "100", "--out", "y.json"])


def test_lut_methods_need_matching_codebooks(tmp_path):
    import numpy as np

    from lutq import codebook

    path = tmp_path / "aciq.npz"
    codebook.save_codebooks({"a.attn2": np.linspace(0, 1, 256)}, path)
    records.write_record(path.with_suffix(".json"), "codebook", {"rule": "aciq", "variant": "standard", "n_prompts": 64})
    ckpt = tmp_path / "c.pth_merged"
    ckpt.write_bytes(b"x")
    base = ["--dgq-ckpt", str(ckpt), "--codebooks", str(path), "--out", str(tmp_path / "o")]
    for bad in (["--method", "lut"], ["--method", "aciq", "--variant", "selfcross"],
                ["--method", "aciq", "--score-levels", "64"]):
        with pytest.raises(SystemExit):
            cli.generate(bad + base)


def _images(folder, n):
    folder.mkdir(parents=True)
    for i in range(n):
        (folder / f"{i:05d}.png").write_bytes(f"image {i}".encode())
    return [records.sha256_file(folder / f"{i:05d}.png") for i in range(n)]


def test_eval_refuses_images_that_differ_from_the_generation_record(tmp_path):
    img = tmp_path / "run" / "images"
    digests = _images(img, 3)
    records.write_record(tmp_path / "run/generate_00000.json", "generation", {"n_prompts": 3},
                         shard={"start": 0, "count": 3}, digests=digests)
    (img / "00002.png").write_bytes(b"a later image")
    with pytest.raises(SystemExit, match="refusing to evaluate"):
        cli.evaluate(["fid", "--images", str(img)])


def test_digest_hash_imports_only_matching_baseline_images(tmp_path, monkeypatch):
    from lutq import data

    prompts = ["a red bicycle", "two cats on a sofa"]
    monkeypatch.setattr(data, "prompts_for", lambda protocol: prompts)
    img = tmp_path / "baseline"
    digests = _images(img, 2)
    prov = {"method": "qdiffusion", "prompts_sha256": records.sha256_text(prompts), "seed": 42, "wbits": 8,
            "abits": 8, "calib_prompts": 64, "steps": 25, "guidance": 7.5, "size": 512, "digests": digests,
            "checkpoint_sha256": "c", "commit": "715783da70baa267321d6700ceb8941400c309d1"}
    (tmp_path / "provenance.json").write_text(json.dumps(prov))
    args = ["hash", str(img), "--protocol", "coco1k", "--method", "qdiffusion", "--provenance",
            str(tmp_path / "provenance.json"), "--out", str(tmp_path / "run")]
    cli.digest(args)
    rec = records.read_record(tmp_path / "run/generate_00000.json")
    assert rec["digests"] == digests and rec["config"]["wa_calib_prompts"] == 64 and rec["config"]["n_prompts"] == 2
    prov["prompts_sha256"] = "another list"
    (tmp_path / "provenance.json").write_text(json.dumps(prov))
    with pytest.raises(SystemExit, match="another prompt list"):
        cli.digest(args)


def test_digest_compare(tmp_path):
    for run, last in (("a", "x"), ("b", "y")):
        records.write_record(tmp_path / run / "generate_00000.json", "generation", {"n_prompts": 2},
                             shard={"start": 0, "count": 2}, digests=["same", last])
    cli.digest(["compare", str(tmp_path / "a"), str(tmp_path / "b"), "--out", str(tmp_path / "cmp.json")])
    rec = records.read_record(tmp_path / "cmp.json")
    assert rec["compared"] == 2 and rec["identical"] == 1 and rec["all_identical"] is False


def test_eval_refuses_a_different_prompt_list_of_the_same_length(tmp_path):
    img = tmp_path / "run" / "images"
    digests = _images(img, 2)
    records.write_record(tmp_path / "run/generate_00000.json", "generation", {"n_prompts": 2},
                         inputs={"prompts_sha256": records.sha256_text(["a red bicycle", "two cats"])},
                         shard={"start": 0, "count": 2}, digests=digests)
    other = tmp_path / "prompts.txt"
    other.write_text("a blue bicycle\ntwo dogs\n")
    with pytest.raises(SystemExit, match="prompt list differs"):
        cli.evaluate(["clip", "--images", str(img), "--prompts", str(other)])
