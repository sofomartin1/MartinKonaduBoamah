"""Metric arithmetic that needs no network weights."""

import numpy as np
import pytest

from lutq.metrics import cmmd, inception_score, inception_score_bootstrap, psnr


def _probs(n=400, classes=20, seed=0, scale=6.0):
    rng = np.random.default_rng(seed)
    logits = rng.normal(size=(n, classes)) * scale
    p = np.exp(logits - logits.max(axis=1, keepdims=True))
    return p / p.sum(axis=1, keepdims=True)


def test_fixed_split_inception_score():
    p = _probs()
    assert inception_score(p) == inception_score(p.copy())
    assert inception_score(np.full((100, 10), 0.1))[0] == pytest.approx(1.0)


def test_bootstrap_describes_the_ten_split_estimator():
    p = _probs()
    point, lo, hi = inception_score_bootstrap(p, n_boot=300, seed=0)
    assert point == inception_score(p)[0] and lo < point < hi
    assert inception_score_bootstrap(p, 50, seed=3) == inception_score_bootstrap(p, 50, seed=3)


def test_cmmd_and_psnr():
    rng = np.random.default_rng(0)
    x, y = rng.normal(size=(50, 8)), rng.normal(loc=0.5, size=(60, 8))
    assert cmmd(x, x) == pytest.approx(0.0, abs=1e-9)
    assert cmmd(x, y) == pytest.approx(cmmd(y, x)) and cmmd(x, y) > 0
    a = rng.random((8, 8, 3))
    assert psnr(a, a + 0.1) == pytest.approx(20.0)


def test_paired_fid_bootstrap():
    pytest.importorskip("cleanfid")
    from lutq.metrics import fid_to_reference_paired

    rng = np.random.default_rng(0)
    ref = rng.normal(size=(300, 16))
    near, far = ref + rng.normal(scale=0.2, size=ref.shape), ref + rng.normal(scale=0.6, size=ref.shape)
    res = fid_to_reference_paired({"lut": near, "dgq": far}, ref, n_boot=100, seed=0)
    assert res["lut"]["fid"] < res["dgq"]["fid"]
    d = res["lut-dgq"]
    assert d["diff"] == pytest.approx(res["lut"]["fid"] - res["dgq"]["fid"]) and d["hi"] < 0
    with pytest.raises(ValueError):
        fid_to_reference_paired({"lut": near[:10]}, ref)


def _reference_mmd(x, y, sigma=10.0, scale=1000.0):
    """``distance.mmd`` of the CMMD reference code (google-research/google-research, cmmd/), in NumPy."""
    x_sq = np.diag(x @ x.T)
    y_sq = np.diag(y @ y.T)
    gamma = 1 / (2 * sigma ** 2)
    k_xx = np.mean(np.exp(-gamma * (-2 * x @ x.T + x_sq[:, None] + x_sq[None, :])))
    k_xy = np.mean(np.exp(-gamma * (-2 * x @ y.T + x_sq[:, None] + y_sq[None, :])))
    k_yy = np.mean(np.exp(-gamma * (-2 * y @ y.T + y_sq[:, None] + y_sq[None, :])))
    return scale * (k_xx + k_yy - 2 * k_xy)


def test_cmmd_equals_the_reference_estimator_on_unit_embeddings():
    rng = np.random.default_rng(1)
    x, y = rng.normal(size=(40, 768)), rng.normal(loc=0.05, size=(30, 768))
    x /= np.linalg.norm(x, axis=1, keepdims=True)
    y /= np.linalg.norm(y, axis=1, keepdims=True)
    assert cmmd(x, y) == pytest.approx(_reference_mmd(x, y), rel=1e-12)


def test_resized_copies_follow_their_originals(tmp_path):
    Image = pytest.importorskip("PIL.Image")
    from lutq.metrics import resized

    src = tmp_path / "run" / "images"
    src.mkdir(parents=True)
    Image.new("RGB", (64, 64), (255, 0, 0)).save(src / "00000.png")
    Image.new("RGB", (64, 64), (0, 255, 0)).save(src / "00001.png")
    out = resized(src, 16)
    assert np.asarray(Image.open(out / "00000.png"))[0, 0].tolist() == [255, 0, 0]
    Image.new("RGB", (64, 64), (0, 0, 255)).save(src / "00000.png")      # same count, new content
    (src / "00001.png").unlink()
    out = resized(src, 16)
    assert np.asarray(Image.open(out / "00000.png"))[0, 0].tolist() == [0, 0, 255]
    assert sorted(p.name for p in out.glob("*.png")) == ["00000.png"]        # the copy without an original is gone


def test_metrics_read_exactly_the_run_images(tmp_path):
    from lutq.metrics import _images

    src = tmp_path / "images"
    src.mkdir()
    for name in ("00000.png", "00001.png"):
        (src / name).write_bytes(b"x")
    assert [p.name for p in _images(src)] == ["00000.png", "00001.png"]
    for extra in ("extra.png", "00002.jpg", "0001.png", "00002.PNG"):
        (src / extra).write_bytes(b"x")
        with pytest.raises(ValueError, match="naming scheme"):
            _images(src)
        (src / extra).unlink()
    (src / "00003.png").write_bytes(b"x")
    with pytest.raises(ValueError, match="indices"):
        _images(src)


def test_cmmd_preprocessing_follows_the_reference_steps():
    """Center crop, PIL bicubic resize to 336, [0, 1], CLIP mean/std (reference io_util and embedding)."""
    Image = pytest.importorskip("PIL.Image")
    from lutq.metrics import cmmd_preprocess

    rng = np.random.default_rng(0)
    im = Image.fromarray(rng.integers(0, 256, (400, 520, 3), dtype=np.uint8))
    w, h = im.size
    l = min(w, h)
    top, left = (h - l) // 2, (w - l) // 2
    ref = np.asarray(im.crop((left, top, left + l, top + l)).resize((336, 336), resample=Image.BICUBIC)).astype(
        np.float32) / 255.0
    mean = np.array([0.48145466, 0.4578275, 0.40821073])            # scenic clip.model.IMAGE_MEAN
    std = np.array([0.26862954, 0.26130258, 0.27577711])             # scenic clip.model.IMAGE_STD
    ref = ((ref - mean) / std).transpose(2, 0, 1)
    got = cmmd_preprocess(im)
    assert got.shape == (3, 336, 336) and np.allclose(got, ref, atol=1e-6)
