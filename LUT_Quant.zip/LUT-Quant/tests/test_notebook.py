"""The walkthrough notebook is valid and is stored without outputs."""

import json
from pathlib import Path

NOTEBOOK = Path(__file__).resolve().parents[1] / "notebooks" / "lutquant_walkthrough.ipynb"


def test_notebook_is_valid_and_has_no_outputs():
    nb = json.loads(NOTEBOOK.read_text(encoding="utf-8"))
    assert nb["nbformat"] == 4
    code = [c for c in nb["cells"] if c["cell_type"] == "code"]
    assert code and all(c["outputs"] == [] and c["execution_count"] is None for c in code)
    for c in code:
        compile("".join(c["source"]), "<cell>", "exec")
