"""Placement rules of Table III."""

import numpy as np
import pytest

from lutq import quantizers
from test_codebook import X


def test_log2_rounds_in_the_log_domain_like_dgq():
    x = np.array([1.0, 0.7, 0.5, 0.36, 0.2, 1e-6, 0.0])
    q = quantizers.log2_quantize(x, 8)
    n = np.clip(np.rint(-np.log2(np.where(x > 0, x, 1e-300))), 0, 7)
    assert np.allclose(q, 2.0 ** -n)


@pytest.mark.parametrize("rule", sorted(quantizers.RULES))
def test_every_rule_places_l_sorted_levels(rule):
    lv = quantizers.levels_for(rule, X, 64)
    assert lv.size == 64 and np.all(np.diff(lv) >= 0) and lv.min() >= 0 and lv.max() <= X.max() + 1e-12


def test_clipping_rules_clip_below_the_maximum():
    assert quantizers.levels_for("histogram", X, 64).max() == pytest.approx(np.percentile(X, 99.9))
    assert quantizers.levels_for("aciq", X, 64).max() < X.max()


def test_learned_log_is_a_fitted_geometric_grid():
    lv = quantizers.levels_for("learned_log", X, 64)[::-1]
    ratios = lv[1:] / lv[:-1]
    assert np.allclose(ratios, ratios[0])
    assert quantizers.quantization_mse("learned_log", X, 64) <= quantizers.quantization_mse("log2", X, 64) * 1.0001


def test_lloyd_beats_log2_and_the_clipped_uniform_rules():
    m = {r: quantizers.quantization_mse(r, X, 256) for r in quantizers.RULES}
    assert m["lloyd"] < min(m["log2"], m["aciq"], m["histogram"])
