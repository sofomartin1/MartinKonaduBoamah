"""scripts/run_experiments.sh issues the commands each table needs.

The lutq-* tools are replaced by stubs that record their arguments, so the
test checks the experiment plan without running a model.
"""

import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ("calibrate", "generate", "eval", "shift", "intrinsic", "latency", "digest", "report", "figures", "bundle")

pytestmark = pytest.mark.skipif(shutil.which("bash") is None, reason="needs bash")


def plan(tmp_path, *args, env_extra=None, books=True, baselines=True, check=True):
    bin_ = tmp_path / "bin"
    bin_.mkdir(exist_ok=True)
    log = tmp_path / "calls.txt"
    log.write_text("")
    for t in TOOLS:
        stub = bin_ / f"lutq-{t}"
        stub.write_text(f'#!/usr/bin/env bash\necho "lutq-{t} $*" >> "{log}"\n')
        stub.chmod(0o755)
    py = bin_ / "python"
    py.write_text(f'#!/usr/bin/env bash\nexec "{sys.executable}" "$@"\n')
    py.chmod(0o755)
    runs = tmp_path / "runs"
    for c, v, lv in () if not books else ((64, "standard", 256), (4, "standard", 256), (8, "standard", 256),
                                          (16, "standard", 256), (32, "standard", 256), (8, "tsadaptive", 256),
                                          (8, "selfcross", 256), (8, "standard", 64), (8, "standard", 16)):
        d = runs / "codebooks" / f"L{lv}_c{c}_{v}"
        d.mkdir(parents=True, exist_ok=True)
        for r in ("lloyd", "aciq", "histogram", "learned_log"):
            (d / f"{r}.npz").write_bytes(b"")
    ckpts = tmp_path / "ckpts"
    ckpts.mkdir(exist_ok=True)
    for n in (4, 8, 64):
        (ckpts / f"sd14_w8a8_c{n}.pth_merged").write_bytes(b"")
    base = tmp_path / "baselines"
    if baselines:
        for proto in ("coco30k", "coco1k"):
            for m in ("qdiffusion", "tfmqdm"):
                (base / proto / m).mkdir(parents=True, exist_ok=True)
                (base / proto / m / "provenance.json").write_text("{}")
                (base / proto / m / "00000.png").write_bytes(b"")
    env = dict(os.environ, PATH=f"{bin_}{os.pathsep}{os.environ['PATH']}", RUNS=str(runs), DGQ_CKPTS=str(ckpts),
               PYTHONPATH=str(ROOT / "src"), BASELINES=str(base))
    env.update(env_extra or {})
    proc = subprocess.run(["bash", str(ROOT / "scripts" / "run_experiments.sh"), *args], cwd=ROOT, env=env,
                          check=check, capture_output=True, text=True)
    calls = []
    for line in log.read_text().splitlines():
        words = shlex.split(line)
        opts, i = {}, 1
        while i < len(words):
            if words[i].startswith("--"):
                vals = []
                while i + 1 < len(words) and not words[i + 1].startswith("--"):
                    vals.append(words[i + 1])
                    i += 1
                opts[words[i - len(vals)]] = " ".join(vals) if vals else True
            i += 1
        calls.append((words[0], opts))
    return calls if check else (proc, calls)


def gens(calls):
    out = set()
    for t, o in calls:
        if t == "lutq-generate":
            ck = Path(o["--dgq-ckpt"]).name if "--dgq-ckpt" in o else None
            cb = "/".join(Path(o["--codebooks"]).parts[-2:]) if "--codebooks" in o else None
            out.add((o["--protocol"], o["--method"], ck, cb, o.get("--variant")))
    return out


def levels(calls):
    return {(o["--protocol"], o.get("--score-levels")) for t, o in calls if t == "lutq-generate" and o["--method"] != "fp16"}


def test_calibrate_fits_every_table_from_one_profile_each(tmp_path):
    calls = plan(tmp_path, "calibrate")
    assert calls == []                      # every look-up table already exists: nothing is refitted
    shutil.rmtree(tmp_path / "runs" / "codebooks")
    calls = [o for t, o in plan(tmp_path, "calibrate", books=False) if t == "lutq-calibrate"]
    got = {(o["--protocol"], o["--variant"], o["--rules"]) for o in calls}
    assert got == {("coco_calib64", "standard", "lloyd aciq histogram learned_log"),
                   *{(f"coco_calib{c}", "standard", "lloyd") for c in (4, 8, 16, 32)},
                   ("coco_calib8", "tsadaptive", "lloyd"), ("coco_calib8", "selfcross", "lloyd")}
    assert {o["--levels"] for o in calls} == {"256", "64", "16"}


def test_table1_and_table8_budgets(tmp_path):
    c1 = plan(tmp_path, "table1")
    g1 = gens(c1)
    ck64 = "sd14_w8a8_c64.pth_merged"
    assert g1 == {("coco30k", "fp16", None, None, None), ("coco30k", "dgq", ck64, None, None),
                  ("coco30k", "lut", ck64, "L256_c64_standard/lloyd.npz", "standard")}
    hashed = {o["--method"]: o for t, o in c1 if t == "lutq-digest"}
    assert set(hashed) == {"qdiffusion", "tfmqdm"} and all("--provenance" in o for o in hashed.values())
    assert all(Path(o["--dgq-ckpt"]).is_absolute() for t, o in c1 if t == "lutq-generate" and "--dgq-ckpt" in o)
    g8 = gens(plan(tmp_path, "table8"))
    assert g8 == {("coco30k", "dgq", f"sd14_w8a8_c{n}.pth_merged", None, None) for n in (4, 8)} | \
                 {("coco30k", "lut", f"sd14_w8a8_c{n}.pth_merged", f"L256_c{n}_standard/lloyd.npz", "standard")
                  for n in (4, 8)}
    evals = [o for t, o in plan(tmp_path, "table8") if t == "lutq-eval"]
    assert len(evals) == 4 and all(o["--bootstrap"] == "1000" for o in evals)


def test_table3_rules_share_the_64_caption_profile(tmp_path):
    g = gens(plan(tmp_path, "table3"))
    assert {(m, cb) for p, m, _, cb, _ in g} == {("aciq", "L256_c64_standard/aciq.npz"),
                                                 ("histogram", "L256_c64_standard/histogram.npz"),
                                                 ("learned_log", "L256_c64_standard/learned_log.npz"),
                                                 ("lut", "L256_c64_standard/lloyd.npz"), ("dgq", None)}
    assert {p for p, *_ in g} == {"coco10k"}


def test_table6_ablations(tmp_path):
    calls = plan(tmp_path, "table6")
    g = gens(calls)
    assert g == {(p, "lut", "sd14_w8a8_c64.pth_merged", f"L256_c8_{v}/lloyd.npz", v)
                 for p in ("coco200", "coco10k") for v in ("standard", "tsadaptive", "selfcross")} | \
                {("coco200", "lut", "sd14_w8a8_c64.pth_merged", f"L256_c{c}_standard/lloyd.npz", "standard")
                 for c in (4, 16)} | \
                {("coco200", "lut", "sd14_w8a8_c64.pth_merged", f"L{lv}_c8_standard/lloyd.npz", "standard")
                 for lv in (64, 16)}
    assert levels(calls) == {("coco200", "256"), ("coco10k", "256"), ("coco200", "64"), ("coco200", "16")}


def test_table4_table5_table7_and_latency(tmp_path):
    c4 = plan(tmp_path, "table4")
    assert {o["--protocol"] for t, o in c4 if t == "lutq-shift"} == {"parti500", "diffusiondb500", "drawbench200"}
    assert len([1 for t, _ in c4 if t == "lutq-generate"]) == 9
    (t, o), = [c for c in plan(tmp_path, "table5") if c[0] == "lutq-intrinsic"]
    assert o["--protocol"] == "coco_calib4" and o["--codebooks"].endswith("L256_c4_standard/lloyd.npz")
    ev = {o["--images"].split("/")[-2]: o for t, o in plan(tmp_path, "table7") if t == "lutq-eval"}
    assert "--fp-images" in ev["dgq"] and "--fp-images" in ev["lut"] and "--fp-images" not in ev["fp16"]
    lat = {o["--method"]: o for t, o in plan(tmp_path, "table2") if t == "lutq-latency"}
    assert set(lat) == {"fp16", "dgq", "lut"} and all(o["--runs"] == "20" for o in lat.values())
    assert "--dgq-ckpt" not in lat["fp16"] and lat["lut"]["--codebooks"].endswith("L256_c64_standard/lloyd.npz")


def test_two_pass_execution(tmp_path):
    only_gen = plan(tmp_path, "table1", env_extra={"EVAL": "0"})
    assert {t for t, _ in only_gen} == {"lutq-generate", "lutq-digest"}     # baseline images are imported here
    only_eval = plan(tmp_path, "table1", env_extra={"ONLY_EVAL": "1"})
    assert {t for t, _ in only_eval} == {"lutq-eval"}


def test_missing_baselines_stop_the_publication_tables(tmp_path):
    for table in ("table1", "table7"):
        proc, calls = plan(tmp_path, table, baselines=False, check=False)
        assert proc.returncode == 4 and "scripts/run_baselines.sh" in proc.stderr


def test_missing_checkpoint_stops_generation(tmp_path):
    proc, _ = plan(tmp_path, "table8", env_extra={"DGQ_CKPTS": str(tmp_path / "empty")}, check=False)
    assert proc.returncode == 3 and "dgq_quantize.sh 8 8 4" in proc.stderr


def test_seed_study_and_determinism(tmp_path):
    seeds = {(o["--method"], o["--seed"]) for t, o in plan(tmp_path, "seeds") if t == "lutq-generate"}
    assert seeds == {(m, s) for m in ("dgq", "lut") for s in ("1042", "2042")}
    calls = plan(tmp_path, "determinism")
    reruns = [o for t, o in calls if t == "lutq-generate" and o.get("--purpose") == "rerun"]
    firsts = [o for t, o in calls if t == "lutq-generate" and "--purpose" not in o]
    assert {o["--method"] for o in reruns} == {"fp16", "dgq", "lut"} == {o["--method"] for o in firsts}
    assert all(o["--protocol"] == "coco200" for o in reruns)
    assert len([1 for t, _ in calls if t == "lutq-digest"]) == 3


def test_report_is_strict_and_compares_with_the_paper(tmp_path):
    calls = plan(tmp_path, "report")
    (t, o), = [c for c in calls if c[0] == "lutq-report"]
    assert o["--expected"] == "paper/reported_values.json" and "--allow-incomplete" not in o
    (t, o), = [c for c in calls if c[0] == "lutq-bundle"]
    assert "data/prompts" in o["--include"] and "locks" in o["--include"]


def test_release_stops_when_the_publication_check_fails(tmp_path):
    """make_release.sh builds nothing when lutq-report fails (missing records or mismatches with the paper)."""
    if shutil.which("git") is None:
        pytest.skip("needs git")
    repo = tmp_path / "repo"
    shutil.copytree(ROOT, repo, ignore=shutil.ignore_patterns(".git", "__pycache__", "runs", "release"))
    bin_ = tmp_path / "bin"
    bin_.mkdir()
    log = tmp_path / "calls.txt"
    for t, code in (("report", 1), ("figures", 0), ("bundle", 0)):
        (bin_ / f"lutq-{t}").write_text(f'#!/usr/bin/env bash\necho "lutq-{t} $*" >> "{log}"\nexit {code}\n')
        (bin_ / f"lutq-{t}").chmod(0o755)
    git = ["git", "-c", "user.name=t", "-c", "user.email=t@t", "-C", str(repo)]
    subprocess.run(git + ["init", "-q"], check=True)
    subprocess.run(git + ["add", "-A"], check=True)
    subprocess.run(git + ["commit", "-qm", "release"], check=True)
    subprocess.run(git + ["tag", "v1.0.0"], check=True)
    env = dict(os.environ, PATH=f"{bin_}{os.pathsep}{os.environ['PATH']}")
    proc = subprocess.run(["bash", str(repo / "scripts" / "make_release.sh"), "v1.0.0"], env=env,
                          capture_output=True, text=True)
    calls = log.read_text().split()
    assert proc.returncode != 0 and "lutq-report" in calls and "lutq-bundle" not in calls
    assert not (repo / "release" / "v1.0.0").exists()
