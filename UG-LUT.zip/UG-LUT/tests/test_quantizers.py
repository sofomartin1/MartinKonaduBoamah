"""Level placements of Table 6 and the uniform lookup grid."""

import numpy as np
import pytest

from uglut import codebook, grid, quantizers
from test_codebook import X


def test_log2_rounds_in_the_log_domain_like_dgq():
    x = np.array([1.0, 0.7, 0.5, 0.36, 0.2, 1e-6, 0.0])
    q = quantizers.log2_quantize(x, 8)
    n = np.clip(np.rint(-np.log2(np.where(x > 0, x, 1e-300))), 0, 7)
    assert np.allclose(q, 2.0 ** -n)
    assert q[-1] == 2.0 ** -7 and q[-2] == 2.0 ** -7   # clamped to the smallest level


def test_placements_have_l_levels_on_zero_to_max():
    for rule in quantizers.RULES:
        lv = quantizers.levels_for(rule, X, 64)
        assert lv.size == 64 and lv.min() >= 0
        if rule == "lloyd":
            assert lv.max() <= X.max()
        else:
            assert lv.max() == pytest.approx(X.max())


@pytest.mark.parametrize("k", [16, 64, 256])
def test_lloyd_beats_uniform_and_log2(k):
    m = {r: quantizers.quantization_mse(r, X, k) for r in quantizers.RULES}
    assert m["lloyd"] < m["log2"] and m["lloyd"] < m["uniform"]


def test_moment_matched_reconstruction_keeps_mean_and_variance():
    y = quantizers.moment_matched(X, 200_000, seed=0)
    assert y.max() <= X.max()
    assert y.mean() == pytest.approx(X.mean(), rel=0.02)
    assert y.var() == pytest.approx(X.var(), rel=0.05)


def test_grid_matches_exact_search_up_to_its_resolution():
    lv = codebook.fit_lloyd(X, k=256).levels
    ce = grid.compilation_error(X, lv, 4096)
    assert ce["mse_exact"] <= ce["mse_grid"] < 1.10 * ce["mse_exact"]
    coarse = codebook.fit_lloyd(X, k=16).levels
    assert grid.compilation_error(X, coarse, 4096)["disagreement_rate"] < 0.01


def test_memory_of_sd14_tables():
    # 16 cross-attention layers x (4,096 int32 grid entries + 256 float32 levels) = 272 KiB
    assert grid.memory_bytes(16) == 272 * 1024
