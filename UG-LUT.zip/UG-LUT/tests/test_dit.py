"""SD3 / FLUX.1 (diffusers >= 0.30): no separable cross-attention tensor, so both score
quantizers leave the model untouched and the quantized outputs are bit-identical.
Runs in the DiT environment (envs/requirements-dit.txt)."""

from types import SimpleNamespace

import pytest

torch = pytest.importorskip("torch")
diffusers = pytest.importorskip("diffusers")
if not hasattr(diffusers, "FluxTransformer2DModel"):
    pytest.skip("SD3 / FLUX.1 need diffusers >= 0.30 (DiT environment)", allow_module_level=True)

from uglut import attention, pipeline  # noqa: E402


def _sd3():
    torch.manual_seed(0)
    m = diffusers.SD3Transformer2DModel(sample_size=8, patch_size=2, in_channels=4, num_layers=2,
                                        attention_head_dim=8, num_attention_heads=2, joint_attention_dim=16,
                                        caption_projection_dim=16, pooled_projection_dim=8, out_channels=4)
    g = torch.Generator().manual_seed(1)
    args = dict(hidden_states=torch.randn(1, 4, 8, 8, generator=g),
                encoder_hidden_states=torch.randn(1, 6, 16, generator=g),
                pooled_projections=torch.randn(1, 8, generator=g), timestep=torch.tensor([500]))
    return m.eval(), args


def _flux():
    torch.manual_seed(0)
    m = diffusers.FluxTransformer2DModel(patch_size=1, in_channels=8, num_layers=1, num_single_layers=1,
                                         attention_head_dim=8, num_attention_heads=2, joint_attention_dim=16,
                                         pooled_projection_dim=8, axes_dims_rope=(2, 2, 4))
    g = torch.Generator().manual_seed(1)
    args = dict(hidden_states=torch.randn(1, 16, 8, generator=g),
                encoder_hidden_states=torch.randn(1, 6, 16, generator=g),
                pooled_projections=torch.randn(1, 8, generator=g), timestep=torch.tensor([0.5]),
                img_ids=torch.zeros(16, 3), txt_ids=torch.zeros(6, 3))
    return m.eval(), args


@pytest.mark.parametrize("make", [_sd3, _flux])
def test_no_attention_module_is_replaced(make):
    model, _ = make()
    assert not any(".attn2." in n for n, _ in model.named_modules())
    assert attention.install(SimpleNamespace(unet=None, transformer=model), mode="log2") == 0
    assert attention.install(SimpleNamespace(unet=None, transformer=model), mode="grid", codebooks={}) == 0


@pytest.mark.parametrize("make", [_sd3, _flux])
def test_dgq_and_uglut_pipelines_are_bit_identical(make):
    outs = []
    for method in ("dgq", "uglut"):
        model, args = make()
        pipeline.quantize_linear_layers(model, 8, 8, {n: 4.0 for n, m in model.named_modules()
                                                      if isinstance(m, torch.nn.Linear)})
        n = attention.install(SimpleNamespace(unet=None, transformer=model),
                              mode=pipeline.SCORE_MODE[method], codebooks={})
        assert n == 0
        with torch.no_grad():
            outs.append(model(**args).sample)
    assert torch.equal(outs[0], outs[1])
