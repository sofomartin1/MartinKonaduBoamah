"""Run records, the ledger, the rendered tables and the record bundle.

The records here are written by the test itself with round numbers; they only
exercise the plumbing from records to tables.
"""

import json
import tarfile

import pytest

from uglut import bundle, records, report


def _gen(root, rel, config, digests, start=0):
    return records.write_record(root / rel / f"generate_{start:05d}.json", "generation", config,
                                shard={"start": start, "count": len(digests)}, digests=digests)


def _metrics(root, rel, **m):
    return records.write_record(root / rel / "metrics.json", "metrics", {"images": rel},
                                image_set_sha256=records.sha256_text(m.pop("digests")), metrics=m)


def _cfg(method, model="sd14", protocol="coco1k", seed=42, wbits=8, abits=8, levels=256, calib=64,
         backend="dgq", variant="standard"):
    q = method != "fp16"
    return {"model": model, "method": method, "backend": backend if q else "none",
            "wbits": wbits if q else None, "abits": abits if q else None,
            "score_levels": levels if q and model in ("sd14", "sdxl") else None,
            "calib_prompts": calib if method == "uglut" and model in ("sd14", "sdxl") else None,
            "variant": variant if method == "uglut" and model in ("sd14", "sdxl") else None,
            "entries": 4096 if method == "uglut" else None, "protocol": protocol, "n_prompts": 4, "seed": seed}


@pytest.fixture
def runs(tmp_path):
    fid = {"dgq": 11.0, "uglut": 10.0}
    for s, off in ((42, 0.0), (137, 0.5), (2024, 0.2)):
        for m in ("dgq", "uglut"):
            for ab, extra in ((8, 0.0), (6, 1.0)):
                d = [f"{m}{s}{ab}{i}" for i in range(4)]
                rel = f"sd14/coco1k/w8a{ab}/seed{s}/{m}"
                _gen(tmp_path, rel, _cfg(m, seed=s, abits=ab), d[:2])
                _gen(tmp_path, rel, _cfg(m, seed=s, abits=ab), d[2:], start=2)
                v = fid[m] + off + extra + (0.1 * (s % 3) if m == "uglut" else 0.0)
                _metrics(tmp_path, rel, fid=v, digests=d, **{"is": 20.0 + off, "clip": 0.3})
    same = ["x0", "x1", "x2", "x3"]
    for m in ("dgq", "uglut"):
        _gen(tmp_path, f"sd3/coco1k/w8a8/seed42/{m}", _cfg(m, model="sd3", backend="reference"), same)
    return tmp_path


def test_ledger_joins_shards_and_metrics(runs):
    led = records.build_ledger(runs)
    r = records.select(led["runs"], model="sd14", method="uglut", abits=6, seed=137)
    assert len(r) == 1 and r[0]["n_images"] == 4 and r[0]["contiguous"]
    assert r[0]["image_set_sha256"] == r[0]["evaluated_set_sha256"]
    assert r[0]["fid"] == pytest.approx(10.0 + 0.5 + 1.0 + 0.2)


def test_shards_with_different_settings_are_rejected(tmp_path):
    _gen(tmp_path, "a/uglut", _cfg("uglut"), ["h0"])
    _gen(tmp_path, "a/uglut", _cfg("uglut", levels=64), ["h1"], start=1)
    with pytest.raises(ValueError):
        records.build_ledger(tmp_path)


def test_tables_are_rendered_from_records(runs):
    files = report.build_report(runs, runs / "report")
    names = {f.name for f in files}
    assert {"ledger.csv", "ledger.json", "tables.md", "table3.csv", "table8.csv"} <= names
    md = (runs / "report" / "tables.md").read_text(encoding="utf-8")
    assert "W8A6, paired ΔFID" in md and "t(2)" in md
    assert "SD3: SHA-256 of the 4 DGQ and UG-LUT images identical" in md
    led = records.build_ledger(runs)
    cols, rows, _ = report.table3(led, "dgq")
    row = next(r for r in rows if r[0] == "W8A8, seed 137")
    assert row[1:3] == ["10.70", "11.50"]


def test_missing_conditions_are_marked(runs):
    led = records.build_ledger(runs)
    _, rows, _ = report.table2(led, "dgq")
    assert all(report.MISSING in r[1] for r in rows)


def test_bundle_round_trip_and_tamper_detection(runs, tmp_path):
    (runs / "sd14" / "coco1k" / "w8a8" / "seed42" / "dgq" / "images").mkdir()
    (runs / "sd14" / "coco1k" / "w8a8" / "seed42" / "dgq" / "images" / "00000.png").write_bytes(b"png")
    out, n = bundle.create(runs, tmp_path / "rec.tar.gz")
    assert n > 0 and bundle.verify(out) == []
    with tarfile.open(out) as tar:
        names = tar.getnames()
    assert not any("/images/" in x for x in names) and any(x.endswith("MANIFEST.sha256") for x in names)
    # rewrite one record inside the archive
    bad = tmp_path / "bad.tar.gz"
    with tarfile.open(out) as src, tarfile.open(bad, "w:gz") as dst:
        for m in src.getmembers():
            data = src.extractfile(m).read()
            if m.name.endswith("metrics.json"):
                data = data.replace(b"20.0", b"21.0")
                m.size = len(data)
            import io
            dst.addfile(m, io.BytesIO(data))
    assert bundle.verify(bad)


def test_image_set_digest_matches_generation_digests(tmp_path):
    for i, b in enumerate((b"a", b"b")):
        (tmp_path / f"{i:05d}.png").write_bytes(b)
    h, n = records.image_set_digest(tmp_path)
    assert n == 2 and h == records.sha256_text(records.sha256_file(tmp_path / f"{i:05d}.png") for i in range(2))
    assert json.loads(json.dumps(records.provenance()))["uglut"]
