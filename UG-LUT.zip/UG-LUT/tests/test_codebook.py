"""Lloyd-Max fitting as specified in Algorithm 1: uniform start, re-seeding, stopping rule."""

import numpy as np
import pytest

from uglut import codebook


def scores(n=60_000, seed=0):
    """Normalized softmax scores of 76 text tokens: concentrated near 0 with a long tail."""
    rng = np.random.default_rng(seed)
    z = rng.normal(0.0, 2.0, (n // 76 + 1, 77))
    z[:, 0] += 4.0
    p = np.exp(z - z.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    x = p[:, 1:].ravel()[:n]
    return np.sort(x / x.max())


X = scores()


def test_initialization_is_uniform_on_zero_to_max():
    lv = codebook.uniform_init(X, 256)
    assert lv[0] == 0.0 and lv[-1] == pytest.approx(X.max())
    assert np.allclose(np.diff(lv), X.max() / 255)


def test_distortion_never_increases_and_levels_stay_in_range():
    fit = codebook.fit_lloyd(X, k=256)
    t = fit.trajectory
    assert all(t[i + 1] <= t[i] * (1 + 1e-12) for i in range(len(t) - 1))
    assert fit.finite and fit.levels.size == 256
    assert fit.levels.min() >= 0.0 and fit.levels.max() <= X.max()
    assert np.all(np.diff(fit.levels) >= 0)


def test_reseeding_populates_every_level():
    fit = codebook.fit_lloyd(X, k=256)
    assert fit.reseeded > 0
    assert fit.empty_cells == 0
    assert codebook.count_empty_cells(X, fit.levels) == 0


def test_textbook_update_fails_on_empty_cells():
    naive = codebook.fit_lloyd(X, k=256, reseed=False)
    assert not naive.finite
    assert naive.empty_cells > 0
    assert codebook.count_empty_cells(X, codebook.uniform_init(X, 256)) == naive.empty_cells


@pytest.mark.parametrize("k", [16, 64, 256, 1024])
def test_every_codebook_size_is_finite(k):
    assert codebook.fit_lloyd(X, k=k).finite


def test_stopping_rule_is_relative_codebook_change():
    fit = codebook.fit_lloyd(X, k=256, iters=50, tol=1e-4)
    assert fit.iterations <= 50
    if fit.converged:
        assert fit.relative_change < 1e-4
    capped = codebook.fit_lloyd(X, k=256, iters=2, tol=0.0)
    assert capped.iterations == 2 and not capped.converged


def test_lloyd_improves_on_its_uniform_start():
    fit = codebook.fit_lloyd(X, k=64)
    assert fit.distortion < codebook.mse(X, codebook.uniform_init(X, 64))


def test_save_and_load_round_trip(tmp_path):
    books = {"a.attn2": codebook.fit_lloyd(X, k=16), "a.attn2@early": np.linspace(0, 1, 16)}
    path = tmp_path / "cb.npz"
    codebook.save_codebooks(books, path, meta={"kind": "test"})
    back = codebook.load_codebooks(path)
    assert set(back) == set(books)
    assert np.allclose(back["a.attn2"], books["a.attn2"].levels, atol=1e-7)
    assert (tmp_path / "cb.json").exists()
    assert codebook.codebook_levels(back) == 16
    with pytest.raises(ValueError):
        codebook.codebook_levels({"a": np.zeros(16), "b": np.zeros(64)})
