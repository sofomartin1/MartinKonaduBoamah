"""Prompt protocols: nesting, disjointness and determinism (with stand-in caption sources)."""

import pytest

from uglut import data


@pytest.fixture
def sources(monkeypatch):
    pairs30k = [(i, f"caption of image {i}") for i in range(0, 60000, 2)]          # 30,000 even ids
    all_val = [(i, f"caption of image {i}") for i in range(60000)]
    monkeypatch.setattr(data, "coco30k_pairs", lambda: pairs30k)
    monkeypatch.setattr(data, "coco_captions", lambda: all_val)
    return pairs30k


def test_evaluation_lists_are_nested_prefixes(sources):
    full = data.sample("coco30k")
    assert len(full) == 30000
    assert data.sample("coco1k") == full[:1000]
    assert data.sample("coco200") == full[:200]


def test_calibration_lists_are_nested_and_disjoint_from_evaluation(sources):
    c64 = data.sample("coco_calib64")
    assert len(c64) == len(set(c64)) == 64
    for k in (4, 8, 16, 32):
        assert data.sample(f"coco_calib{k}") == c64[:k]
    assert not set(c64) & set(data.sample("coco30k"))
    assert data.sample("coco_calib64") == c64            # deterministic


def test_image_ids_are_read_from_file_names():
    assert data._image_id("COCO_val2014_000000000042.jpg") == 42
    assert data._image_id("000000391895") == 391895


def test_prompt_file_round_trip(tmp_path):
    prompts = ["a red bicycle", "two cats on a sofa", "a lighthouse at dusk"]
    p = tmp_path / "prompts" / "x.txt"
    data.write_prompts(prompts, p)
    assert data.read_prompts(p) == prompts


def test_unknown_protocol_raises():
    with pytest.raises(KeyError):
        data.sample("nope")
