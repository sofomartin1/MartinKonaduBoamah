"""Statistical procedures, checked against SciPy and closed forms."""

import numpy as np
import pytest
from scipy import stats as sps

from uglut import stats

X = [10.4, 11.1, 9.8, 10.9, 10.2]
Y = [10.9, 11.3, 10.6, 11.4, 10.3]


def test_paired_t_matches_scipy():
    r = stats.paired_t(X, Y)
    ref = sps.ttest_rel(X, Y)
    assert r.statistic == pytest.approx(ref.statistic)
    assert r.p_value == pytest.approx(ref.pvalue)
    assert r.df == len(X) - 1


def test_paired_t_ci_matches_scipy():
    lo, hi = stats.paired_t_ci(X, Y)
    ci = sps.ttest_rel(X, Y).confidence_interval(0.95)
    assert (lo, hi) == pytest.approx((ci.low, ci.high))


def test_welch_matches_scipy_on_summaries():
    a, b = np.array([2744.0, 2760, 2731, 2752, 2749]), np.array([2892.0, 2880, 2901, 2887, 2899])
    r = stats.welch_t(a.mean(), a.std(ddof=1), a.size, b.mean(), b.std(ddof=1), b.size)
    ref = sps.ttest_ind(a, b, equal_var=False)
    assert r.statistic == pytest.approx(ref.statistic)
    assert r.p_value == pytest.approx(ref.pvalue)


def test_clopper_pearson_bounds():
    lo, hi = stats.clopper_pearson(0, 16)
    assert lo == 0.0 and hi == pytest.approx(1 - 0.025 ** (1 / 16))
    lo, hi = stats.clopper_pearson(16, 16)
    assert hi == 1.0 and lo == pytest.approx(0.025 ** (1 / 16))


def test_sign_test():
    assert stats.sign_test(4, 8) == pytest.approx(1.0)
    assert stats.sign_test(8, 8) == pytest.approx(2 * 0.5 ** 8)


def test_kendall_w_perfect_and_null():
    perfect = np.array([[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]])
    assert stats.kendall_w(perfect) == pytest.approx(1.0)
    anti = np.array([[1, 2, 3, 4], [4, 3, 2, 1]])
    assert stats.kendall_w(anti) == pytest.approx(0.0)


def test_mdd_attains_target_power():
    sd, n = 0.6, 3
    d = stats.mdd_paired(sd, n)
    df, tcrit, lam = n - 1, sps.t.ppf(0.975, n - 1), d / (sd / np.sqrt(n))
    power = sps.nct.sf(tcrit, df, lam) + sps.nct.cdf(-tcrit, df, lam)
    assert power == pytest.approx(0.80, abs=1e-6)
    assert stats.mdd_paired(sd, 3) > stats.mdd_paired(sd, 10) > 0


def test_percentile_bootstrap_is_seeded():
    x = np.arange(100.0)
    assert stats.percentile_bootstrap(x, seed=1) == stats.percentile_bootstrap(x, seed=1)
    lo, hi = stats.percentile_bootstrap(x, seed=1)
    assert lo < x.mean() < hi
