"""Score-quantizing attention processors on a diffusers U-Net.

The U-Net is a small, randomly initialized ``UNet2DConditionModel`` built from
a config, so no checkpoint is downloaded.
"""

from types import SimpleNamespace

import numpy as np
import pytest

torch = pytest.importorskip("torch")
diffusers = pytest.importorskip("diffusers")

from uglut import attention  # noqa: E402
from uglut.attention import (LUTAttnProcessor, LUTTable, StepTracker, install, layer_key,  # noqa: E402
                             log2_quant, phase_of, short_name)
from uglut.codebook import fit_lloyd, fit_layers  # noqa: E402
from uglut.grid import compile_grid  # noqa: E402
from uglut.profiling import ErrorLog, ScoreProfiler  # noqa: E402


def _probs(seed=0):
    g = torch.Generator().manual_seed(seed)
    return torch.softmax(torch.randn(16, 64, 77, generator=g) * 3, dim=-1)


def _levels(p, k=256):
    a = (p[..., 1:] / p[..., 1:].amax()).reshape(-1).numpy()
    return fit_lloyd(np.sort(a), k=k).levels


def _proc(mode, levels=None, **kw):
    tables = None if levels is None else {None: LUTTable(levels, 4096, device="cpu")}
    return LUTAttnProcessor("x", mode, tables, levels=256 if levels is None else len(levels), **kw)


# --------------------------------------------------------------------- numerics
def test_start_column_kept_and_scale_restored():
    p = _probs()
    q = _proc("grid", _levels(p)).quantize_probs(p)
    assert torch.equal(q[..., 0], p[..., 0])
    assert float((q[..., 1:] - p[..., 1:]).abs().max()) < 0.05 * float(p[..., 1:].amax())


def test_self_attention_quantizes_every_column():
    p = _probs(1)
    a = (p / p.amax()).reshape(-1).numpy()
    q = _proc("grid", fit_lloyd(np.sort(a), k=64).levels, keep_first=False).quantize_probs(p)
    assert not torch.equal(q[..., 0], p[..., 0])


def test_torch_grid_matches_numpy_grid():
    p = _probs(2)
    lv = _levels(p, 64)
    a = p[..., 1:] / p[..., 1:].amax()
    t = LUTTable(lv, 4096, device="cpu")
    ref = compile_grid(lv, 4096).quantize(a.double().numpy())
    assert np.allclose(t.grid(a).numpy(), ref, atol=1e-7)
    assert t.table.dtype == torch.int32 and t.nbytes() == 4096 * 4 + 64 * 4


def test_grid_error_close_to_exact_search():
    p = _probs(3)
    lv = _levels(p)
    g, b = _proc("grid", lv).quantize_probs(p), _proc("bucketize", lv).quantize_probs(p)
    mse_g, mse_b = float(((g - p) ** 2).mean()), float(((b - p) ** 2).mean())
    assert mse_b <= mse_g < 1.10 * mse_b


def test_log2_matches_dgq_real_time_log_quantizer():
    w = _probs(4)[..., 1:]
    delta = w.max()
    for bits in (4, 6, 8):
        # DGQ, quant/quant_layer_text.py, T2ILogQuantizer.forward with real_time=True
        x_q = torch.clamp(torch.round(-1 * torch.log2(w / delta)), 0, 2 ** bits - 1)
        dgq = 2 ** (-1 * x_q) * delta
        assert torch.allclose(log2_quant(w / delta, 2 ** bits) * delta, dgq, rtol=1e-6, atol=0)


def test_score_levels_set_log2_precision():
    p = _probs(5)
    q16 = LUTAttnProcessor("x", "log2", levels=16).quantize_probs(p)
    q256 = LUTAttnProcessor("x", "log2", levels=256).quantize_probs(p)
    assert torch.unique(q16[..., 1:] / q16[..., 1:].amax()).numel() <= 16
    assert float(((q16 - p) ** 2).mean()) > float(((q256 - p) ** 2).mean())


def test_fp_mode_is_identity_and_modes_are_checked():
    p = _probs(6)
    assert LUTAttnProcessor("x", "fp").quantize_probs(p) is p
    with pytest.raises(ValueError):
        LUTAttnProcessor("x", "grid")
    with pytest.raises(ValueError):
        LUTAttnProcessor("x", "nope")


def test_layer_names():
    k = "down_blocks.0.attentions.1.transformer_blocks.0.attn2"
    assert layer_key(k + ".processor") == k and layer_key("model." + k) == k
    assert short_name(k) == "D0.A1.T0.attn2"
    assert short_name("mid_block.attentions.0.transformer_blocks.0.attn2") == "Mid.T0.attn2"
    assert short_name("up_blocks.3.attentions.1.transformer_blocks.0.attn2.processor") == "U3.A1.T0.attn2"


def test_phases_split_the_schedule_in_thirds():
    ddim = [961 - 40 * i for i in range(25)]
    counts = [sum(phase_of(t) == p for t in ddim) for p in attention.PHASES]
    assert counts == [8, 8, 9]
    assert [phase_of(t) for t in (999, 749, 499, 249)] == ["early", "early", "mid", "late"]


# ----------------------------------------------------------------- U-Net level
@pytest.fixture()
def unet():
    torch.manual_seed(0)
    return diffusers.UNet2DConditionModel(
        sample_size=8, in_channels=4, out_channels=4, layers_per_block=1,
        block_out_channels=(32, 64), down_block_types=("CrossAttnDownBlock2D", "DownBlock2D"),
        up_block_types=("UpBlock2D", "CrossAttnUpBlock2D"), cross_attention_dim=32,
        attention_head_dim=8, norm_num_groups=8).eval()


def _forward(unet, seed=0, t=500):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(2, 4, 8, 8, generator=g)
    ctx = torch.randn(2, 77, 32, generator=g)
    with torch.no_grad():
        return unet(x, torch.tensor([t, t]), encoder_hidden_states=ctx).sample


def _profile(unet, **kw):
    prof = ScoreProfiler(per_call=20000, seed=0)
    install(SimpleNamespace(unet=unet), mode="fp", profiler=prof, **kw)
    for t in (900, 500, 100):
        _forward(unet, t=t)
    return prof.population()


def test_fp_processor_matches_diffusers(unet):
    from diffusers.models.attention_processor import AttnProcessor

    unet.set_attn_processor(AttnProcessor())
    ref = _forward(unet)
    n = install(SimpleNamespace(unet=unet), mode="fp")
    assert n == len(attention.attention_names(unet, "cross")) == 4
    assert torch.allclose(_forward(unet), ref, atol=1e-5)


def test_profile_fit_and_install_grid(unet):
    pop = _profile(unet)
    assert len(pop) == 4 and all(k.endswith(".attn2") for k in pop)
    books = {k: f.levels for k, f in fit_layers(pop, k=64).items()}
    ref = _forward(unet, seed=1)
    assert install(SimpleNamespace(unet=unet), mode="grid", codebooks=books, levels=64) == 4
    out = _forward(unet, seed=1)
    assert torch.isfinite(out).all() and not torch.equal(out, ref)
    assert float((out - ref).abs().max()) < 0.1 * float(ref.abs().max())


def test_codebook_size_must_match_score_levels(unet):
    books = {k: f.levels for k, f in fit_layers(_profile(unet), k=64).items()}
    with pytest.raises(ValueError):
        install(SimpleNamespace(unet=unet), mode="grid", codebooks=books, levels=256)
    with pytest.raises(KeyError):
        install(SimpleNamespace(unet=unet), mode="grid", codebooks={}, levels=64)


def test_self_and_cross_variant(unet):
    pop = _profile(unet, self_attention=True)
    assert sum(k.endswith(".attn1") for k in pop) == 4 and sum(k.endswith(".attn2") for k in pop) == 4
    books = {k: f.levels for k, f in fit_layers(pop, k=64).items()}
    n = install(SimpleNamespace(unet=unet), mode="grid", codebooks=books, levels=64, self_attention=True)
    assert n == 8
    procs = attention.lut_processors(SimpleNamespace(unet=unet))
    assert sorted(p.keep_first for p in procs) == [False] * 4 + [True] * 4
    assert torch.isfinite(_forward(unet)).all()


def test_timestep_adaptive_variant_uses_the_codebook_of_each_phase(unet):
    tracker = StepTracker().attach(unet)
    pop = _profile(unet, tracker=tracker)
    assert {k.split("@")[1] for k in pop} == set(attention.PHASES)
    books = {k: f.levels for k, f in fit_layers(pop, k=64).items()}
    with pytest.raises(ValueError):
        install(SimpleNamespace(unet=unet), mode="grid", codebooks=books, levels=64)
    install(SimpleNamespace(unet=unet), mode="grid", codebooks=books, levels=64, tracker=tracker)
    used = []
    for proc in attention.lut_processors(SimpleNamespace(unet=unet)):
        for phase, table in proc.tables.items():
            table.grid = (lambda f, ph: (lambda a: used.append(ph) or f(a)))(table.grid, phase)
    for t, phase in ((950, "early"), (500, "mid"), (20, "late")):
        used.clear()
        _forward(unet, t=t)
        assert used and set(used) == {phase}
    tracker.detach()


def test_measurement_leaves_scores_untouched_and_logs_every_rule(unet):
    from diffusers.models.attention_processor import AttnProcessor

    books = {k: f.levels for k, f in fit_layers(_profile(unet), k=256).items()}
    unet.set_attn_processor(AttnProcessor())
    ref = _forward(unet, seed=2)
    logs = {r: ErrorLog() for r in ("uniform", "log2", "grid")}
    attention.install_measurement(SimpleNamespace(unet=unet), logs, books, levels=256)
    assert torch.allclose(_forward(unet, seed=2), ref, atol=1e-5)
    per = {r: log.per_layer() for r, log in logs.items()}
    assert all(len(v) == 4 for v in per.values())
    for layer in per["grid"]:
        assert 0 < per["grid"][layer] < per["log2"][layer]


def test_joint_attention_models_have_nothing_to_replace():
    assert install(SimpleNamespace(unet=None, transformer=object()), mode="grid") == 0
