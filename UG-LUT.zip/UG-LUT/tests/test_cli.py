"""Command-line tools that need no model download: uglut-sizes, uglut-report, uglut-bundle."""

import json

import numpy as np
import pytest

from uglut import cli
from test_codebook import scores


def test_sizes_study(tmp_path):
    path = tmp_path / "s_scores.npz"
    np.savez(path, **{f"down_blocks.{i}.attentions.0.transformer_blocks.0.attn2": scores(20_000, i) for i in range(2)})
    out = tmp_path / "sizes.json"
    cli.sizes(["--scores", str(path), "--levels", "16", "256", "--out", str(out)])
    rec = json.loads(out.read_text())
    assert rec["kind"] == "codebook_sizes" and rec["config"]["n_layers"] == 2
    by = {s["levels"]: s for s in rec["summary"]}
    assert by[16]["nonfinite"] == 0 and by[256]["nonfinite"] == 0
    assert by[256]["textbook_nonfinite"] > 0 and by[256]["reseeded_per_layer"] > 0
    assert all(s["mean_reduction_vs_log2"] < 0 for s in rec["summary"])
    cli.sizes(["--scores", str(path), "--levels", "64", "--source", "moment-matched", "--out", str(out)])


def test_report_and_bundle_commands(tmp_path, capsys):
    (tmp_path / "runs").mkdir()
    np.savez(tmp_path / "s.npz", **{"a.attn2": scores(5000)})
    cli.sizes(["--scores", str(tmp_path / "s.npz"), "--levels", "16", "--out", str(tmp_path / "runs/sizes.json")])
    cli.report([str(tmp_path / "runs")])
    assert (tmp_path / "runs/report/tables.md").exists()
    cli.bundle(["create", str(tmp_path / "runs"), "--out", str(tmp_path / "r.tar.gz")])
    cli.bundle(["verify", str(tmp_path / "r.tar.gz")])
    assert "all files match" in capsys.readouterr().out


def test_score_levels_must_be_powers_of_two():
    with pytest.raises(SystemExit):
        cli.sizes(["--scores", "x", "--levels", "100", "--out", "y"])
