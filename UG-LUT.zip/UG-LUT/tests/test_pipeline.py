"""Seeded generation, image digests and the reference weight/activation back-end."""

import hashlib

import numpy as np
import pytest

torch = pytest.importorskip("torch")
PIL = pytest.importorskip("PIL.Image")

from uglut import pipeline  # noqa: E402


class _Pipe:
    """Returns an image whose pixels are drawn from the generator it receives."""

    device = "cpu"

    def __call__(self, prompt, num_inference_steps, guidance_scale, height, width, generator):
        x = torch.randint(0, 256, (height, width, 3), generator=generator, dtype=torch.uint8).numpy()
        return type("Out", (), {"images": [PIL.fromarray(x)]})()


def test_image_i_uses_seed_plus_i(tmp_path):
    cfg = pipeline.GenConfig("sd14", size=16)
    prompts = ["a", "b", "c", "d"]
    full = pipeline.generate(_Pipe(), prompts, cfg, seed=42, save_dir=tmp_path / "all")
    shard = pipeline.generate(_Pipe(), prompts[2:], cfg, seed=42, start_index=2, save_dir=tmp_path / "s")
    assert full[2:] == shard and len(set(full)) == 4
    assert sorted(p.name for p in (tmp_path / "s").iterdir()) == ["00002.png", "00003.png"]
    assert hashlib.sha256((tmp_path / "all" / "00001.png").read_bytes()).hexdigest() == full[1]


def test_model_registry():
    assert pipeline.GenConfig("sd14").resolved() == (25, 7.5, 512)
    assert pipeline.GenConfig("sdxl").resolved() == (4, 0.0, 512)
    assert pipeline.GenConfig("sd3").resolved() == (28, 7.0, 1024)
    assert pipeline.GenConfig("flux").resolved() == (4, 0.0, 1024)
    assert pipeline.MODELS["sd14"]["scheduler"] == "ddim"


def test_reference_weights_are_symmetric_per_output_channel():
    lin = torch.nn.Linear(16, 8)
    pipeline.quantize_linear_layers(lin, w_bits=4, a_bits=8)
    w = lin.weight.detach()
    step = w.abs().amax(dim=1, keepdim=True) / 7
    assert torch.allclose(w / step, torch.round(w / step), atol=1e-4)
    assert all(np.unique(r).size <= 15 for r in (w / step).round().numpy())


def test_reference_activation_hook_is_symmetric_min_max_on_linear_layers():
    net = torch.nn.Sequential(torch.nn.Linear(4, 4), torch.nn.Conv2d(1, 1, 1))
    hooks = pipeline.quantize_linear_layers(net, 8, 6, act_ranges={"0": 2.0, "1": 1.0})
    assert len(hooks) == 1                                   # nn.Linear only
    seen = {}
    net[0].register_forward_pre_hook(lambda m, inp: seen.setdefault("x", inp[0]))
    x = torch.linspace(-3, 3, 32).reshape(8, 4)
    net[0](x)
    q = seen["x"]
    step = 2.0 / 31
    assert torch.allclose(q / step, torch.round(q / step), atol=1e-4)
    assert float(q.max()) == pytest.approx(31 * step) and float(q.min()) == pytest.approx(-32 * step)


def test_build_rejects_inconsistent_settings():
    with pytest.raises(ValueError):
        pipeline.build("sd14", "uglut", backend="reference")          # no codebooks
    with pytest.raises(ValueError):
        pipeline.build("sd3", "dgq", backend="dgq", dgq_ckpt="x")     # DGQ supports U-Nets only
    with pytest.raises(ValueError):
        pipeline.build("sd14", "dgq", backend="dgq")                  # no DGQ checkpoint
    with pytest.raises(ValueError):
        pipeline.build("sd14", "uglut", variant="nope", codebooks={"a": [0]})
