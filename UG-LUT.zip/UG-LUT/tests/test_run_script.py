"""scripts/run_experiments.sh issues the commands each table needs.

The uglut-* tools are replaced by stubs that only record their arguments, so
the test checks the experiment plan without running a model.
"""

import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ("calibrate", "generate", "eval", "intrinsic", "sizes", "latency", "digest", "report", "bundle")

pytestmark = pytest.mark.skipif(shutil.which("bash") is None, reason="needs bash")


def plan(tmp_path, *args):
    """Run the script with stub tools; return the recorded calls as (tool, {option: value})."""
    bin_ = tmp_path / "bin"
    bin_.mkdir(exist_ok=True)
    log = tmp_path / "calls.txt"
    for t in TOOLS:
        stub = bin_ / f"uglut-{t}"
        stub.write_text(f'#!/usr/bin/env bash\necho "uglut-{t} $*" >> "{log}"\n')
        stub.chmod(0o755)
    py = bin_ / "python"
    py.write_text(f'#!/usr/bin/env bash\nexec "{sys.executable}" "$@"\n')
    py.chmod(0o755)
    env = dict(os.environ, PATH=f"{bin_}{os.pathsep}{os.environ['PATH']}", RUNS=str(tmp_path / "runs"),
               PYTHONPATH=str(ROOT / "src"), BASELINES=str(tmp_path / "none"))
    subprocess.run(["bash", str(ROOT / "scripts" / "run_experiments.sh"), *args], cwd=ROOT, env=env,
                   check=True, capture_output=True, text=True)
    calls = []
    for line in log.read_text().splitlines():
        words = shlex.split(line)
        opts, i = {}, 1
        while i < len(words):
            if words[i].startswith("--"):
                has_value = i + 1 < len(words) and not words[i + 1].startswith("--")
                opts[words[i]] = words[i + 1] if has_value else True
                i += 2 if has_value else 1
            else:
                opts.setdefault("_", []).append(words[i])
                i += 1
        calls.append((words[0], opts))
    return calls


def settings(calls, **match):
    gen = [o for t, o in calls if t == "uglut-generate"]
    return {(o["--model"], o["--method"], o.get("--wbits"), o.get("--abits"), o.get("--score-levels"),
             o.get("--seed")) for o in gen if all(o.get(k) == v for k, v in match.items())}


def test_table5_sweep_and_reduced_score_rows(tmp_path):
    calls = plan(tmp_path, "table5")
    main = settings(calls, **{"--score-levels": "256"})
    expected = {(mod, m, w, a, "256", "42") for mod in ("sd14", "sdxl") for m in ("dgq", "uglut")
                for w, a in (("8", "8"), ("8", "6"), ("4", "8"), ("4", "6"))}
    assert main == expected
    for L in ("64", "16"):
        assert settings(calls, **{"--score-levels": L}) == {("sd14", m, "8", "8", L, "42") for m in ("dgq", "uglut")}
    ckpts = {o["--dgq-ckpt"].rsplit("/", 1)[1] for t, o in calls if t == "uglut-generate"}
    assert {"sd14_w8a8_s64.pth_merged", "sd14_w8a8_s16.pth_merged"} <= ckpts
    books = {o["--codebooks"].rsplit("/", 1)[1] for t, o in calls if "--codebooks" in o}
    assert {"sd14_L64_c64_standard.npz", "sd14_L16_c64_standard.npz"} <= books


def test_table3_seeds_and_settings(tmp_path):
    got = settings(plan(tmp_path, "table3"))
    assert got == {("sd14", m, "8", a, "256", s) for m in ("dgq", "uglut") for a in ("8", "6")
                   for s in ("42", "137", "2024")}


def test_table8_ablation_grid(tmp_path):
    calls = plan(tmp_path, "table8")
    gen = [o for t, o in calls if t == "uglut-generate"]
    assert all(o["--protocol"] == "coco200" and o["--method"] == "uglut" for o in gen)
    rows = {(o["--variant"], Path(o["--codebooks"]).stem, o["--score-levels"]) for o in gen}
    assert rows == {("standard", "sd14_L256_c8_standard", "256"),
                    ("tsadaptive", "sd14_L256_c8_tsadaptive", "256"),
                    ("selfcross", "sd14_L256_c8_selfcross", "256"),
                    *{("standard", f"sd14_L256_c{c}_standard", "256") for c in (4, 16, 32, 64)},
                    *{("standard", f"sd14_L{L}_c8_standard", L) for L in ("16", "64", "1024")}}
    assert sum(t == "uglut-sizes" for t, _ in calls) == 2


def test_table7_times_the_dgq_backend(tmp_path):
    lat = [o for t, o in plan(tmp_path, "table7") if t == "uglut-latency"]
    sd14 = {o["--method"]: o for o in lat if o["--model"] == "sd14"}
    assert set(sd14) == {"fp16", "dgq", "uglut", "bucketize"}
    for m in ("dgq", "uglut", "bucketize"):
        assert sd14[m]["--backend"] == "dgq" and sd14[m]["--dgq-ckpt"].endswith("sd14_w8a8_s256.pth_merged")
    assert "--backend" not in sd14["fp16"]
    assert {o["--backend"] for o in lat if o["--model"] in ("sd3", "flux")} == {"reference"}
