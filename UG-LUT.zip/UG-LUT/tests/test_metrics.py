"""Inception Score estimator and its bootstrap interval (no network weights needed)."""

import numpy as np
import pytest

from uglut.metrics import inception_score, inception_score_bootstrap


def _probs(n=400, classes=20, seed=0, scale=6.0):
    rng = np.random.default_rng(seed)
    logits = rng.normal(size=(n, classes)) * scale
    p = np.exp(logits - logits.max(axis=1, keepdims=True))
    return p / p.sum(axis=1, keepdims=True)


def test_fixed_split_assignment_is_repeatable():
    p = _probs()
    assert inception_score(p) == inception_score(p.copy())
    assert inception_score(np.full((100, 10), 0.1))[0] == pytest.approx(1.0)


def test_bootstrap_describes_the_ten_split_estimator():
    p = _probs()
    point, lo, hi = inception_score_bootstrap(p, n_boot=300, seed=0)
    assert point == inception_score(p, 10)[0]        # the same estimator as the point value
    assert lo < point < hi


def test_bootstrap_resamples_use_ten_splits():
    # A single-split IS of the full set is larger than the mean of 10 split-wise
    # scores on few images; the interval must be centred on the 10-split value.
    p = _probs(n=200)
    point, lo, hi = inception_score_bootstrap(p, n_boot=300, seed=1)
    py = p.mean(0, keepdims=True)
    single = float(np.exp((p * (np.log(p) - np.log(py))).sum(1).mean()))
    assert single > point
    assert hi < single or lo < point < hi


def test_bootstrap_is_seeded():
    p = _probs()
    assert inception_score_bootstrap(p, 100, seed=3) == inception_score_bootstrap(p, 100, seed=3)
