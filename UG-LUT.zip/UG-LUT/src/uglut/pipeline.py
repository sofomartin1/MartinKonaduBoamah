"""Model loading, weight/activation back-ends, method installation and seeded generation.

Models (Hugging Face Hub ids)
-----------------------------
sd14   CompVis/stable-diffusion-v1-4                     25 DDIM steps, CFG 7.5, 512 px
sdxl   stabilityai/sdxl-turbo                            4 steps, CFG 0.0, 512 px
sd3    stabilityai/stable-diffusion-3-medium-diffusers   28 steps, CFG 7.0, 1024 px
flux   black-forest-labs/FLUX.1-schnell                  4 steps, CFG 0.0, 1024 px

Methods
-------
fp16        no quantization
dgq         DGQ's logarithmic cross-attention score quantizer
uglut       per-layer Lloyd-Max codebook through the 4,096-entry uniform grid
bucketize   the same codebook with exact O(log L) search (latency comparison)

Weight/activation back-ends
---------------------------
``dgq``        the official DGQ implementation (SD v1.4 and SDXL-Turbo):
               channel-wise weights (BRECQ + AdaRound reconstruction for the
               calibrated checkpoints), outlier-preserving group-wise
               activations, time-aware activation ranges.  UG-LUT replaces
               only DGQ's cross-attention score quantizer
               (:mod:`uglut.integrations.dgq`).
``reference``  the linear-layer hook of Algorithm 1 (every diffusers model,
               including SD3 and FLUX.1): per-output-channel symmetric
               min-max weights on every ``nn.Linear`` and ``nn.Conv2d``, and a
               per-tensor symmetric min-max activation hook on every
               ``nn.Linear``, calibrated on the calibration captions.

Variants (ablation of Table 8)
------------------------------
standard     one codebook per cross-attention layer
tsadaptive   one codebook per cross-attention layer and denoising phase
             (early / mid / late, see :mod:`uglut.attention`)
selfcross    codebooks on the self-attention (attn1) layers as well
"""

from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass

MODELS = {
    "sd14": dict(repo="CompVis/stable-diffusion-v1-4", steps=25, guidance=7.5, size=512, scheduler="ddim"),
    "sdxl": dict(repo="stabilityai/sdxl-turbo", steps=4, guidance=0.0, size=512, scheduler=None),
    "sd3": dict(repo="stabilityai/stable-diffusion-3-medium-diffusers", steps=28, guidance=7.0, size=1024,
                scheduler=None),
    "flux": dict(repo="black-forest-labs/FLUX.1-schnell", steps=4, guidance=0.0, size=1024, scheduler=None),
}
UNET_MODELS = ("sd14", "sdxl")          # a separable cross-attention tensor exists
METHODS = ("fp16", "dgq", "uglut", "bucketize")
SCORE_MODE = {"dgq": "log2", "uglut": "grid", "bucketize": "bucketize"}
VARIANTS = ("standard", "tsadaptive", "selfcross")


@dataclass
class GenConfig:
    model: str = "sd14"
    steps: int | None = None
    guidance: float | None = None
    size: int | None = None

    def resolved(self):
        m = MODELS[self.model]
        return (self.steps or m["steps"],
                m["guidance"] if self.guidance is None else self.guidance,
                self.size or m["size"])


def load_pipeline(model: str = "sd14", device: str | None = None, dtype: str | None = None):
    """Load a full-precision text-to-image pipeline from the Hugging Face Hub.

    ``device`` defaults to CUDA when available and the CPU otherwise; ``dtype``
    defaults to float16 on CUDA (bfloat16 for FLUX.1, whose weights are
    released in bfloat16) and float32 on the CPU.  The safety checker is
    disabled for every model and method, as in DGQ's evaluation code, so that
    no generation is replaced by a blank image before the metrics are computed.
    """
    import torch
    from diffusers import AutoPipelineForText2Image, DDIMScheduler

    spec = MODELS[model]
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    dtype = dtype or ("float16" if str(device).startswith("cuda") else "float32")
    td = {"float16": torch.float16, "bfloat16": torch.bfloat16, "float32": torch.float32}[dtype]
    if model == "flux" and td == torch.float16:
        td = torch.bfloat16
    pipe = AutoPipelineForText2Image.from_pretrained(spec["repo"], torch_dtype=td)
    if spec["scheduler"] == "ddim":
        pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
    if getattr(pipe, "safety_checker", None) is not None:
        pipe.safety_checker = None
        pipe.requires_safety_checker = False
    pipe.set_progress_bar_config(disable=True)
    return pipe.to(device)


def denoiser_of(pipe):
    return getattr(pipe, "unet", None) or pipe.transformer


# ----------------------------------------------------------- reference W/A back-end
def quantize_linear_layers(module, w_bits: int = 8, a_bits: int = 8, act_ranges: dict | None = None):
    """Reference W/A quantization (quantize-dequantize), see the module docstring.

    Weights: per-output-channel symmetric min-max on every ``nn.Linear`` and
    ``nn.Conv2d``.  Activations: per-tensor symmetric min-max on the input of
    every ``nn.Linear`` with a calibrated range (``act_ranges[name] = max|x|``).
    Returns the hook handles.
    """
    import torch
    import torch.nn as nn

    qmax_w = 2 ** (w_bits - 1) - 1
    qmax_a = 2 ** (a_bits - 1) - 1

    def qw(w):
        dims = tuple(range(1, w.ndim))
        s = w.abs().amax(dim=dims, keepdim=True).clamp_min(1e-8) / qmax_w
        return torch.round(w / s).clamp(-qmax_w - 1, qmax_w) * s

    handles = []
    for name, m in module.named_modules():
        if isinstance(m, (nn.Linear, nn.Conv2d)):
            with torch.no_grad():
                m.weight.copy_(qw(m.weight.float()).to(m.weight.dtype))
        if isinstance(m, nn.Linear) and act_ranges and name in act_ranges:
            scale = max(float(act_ranges[name]), 1e-8) / qmax_a

            def pre(mod, inp, scale=scale):
                x = inp[0]
                q = torch.round(x.float() / scale).clamp(-qmax_a - 1, qmax_a) * scale
                return (q.to(x.dtype),) + tuple(inp[1:])

            handles.append(m.register_forward_pre_hook(pre))
    return handles


def collect_activation_ranges(pipe, prompts, cfg: GenConfig, seed: int = 0) -> dict:
    """``{name: max |x|}`` of the input to every ``nn.Linear`` over the calibration prompts."""
    import torch.nn as nn

    den = denoiser_of(pipe)
    ranges, handles = {}, []
    for name, m in den.named_modules():
        if isinstance(m, nn.Linear):
            def hook(mod, inp, name=name):
                v = float(inp[0].detach().abs().max())
                ranges[name] = max(ranges.get(name, 0.0), v)
            handles.append(m.register_forward_pre_hook(hook))
    generate(pipe, prompts, cfg, seed=seed, save_dir=None)
    for h in handles:
        h.remove()
    return ranges


# ------------------------------------------------------------------ method assembly
def build(model: str, method: str, *, backend: str = "reference", w_bits: int = 8, a_bits: int = 8,
          score_levels: int = 256, codebooks: dict | None = None, variant: str = "standard",
          entries: int = 4096, dgq_ckpt: str | None = None, calib_prompts=None):
    """A pipeline quantized as one row of the experiments; returns ``(pipe, info)``.

    ``info`` records what was installed: the number of replaced score
    quantizers, the back-end and, for DGQ, the commit of the DGQ checkout.
    """
    from . import attention

    if method not in METHODS:
        raise ValueError(f"unknown method {method!r}")
    if variant not in VARIANTS:
        raise ValueError(f"unknown variant {variant!r}")
    unet = model in UNET_MODELS
    if method in {"uglut", "bucketize"} and unet and not codebooks:
        raise ValueError(f"method {method!r} needs codebooks for {model}")
    selfattn = variant == "selfcross"
    info = {"backend": backend if method != "fp16" else "none", "replaced": 0}

    if method == "fp16":
        return load_pipeline(model), info

    if backend == "dgq":
        if not unet:
            raise ValueError("the DGQ back-end supports sd14 and sdxl; use backend='reference'")
        if not dgq_ckpt:
            raise ValueError("backend 'dgq' needs the merged DGQ checkpoint of this W/A/score setting")
        from .integrations import dgq

        pipe = dgq.load_dgq_pipeline(model, dgq_ckpt, w_bits, a_bits, score_levels)
        tracker = attention.StepTracker().attach(pipe.unet) if variant == "tsadaptive" else None
        if method in {"uglut", "bucketize"}:
            info["replaced"] = dgq.install_lut(pipe.unet, codebooks, entries=entries, mode=SCORE_MODE[method],
                                               levels=score_levels, self_attention=selfattn, tracker=tracker)
        info["dgq_commit"] = dgq.dgq_commit()
        return pipe, info

    if backend != "reference":
        raise ValueError(f"unknown back-end {backend!r}")
    pipe = load_pipeline(model)
    cfg = GenConfig(model)
    ranges = collect_activation_ranges(pipe, list(calib_prompts or []), cfg)
    quantize_linear_layers(denoiser_of(pipe), w_bits, a_bits, ranges)
    tracker = (attention.StepTracker().attach(pipe.unet)
               if variant == "tsadaptive" and unet else None)
    if unet:
        info["replaced"] = attention.install(
            pipe, mode=SCORE_MODE[method], codebooks=codebooks if method != "dgq" else None,
            entries=entries, levels=score_levels, self_attention=selfattn and method != "dgq",
            tracker=tracker if method != "dgq" else None)
    return pipe, info


# ----------------------------------------------------------------------- generation
def prompt_generator(seed: int, index: int, device="cpu"):
    """Per-prompt generator: image i of a run always uses seed + i."""
    import torch

    return torch.Generator(device=device).manual_seed(int(seed) + int(index))


def png_digest(img) -> tuple[str, bytes]:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    data = buf.getvalue()
    return hashlib.sha256(data).hexdigest(), data


def generate(pipe, prompts, cfg: GenConfig, seed: int = 42, save_dir=None, start_index: int = 0,
             on_prompt=None) -> list:
    """Generate one image per prompt (image i uses seed + i); return the SHA-256 digests of the PNG bytes."""
    import os

    import torch

    steps, guidance, size = cfg.resolved()
    digests = []
    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
    device = getattr(pipe, "device", "cpu")
    for i, prompt in enumerate(prompts):
        if on_prompt is not None:
            on_prompt(start_index + i)
        gen = prompt_generator(seed, start_index + i, device)
        with torch.inference_mode():
            img = pipe(prompt=prompt, num_inference_steps=steps, guidance_scale=guidance,
                       height=size, width=size, generator=gen).images[0]
        h, data = png_digest(img)
        digests.append(h)
        if save_dir:
            with open(os.path.join(save_dir, f"{start_index + i:05d}.png"), "wb") as f:
                f.write(data)
    return digests
