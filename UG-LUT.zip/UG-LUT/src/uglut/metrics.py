"""Image-quality and text-image alignment metrics.

FID   clean-fid (mode "clean", Inception-v3 pool features) against the 40,504
      MS-COCO val2014 images.  The reference statistics are computed once and
      cached.  The bootstrap interval resamples the generated images (the
      reference statistics stay fixed).
IS    Inception Score on a zero-shot CLIP ViT-B/32 classifier (OpenAI weights)
      over the 1,000 ImageNet classes, with a FIXED split assignment: image i
      of the evaluated set goes to split i mod 10.  The reported value is the
      mean over the 10 splits, ``is_sd`` their standard deviation, and the
      bootstrap interval resamples images and recomputes the same 10-split
      estimate on every resample, so the point estimate and the interval
      describe the same estimator.
CLIP  mean cosine similarity between the open_clip ViT-L/14 (OpenAI weights)
      embeddings of each image and its prompt (not multiplied by 100).
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

IS_SPLITS = 10
CLIP_MODEL = ("ViT-L-14", "openai")
IS_MODEL = ("ViT-B-32", "openai")


def _images(folder):
    return sorted(p for p in Path(folder).iterdir() if p.suffix.lower() in {".png", ".jpg", ".jpeg"})


def _device():
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


# ----------------------------------------------------------------------------- FID
def _stats(feats):
    return np.mean(feats, axis=0), np.cov(feats, rowvar=False)


def fid_features(folder, mode: str = "clean", batch_size: int = 64) -> np.ndarray:
    import torch
    from cleanfid import fid as cf
    from cleanfid.features import build_feature_extractor

    dev = torch.device(_device())
    model = build_feature_extractor(mode, device=dev)
    return cf.get_folder_features(str(folder), model, batch_size=batch_size, device=dev, mode=mode,
                                  description=f"FID features {Path(folder).name}: ")


def reference_stats(ref_dir, cache_dir=None, mode: str = "clean"):
    """``(mu, sigma)`` of the reference folder, cached as .npz keyed by folder path and file count."""
    files = _images(ref_dir)
    key = hashlib.sha256(f"{Path(ref_dir).resolve()}|{len(files)}|{mode}".encode()).hexdigest()[:16]
    cache = Path(cache_dir or Path(ref_dir).parent / "fid_stats") / f"ref_{mode}_{key}.npz"
    if cache.exists():
        with np.load(cache) as z:
            return z["mu"], z["sigma"]
    mu, sigma = _stats(fid_features(ref_dir, mode))
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.savez(cache, mu=mu, sigma=sigma, n=len(files))
    return mu, sigma


def fid(gen_dir, ref_dir, n_boot: int = 0, seed: int = 0) -> dict:
    """FID of ``gen_dir`` against ``ref_dir``; with ``n_boot`` > 0 also a 95% percentile-bootstrap interval."""
    from cleanfid.fid import frechet_distance

    mu_r, s_r = reference_stats(ref_dir)
    g = fid_features(gen_dir)
    mu_g, s_g = _stats(g)
    out = {"fid": float(frechet_distance(mu_g, s_g, mu_r, s_r)), "n_images": int(len(g))}
    if n_boot:
        rng = np.random.default_rng(seed)
        boots = []
        for _ in range(n_boot):
            m, s = _stats(g[rng.integers(0, len(g), len(g))])
            boots.append(frechet_distance(m, s, mu_r, s_r))
        out["fid_lo"], out["fid_hi"] = (float(v) for v in np.percentile(boots, [2.5, 97.5]))
    return out


# ------------------------------------------------------------------------------ IS
def class_probs(gen_dir, batch_size: int = 64) -> np.ndarray:
    """Zero-shot CLIP ViT-B/32 class probabilities (N, 1000) over the ImageNet classes, in file order."""
    import open_clip
    import torch
    from open_clip.zero_shot_metadata import IMAGENET_CLASSNAMES
    from PIL import Image

    dev = _device()
    model, _, pre = open_clip.create_model_and_transforms(IS_MODEL[0], pretrained=IS_MODEL[1], device=dev)
    model.eval()
    tok = open_clip.get_tokenizer(IS_MODEL[0])
    with torch.no_grad():
        t = model.encode_text(tok([f"a photo of a {c}." for c in IMAGENET_CLASSNAMES]).to(dev))
        t = t / t.norm(dim=-1, keepdim=True)
    files = _images(gen_dir)
    out = []
    for i in range(0, len(files), batch_size):
        x = torch.stack([pre(Image.open(f).convert("RGB")) for f in files[i:i + batch_size]]).to(dev)
        with torch.no_grad():
            v = model.encode_image(x)
            v = v / v.norm(dim=-1, keepdim=True)
            logits = 100.0 * v @ t.T
        out.append(torch.softmax(logits.double(), dim=1).cpu().numpy())
    return np.concatenate(out)


def inception_score(p: np.ndarray, splits: int = IS_SPLITS) -> tuple[float, float]:
    """Mean and SD of the per-split IS; image i belongs to split i mod ``splits``."""
    scores = []
    for s in range(splits):
        part = p[s::splits]
        py = part.mean(axis=0, keepdims=True)
        kl = (part * (np.log(part + 1e-12) - np.log(py + 1e-12))).sum(axis=1)
        scores.append(np.exp(kl.mean()))
    return float(np.mean(scores)), float(np.std(scores))


def inception_score_bootstrap(p: np.ndarray, n_boot: int = 1000, seed: int = 0,
                              splits: int = IS_SPLITS) -> tuple[float, float, float]:
    """The 10-split IS and a 95% percentile-bootstrap interval of the same estimator.

    Each resample draws ``len(p)`` images with replacement; the resampled set
    is split by position (i mod ``splits``) exactly as the point estimate is.
    """
    point, _ = inception_score(p, splits)
    rng = np.random.default_rng(seed)
    boots = [inception_score(p[rng.integers(0, len(p), len(p))], splits)[0] for _ in range(n_boot)]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return point, float(lo), float(hi)


# ---------------------------------------------------------------------------- CLIP
def clip_score(gen_dir, prompts, batch_size: int = 64) -> float:
    """Mean image-prompt cosine similarity with open_clip ViT-L/14 (OpenAI weights)."""
    import open_clip
    import torch
    from PIL import Image

    dev = _device()
    model, _, pre = open_clip.create_model_and_transforms(CLIP_MODEL[0], pretrained=CLIP_MODEL[1], device=dev)
    model.eval()
    tok = open_clip.get_tokenizer(CLIP_MODEL[0])
    files = _images(gen_dir)
    if len(files) != len(prompts):
        raise ValueError(f"{len(files)} images but {len(prompts)} prompts: one prompt per image, in file order")
    sims = []
    for i in range(0, len(files), batch_size):
        x = torch.stack([pre(Image.open(f).convert("RGB")) for f in files[i:i + batch_size]]).to(dev)
        t = tok(prompts[i:i + batch_size]).to(dev)
        with torch.no_grad():
            v = model.encode_image(x)
            w = model.encode_text(t)
        v = v / v.norm(dim=-1, keepdim=True)
        w = w / w.norm(dim=-1, keepdim=True)
        sims.append((v * w).sum(dim=-1).float().cpu().numpy())
    return float(np.concatenate(sims).mean())
