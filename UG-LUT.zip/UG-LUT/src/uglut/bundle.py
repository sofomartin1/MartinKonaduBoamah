"""Packaging of run records for publication.

``create`` collects, from a run folder,

* codebooks (``*.npz``) and their fit records, and the calibration score populations;
* every JSON record (generation records with per-image SHA-256 digests,
  metrics, intrinsic, codebook-size, latency and digest-comparison records);
* run logs (``*.log``) and environment snapshots (``env/*.txt``);
* the report (ledger and tables) when ``uglut-report`` has been run;

but not the generated images, which are identified by their digests.  The
archive contains ``MANIFEST.sha256`` (``sha256sum`` format), so it can be
checked with ``uglut-bundle verify`` or, after unpacking, ``sha256sum -c``.
"""

from __future__ import annotations

import hashlib
import io
import tarfile
from pathlib import Path

from .records import sha256_file

SUFFIXES = {".json", ".npz", ".log", ".txt", ".csv", ".md", ".jsonl"}


def collect(root, include_scores: bool = True) -> list:
    root = Path(root)
    out = []
    for f in sorted(root.rglob("*")):
        if not f.is_file() or f.suffix not in SUFFIXES:
            continue
        rel = f.relative_to(root)
        if "images" in rel.parts:
            continue
        if not include_scores and f.name.endswith("_scores.npz"):
            continue
        out.append(rel)
    return out


def create(root, out, include_scores: bool = True) -> tuple:
    root, out = Path(root), Path(out)
    files = collect(root, include_scores)
    if not files:
        raise FileNotFoundError(f"no records under {root}")
    prefix = out.name.split(".tar")[0]
    manifest = "".join(f"{sha256_file(root / rel)}  {rel.as_posix()}\n" for rel in files)
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, "w:gz") as tar:
        for rel in files:
            tar.add(root / rel, arcname=f"{prefix}/{rel.as_posix()}")
        data = manifest.encode()
        info = tarfile.TarInfo(f"{prefix}/MANIFEST.sha256")
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
    return out, len(files)


def verify(archive) -> list:
    """Names of the files whose digest differs from the manifest (empty list = all match)."""
    bad = []
    with tarfile.open(archive, "r:gz") as tar:
        members = {m.name: m for m in tar.getmembers() if m.isfile()}
        man = [n for n in members if n.endswith("/MANIFEST.sha256")]
        if len(man) != 1:
            return ["MANIFEST.sha256 missing"]
        prefix = man[0][: -len("MANIFEST.sha256")]
        listed = set()
        for line in tar.extractfile(members[man[0]]).read().decode().splitlines():
            digest, name = line.split(maxsplit=1)
            listed.add(prefix + name)
            m = members.get(prefix + name)
            if m is None or hashlib.sha256(tar.extractfile(m).read()).hexdigest() != digest:
                bad.append(name)
        bad += [n[len(prefix):] + " (not in manifest)" for n in members if n not in listed and n != man[0]]
    return bad
