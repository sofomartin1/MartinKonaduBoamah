"""Integrations with third-party quantization code bases."""
