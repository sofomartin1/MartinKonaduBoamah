"""UG-LUT inside the official DGQ quantized U-Net.

DGQ (Ryu, Park and Shim, ICLR 2025; https://github.com/ugonfor/DGQ) quantizes
the weights and activations of SD v1.4 and SDXL-Turbo and applies its own
logarithmic quantizer to the post-softmax attention probabilities.  In DGQ's
rewritten attention forward the probabilities pass through ``aqtizer_w``; for
cross-attention (``attn2``) the ``<start>`` column is split off first
(``t2i_start_peak``) and only ``A[..., 1:]`` reaches the quantizer.

UG-LUT keeps every DGQ quantizer (weights, activations, queries, keys, values,
self-attention probabilities) and replaces ``attn2.aqtizer_w`` alone with
:class:`LUTScoreQuantizer`, which applies the per-layer Lloyd-Max codebook
through the uniform lookup grid.  The comparison between the two is therefore
a comparison of the cross-attention score quantizer only.

Score precision
---------------
The score quantizer is a separate stage from the activation quantizer, and
its precision is set separately.  DGQ's own scripts tie it to the activation
bit-width (``softmax_a_bit = a_bits``); here it is set by ``score_levels``
(``softmax_a_bit = log2(score_levels)``) for both methods, so at W8A6 both
DGQ and UG-LUT quantize the scores at 256 levels and the reduced-precision
rows use 64 or 16 levels for both.  DGQ's score quantizer is the real-time
``T2ILogQuantizer`` (scale = per-call maximum), so its precision has no
calibrated state and can be set when the checkpoint is loaded.

Environment
-----------
DGQ pins its own software stack (Python 3.9, PyTorch 2.2.2 and a bundled fork
of diffusers 0.26); ``environment-dgq.yml`` and ``scripts/setup_dgq.sh``
create it and clone DGQ at the commit the experiments used
(:data:`DGQ_COMMIT`).  The merged weight + activation checkpoints are made
by ``scripts/dgq_quantize.sh``.

Usage::

    from uglut.codebook import load_codebooks
    from uglut.integrations import dgq

    pipe = dgq.load_dgq_pipeline("sd14", "checkpoints/dgq/sd14_w8a6_s256.pth_merged",
                                 w_bits=8, a_bits=6, score_levels=256)
    dgq.install_lut(pipe.unet, load_codebooks("runs/codebooks/sd14_L256_c64_standard.npz"))
"""

from __future__ import annotations

import contextlib
import math
import os
import subprocess
from pathlib import Path
from typing import Optional

import numpy as np
import torch

from ..attention import LUTTable, StepTracker, layer_key, split_codebooks

DGQ_REPO = "https://github.com/ugonfor/DGQ"
DGQ_COMMIT = "f449f6ad8052105c72e0bdf5a1cd05bbb98ae037"
MODEL_TYPE = {"sd14": "sd", "sdxl": "sdxl"}
STEPS = {"sd14": 25, "sdxl": 4}
GROUPS = 8  # DGQ's group count for the activation quantizer (g8)


def score_bits(score_levels: int) -> int:
    """``log2(score_levels)``; the level count must be a power of two."""
    b = int(round(math.log2(score_levels)))
    if score_levels < 2 or 2 ** b != score_levels:
        raise ValueError(f"score levels must be a power of two, got {score_levels}")
    return b


def quant_params(w_bits: int, a_bits: int, score_levels: int = 256):
    """DGQ's ``(wq_params, aq_params, softmax_aq_params)`` for one W/A/score setting.

    The full DGQ configuration: channel-wise min-max weights, min-max
    activations, and the logarithmic, real-time, start-peak score quantizer
    with ``softmax_a_bit = log2(score_levels)``.
    """
    from quant.quant_layer import Scaler

    wq = {"bits": w_bits, "channel_wise": True, "scaler": Scaler.MINMAX}
    aq = {"bits": a_bits, "channel_wise": False, "scaler": Scaler.MINMAX, "leaf_param": True}
    sq = {"softmax_a_bit": score_bits(score_levels), "t2i_log_quant": True, "t2i_real_time": True,
          "t2i_start_peak": True, "log_max_1": False}
    return wq, aq, sq


class LUTScoreQuantizer(torch.nn.Module):
    """Drop-in replacement for DGQ's ``aqtizer_w``.

    Receives the attention probabilities (for ``attn2`` without the
    ``<start>`` column), normalizes them by their maximum, maps every value to
    its codebook level through the uniform grid (``mode="grid"``) or by exact
    search (``mode="bucketize"``), and restores the scale.  ``tables`` maps a
    phase (``None``, or ``"early"``/``"mid"``/``"late"`` with a ``tracker``) to
    a :class:`~uglut.attention.LUTTable`.
    """

    def __init__(self, name: str, tables: dict, mode: str = "grid", tracker: Optional[StepTracker] = None):
        super().__init__()
        if mode not in {"grid", "bucketize"}:
            raise ValueError(f"unknown mode {mode!r}")
        if None not in tables and tracker is None:
            raise ValueError("timestep-adaptive codebooks need a StepTracker")
        self.name, self.tables, self.mode, self.tracker = name, tables, mode, tracker
        self.level = next(iter(tables.values())).levels.numel()  # read by DGQ's reconstruction code
        self.use_aq = True
        self.running_stat = False

    def forward(self, w: torch.Tensor) -> torch.Tensor:
        table = self.tables[None] if None in self.tables else self.tables[self.tracker.phase]
        w = w.float()
        s = w.amax().clamp_min(torch.finfo(torch.float32).tiny)
        a = w / s
        q = table.grid(a) if self.mode == "grid" else table.bucketize(a)
        return q * s

    def extra_repr(self) -> str:
        phases = "single" if None in self.tables else "/".join(self.tables)
        t = next(iter(self.tables.values()))
        return f"name={self.name}, mode={self.mode}, levels={self.level}, entries={t.entries}, codebooks={phases}"


def attention_blocks(unet) -> dict:
    """Canonical ``attn2`` key -> DGQ ``QuantBasicTransformerBlock``, for every transformer block.

    Works on DGQ's ``QuantModel`` (module paths prefixed with ``model.``) and
    on any module tree whose transformer blocks expose ``attn2.aqtizer_w``.
    """
    out = {}
    for name, module in unet.named_modules():
        attn2 = getattr(module, "attn2", None)
        if attn2 is not None and hasattr(attn2, "aqtizer_w"):
            out[layer_key(f"{name}.attn2")] = module
    return out


def install_lut(unet, codebooks: dict, entries: int = 4096, mode: str = "grid", levels: int = 256,
                self_attention: bool = False, tracker: Optional[StepTracker] = None) -> int:
    """Replace the score quantizers of a DGQ U-Net with UG-LUT; return the count replaced.

    ``attn2.aqtizer_w`` of every block is replaced; ``attn1.aqtizer_w`` too
    when ``self_attention`` is set.  Every replaced module needs a codebook of
    ``levels`` levels (``KeyError`` / ``ValueError`` otherwise); a
    timestep-adaptive codebook file needs ``tracker`` attached to the U-Net.
    """
    blocks = attention_blocks(unet)
    if not blocks:
        raise RuntimeError("no DGQ attention blocks found: is this a DGQ QuantModel?")
    books, phased = split_codebooks(codebooks)
    if phased and tracker is None:
        raise ValueError("timestep-adaptive codebooks need a StepTracker attached to the U-Net")
    targets = []
    for key, block in blocks.items():
        targets.append((key, block.attn2))
        if self_attention:
            targets.append((key[: -len("attn2")] + "attn1", block.attn1))
    missing = [k for k, _ in targets if k not in books]
    if missing:
        raise KeyError(f"no codebook for {len(missing)} of {len(targets)} layers, e.g. {missing[0]}")
    for k, _ in targets:
        if any(np.asarray(v).size != levels for v in books[k].values()):
            raise ValueError(f"codebook of {k} does not have {levels} levels")
    device = next(unet.parameters()).device
    for key, attn in targets:
        tables = {p: LUTTable(v, entries, device=device) for p, v in books[key].items()}
        attn.aqtizer_w = LUTScoreQuantizer(key, tables, mode, tracker)
    return len(targets)


@contextlib.contextmanager
def _cwd(path: Path):
    prev = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev)


def dgq_root() -> Path:
    """The DGQ checkout on ``PYTHONPATH``."""
    try:
        import quant  # DGQ's package
    except ImportError as exc:
        raise ImportError(
            "DGQ is not importable. Run scripts/setup_dgq.sh and activate the DGQ environment "
            "(see README, 'Environments')."
        ) from exc
    return Path(quant.__file__).resolve().parents[1]


def dgq_commit() -> str:
    try:
        return subprocess.check_output(["git", "-C", str(dgq_root()), "rev-parse", "HEAD"],
                                       stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "unknown"


def load_dgq_pipeline(model: str, cali_ckpt: str, w_bits: int = 8, a_bits: int = 8, score_levels: int = 256,
                      *, use_group: bool = True, fp16: bool = True, device: str = "cuda"):
    """The DGQ-quantized pipeline (weights, activations and DGQ's own score quantizer).

    Mirrors DGQ's ``src/inference_qmodel.py`` with the full DGQ configuration
    (:func:`quant_params`, group-wise activations, time-aware activation
    quantizer).  SD v1.4 samples with DDIM, as in every other configuration of
    the experiments.  Call :func:`install_lut` on ``pipe.unet`` afterwards to switch
    the cross-attention score quantizer to UG-LUT.
    """
    if model not in MODEL_TYPE:
        raise ValueError(f"DGQ supports {sorted(MODEL_TYPE)}, not {model!r}")
    os.environ["DIFFUSERS_REWRITE"] = MODEL_TYPE[model]  # read by DGQ at import time
    root = dgq_root()
    ckpt = str(Path(cali_ckpt).resolve())
    with _cwd(root):
        from quant.load_qmodel_util import get_qmodel
        from utils import prepare_pipe  # DGQ's src/utils.py

        pipe = prepare_pipe(MODEL_TYPE[model])
        if model == "sd14":
            # 25 DDIM steps (t = 961, 921, ..., 1), one U-Net call per step; DGQ's
            # time-aware activation quantizer indexes its per-step ranges by
            # (1000 - t) // 40, so every DDIM step maps to its own range set.
            from diffusers import DDIMScheduler

            pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
        wq, aq, sq = quant_params(w_bits, a_bits, score_levels)
        qnn = get_qmodel(MODEL_TYPE[model], pipe, ckpt, wq, True, aq, sq, use_group,
                         num_inference_steps=STEPS[model], time_aware_aqtizer=True)
    qnn = qnn.half() if fp16 else qnn.float()
    pipe.unet = qnn.to(device)
    pipe.unet.disable_out_quantization()
    pipe.safety_checker = None
    pipe.requires_safety_checker = False
    pipe.set_progress_bar_config(disable=True)
    return pipe
