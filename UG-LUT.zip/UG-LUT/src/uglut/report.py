"""The results ledger and the tables of the paper, rendered from run records only.

``build_report(runs, out)`` writes

``ledger.csv``    one row per run: condition, image count, image-set digest, metrics
``ledger.json``   the same rows plus every other record (codebook fits, intrinsic
                  MSE, codebook sizes, latency, digest comparisons), without the
                  per-image digests
``tables.md``     Tables 1-8 of the paper, each with the conditions it selects
``table<N>.csv``  the same tables as CSV

Every number comes from a record; a condition without a record is shown as
``—``.  Conditions are selected by their configuration (model, protocol,
method, back-end, bit-widths, score levels, calibration budget, variant,
seed), never by folder names.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from . import stats
from .records import build_ledger, select

SEEDS = (42, 137, 2024)
MISSING = "—"
MODEL_NAMES = {"sd14": "SD v1.4", "sdxl": "SDXL Turbo", "sd3": "SD3", "flux": "FLUX.1-schnell"}
METHOD_NAMES = {"fp16": "FP16", "dgq": "DGQ", "uglut": "UG-LUT", "bucketize": "UG-LUT (naive bucketize)",
                "qdiffusion": "Q-Diffusion", "tfmqdm": "TFMQ-DM"}
UNET = ("sd14", "sdxl")


# ------------------------------------------------------------------------- selection
def pick(runs, model, protocol, method, *, backend="dgq", wbits=8, abits=8, levels=256, calib=64,
         variant="standard", seed=42):
    """The run of one condition (the most recently listed if a condition was run twice)."""
    crit = dict(model=model, protocol=protocol, method=method, seed=seed)
    if method != "fp16":
        crit.update(wbits=wbits, abits=abits)
        if method in ("dgq", "uglut", "bucketize"):
            crit["backend"] = backend if model in UNET else "reference"
            crit["score_levels"] = levels if model in UNET else None
        if method in ("uglut", "bucketize") and model in UNET:
            crit.update(calib_prompts=calib, variant=variant)
    rows = select(runs, **crit)
    return rows[-1] if rows else None


def _v(row, key):
    if row is None or key not in row or row[key] is None:
        return None
    return float(row[key])


def f(v, nd=2, signed=False):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return MISSING
    s = f"{v:+.{nd}f}" if signed else f"{v:.{nd}f}"
    return s.replace("-", "−")


def _table(cols, rows):
    head = "| " + " | ".join(cols) + " |\n|" + "|".join("---" for _ in cols) + "|\n"
    return head + "".join("| " + " | ".join(str(c) for c in r) + " |\n" for r in rows)


# ---------------------------------------------------------------------------- tables
def table1(led, backend):
    runs = led["runs"]
    rows, notes = [], []
    for model, proto in (("sd14", "coco30k"), ("sdxl", "coco1k"), ("sd3", "coco1k"), ("flux", "coco1k")):
        n = "30K" if proto == "coco30k" else "1K"
        got = {}
        for m in ("fp16", "dgq", "uglut"):
            r = got[m] = pick(runs, model, proto, m, backend=backend)
            rows.append([f"{MODEL_NAMES[model]} ({n})", METHOD_NAMES[m], f(_v(r, "fid")), f(_v(r, "is")),
                         f(_v(r, "clip"), 4)])
        if model not in UNET and got["dgq"] and got["uglut"]:
            same = got["dgq"]["image_set_sha256"] == got["uglut"]["image_set_sha256"]
            notes.append(f"{MODEL_NAMES[model]}: SHA-256 of the {got['uglut']['n_images']} DGQ and UG-LUT "
                         f"images {'identical' if same else 'NOT identical'} (image-set digest).")
    return ["Architecture", "Method", "FID ↓", "IS ↑", "CLIP ↑"], rows, notes


def table2(led, backend):
    rows = []
    for m in ("uglut", "dgq"):
        r = pick(led["runs"], "sd14", "coco30k", m, backend=backend)
        fid = (f"{f(_v(r, 'fid'))} ({f(_v(r, 'fid_lo'))}–{f(_v(r, 'fid_hi'))})"
               if _v(r, "fid_lo") is not None else f(_v(r, "fid")))
        is_ = (f"{f(_v(r, 'is'))} [{f(_v(r, 'is_lo'))}, {f(_v(r, 'is_hi'))}]"
               if _v(r, "is_lo") is not None else f(_v(r, "is")))
        rows.append([METHOD_NAMES[m], fid, is_, f(_v(r, "clip"), 4)])
    return ["Method", "FID ↓ (95% CI)", "IS ↑ (95% CI)", "CLIP ↑"], rows, []


def _paired(runs, wbits, abits, backend, metric="fid"):
    seeds, u, d = [], [], []
    for s in SEEDS:
        a = pick(runs, "sd14", "coco1k", "uglut", backend=backend, wbits=wbits, abits=abits, seed=s)
        b = pick(runs, "sd14", "coco1k", "dgq", backend=backend, wbits=wbits, abits=abits, seed=s)
        if _v(a, metric) is not None and _v(b, metric) is not None:
            seeds.append(s)
            u.append(_v(a, metric))
            d.append(_v(b, metric))
    return seeds, u, d


def table3(led, backend):
    runs, rows, notes = led["runs"], [], []
    cols = ["Seed", "UG-LUT FID ↓", "DGQ FID ↓", "UG-LUT IS ↑", "DGQ IS ↑"]
    for wb, ab in ((8, 8), (8, 6)):
        tag = f"W{wb}A{ab}"
        for s in SEEDS:
            a = pick(runs, "sd14", "coco1k", "uglut", backend=backend, wbits=wb, abits=ab, seed=s)
            b = pick(runs, "sd14", "coco1k", "dgq", backend=backend, wbits=wb, abits=ab, seed=s)
            rows.append([f"{tag}, seed {s}", f(_v(a, "fid")), f(_v(b, "fid")), f(_v(a, "is")), f(_v(b, "is"))])
        seeds, u, d = _paired(runs, wb, ab, backend, "fid")
        _, ui, di = _paired(runs, wb, ab, backend, "is")
        ms = lambda x: f"{f(float(np.mean(x)))} ± {f(stats.sd(x))}" if len(x) > 1 else MISSING  # noqa: E731
        rows.append([f"{tag}, mean ± σ", ms(u), ms(d), ms(ui), ms(di)])
        if len(seeds) >= 2 and stats.sd(np.subtract(u, d)) > 0:
            t = stats.paired_t(u, d)
            lo, hi = stats.paired_t_ci(u, d)
            diff = float(np.mean(np.subtract(u, d)))
            rows.append([f"{tag}, paired ΔFID", f"{f(diff, signed=True)} [{f(lo, signed=True)}, {f(hi, signed=True)}]",
                         f"t({t.df:.0f}) = {f(t.statistic)}, p = {t.p_value:.3f}", "-", "-"])
            notes.append(f"{tag}: seeds {', '.join(map(str, seeds))}; paired SD {f(stats.sd(np.subtract(u, d)))}; "
                         f"minimum detectable paired ΔFID at 80% power "
                         f"{f(stats.mdd_paired(stats.sd(np.subtract(u, d)), len(seeds)))}.")
        else:
            rows.append([f"{tag}, paired ΔFID", MISSING, MISSING, "-", "-"])
    return cols, rows, notes


def table4(led, backend):
    runs, rows = led["runs"], []
    for m in ("fp16", "qdiffusion", "tfmqdm", "dgq", "uglut"):
        r = pick(runs, "sd14", "coco1k", m, backend=backend)
        rows.append([METHOD_NAMES[m] + (" (reference)" if m == "fp16" else ""), f(_v(r, "fid")), f(_v(r, "is")),
                     f(_v(r, "clip"), 4)])
    return ["Method", "FID ↓", "IS ↑", "CLIP ↑"], rows, []


def table5(led, backend):
    runs, rows, deltas = led["runs"], [], []
    settings = [(m, w, a, 256) for m in UNET for (w, a) in ((8, 8), (8, 6), (4, 8), (4, 6))]
    settings += [("sd14", 8, 8, 64), ("sd14", 8, 8, 16)]
    for model, wb, ab, L in settings:
        d = pick(runs, model, "coco1k", "dgq", backend=backend, wbits=wb, abits=ab, levels=L)
        u = pick(runs, model, "coco1k", "uglut", backend=backend, wbits=wb, abits=ab, levels=L)
        dfid = None if _v(u, "fid") is None or _v(d, "fid") is None else _v(u, "fid") - _v(d, "fid")
        if L == 256 and dfid is not None:
            deltas.append(dfid)
        rows.append([MODEL_NAMES[model], f"W{wb}A{ab}", f"{L} / {L}", f(_v(d, "fid")), f(_v(u, "fid")),
                     f(_v(d, "is")), f(_v(u, "is")), f(dfid, signed=True)])
    notes = []
    if deltas:
        neg = sum(x < 0 for x in deltas)
        notes.append(f"ΔFID < 0 in {neg} of {len(deltas)} settings at 256 levels "
                     f"(exact two-sided sign test p = {stats.sign_test(neg, len(deltas)):.3f}).")
    cols = ["Backbone", "Bits", "Score levels (DGQ / UG-LUT)", "DGQ FID ↓", "UG-LUT FID ↓", "DGQ IS ↑",
            "UG-LUT IS ↑", "ΔFID"]
    return cols, rows, notes


def table6(led, backend):
    recs = [r for r in led.get("intrinsic", []) if r["config"].get("model") == "sd14"
            and r["config"].get("levels") == 256]
    if not recs:
        return ["Layer", "Uniform linear", "DGQ log₂", "Lloyd LUT", "Reduction vs log₂"], [], []
    rec = recs[-1]
    rows = [[r["short"], f(r["uniform"] * 1e6), f(r["log2"] * 1e6), f(r["lloyd"] * 1e6),
             f"{f(100 * r['reduction_vs_log2'], 1)}%"] for r in rec["layers"]]
    a = rec["average"]
    rows.append([f"Average ({len(rec['layers'])} layers)", f(a["uniform"] * 1e6), f(a["log2"] * 1e6),
                 f(a["lloyd"] * 1e6), f"{f(100 * a['mean_reduction_vs_log2'], 1)}%"])
    notes = [f"MSE ×10⁻⁶ in squared attention probability; {rec['config']['n_prompts']} calibration captions "
             f"({rec['file']}). Average reduction = mean of the per-layer reductions."]
    return ["Layer", "Uniform linear", "DGQ log₂", "Lloyd LUT", "Reduction vs log₂"], rows, notes


def _lat(led, model, method, backend):
    c = dict(model=model, method=method)
    if method != "fp16":
        c.update(backend=backend if model in UNET else "reference", wbits=8, abits=8)
    recs = [r for r in led.get("latency", []) if all(r["config"].get(k) == v for k, v in c.items())
            and (method == "fp16" or model not in UNET or r["config"].get("score_levels") == 256)]
    return recs[-1] if recs else None


def table7(led, backend):
    rows, notes = [], []
    fp = _lat(led, "sd14", "fp16", backend)
    base = _lat(led, "sd14", "dgq", backend)
    labels = {"fp16": "FP16", "dgq": "DGQ (log₂)", "uglut": "UG-LUT (uniform grid)",
              "bucketize": "UG-LUT (naive bucketize)"}
    for m in ("fp16", "dgq", "uglut", "bucketize"):
        r = _lat(led, "sd14", m, backend)
        if r is None:
            rows.append([f"SD v1.4 – {labels[m]}", MISSING, MISSING, MISSING])
            continue
        slow = "1.00× (baseline)" if m == "fp16" else (
            f"{f(100 * (r['mean_ms'] / fp['mean_ms'] - 1), 1, signed=True)}%" if fp else MISSING)
        over = "–" if m == "fp16" else ("baseline" if m == "dgq" else (
            f"{f(100 * (r['mean_ms'] / base['mean_ms'] - 1), 1, signed=True)}%" if base else MISSING))
        rows.append([f"SD v1.4 – {labels[m]}", f"{r['mean_ms']:,.0f} ± {r['sd_ms']:,.0f}", slow, over])
        if m in ("uglut", "bucketize") and base:
            w = stats.welch_t(r["mean_ms"], r["sd_ms"], len(r["ms"]), base["mean_ms"], base["sd_ms"], len(base["ms"]))
            notes.append(f"{labels[m]} vs DGQ: {r['mean_ms'] - base['mean_ms']:+.0f} ms, Welch t({w.df:.1f}) = "
                         f"{w.statistic:.2f}, p = {w.p_value:.3g}; LUT memory {r['lut_memory_bytes'] / 1024:.0f} KiB.")
    g, b = _lat(led, "sd14", "uglut", backend), _lat(led, "sd14", "bucketize", backend)
    if g and b:
        w = stats.welch_t(b["mean_ms"], b["sd_ms"], len(b["ms"]), g["mean_ms"], g["sd_ms"], len(g["ms"]))
        notes.append(f"bucketize vs uniform grid: {b['mean_ms'] - g['mean_ms']:+.0f} ms, Welch t({w.df:.1f}) = "
                     f"{w.statistic:.2f}, p = {w.p_value:.3g}.")
    for model in ("sdxl", "sd3", "flux"):
        u, d = _lat(led, model, "uglut", backend), _lat(led, model, "dgq", backend)
        if u and d:
            notes.append(f"{MODEL_NAMES[model]}: UG-LUT overhead vs DGQ "
                         f"{100 * (u['mean_ms'] / d['mean_ms'] - 1):+.2f}% ({u['mean_ms']:,.0f} vs {d['mean_ms']:,.0f} ms).")
    gpus = sorted({r["provenance"].get("gpu", "") for r in led.get("latency", [])} - {""})
    if gpus:
        notes.append("GPU: " + ", ".join(gpus) + ".")
    return ["Configuration", "Latency (ms)", "Slowdown vs. FP16", "Overhead vs. DGQ"], rows, notes


def table8(led, backend):
    runs, rows = led["runs"], []

    def row(axis, label, **kw):
        r = pick(runs, "sd14", "coco200", "uglut", backend=backend, **kw)
        rows.append([axis, label, f(_v(r, "fid")), (f"{f(_v(r, 'is'))} ± {f(_v(r, 'is_sd'))}" if _v(r, "is") is not None else MISSING), f(_v(r, "clip"), 4)])

    row("Timestep", "Standard (single LUT)", calib=8)
    row("Timestep", "Timestep-adaptive (early/mid/late)", calib=8, variant="tsadaptive")
    row("Attention", "Cross-attention only", calib=8)
    row("Attention", "Self + cross", calib=8, variant="selfcross")
    for c in (4, 8, 16, 32, 64):
        extra = " (ablation default)" if c == 8 else " (headline budget)" if c == 64 else ""
        row("Calibration", f"{c} prompts{extra}", calib=c)
    for L, b in ((16, 4), (64, 6), (256, 8), (1024, 10)):
        row("LUT size", f"{b}-bit ({L} levels)", calib=8, levels=L)
    row("Lloyd iterations", "50 iterations (default)", calib=8)

    notes = []
    fits = [r for r in led.get("codebook", []) if r["config"].get("model") == "sd14"
            and r["config"].get("variant") == "standard" and r["config"].get("levels") == 256
            and r["config"].get("n_prompts") in (4, 8, 16, 32)]
    if fits:
        n = sum(r["summary"]["n_codebooks"] for r in fits)
        k = sum(r["summary"]["nonfinite"] for r in fits)
        hi = stats.clopper_pearson(k, n)[1]
        notes.append(f"Non-finite codebooks at 4–32 prompts: {k} of {n} "
                     f"(95% Clopper–Pearson upper bound {hi:.3f}).")
    sz = led.get("codebook_sizes", [])
    if sz:
        s = sz[-1]
        notes.append(f"Codebook sizes ({s['config']['source']} populations, {s['config']['n_layers']} layers): " + "; ".join(
            f"{x['levels']} levels: non-finite {x['nonfinite']}, re-seeded {x['reseeded_per_layer']:.1f}/layer, "
            f"empty without re-seeding {x['empty_without_reseeding_per_layer']:.1f}/layer, "
            f"MSE vs log₂ {100 * x['mean_reduction_vs_log2']:+.1f}%" for x in s["summary"]) + ".")
    return ["Ablation axis", "Configuration", "FID ↓", "IS ↑", "CLIP ↑"], rows, notes


TABLES = [
    ("Table 1. Headline cross-architecture comparison at W8A8", table1),
    ("Table 2. Statistical robustness on SD v1.4 (30K, 95% bootstrap intervals)", table2),
    ("Table 3. Multi-seed robustness (SD v1.4, W8A8 and W8A6, 1K)", table3),
    ("Table 4. Head-to-head with related quantizers (SD v1.4, W8A8, 1K)", table4),
    ("Table 5. Bit-width robustness with score-quantizer levels (1K, seed 42)", table5),
    ("Table 6. Per-layer attention-score MSE (×10⁻⁶) at 256 levels, SD v1.4 calibration set", table6),
    ("Table 7. Inference latency (mean ± σ over timed runs)", table7),
    ("Table 8. Ablation study (200 images, W8A8, SD v1.4; 8 calibration prompts unless stated)", table8),
]


# ---------------------------------------------------------------------------- output
def _strip(rec):
    return {k: v for k, v in rec.items() if k not in ("digests", "per_prompt", "layers", "ms")}


def build_report(runs, out, backend: str = "dgq") -> list:
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    led = build_ledger(runs)
    files = []

    cols = ["run", "model", "protocol", "method", "backend", "wbits", "abits", "score_levels", "calib_prompts",
            "variant", "seed", "n_images", "fid", "fid_lo", "fid_hi", "is", "is_sd", "is_lo", "is_hi", "clip",
            "image_set_sha256", "evaluated_set_sha256"]
    with open(out / "ledger.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in led["runs"]:
            w.writerow({c: r.get(c, "") for c in cols})
    files.append(out / "ledger.csv")
    compact = {k: (v if k == "runs" else [_strip(r) for r in v]) for k, v in led.items()}
    (out / "ledger.json").write_text(json.dumps(compact, indent=1, default=float), encoding="utf-8")
    files.append(out / "ledger.json")

    md = [f"# Results\n\nRendered by `uglut-report` from the records under `{Path(runs).as_posix()}` "
          f"(U-Net weight/activation back-end: `{backend}`). {MISSING} marks a condition without a record.\n"]
    mismatched = [r["run"] for r in led["runs"] if r.get("evaluated_set_sha256")
                  and r["evaluated_set_sha256"] != r["image_set_sha256"]]
    if mismatched:
        md.append("\n**Evaluated images differ from the generated ones in:** " + ", ".join(mismatched) + "\n")
    for i, (title, fn) in enumerate(TABLES, 1):
        cols_, rows, notes = fn(led, backend)
        md.append(f"\n## {title}\n\n" + (_table(cols_, rows) if rows else f"{MISSING}\n"))
        md += [f"\n{n}\n" for n in notes]
        with open(out / f"table{i}.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(cols_)
            w.writerows(rows)
        files.append(out / f"table{i}.csv")
    (out / "tables.md").write_text("".join(md), encoding="utf-8")
    files.append(out / "tables.md")
    return files
