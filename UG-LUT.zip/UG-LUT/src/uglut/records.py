"""Run records: provenance, file hashes and the results ledger.

Every ``uglut-*`` tool writes one self-describing JSON record next to its
outputs.  A record carries

``kind``        what it describes (``codebook``, ``generation``, ``metrics``,
                ``intrinsic``, ``codebook_sizes``, ``latency``, ``digest_comparison``);
``config``      the experimental condition (model, protocol, method, back-end,
                bit-widths, score levels, calibration budget, variant, seed ...);
``provenance``  the command line, the git commit of this repository (and of the
                DGQ checkout when it was used), package versions, GPU and UTC time;
``inputs``      SHA-256 digests of the files the tool read (codebooks, DGQ
                checkpoint, prompt list);

plus its results.  :func:`build_ledger` walks a run folder, joins the
generation and metric records of every run into one row, and collects every
other record by kind; ``uglut-report`` renders the paper's tables from that
ledger and nothing else, and ``uglut-bundle`` packages the records with a
SHA-256 manifest for publication.
"""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

SCHEMA = 1
PACKAGES = ("numpy", "scipy", "torch", "diffusers", "transformers", "huggingface_hub", "accelerate",
            "cleanfid", "open_clip")


def sha256_file(path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def sha256_text(lines) -> str:
    return hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()


def _git_commit(path=None) -> str:
    try:
        cmd = ["git", "rev-parse", "HEAD"] if path is None else ["git", "-C", str(path), "rev-parse", "HEAD"]
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "unknown"


def provenance(args=None) -> dict:
    vers = {}
    for mod in PACKAGES:
        try:
            vers[mod] = __import__(mod).__version__
        except Exception:
            pass
    gpu = ""
    try:
        import torch

        if torch.cuda.is_available():
            gpu = torch.cuda.get_device_name(0)
            vers["cuda"] = torch.version.cuda
    except Exception:
        pass
    from . import __version__

    return {"argv": sys.argv, "args": vars(args) if args is not None else {}, "uglut": __version__,
            "commit": _git_commit(), "python": platform.python_version(), "platform": platform.platform(),
            "versions": vers, "gpu": gpu, "time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}


def write_record(path, kind: str, config: dict, args=None, inputs: dict | None = None, **results) -> Path:
    rec = {"schema": SCHEMA, "kind": kind, "config": config, "provenance": provenance(args),
           "inputs": inputs or {}}
    rec.update(results)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(rec, indent=2, default=float), encoding="utf-8")
    print(f"wrote {path}")
    return path


def read_record(path) -> dict | None:
    try:
        rec = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    return rec if isinstance(rec, dict) and "kind" in rec and "config" in rec else None


# ------------------------------------------------------------------------------ ledger
RUN_KEYS = ("model", "protocol", "method", "backend", "wbits", "abits", "score_levels", "calib_prompts",
            "variant", "seed")


def build_ledger(root) -> dict:
    """Every record under ``root``: ``{"runs": [...], "<kind>": [...]}``.

    A run is a folder with generation records (one per shard); its row holds
    the generation config, the number of generated images, the digest of the
    whole image set (SHA-256 over the per-image digests in index order) and
    the metrics of the ``metrics.json`` in the same folder.
    """
    root = Path(root)
    gens = defaultdict(list)
    other = defaultdict(list)
    metrics = {}
    for f in sorted(root.rglob("*.json")):
        if "report" in f.relative_to(root).parts:
            continue
        rec = read_record(f)
        if rec is None:
            continue
        rel = f.relative_to(root).as_posix()
        if rec["kind"] == "generation":
            gens[f.parent].append((rec, rel))
        elif rec["kind"] == "metrics":
            metrics[f.parent] = (rec, rel)
        else:
            other[rec["kind"]].append(dict(rec, file=rel))
    runs = []
    for folder, parts in sorted(gens.items()):
        cfgs = {json.dumps(r["config"], sort_keys=True) for r, _ in parts}
        if len(cfgs) != 1:
            raise ValueError(f"shards of {folder} were generated with different configurations")
        digests = {}
        for r, _ in parts:
            start = int(r.get("shard", {}).get("start", 0))
            for i, h in enumerate(r["digests"]):
                digests[start + i] = h
        order = sorted(digests)
        row = dict(parts[0][0]["config"])
        row.update(run=folder.relative_to(root).as_posix(), n_images=len(order),
                   contiguous=order == list(range(len(order))),
                   image_set_sha256=sha256_text(digests[i] for i in order),
                   files=[rel for _, rel in parts])
        if folder in metrics:
            mrec, rel = metrics[folder]
            row.update(mrec.get("metrics", {}))
            row["metrics_file"] = rel
            row["evaluated_set_sha256"] = mrec.get("image_set_sha256")
        runs.append(row)
    out = {"runs": runs}
    out.update(other)
    return out


def select(rows, **criteria) -> list:
    """Rows whose fields equal every given criterion (``None`` criteria are ignored)."""
    return [r for r in rows if all(v is None or r.get(k) == v for k, v in criteria.items())]


def image_set_digest(folder) -> tuple[str, int]:
    """SHA-256 over the SHA-256 of every PNG in ``folder`` (file-name order) and the count."""
    files = sorted(p for p in Path(folder).iterdir() if p.suffix.lower() == ".png")
    return sha256_text(sha256_file(p) for p in files), len(files)
