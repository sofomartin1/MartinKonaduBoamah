"""Compilation of a codebook into a uniform lookup grid (O(1) assignment).

A Lloyd codebook has non-uniform bin edges, so assigning a score needs a
search (``bucketize``, O(log k)).  UG-LUT compiles the codebook into a uniform
grid of ``G`` entries (4,096 by default) over [0, 1]: entry ``j`` stores the
index of the level that the grid point ``j / (G - 1)`` is assigned to, so the
inference-time assignment is one multiply, one round and one gather.

``compilation_error`` measures what the compilation costs: the fraction of
scores that the grid assigns to a different level than exact search, and the
excess MSE this causes.  ``memory_bytes`` gives the resident size of the
tables: one 32-bit index per grid entry and one 32-bit float per level, i.e.
16 KB + 1 KB per layer for the default 4,096-entry grid over 256 levels, or
272 KB for the 16 cross-attention layers of SD v1.4.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .codebook import assign

DEFAULT_ENTRIES = 4096


@dataclass(frozen=True)
class Grid:
    table: np.ndarray  # int index into the codebook, one per grid cell
    levels: np.ndarray

    @property
    def entries(self) -> int:
        return int(self.table.size)

    def index(self, a: np.ndarray) -> np.ndarray:
        g = self.entries - 1
        j = np.clip(np.rint(np.asarray(a, dtype=np.float64) * g), 0, g).astype(np.int64)
        return self.table[j]

    def quantize(self, a: np.ndarray) -> np.ndarray:
        return self.levels[self.index(a)]


def compile_grid(levels: np.ndarray, entries: int = DEFAULT_ENTRIES) -> Grid:
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    probes = np.linspace(0.0, 1.0, entries)
    return Grid(table=assign(probes, lv).astype(np.int64), levels=lv)


def compilation_error(x: np.ndarray, levels: np.ndarray, entries: int = DEFAULT_ENTRIES) -> dict:
    a = np.asarray(x, dtype=np.float64)
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    exact = assign(a, lv)
    grid = compile_grid(lv, entries).index(a)
    m_exact = float(np.mean((a - lv[exact]) ** 2))
    m_grid = float(np.mean((a - lv[grid]) ** 2))
    return {
        "entries": int(entries),
        "disagreement_rate": float(np.mean(exact != grid)),
        "mse_exact": m_exact,
        "mse_grid": m_grid,
        "excess_mse": m_grid - m_exact,
    }


def memory_bytes(n_layers: int, entries: int = DEFAULT_ENTRIES, levels: int = 256,
                 index_bytes: int = 4, level_bytes: int = 4) -> int:
    """Resident size of the grids and codebooks of ``n_layers`` layers."""
    return int(n_layers * (entries * index_bytes + levels * level_bytes))
