"""Per-layer Lloyd-Max codebooks for normalized cross-attention scores.

The score population of one cross-attention layer is the set of normalized
post-softmax probabilities

    x = A[:, :, :, 1:] / max(A[:, :, :, 1:])      (the <start> column is excluded)

collected over all heads, all denoising steps and all calibration prompts.  An
``L``-level codebook is fitted with Lloyd's algorithm (Algorithm 1, lines 7-12
of the paper):

* initialization: ``L`` levels spaced uniformly on ``[0, max(x)]``;
* assignment:     every score goes to its nearest level (Eq. 5);
* update:         every level moves to the mean of its scores (Eq. 6);
* stopping:       at most 50 iterations, or earlier once the relative codebook
                  change ``max|c_t - c_{t-1}| / max|c_{t-1}|`` falls below 1e-4.

Empty-cell re-seeding
---------------------
The scores concentrate in the first few percent of their range, so a uniformly
initialized codebook leaves many upper cells without data, and Eq. (6) then
asks for the mean of an empty set, which is undefined (NaN).  At every
iteration each empty cell is re-seeded by splitting the most populous cell at
its median: the populous level takes the mean of the lower half and the empty
level the mean of the upper half.  All ``L`` levels stay populated and the
distortion never increases.  Every repair is counted.

``fit_lloyd(..., reseed=False)`` runs the textbook update without re-seeding
(empty centroid = 0 / 0 = NaN), which makes the failure mode observable, and
``count_empty_cells`` reports how many levels receive no data when empty cells
are simply left in place.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

MAX_ITERS = 50
TOLERANCE = 1e-4


@dataclass
class CodebookFit:
    """Result of one Lloyd-Max fit.

    ``levels`` are the sorted reconstruction levels and ``distortion`` the
    final mean squared error.  ``trajectory`` holds the distortion before the
    first and after every iteration, ``reseeded`` the number of empty cells
    repaired over the whole fit (``reseeded_by_iter`` per iteration), and
    ``empty_cells`` the number of levels without data at the end.
    """

    levels: np.ndarray
    distortion: float
    trajectory: list = field(default_factory=list)
    iterations: int = 0
    converged: bool = False
    reseeded: int = 0
    reseeded_by_iter: list = field(default_factory=list)
    empty_cells: int = 0
    relative_change: float = float("nan")

    @property
    def finite(self) -> bool:
        return bool(np.all(np.isfinite(self.levels)) and np.isfinite(self.distortion))

    def as_dict(self) -> dict:
        return {
            "levels": int(np.asarray(self.levels).size),
            "distortion": self.distortion,
            "iterations": self.iterations,
            "converged": self.converged,
            "reseeded": self.reseeded,
            "empty_cells": self.empty_cells,
            "finite": self.finite,
            "relative_change": self.relative_change,
            "trajectory": [float(v) for v in self.trajectory],
        }


# ----------------------------------------------------------------------------- basics
def uniform_init(x: np.ndarray, k: int) -> np.ndarray:
    """``k`` levels evenly spaced on ``[0, max(x)]`` (Algorithm 1, line 7)."""
    return np.linspace(0.0, float(np.max(x)), k)


def midpoints(levels: np.ndarray) -> np.ndarray:
    """Nearest-level decision boundaries ``b_k = (c_k + c_{k+1}) / 2``."""
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    return 0.5 * (lv[1:] + lv[:-1])


def assign(x: np.ndarray, levels: np.ndarray) -> np.ndarray:
    """Index of the nearest level for every value (``levels`` sorted ascending)."""
    return np.searchsorted(midpoints(levels), np.asarray(x, dtype=np.float64), side="right")


def mse(x: np.ndarray, levels: np.ndarray) -> float:
    """Mean squared error of nearest-level quantization."""
    a = np.asarray(x, dtype=np.float64)
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    return float(np.mean((a - lv[assign(a, lv)]) ** 2))


def count_empty_cells(x: np.ndarray, levels: np.ndarray) -> int:
    """Number of levels to which no value of ``x`` is assigned."""
    lv = np.sort(np.asarray(levels, dtype=np.float64))
    return int(np.sum(np.bincount(assign(x, lv), minlength=lv.size) == 0))


# ------------------------------------------------------------------------------ Lloyd
def _reseed(new: np.ndarray, counts: np.ndarray, csum: np.ndarray) -> int:
    """Split the most populous cell at its median once for every empty cell.

    ``x`` is sorted and the assignment is nearest-level, so every cell is one
    contiguous index range; both halves' means are read from the prefix sums
    ``csum`` without a pass over the data.  Returns the number of repairs.
    """
    empty = np.flatnonzero(counts == 0)
    if not empty.size:
        return 0
    work = counts.astype(np.int64).copy()
    start = np.concatenate([[0], np.cumsum(counts)])[:-1].astype(np.int64)
    done = 0
    for e in empty:
        j = int(np.argmax(work))
        c = int(work[j])
        if c < 2:
            break
        s, half = int(start[j]), c // 2
        new[j] = (csum[s + half] - csum[s]) / half
        new[e] = (csum[s + c] - csum[s + half]) / (c - half)
        work[j], work[e], start[e] = half, c - half, s + half
        done += 1
    return done


def fit_lloyd(x: np.ndarray, k: int = 256, iters: int = MAX_ITERS, tol: float = TOLERANCE,
              reseed: bool = True) -> CodebookFit:
    """Fit a ``k``-level Lloyd-Max codebook to ``x`` from a uniform initialization.

    ``reseed=False`` runs the textbook update: an empty cell produces a NaN
    level and the fit stops at that iteration.
    """
    a = np.sort(np.asarray(x, dtype=np.float64))
    csum = np.concatenate([[0.0], np.cumsum(a)])
    levels = uniform_init(a, k)
    prev = mse(a, levels)
    traj, by_iter = [prev], []
    converged, rel, it = False, float("nan"), 0

    for it in range(1, iters + 1):
        idx = assign(a, levels)
        counts = np.bincount(idx, minlength=k)
        sums = np.bincount(idx, weights=a, minlength=k)
        if not reseed and np.any(counts == 0):
            with np.errstate(invalid="ignore", divide="ignore"):
                bad = sums / counts
            traj.append(float("nan"))
            return CodebookFit(levels=bad, distortion=float("nan"), trajectory=traj, iterations=it,
                               empty_cells=int(np.sum(counts == 0)))
        new = levels.copy()
        occ = counts > 0
        new[occ] = sums[occ] / counts[occ]
        n_rep = _reseed(new, counts, csum) if reseed else 0
        new = np.sort(new)
        cur = mse(a, new)
        if cur > prev:  # a split can only lower the distortion; guard against round-off
            new = np.sort(np.where(occ, sums / np.maximum(counts, 1), levels))
            cur, n_rep = mse(a, new), 0
        by_iter.append(n_rep)
        denom = float(np.max(np.abs(levels)))
        rel = float(np.max(np.abs(new - levels))) / denom if denom > 0 else 0.0
        levels, prev = new, cur
        traj.append(cur)
        if rel < tol:
            converged = True
            break

    return CodebookFit(levels=levels, distortion=prev, trajectory=traj, iterations=it,
                       converged=converged, reseeded=int(sum(by_iter)), reseeded_by_iter=by_iter,
                       empty_cells=count_empty_cells(a, levels), relative_change=rel)


def fit_layers(samples: dict, k: int = 256, iters: int = MAX_ITERS, tol: float = TOLERANCE,
               reseed: bool = True) -> dict:
    """One codebook per layer; ``samples`` maps layer key -> 1-D array of normalized scores."""
    return {name: fit_lloyd(x, k=k, iters=iters, tol=tol, reseed=reseed) for name, x in samples.items()}


# -------------------------------------------------------------------------------- I/O
def save_codebooks(levels: dict, path, meta: dict | None = None) -> None:
    """Write ``{key: levels}`` to ``path`` (.npz, float32) and ``meta`` to the .json beside it.

    Keys are canonical layer keys (see ``attention.layer_key``); a
    timestep-adaptive file stores one codebook per phase under
    ``<layer>@<phase>``.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    arrays = {k: np.asarray(getattr(v, "levels", v), dtype=np.float32) for k, v in levels.items()}
    np.savez_compressed(path, **arrays)
    if meta is not None:
        path.with_suffix(".json").write_text(json.dumps(meta, indent=2, default=float), encoding="utf-8")


def load_codebooks(path) -> dict:
    with np.load(path) as z:
        return {k: np.sort(z[k].astype(np.float64)) for k in z.files}


def codebook_levels(books: dict) -> int:
    """The common number of levels of a codebook file (raises if the sizes differ)."""
    sizes = {int(np.asarray(v).size) for v in books.values()}
    if len(sizes) != 1:
        raise ValueError(f"codebooks of different sizes in one file: {sorted(sizes)}")
    return sizes.pop()
