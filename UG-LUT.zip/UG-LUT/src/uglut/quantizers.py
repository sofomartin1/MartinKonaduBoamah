"""Level placements compared in the per-layer score-MSE analysis (Table 6).

Every rule acts on the normalized score population of one layer and returns
``L`` sorted reconstruction levels on ``[0, max]``.

uniform   ``L`` evenly spaced levels                      (uniform linear quantizer)
log2      ``max * 2**-n`` for n = 0 .. L-1                (DGQ's logarithmic score quantizer)
lloyd     Lloyd-Max codebook, uniform initialization,     (UG-LUT)
          empty-cell re-seeding

``quantize(rule, x, levels)`` applies a placement the way the corresponding
quantizer does at inference: nearest level for ``uniform`` and ``lloyd`` and
rounding in the log domain for ``log2`` (``round(-log2(x))`` clamped to
``[0, L-1]``, exactly as DGQ's ``T2ILogQuantizer``).
"""

from __future__ import annotations

import numpy as np

from .codebook import assign, fit_lloyd


def place_uniform(x, k: int) -> np.ndarray:
    return np.linspace(0.0, float(np.max(x)), k)


def place_log2(x, k: int) -> np.ndarray:
    return np.sort(float(np.max(x)) * 2.0 ** -np.arange(k, dtype=np.float64))


def place_lloyd(x, k: int) -> np.ndarray:
    return fit_lloyd(x, k=k).levels


RULES = {"uniform": place_uniform, "log2": place_log2, "lloyd": place_lloyd}


def levels_for(rule: str, x, k: int = 256) -> np.ndarray:
    if rule not in RULES:
        raise KeyError(f"unknown placement rule {rule!r}; choose from {sorted(RULES)}")
    return np.sort(np.asarray(RULES[rule](x, k), dtype=np.float64))


def log2_quantize(x, k: int) -> np.ndarray:
    """DGQ's logarithmic quantizer on values normalized by their maximum."""
    a = np.asarray(x, dtype=np.float64)
    s = float(a.max())
    with np.errstate(divide="ignore"):
        n = np.clip(np.rint(-np.log2(a / s)), 0, k - 1)
    return s * 2.0 ** -n


def quantize(rule: str, x, k: int = 256, levels: np.ndarray | None = None) -> np.ndarray:
    """Quantized values of ``x`` under ``rule`` with ``k`` levels."""
    a = np.asarray(x, dtype=np.float64)
    if rule == "log2":
        return log2_quantize(a, k)
    lv = levels_for(rule, a, k) if levels is None else np.sort(np.asarray(levels, dtype=np.float64))
    return lv[assign(a, lv)]


def quantization_mse(rule: str, x, k: int = 256, levels: np.ndarray | None = None) -> float:
    a = np.asarray(x, dtype=np.float64)
    return float(np.mean((a - quantize(rule, a, k, levels)) ** 2))


def moment_matched(x, n: int = 200_000, seed: int = 0) -> np.ndarray:
    """A Beta sample on ``[0, max(x)]`` with the mean and variance of ``x``.

    Used by the codebook-size study to compare placements on a smooth
    reconstruction of each layer's score distribution (``uglut-sizes
    --source moment-matched``).
    """
    a = np.asarray(x, dtype=np.float64)
    hi = float(a.max())
    m, v = float(a.mean()) / hi, float(a.var()) / hi ** 2
    common = m * (1.0 - m) / v - 1.0
    alpha, beta = m * common, (1.0 - m) * common
    return np.sort(hi * np.random.default_rng(seed).beta(alpha, beta, size=n))
