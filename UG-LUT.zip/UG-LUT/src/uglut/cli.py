"""Command-line tools (installed by ``pip install -e .``).

uglut-calibrate   profile attention scores in FP16 and fit per-layer Lloyd-Max codebooks
uglut-generate    generate the images of a prompt protocol for one method and setting
uglut-eval        FID / IS / CLIP score of a folder of generated images
uglut-intrinsic   per-layer attention-score MSE of the uniform, log2 and Lloyd-Max quantizers
uglut-sizes       codebook-size study: re-seeding, empty cells, MSE against log2
uglut-latency     end-to-end latency per image over repeated runs
uglut-digest      compare the image digests of two runs, or hash externally generated images
uglut-report      build the results ledger and the paper's tables from a run folder
uglut-bundle      package the run records with a SHA-256 manifest, or verify a package

Every tool writes a JSON record (see :mod:`uglut.records`) next to its outputs.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

from . import records


# ----------------------------------------------------------------------------- utils
def _prompts(args) -> list:
    from . import data

    if getattr(args, "prompts", None):
        return data.read_prompts(args.prompts)
    return data.prompts_for(args.protocol)


def _seed_everything(seed: int) -> None:
    import random

    import torch

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False


def _codebook_record(path) -> dict:
    """The fit record written next to a codebook file (empty if absent)."""
    rec = records.read_record(Path(path).with_suffix(".json")) if path else None
    return rec or {}


def _power_of_two(v: str) -> int:
    n = int(v)
    if n < 2 or n & (n - 1):
        raise argparse.ArgumentTypeError(f"{n} is not a power of two")
    return n


def _add_setting_args(ap, method_required: bool = True) -> None:
    from .pipeline import METHODS, VARIANTS

    ap.add_argument("--model", default="sd14", choices=["sd14", "sdxl", "sd3", "flux"])
    ap.add_argument("--method", choices=METHODS, required=method_required,
                    help="fp16: no quantization; dgq: DGQ's log2 score quantizer; uglut: Lloyd-Max codebook "
                         "through the uniform grid; bucketize: the same codebook with exact search")
    ap.add_argument("--backend", choices=["dgq", "reference"], default="dgq",
                    help="weight/activation back-end: the official DGQ code (sd14, sdxl) or the reference "
                         "linear-layer hook (every model)")
    ap.add_argument("--wbits", type=int, default=8, help="weight bits")
    ap.add_argument("--abits", type=int, default=8, help="activation bits")
    ap.add_argument("--score-levels", type=_power_of_two, default=256,
                    help="levels of the attention-score quantizer, for DGQ and UG-LUT alike (256 = 8 bits)")
    ap.add_argument("--codebooks", help=".npz from uglut-calibrate (uglut, bucketize)")
    ap.add_argument("--variant", default="standard", choices=VARIANTS,
                    help="codebook variant; must match the codebook file")
    ap.add_argument("--entries", type=int, default=4096, help="uniform-grid entries")
    ap.add_argument("--dgq-ckpt", help="merged DGQ checkpoint of this W/A/score setting (--backend dgq)")
    ap.add_argument("--act-calib-protocol", default="coco_calib64",
                    help="activation-range calibration captions of the reference back-end")


def _setting(args) -> tuple[dict, dict, dict | None]:
    """Validated ``(config, inputs, codebooks)`` of the setting described by ``args``."""
    from . import codebook
    from .pipeline import UNET_MODELS

    unet = args.model in UNET_MODELS
    if args.method != "fp16" and args.backend == "dgq" and not unet:
        sys.exit(f"the DGQ back-end supports sd14 and sdxl; use --backend reference for {args.model}")
    if args.method != "fp16" and args.backend == "dgq" and not args.dgq_ckpt:
        sys.exit("--backend dgq needs --dgq-ckpt (made by scripts/dgq_quantize.sh)")
    books, crec, inputs = None, {}, {}
    if args.method in {"uglut", "bucketize"} and unet:
        if not args.codebooks:
            sys.exit(f"--method {args.method} needs --codebooks (run uglut-calibrate first)")
        books = codebook.load_codebooks(args.codebooks)
        crec = _codebook_record(args.codebooks)
        ccfg = crec.get("config", {})
        if codebook.codebook_levels(books) != args.score_levels:
            sys.exit(f"the codebooks have {codebook.codebook_levels(books)} levels but --score-levels is "
                     f"{args.score_levels}")
        if ccfg and ccfg.get("variant", "standard") != args.variant:
            sys.exit(f"the codebooks are of variant {ccfg.get('variant')!r}, not {args.variant!r}")
        if ccfg and ccfg.get("model") != args.model:
            sys.exit(f"the codebooks were fitted on {ccfg.get('model')}, not {args.model}")
        inputs["codebooks"] = {"file": str(args.codebooks), "sha256": records.sha256_file(args.codebooks)}
    quant = args.method != "fp16"
    config = {
        "model": args.model,
        "method": args.method,
        "backend": args.backend if quant else "none",
        "wbits": args.wbits if quant else None,
        "abits": args.abits if quant else None,
        "score_levels": args.score_levels if quant and unet else None,
        "calib_prompts": crec.get("config", {}).get("n_prompts") if books is not None else None,
        "variant": args.variant if books is not None else None,
        "entries": args.entries if books is not None else None,
    }
    if quant and args.backend == "dgq":
        inputs["dgq_ckpt"] = {"file": str(args.dgq_ckpt), "sha256": records.sha256_file(args.dgq_ckpt)}
    return config, inputs, books


def _build(args, books):
    from . import data, pipeline

    calib = data.prompts_for(args.act_calib_protocol) if args.method != "fp16" and args.backend == "reference" else None
    return pipeline.build(args.model, args.method, backend=args.backend, w_bits=args.wbits, a_bits=args.abits,
                          score_levels=args.score_levels, codebooks=books, variant=args.variant,
                          entries=args.entries, dgq_ckpt=args.dgq_ckpt, calib_prompts=calib)


# ------------------------------------------------------------------------- calibrate
def calibrate(argv=None):
    """Profile attention scores of the FP16 model on calibration captions and fit one codebook per layer."""
    ap = argparse.ArgumentParser(description=calibrate.__doc__)
    ap.add_argument("--model", default="sd14", choices=["sd14", "sdxl"])
    ap.add_argument("--protocol", default="coco_calib64", help="calibration captions (coco_calib4 ... 64)")
    ap.add_argument("--prompts", help="text file, one prompt per line (overrides --protocol)")
    ap.add_argument("--levels", type=_power_of_two, default=256, help="codebook size L (256 = 8-bit scores)")
    ap.add_argument("--variant", default="standard", choices=["standard", "tsadaptive", "selfcross"],
                    help="standard: one codebook per cross-attention layer; tsadaptive: one per layer and "
                         "denoising phase; selfcross: self-attention layers as well")
    ap.add_argument("--iters", type=int, default=50, help="maximum Lloyd iterations")
    ap.add_argument("--tol", type=float, default=1e-4, help="relative codebook change that stops the iteration")
    ap.add_argument("--per-call", type=int, default=2000, help="scores subsampled from every processor call")
    ap.add_argument("--samples-per-layer", type=int, default=200_000, help="subsample per layer for the fit")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--no-scores", action="store_true", help="do not keep the fitted score populations")
    ap.add_argument("--out", required=True, help="output .npz; the record goes to the .json beside it")
    args = ap.parse_args(argv)

    from . import attention, codebook, grid, pipeline, profiling

    _seed_everything(args.seed)
    pipe = pipeline.load_pipeline(args.model)
    prof = profiling.ScoreProfiler(per_call=args.per_call, seed=args.seed)
    tracker = attention.StepTracker().attach(pipe.unet) if args.variant == "tsadaptive" else None
    attention.install(pipe, mode="fp", self_attention=args.variant == "selfcross", tracker=tracker,
                      profiler=prof)
    prompts = _prompts(args)
    t0 = time.time()
    pipeline.generate(pipe, prompts, pipeline.GenConfig(args.model), seed=args.seed)
    rng = np.random.default_rng(args.seed)
    pop = {k: (np.sort(rng.choice(v, size=args.samples_per_layer, replace=False))
               if v.size > args.samples_per_layer else np.sort(v)) for k, v in sorted(prof.population().items())}
    fits = codebook.fit_layers(pop, k=args.levels, iters=args.iters, tol=args.tol)
    out = Path(args.out)
    config = {"model": args.model, "protocol": args.protocol if not args.prompts else None,
              "n_prompts": len(prompts), "levels": args.levels, "variant": args.variant,
              "iters": args.iters, "tol": args.tol, "init": "uniform", "reseed": "split-most-populous-at-median",
              "per_call": args.per_call, "samples_per_layer": args.samples_per_layer, "seed": args.seed}
    codebook.save_codebooks(fits, out)
    files = {"codebooks": {"file": out.name, "sha256": records.sha256_file(out)}}
    if not args.no_scores:
        scores = out.with_name(out.stem + "_scores.npz")
        np.savez_compressed(scores, **{k: v.astype(np.float32) for k, v in pop.items()})
        files["scores"] = {"file": scores.name, "sha256": records.sha256_file(scores)}
    layers = {k: f.as_dict() for k, f in fits.items()}
    n_modules = len({k.split("@")[0] for k in fits})
    summary = {
        "n_codebooks": len(fits),
        "n_modules": n_modules,
        "nonfinite": int(sum(not f.finite for f in fits.values())),
        "reseeded_per_codebook": float(np.mean([f.reseeded for f in fits.values()])),
        "empty_cells": int(sum(f.empty_cells for f in fits.values())),
        "iterations_max": int(max(f.iterations for f in fits.values())),
        "converged": int(sum(f.converged for f in fits.values())),
        "memory_bytes": grid.memory_bytes(len(fits), levels=args.levels),
        "seconds": time.time() - t0,
    }
    records.write_record(out.with_suffix(".json"), "codebook", config, args,
                         inputs={"prompts_sha256": records.sha256_text(prompts)},
                         outputs=files, summary=summary, layers=layers)


# -------------------------------------------------------------------------- generate
def generate(argv=None):
    """Generate one image per prompt of a protocol for one method and setting."""
    ap = argparse.ArgumentParser(description=generate.__doc__)
    _add_setting_args(ap)
    ap.add_argument("--protocol", default="coco1k")
    ap.add_argument("--prompts", help="text file, one prompt per line (overrides --protocol)")
    ap.add_argument("--seed", type=int, default=42, help="image i uses generator seed SEED + i")
    ap.add_argument("--start", type=int, default=0, help="first prompt index (for sharding)")
    ap.add_argument("--count", type=int, default=None, help="number of prompts from --start")
    ap.add_argument("--out", required=True, help="run folder: images/ and generate_<start>.json")
    args = ap.parse_args(argv)

    from . import pipeline

    config, inputs, books = _setting(args)
    _seed_everything(args.seed)
    prompts = _prompts(args)
    end = len(prompts) if args.count is None else min(len(prompts), args.start + args.count)
    pipe, info = _build(args, books)
    t0 = time.time()
    digests = pipeline.generate(pipe, prompts[args.start:end], pipeline.GenConfig(args.model), seed=args.seed,
                                save_dir=Path(args.out) / "images", start_index=args.start)
    config.update(protocol=args.protocol if not args.prompts else None, n_prompts=len(prompts), seed=args.seed)
    inputs["prompts_sha256"] = records.sha256_text(prompts)
    records.write_record(Path(args.out) / f"generate_{args.start:05d}.json", "generation", config, args,
                         inputs=inputs, shard={"start": args.start, "count": end - args.start},
                         installed=info, seconds=time.time() - t0, digests=digests)


# ------------------------------------------------------------------------------ eval
def evaluate(argv=None):
    """FID, IS and CLIP score of a folder of generated images."""
    ap = argparse.ArgumentParser(description=evaluate.__doc__)
    ap.add_argument("what", nargs="?", default="all", choices=["all", "fid", "is", "clip"])
    ap.add_argument("--images", required=True, help="folder of generated PNGs (file order = prompt order)")
    ap.add_argument("--protocol", help="prompt protocol of the images (CLIP score)")
    ap.add_argument("--prompts", help="prompt file in image order (overrides --protocol)")
    ap.add_argument("--reference", help="FID reference folder (default: MS-COCO val2014)")
    ap.add_argument("--bootstrap", type=int, default=0, help="bootstrap resamples for 95%% intervals (0 = off)")
    ap.add_argument("--seed", type=int, default=0, help="bootstrap seed")
    ap.add_argument("--out", help="record path (default: <images>/../metrics.json)")
    args = ap.parse_args(argv)

    from . import data, metrics

    want = lambda k: args.what in ("all", k)  # noqa: E731
    if want("clip") and not (args.prompts or args.protocol):
        sys.exit("the CLIP score needs --protocol or --prompts")
    set_sha, n = records.image_set_digest(args.images)
    res = {"n_images": n}
    if want("fid"):
        ref = args.reference or str(data.coco_reference_images())
        res.update(metrics.fid(args.images, ref, n_boot=args.bootstrap, seed=args.seed))
    if want("is"):
        p = metrics.class_probs(args.images)
        res["is"], res["is_sd"] = metrics.inception_score(p)
        if args.bootstrap:
            _, res["is_lo"], res["is_hi"] = metrics.inception_score_bootstrap(p, args.bootstrap, args.seed)
    if want("clip"):
        res["clip"] = metrics.clip_score(args.images, _prompts(args))
    out = Path(args.out) if args.out else Path(args.images).resolve().parent / "metrics.json"
    config = {"images": str(args.images), "protocol": args.protocol, "bootstrap": args.bootstrap,
              "is_splits": metrics.IS_SPLITS, "is_backbone": "/".join(metrics.IS_MODEL),
              "clip_backbone": "/".join(metrics.CLIP_MODEL), "fid": "clean-fid, mode clean"}
    records.write_record(out, "metrics", config, args, image_set_sha256=set_sha, metrics=res)


# ------------------------------------------------------------------------- intrinsic
def intrinsic(argv=None):
    """Per-layer attention-score MSE between FP16 and the uniform, log2 and Lloyd-Max quantizers (Table 6)."""
    ap = argparse.ArgumentParser(description=intrinsic.__doc__)
    ap.add_argument("--model", default="sd14", choices=["sd14", "sdxl"])
    ap.add_argument("--protocol", default="coco_calib64")
    ap.add_argument("--prompts", help="text file, one prompt per line (overrides --protocol)")
    ap.add_argument("--codebooks", required=True, help="standard .npz from uglut-calibrate")
    ap.add_argument("--levels", type=_power_of_two, default=256)
    ap.add_argument("--entries", type=int, default=4096)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args(argv)

    from . import attention, codebook, pipeline, profiling

    _seed_everything(args.seed)
    books = codebook.load_codebooks(args.codebooks)
    pipe = pipeline.load_pipeline(args.model)
    logs = {"uniform": profiling.ErrorLog(), "log2": profiling.ErrorLog(), "grid": profiling.ErrorLog()}
    attention.install_measurement(pipe, logs, books, levels=args.levels, entries=args.entries)
    prompts = _prompts(args)
    pipeline.generate(pipe, prompts, pipeline.GenConfig(args.model), seed=args.seed,
                      on_prompt=lambda i: [log.set_prompt(i) for log in logs.values()])
    per_layer = {rule: log.per_layer() for rule, log in logs.items()}
    layers = list(per_layer["grid"])
    rows = [{"layer": l, "short": attention.short_name(l), "uniform": per_layer["uniform"][l],
             "log2": per_layer["log2"][l], "lloyd": per_layer["grid"][l],
             "reduction_vs_log2": per_layer["grid"][l] / per_layer["log2"][l] - 1.0} for l in layers]
    avg = {k: float(np.mean([r[k] for r in rows])) for k in ("uniform", "log2", "lloyd")}
    avg["mean_reduction_vs_log2"] = float(np.mean([r["reduction_vs_log2"] for r in rows]))
    avg["reduction_of_mean_vs_log2"] = avg["lloyd"] / avg["log2"] - 1.0
    config = {"model": args.model, "protocol": args.protocol if not args.prompts else None,
              "n_prompts": len(prompts), "levels": args.levels, "entries": args.entries, "seed": args.seed,
              "units": "squared attention probability"}
    records.write_record(args.out, "intrinsic", config, args,
                         inputs={"codebooks": {"file": str(args.codebooks),
                                               "sha256": records.sha256_file(args.codebooks)},
                                 "prompts_sha256": records.sha256_text(prompts)},
                         layers=rows, average=avg,
                         per_prompt={rule: log.per_prompt_layer() for rule, log in logs.items()})


# ----------------------------------------------------------------------------- sizes
def sizes(argv=None):
    """Codebook-size study on calibrated score populations: re-seeding, empty cells and MSE against log2."""
    ap = argparse.ArgumentParser(description=sizes.__doc__)
    ap.add_argument("--scores", required=True, help="*_scores.npz written by uglut-calibrate")
    ap.add_argument("--levels", type=_power_of_two, nargs="+", default=[16, 64, 256, 1024])
    ap.add_argument("--source", choices=["calibration", "moment-matched"], default="calibration",
                    help="fit the calibrated scores themselves, or a Beta reconstruction matched to each "
                         "layer's mean and variance")
    ap.add_argument("--iters", type=int, default=50)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args(argv)

    from . import codebook, quantizers

    with np.load(args.scores) as z:
        pops = {k: z[k].astype(np.float64) for k in z.files if "@" not in k and ".attn2" in k}
    if args.source == "moment-matched":
        pops = {k: quantizers.moment_matched(x, x.size, seed=args.seed) for k, x in pops.items()}
    rows = []
    for L in args.levels:
        for layer, x in pops.items():
            fit = codebook.fit_lloyd(x, k=L, iters=args.iters)
            naive = codebook.fit_lloyd(x, k=L, iters=args.iters, reseed=False)
            m_lloyd = codebook.mse(x, fit.levels)
            m_log2 = quantizers.quantization_mse("log2", x, L)
            rows.append({"levels": L, "layer": layer, "finite": fit.finite, "reseeded": fit.reseeded,
                         "iterations": fit.iterations, "converged": fit.converged,
                         "textbook_finite": naive.finite,
                         "empty_without_reseeding": naive.empty_cells if not naive.finite else 0,
                         "mse_lloyd": m_lloyd, "mse_log2": m_log2, "reduction_vs_log2": m_lloyd / m_log2 - 1.0})
    summary = []
    for L in args.levels:
        r = [row for row in rows if row["levels"] == L]
        summary.append({"levels": L, "layers": len(r), "nonfinite": sum(not x["finite"] for x in r),
                        "textbook_nonfinite": sum(not x["textbook_finite"] for x in r),
                        "reseeded_per_layer": float(np.mean([x["reseeded"] for x in r])),
                        "empty_without_reseeding_per_layer": float(np.mean([x["empty_without_reseeding"] for x in r])),
                        "iterations_max": int(max(x["iterations"] for x in r)),
                        "mean_reduction_vs_log2": float(np.mean([x["reduction_vs_log2"] for x in r]))})
    config = {"source": args.source, "levels": args.levels, "iters": args.iters, "seed": args.seed,
              "n_layers": len(pops)}
    records.write_record(args.out, "codebook_sizes", config, args,
                         inputs={"scores": {"file": str(args.scores), "sha256": records.sha256_file(args.scores)}},
                         summary=summary, layers=rows)


# --------------------------------------------------------------------------- latency
def latency(argv=None):
    """End-to-end latency per image of one quantized configuration (mean and SD over timed runs)."""
    ap = argparse.ArgumentParser(description=latency.__doc__)
    _add_setting_args(ap)
    ap.add_argument("--runs", type=int, default=30, help="timed runs")
    ap.add_argument("--warmup", type=int, default=5, help="untimed warm-up runs")
    ap.add_argument("--prompt", default="a photograph of an astronaut riding a horse")
    ap.add_argument("--out", required=True)
    args = ap.parse_args(argv)

    import torch

    from . import attention, pipeline

    if not torch.cuda.is_available():
        sys.exit("uglut-latency measures GPU latency and needs a CUDA device")
    config, inputs, books = _setting(args)
    _seed_everything(0)
    pipe, info = _build(args, books)
    cfg = pipeline.GenConfig(args.model)
    times = []
    for r in range(args.warmup + args.runs):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        pipeline.generate(pipe, [args.prompt], cfg, seed=r)
        torch.cuda.synchronize()
        if r >= args.warmup:
            times.append(1000.0 * (time.perf_counter() - t0))
    tables = [t for p in attention.lut_processors(pipe) for t in p.tables.values()]
    if not tables and getattr(pipe, "unet", None) is not None:  # DGQ back-end
        tables = [t for m in pipe.unet.modules() for t in getattr(m, "tables", {}).values()]
    config.update(runs=args.runs, warmup=args.warmup, prompt=args.prompt)
    records.write_record(args.out, "latency", config, args, inputs=inputs, installed=info, ms=times,
                         mean_ms=float(np.mean(times)), sd_ms=float(np.std(times, ddof=1)),
                         lut_memory_bytes=int(sum(t.nbytes() for t in tables)),
                         max_memory_allocated=int(torch.cuda.max_memory_allocated()))


# ---------------------------------------------------------------------------- digest
def _load_digests(folder) -> dict:
    ds = {}
    for f in sorted(Path(folder).glob("generate_*.json")):
        rec = records.read_record(f) or {}
        start = int(rec.get("shard", {}).get("start", 0))
        for i, h in enumerate(rec.get("digests", [])):
            ds[start + i] = h
    return ds


def digest(argv=None):
    """Compare the per-image SHA-256 digests of two runs, or hash externally generated images."""
    ap = argparse.ArgumentParser(description=digest.__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("compare", help="image i of run A against image i of run B")
    c.add_argument("run_a")
    c.add_argument("run_b")
    c.add_argument("--out", help="record path")
    h = sub.add_parser("hash", help="generation record for images made by another code base (e.g. Q-Diffusion)")
    h.add_argument("images", help="folder of PNGs named <index>.png in prompt order")
    h.add_argument("--model", default="sd14")
    h.add_argument("--protocol", required=True)
    h.add_argument("--method", required=True, help="label of the method, e.g. qdiffusion or tfmqdm")
    h.add_argument("--wbits", type=int, default=8)
    h.add_argument("--abits", type=int, default=8)
    h.add_argument("--seed", type=int, default=42)
    h.add_argument("--source", required=True, help="code base and commit that generated the images")
    h.add_argument("--out", required=True, help="run folder that receives generate_00000.json")
    args = ap.parse_args(argv)

    if args.cmd == "compare":
        a, b = _load_digests(args.run_a), _load_digests(args.run_b)
        common = sorted(set(a) & set(b))
        same = sum(a[i] == b[i] for i in common)
        res = {"n_a": len(a), "n_b": len(b), "compared": len(common), "identical": same,
               "all_identical": bool(common) and same == len(common) == len(a) == len(b)}
        print(json.dumps(res))
        if args.out:
            records.write_record(args.out, "digest_comparison", {"run_a": args.run_a, "run_b": args.run_b},
                                 args, **res)
        return
    from . import data

    files = sorted(p for p in Path(args.images).iterdir() if p.suffix.lower() == ".png")
    prompts = data.prompts_for(args.protocol)
    if len(files) != len(prompts):
        sys.exit(f"{len(files)} images for {len(prompts)} prompts of {args.protocol}")
    config = {"model": args.model, "method": args.method, "backend": "external", "wbits": args.wbits,
              "abits": args.abits, "score_levels": None, "calib_prompts": None, "variant": None,
              "entries": None, "protocol": args.protocol, "n_prompts": len(prompts), "seed": args.seed}
    records.write_record(Path(args.out) / "generate_00000.json", "generation", config, args,
                         inputs={"prompts_sha256": records.sha256_text(prompts)}, source=args.source,
                         shard={"start": 0, "count": len(files)},
                         digests=[records.sha256_file(p) for p in files])


# ---------------------------------------------------------------------------- report
def report(argv=None):
    """Build the results ledger and the tables of the paper from every record under a run folder."""
    ap = argparse.ArgumentParser(description=report.__doc__)
    ap.add_argument("runs", nargs="?", default="runs", help="root folder of the runs (default: runs)")
    ap.add_argument("--out", default=None, help="output folder (default: RUNS/report)")
    ap.add_argument("--backend", default="dgq", help="W/A back-end of the U-Net rows (default: dgq)")
    args = ap.parse_args(argv)

    from . import report as rp

    if not Path(args.runs).is_dir():
        sys.exit(f"run folder {args.runs!r} does not exist")
    out = Path(args.out or Path(args.runs) / "report")
    for f in rp.build_report(args.runs, out, backend=args.backend):
        print(f"wrote {f}")


# ---------------------------------------------------------------------------- bundle
def bundle(argv=None):
    """Package every run record (not the images) with a SHA-256 manifest, or verify such a package."""
    ap = argparse.ArgumentParser(description=bundle.__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("create")
    c.add_argument("runs", nargs="?", default="runs")
    c.add_argument("--out", required=True, help="output .tar.gz")
    c.add_argument("--no-scores", action="store_true", help="leave out the calibration score populations")
    v = sub.add_parser("verify")
    v.add_argument("archive")
    args = ap.parse_args(argv)

    from . import bundle as bd

    if args.cmd == "create":
        path, n = bd.create(args.runs, args.out, include_scores=not args.no_scores)
        print(f"wrote {path} ({n} files)")
    else:
        bad = bd.verify(args.archive)
        if bad:
            sys.exit("manifest mismatch: " + ", ".join(bad))
        print("all files match the manifest")


if __name__ == "__main__":
    tools = {"calibrate": calibrate, "generate": generate, "eval": evaluate, "intrinsic": intrinsic,
             "sizes": sizes, "latency": latency, "digest": digest, "report": report, "bundle": bundle}
    tools[sys.argv[1]](sys.argv[2:])
