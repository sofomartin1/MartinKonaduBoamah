"""Collection of normalized attention scores and of per-call score-quantization error.

``ScoreProfiler`` keeps, per layer (or per layer and phase), a seeded random
subsample of the normalized scores of every processor call, so that the
calibration population is reproducible and bounded in memory.

``ErrorLog`` accumulates the squared error between the full-precision and the
quantized attention scores (in probability units, i.e. after de-normalization)
per prompt, layer and denoising step; ``uglut-intrinsic`` reports it.
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np


class ScoreProfiler:
    """Seeded subsample of ``per_call`` normalized scores from every processor call."""

    def __init__(self, per_call: int = 2000, seed: int = 0):
        import torch

        self.per_call = per_call
        self.gen = torch.Generator(device="cpu").manual_seed(seed)
        self.samples = defaultdict(list)

    def record(self, key: str, a) -> None:
        import torch

        flat = a.detach().reshape(-1).float().cpu()
        if flat.numel() > self.per_call:
            idx = torch.randint(0, flat.numel(), (self.per_call,), generator=self.gen)
            flat = flat[idx]
        self.samples[key].append(flat.numpy())

    def population(self) -> dict:
        return {k: np.concatenate(v) for k, v in self.samples.items()}


class ErrorLog:
    """Sum of squared error and element count per (prompt, layer, step).

    The step of a call is the number of earlier calls of the same layer for
    the same prompt: diffusers and DGQ batch the conditional and unconditional
    branches of classifier-free guidance into one call per denoising step.
    """

    def __init__(self):
        self.prompt = 0
        self.sse = defaultdict(float)
        self.n = defaultdict(int)
        self._calls = defaultdict(int)

    def set_prompt(self, i: int) -> None:
        self.prompt = i

    def record(self, layer: str, x, q) -> None:
        step = self._calls[(self.prompt, layer)]
        self._calls[(self.prompt, layer)] += 1
        d = x.double() - q.double()
        key = (self.prompt, layer, step)
        self.sse[key] += float((d * d).sum())
        self.n[key] += int(d.numel())

    def per_layer(self) -> dict:
        """Pooled MSE per layer, in first-call order."""
        layers = list(dict.fromkeys(k[1] for k in self.sse))
        out = {}
        for layer in layers:
            keys = [k for k in self.sse if k[1] == layer]
            out[layer] = sum(self.sse[k] for k in keys) / sum(self.n[k] for k in keys)
        return out

    def per_prompt_layer(self) -> dict:
        """``{layer: [MSE of prompt 0, prompt 1, ...]}``."""
        prompts = sorted({k[0] for k in self.sse})
        out = {}
        for layer in dict.fromkeys(k[1] for k in self.sse):
            vals = []
            for p in prompts:
                keys = [k for k in self.sse if k[0] == p and k[1] == layer]
                vals.append(sum(self.sse[k] for k in keys) / sum(self.n[k] for k in keys))
            out[layer] = vals
        return out
