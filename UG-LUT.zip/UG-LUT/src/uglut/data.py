"""Prompt protocols and the FID reference set (MS-COCO 2014 validation).

All downloads go to ``$UGLUT_DATA`` (default ``./data``);
``scripts/fetch_data.py`` writes the prompt list of every protocol to
``data/prompts/<protocol>.txt`` together with a ``SHA256SUMS`` file.

Sources
-------
MS-COCO 2014 validation captions   https://cocodataset.org/#download
    http://images.cocodataset.org/annotations/annotations_trainval2014.zip
MS-COCO 2014 validation images     (40,504 images; the FID reference set)
    http://images.cocodataset.org/zips/val2014.zip
MS-COCO 30K caption list           the 30,000 (image, caption) pairs of the BK-SDM /
                                   DGQ benchmark (DGQ, scripts/get_mscoco_files.sh)
    https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/data/mscoco_val2014_30k/metadata.csv

Protocols
---------
coco30k          the 30K caption list, in file order                  (Tables 1, 2)
coco1k           its first 1,000 captions                             (Tables 1, 3, 4, 5)
coco200          its first 200 captions                               (Table 8)
coco_calib64     64 calibration captions: a seeded sample (seed 0) of the first
                 caption of every val2014 image outside the 30K list  (Tables 1-7)
coco_calib{4,8,16,32}   the first 4, 8, 16, 32 of those 64           (Table 8)

The evaluation lists are nested (200 in 1K in 30K), the calibration lists are
nested (4 in 8 in ... in 64), and no calibration caption belongs to an image
of the evaluation lists.
"""

from __future__ import annotations

import csv
import json
import os
import random
import re
import zipfile
from pathlib import Path

URLS = {
    "coco_ann": "http://images.cocodataset.org/annotations/annotations_trainval2014.zip",
    "coco_val": "http://images.cocodataset.org/zips/val2014.zip",
    "coco30k": "https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/data/"
               "mscoco_val2014_30k/metadata.csv",
}
CALIB_SEED = 0
CALIB_POOL = 64

# protocol -> number of prompts
PROTOCOLS = {
    "coco_calib4": 4, "coco_calib8": 8, "coco_calib16": 16, "coco_calib32": 32, "coco_calib64": 64,
    "coco30k": 30000, "coco1k": 1000, "coco200": 200,
}


def data_root() -> Path:
    return Path(os.environ.get("UGLUT_DATA", "data")).resolve()


def _download(url: str, dest: Path) -> Path:
    import requests

    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        return dest
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        tmp = dest.with_suffix(dest.suffix + ".part")
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 20):
                f.write(chunk)
        tmp.rename(dest)
    return dest


def _image_id(file_name: str) -> int:
    m = re.search(r"(\d+)(?:\.\w+)?$", file_name)
    if not m:
        raise ValueError(f"cannot read an image id from {file_name!r}")
    return int(m.group(1))


def coco30k_pairs() -> list:
    """(image_id, caption) pairs of the 30K benchmark list, in file order."""
    p = _download(URLS["coco30k"], data_root() / "coco" / "mscoco_val2014_30k_metadata.csv")
    with open(p, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    header, rows = rows[0], rows[1:]
    fi = header.index("file_name") if "file_name" in header else 0
    ti = header.index("text") if "text" in header else 1
    return [(_image_id(r[fi]), r[ti].strip()) for r in rows]


def coco_captions() -> list:
    """(image_id, caption) of MS-COCO val2014, first caption (lowest annotation id) per image."""
    root = data_root() / "coco"
    z = _download(URLS["coco_ann"], root / "annotations_trainval2014.zip")
    with zipfile.ZipFile(z) as zf:
        ann = json.loads(zf.read("annotations/captions_val2014.json"))
    first = {}
    for a in sorted(ann["annotations"], key=lambda a: a["id"]):
        first.setdefault(a["image_id"], a["caption"].strip().replace("\n", " "))
    return sorted(first.items())


def calibration_captions(eval_ids: set, pairs: list, n: int = CALIB_POOL, seed: int = CALIB_SEED) -> list:
    """Seeded sample of ``n`` captions from images outside ``eval_ids``."""
    pool = [c for i, c in pairs if i not in eval_ids]
    return random.Random(seed).sample(pool, n)


def sample(protocol: str) -> list:
    """The prompt list of a protocol (deterministic)."""
    if protocol not in PROTOCOLS:
        raise KeyError(f"unknown protocol {protocol!r}; choose from {sorted(PROTOCOLS)}")
    n = PROTOCOLS[protocol]
    pairs30k = coco30k_pairs()
    if protocol.startswith("coco_calib"):
        return calibration_captions({i for i, _ in pairs30k}, coco_captions())[:n]
    return [c for _, c in pairs30k[:n]]


def coco_reference_images() -> Path:
    """Unpacked val2014 images (the 40,504-image FID reference set)."""
    root = data_root() / "coco"
    out = root / "val2014"
    if not out.exists():
        z = _download(URLS["coco_val"], root / "val2014.zip")
        with zipfile.ZipFile(z) as zf:
            zf.extractall(root)
    return out


def prompts_for(protocol: str) -> list:
    """The prompt list of a protocol, read from ``data/prompts`` when it has been fetched."""
    local = data_root() / "prompts" / f"{protocol}.txt"
    return read_prompts(local) if local.exists() else sample(protocol)


def read_prompts(path) -> list:
    with open(path, encoding="utf-8") as f:
        return [ln.rstrip("\n") for ln in f if ln.strip()]


def write_prompts(prompts, path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(p.replace("\n", " ") for p in prompts) + "\n")
