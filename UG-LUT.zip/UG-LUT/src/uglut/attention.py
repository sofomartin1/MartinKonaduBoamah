"""Attention-score quantizers for diffusers U-Nets (SD v1.4, SDXL-Turbo).

The processor replaces the post-softmax probabilities ``A`` of an attention
module before they multiply ``V``.  For cross-attention (``attn2``):

    s              = max(A[..., 1:])                 dynamic per-call scale
    x              = A[..., 1:] / s                  normalized scores in [0, 1]
    A'[..., 1:]    = C_l[ lookup(x) ] * s            codebook value, de-normalized
    A'[..., 0]     = A[..., 0]                       <start> column kept in full precision
    O              = A' V

Self-attention (``attn1``, quantized only in the self + cross ablation) has no
``<start>`` column, so every column is quantized.

``mode`` selects the lookup:

* ``"fp"``         no quantization (full precision; used for profiling);
* ``"grid"``       UG-LUT: uniform 4,096-entry table, O(1) gather (Eq. 8);
* ``"bucketize"``  exact nearest-level search on the codebook boundaries, O(log L);
* ``"log2"``       DGQ's logarithmic score quantizer, see :func:`log2_quant`;
* ``"uniform"``    ``L`` evenly spaced levels (the uniform linear rule of Table 6).

Timestep-adaptive codebooks
---------------------------
The timestep-adaptive variant keeps one codebook per denoising phase.
:class:`StepTracker` reads the timestep ``t`` passed to the denoiser and the
processor selects the phase from it: ``early`` for ``t >= 2T/3``, ``mid`` for
``T/3 <= t < 2T/3`` and ``late`` below, with ``T = 1000`` training timesteps.
With 25 DDIM steps (t = 961, 921, ..., 1) this gives 8 early, 8 mid and 9 late
steps; with SDXL-Turbo's 4 steps (t = 999, 749, 499, 249) it gives 2, 1 and 1.

SD3 and FLUX.1 compute joint attention over the concatenated image and text
tokens and expose no separate cross-attention module, so :func:`install`
replaces nothing on them (it returns 0).
"""

from __future__ import annotations

import math
from typing import Optional

import numpy as np

PHASES = ("early", "mid", "late")
TRAIN_TIMESTEPS = 1000
MODES = ("fp", "grid", "bucketize", "log2", "uniform")


def _torch():
    import torch

    return torch


def phase_of(t: float, train_timesteps: int = TRAIN_TIMESTEPS) -> str:
    """Denoising phase of timestep ``t``: thirds of the training schedule."""
    if t >= 2.0 * train_timesteps / 3.0:
        return "early"
    if t >= train_timesteps / 3.0:
        return "mid"
    return "late"


def phase_key(layer: str, phase: str) -> str:
    """Codebook key of one phase of a timestep-adaptive codebook file."""
    return f"{layer}@{phase}"


class StepTracker:
    """Records the timestep of every denoiser call (forward pre-hook)."""

    def __init__(self, train_timesteps: int = TRAIN_TIMESTEPS):
        self.t: Optional[float] = None
        self.calls = 0
        self.train_timesteps = train_timesteps
        self.handle = None

    def attach(self, denoiser) -> "StepTracker":
        self.handle = denoiser.register_forward_pre_hook(self._hook, with_kwargs=True)
        return self

    def detach(self) -> None:
        if self.handle is not None:
            self.handle.remove()
            self.handle = None

    def _hook(self, module, args, kwargs):
        t = kwargs.get("timestep", kwargs.get("timesteps"))
        if t is None and len(args) > 1:
            t = args[1]
        torch = _torch()
        self.t = float(t.reshape(-1)[0]) if isinstance(t, torch.Tensor) else float(t)
        self.calls += 1

    @property
    def phase(self) -> str:
        if self.t is None:
            raise RuntimeError("StepTracker has not seen a denoiser call")
        return phase_of(self.t, self.train_timesteps)


class LUTTable:
    """Torch-side copy of a codebook and its uniform lookup grid."""

    def __init__(self, levels: np.ndarray, entries: int = 4096, device="cuda"):
        torch = _torch()
        from .codebook import midpoints
        from .grid import compile_grid

        lv = np.sort(np.asarray(levels, dtype=np.float64))
        self.levels = torch.tensor(lv, device=device, dtype=torch.float32)
        self.edges = torch.tensor(midpoints(lv), device=device, dtype=torch.float32)
        self.table = torch.tensor(compile_grid(lv, entries).table, device=device, dtype=torch.int32)
        self.entries = entries

    def grid(self, a):
        torch = _torch()
        j = torch.clamp(torch.round(a * (self.entries - 1)), 0, self.entries - 1).long()
        return self.levels[self.table[j].long()]

    def bucketize(self, a):
        torch = _torch()
        return self.levels[torch.bucketize(a, self.edges, right=True)]

    def nbytes(self) -> int:
        return int(self.table.numel() * 4 + self.levels.numel() * 4)


def log2_quant(a, levels: int = 256):
    """DGQ's logarithmic score quantizer on normalized scores ``a`` in [0, 1].

    Identical to DGQ's real-time ``T2ILogQuantizer`` (https://github.com/ugonfor/DGQ,
    ``quant/quant_layer_text.py``) with ``2**bits = levels``, applied after
    normalization by the maximum: the exponent ``-log2(a)`` is rounded and
    clamped to ``[0, levels - 1]``, so the levels are ``2**-n``.
    """
    torch = _torch()
    n = torch.clamp(torch.round(-torch.log2(a.float())), 0, levels - 1)
    return torch.pow(2.0, -n)


def uniform_quant(a, levels: int = 256):
    """``levels`` evenly spaced levels on [0, 1], nearest-level assignment."""
    torch = _torch()
    return torch.round(a.float() * (levels - 1)) / (levels - 1)


class LUTAttnProcessor:
    """Drop-in replacement for ``diffusers.models.attention_processor.AttnProcessor``.

    ``tables`` maps a phase (``None`` for a single codebook, or ``"early"``,
    ``"mid"``, ``"late"``) to a :class:`LUTTable`; a phase-keyed table needs a
    ``tracker``.  ``keep_first`` keeps column 0 (the ``<start>`` token of
    cross-attention) in full precision.
    """

    def __init__(self, name: str, mode: str = "grid", tables: Optional[dict] = None, levels: int = 256,
                 keep_first: bool = True, tracker: Optional[StepTracker] = None, profiler=None,
                 error_log=None):
        if mode not in MODES:
            raise ValueError(f"unknown mode {mode!r}; choose from {MODES}")
        if mode in {"grid", "bucketize"} and not tables:
            raise ValueError(f"mode {mode!r} needs a codebook for layer {name}")
        if tables and None not in tables and tracker is None:
            raise ValueError("timestep-adaptive codebooks need a StepTracker")
        self.name, self.mode, self.tables, self.levels = name, mode, tables or {}, levels
        self.keep_first, self.tracker = keep_first, tracker
        self.profiler, self.error_log = profiler, error_log
        self.calls = 0

    def _table(self) -> LUTTable:
        return self.tables[None] if None in self.tables else self.tables[self.tracker.phase]

    # -- the quantization step ------------------------------------------------
    def quantize_probs(self, probs):
        torch = _torch()
        body = probs[..., 1:].float() if self.keep_first else probs.float()
        s = body.amax().clamp_min(torch.finfo(torch.float32).tiny)
        a = body / s
        if self.profiler is not None:
            key = self.name if self.tracker is None else phase_key(self.name, self.tracker.phase)
            self.profiler.record(key, a)
        if self.mode == "fp":
            q = a
        elif self.mode == "grid":
            q = self._table().grid(a)
        elif self.mode == "bucketize":
            q = self._table().bucketize(a)
        elif self.mode == "log2":
            q = log2_quant(a, self.levels)
        else:
            q = uniform_quant(a, self.levels)
        if self.error_log is not None:
            self.error_log.record(self.name, a * s, q * s)
        self.calls += 1
        if self.mode == "fp":
            return probs
        out = probs.clone()
        if self.keep_first:
            out[..., 1:] = (q * s).to(probs.dtype)
        else:
            out[...] = (q * s).to(probs.dtype)
        return out

    # -- the standard diffusers attention body --------------------------------
    def __call__(self, attn, hidden_states, encoder_hidden_states=None, attention_mask=None,
                 temb=None, *args, **kwargs):
        torch = _torch()
        residual = hidden_states
        if attn.spatial_norm is not None:
            hidden_states = attn.spatial_norm(hidden_states, temb)
        input_ndim = hidden_states.ndim
        if input_ndim == 4:
            b, c, h, w = hidden_states.shape
            hidden_states = hidden_states.view(b, c, h * w).transpose(1, 2)
        batch_size, seq_len, _ = (hidden_states.shape if encoder_hidden_states is None
                                  else encoder_hidden_states.shape)
        attention_mask = attn.prepare_attention_mask(attention_mask, seq_len, batch_size)
        if attn.group_norm is not None:
            hidden_states = attn.group_norm(hidden_states.transpose(1, 2)).transpose(1, 2)
        query = attn.to_q(hidden_states)
        if encoder_hidden_states is None:
            encoder_hidden_states = hidden_states
        elif attn.norm_cross:
            encoder_hidden_states = attn.norm_encoder_hidden_states(encoder_hidden_states)
        key = attn.to_k(encoder_hidden_states)
        value = attn.to_v(encoder_hidden_states)
        query = attn.head_to_batch_dim(query)
        key = attn.head_to_batch_dim(key)
        value = attn.head_to_batch_dim(value)

        probs = attn.get_attention_scores(query, key, attention_mask)
        probs = self.quantize_probs(probs)
        hidden_states = torch.bmm(probs, value)

        hidden_states = attn.batch_to_head_dim(hidden_states)
        hidden_states = attn.to_out[0](hidden_states)
        hidden_states = attn.to_out[1](hidden_states)
        if input_ndim == 4:
            hidden_states = hidden_states.transpose(-1, -2).reshape(b, c, h, w)
        if attn.residual_connection:
            hidden_states = hidden_states + residual
        return hidden_states / attn.rescale_output_factor


# ----------------------------------------------------------------------- installation
def layer_key(name: str) -> str:
    """Canonical codebook key of an attention module.

    Strips a trailing ``.processor`` (diffusers processor keys) and a leading
    ``model.`` (wrapped U-Nets such as DGQ's ``QuantModel``), so the same
    codebook file serves both weight/activation back-ends.
    """
    key = name[: -len(".processor")] if name.endswith(".processor") else name
    return key[len("model."):] if key.startswith("model.") else key


def attention_names(unet, kind: str = "cross") -> list:
    """Processor keys of the cross-attention (``attn2``) or self-attention (``attn1``) modules."""
    tag = {"cross": ".attn2.", "self": ".attn1."}[kind]
    return [k for k in unet.attn_processors.keys() if tag in k]


def short_name(key: str) -> str:
    """Compact layer label, e.g. ``down_blocks.0.attentions.1.transformer_blocks.0.attn2`` -> ``D0.A1.T0.attn2``."""
    parts = layer_key(key).split(".")
    out, i = [], 0
    while i < len(parts):
        p = parts[i]
        if p in {"down_blocks", "up_blocks"}:
            out.append(("D" if p == "down_blocks" else "U") + parts[i + 1])
            i += 2
        elif p == "mid_block":
            out.append("Mid")
            i += 1
        elif p == "attentions":
            if out and out[-1] != "Mid":
                out.append("A" + parts[i + 1])
            i += 2
        elif p == "transformer_blocks":
            out.append("T" + parts[i + 1])
            i += 2
        else:
            out.append(p)
            i += 1
    return ".".join(out)


def split_codebooks(books: dict) -> tuple[dict, bool]:
    """``{layer: {phase or None: levels}}`` from a codebook file, and whether it is phase-keyed."""
    out: dict = {}
    phased = False
    for k, v in books.items():
        if "@" in k:
            layer, phase = k.rsplit("@", 1)
            if phase not in PHASES:
                raise KeyError(f"unknown phase {phase!r} in codebook key {k!r}")
            phased = True
        else:
            layer, phase = k, None
        out.setdefault(layer_key(layer), {})[phase] = v
    return out, phased


def install(pipe, mode: str = "grid", codebooks: Optional[dict] = None, entries: int = 4096,
            levels: int = 256, self_attention: bool = False, tracker: Optional[StepTracker] = None,
            profiler=None, error_log=None) -> int:
    """Install score quantizers on the attention modules of a U-Net; return the count replaced.

    Cross-attention modules are always replaced; self-attention modules too
    when ``self_attention`` is set (they then need codebooks as well in the
    ``grid`` and ``bucketize`` modes).  A timestep-adaptive codebook file
    (keys ``<layer>@<phase>``) needs ``tracker``, attached to the denoiser.
    """
    denoiser = getattr(pipe, "unet", None)
    if denoiser is None:  # SD3 / FLUX.1: joint attention only
        return 0
    names = attention_names(denoiser, "cross") + (attention_names(denoiser, "self") if self_attention else [])
    books, phased = split_codebooks(codebooks or {})
    if mode in {"grid", "bucketize"}:
        missing = [n for n in names if layer_key(n) not in books]
        if missing:
            raise KeyError(f"no codebook for {len(missing)} of {len(names)} layers, e.g. {layer_key(missing[0])}")
        wrong = {n for n in names if any(np.asarray(v).size != levels for v in books[layer_key(n)].values())}
        if wrong:
            raise ValueError(f"codebooks do not have {levels} levels (e.g. {layer_key(next(iter(wrong)))})")
    if phased and tracker is None:
        raise ValueError("timestep-adaptive codebooks need a StepTracker attached to the denoiser")
    device = denoiser.device
    procs = dict(denoiser.attn_processors)
    for n in names:
        tables = ({p: LUTTable(v, entries, device=device) for p, v in books[layer_key(n)].items()}
                  if mode in {"grid", "bucketize"} else None)
        procs[n] = LUTAttnProcessor(layer_key(n), mode, tables, levels, keep_first=".attn2." in n,
                                    tracker=tracker, profiler=profiler, error_log=error_log)
    denoiser.set_attn_processor(procs)
    return len(names)


class MeasureProcessor(LUTAttnProcessor):
    """Leaves the scores in full precision and logs the error every quantizer would make.

    For each call, the normalized scores are quantized with every rule in
    ``logs`` (``"uniform"``, ``"log2"``, ``"grid"``) and the squared error of
    each, in probability units, goes to that rule's :class:`~uglut.profiling.ErrorLog`.
    The trajectory is the FP16 one, so all rules are measured on identical
    scores.
    """

    def __init__(self, name: str, table: Optional[LUTTable], levels: int, logs: dict):
        super().__init__(name, "fp", levels=levels)
        self.table, self.logs = table, logs

    def quantize_probs(self, probs):
        torch = _torch()
        body = probs[..., 1:].float()
        s = body.amax().clamp_min(torch.finfo(torch.float32).tiny)
        a = body / s
        for rule, log in self.logs.items():
            if rule == "uniform":
                q = uniform_quant(a, self.levels)
            elif rule == "log2":
                q = log2_quant(a, self.levels)
            elif rule == "grid":
                q = self.table.grid(a)
            else:
                raise ValueError(rule)
            log.record(self.name, body, q * s)
        self.calls += 1
        return probs


def install_measurement(pipe, logs: dict, codebooks: Optional[dict] = None, levels: int = 256,
                        entries: int = 4096) -> int:
    """Install :class:`MeasureProcessor` on every cross-attention module; return the count."""
    denoiser = pipe.unet
    books, _ = split_codebooks(codebooks or {})
    procs = dict(denoiser.attn_processors)
    names = attention_names(denoiser, "cross")
    for n in names:
        table = None
        if "grid" in logs:
            lv = books[layer_key(n)][None]
            if np.asarray(lv).size != levels:
                raise ValueError(f"codebook of {layer_key(n)} does not have {levels} levels")
            table = LUTTable(lv, entries, device=denoiser.device)
        procs[n] = MeasureProcessor(layer_key(n), table, levels, logs)
    denoiser.set_attn_processor(procs)
    return len(names)


def lut_processors(pipe) -> list:
    den = getattr(pipe, "unet", None)
    return [] if den is None else [p for p in den.attn_processors.values() if isinstance(p, LUTAttnProcessor)]


def calls_per_step(pipe, steps: int) -> float:
    ps = lut_processors(pipe)
    return math.nan if not ps else ps[0].calls / max(steps, 1)
