"""UG-LUT: uniform-grid lookup-table quantization of cross-attention scores.

UG-LUT replaces the fixed logarithmic cross-attention score quantizer of
low-bit text-to-image diffusion models with a per-layer Lloyd-Max codebook
fitted to the empirical distribution of post-softmax cross-attention scores.
Each codebook is compiled into a uniform 4,096-entry lookup grid so that a
score is assigned to its level in O(1) time at inference.

Modules
-------
Numerical core (NumPy / SciPy only)
    codebook     Lloyd-Max fitting (uniform initialization, empty-cell re-seeding)
    grid         compilation of a codebook into a uniform lookup grid
    quantizers   the uniform, log2 and Lloyd-Max level placements
    stats        paired / Welch t tests, sign test, Clopper-Pearson, minimum detectable difference
    records      run records, provenance and the results ledger
    report       the paper's tables, rendered from the ledger
    bundle       SHA-256-manifested archive of the run records

Diffusion pipeline (PyTorch / diffusers, imported lazily)
    attention    score-quantizing attention processors for diffusers U-Nets
    profiling    calibration score sampler and score-error log
    pipeline     models, weight/activation back-ends, seeded generation
    data         prompt protocols and the FID reference set
    metrics      FID, IS (CLIP ViT-B/32), CLIP score (ViT-L/14)
    cli          the ``uglut-*`` command-line tools
    integrations.dgq   UG-LUT inside the official DGQ quantized U-Net
"""

__version__ = "1.0.0"
