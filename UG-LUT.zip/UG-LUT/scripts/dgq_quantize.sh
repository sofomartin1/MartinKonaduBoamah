#!/usr/bin/env bash
# Merged DGQ weight + activation checkpoint for one W/A/score setting.
#
#   scripts/dgq_quantize.sh MODEL W A [L]      MODEL sd14 | sdxl, W 4 | 8, A 6 | 8, L score levels (default 256)
#
# writes checkpoints/dgq/<MODEL>_w<W>a<A>_s<L>.pth_merged, the file that
# `uglut-generate --backend dgq --dgq-ckpt` and scripts/run_experiments.sh use.
#
# Steps, all with DGQ's own code (third_party/DGQ, pinned by scripts/setup_dgq.sh):
#   1. weight quantization, once per MODEL and W: channel-wise weights (MSE-searched
#      initial ranges) refined by block reconstruction with learned rounding
#      (BRECQ + AdaRound; DGQ's src/quantize_weight.py with --no_recon False --fast False);
#   2. activation calibration: group-wise activations (8 groups), the time-aware
#      activation quantizer, and the logarithmic real-time start-peak score quantizer
#      at log2(L) bits (--softmax_a_bit), i.e. the score precision is set by L and
#      not by the activation bit-width A;
#   3. DGQ's results/merge.py.
# Both calibration steps use the 64 calibration captions of this repository
# (data/prompts/coco_calib64.txt), passed to DGQ as a COCO-format caption file.
#
# Run inside the uglut-dgq environment with DGQ on PYTHONPATH (source scripts/dgq_env.sh).
# Weight reconstruction of SDXL-Turbo needs a GPU with 80 GB; set DGQ_NO_RECON=True to
# use DGQ's min-max weights without reconstruction instead.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

MODEL=${1:?model: sd14 or sdxl}; W=${2:?weight bits}; A=${3:?activation bits}; L=${4:-256}
case $MODEL in sd14) TYPE=sd; STEPS=25 ;; sdxl) TYPE=sdxl; STEPS=4 ;; *) echo "model must be sd14 or sdxl" >&2; exit 2 ;; esac
SOFTMAX_BITS=$(python -c "import math,sys; b=round(math.log2($L)); sys.exit('L must be a power of two') if 2**b!=$L else print(b)")
NO_RECON=${DGQ_NO_RECON:-False}
DGQ="$ROOT/third_party/DGQ"
CKPTS="$ROOT/checkpoints/dgq"
WORK="$CKPTS/work/$MODEL"
mkdir -p "$WORK"
export DIFFUSERS_REWRITE=$TYPE

# calibration captions in the COCO caption-file format DGQ reads
CAPTIONS="$WORK/calibration_captions.json"
python - "$ROOT" "$CAPTIONS" <<'PY'
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / "src"))
from uglut.data import prompts_for
caps = prompts_for("coco_calib64")
json.dump({"annotations": [{"id": i, "image_id": i, "caption": c} for i, c in enumerate(caps)]},
          open(sys.argv[2], "w"))
PY

newest() { ls -t $1 2>/dev/null | head -1; }
cd "$DGQ"

# 1. weights (shared by every A and L)
WCKPT="$CKPTS/${MODEL}_w${W}.pth_weight_only"
if [[ ! -f $WCKPT ]]; then
  python src/quantize_weight.py --wq "$W" --cali_prompt_data_n 64 --coco_path "$CAPTIONS" \
         --cali_data_path "$WORK/cali_data_${STEPS}steps" --step_size "$STEPS" \
         --tib_recon False --no_recon "$NO_RECON" --fast False --outdir "$WORK/weight_w${W}" \
         2>&1 | tee "$WORK/weight_w${W}.log"
  cp "$(newest "$WORK/weight_w${W}/*/cali_ckpt.pth_weight_only")" "$WCKPT"
fi

# 2. activations and the score quantizer
OUT="$WORK/act_w${W}a${A}_s${L}"
python src/quantize_act.py --outdir "$OUT" --weight_only_ckpt "$WCKPT" \
       --wq "$W" --aq "$A" --softmax_a_bit "$SOFTMAX_BITS" \
       --time_aware_aqtizer True --t2i_log_quant True --t2i_real_time True --t2i_start_peak True \
       --group_num 8 --group_mode minmax --cali_prompt_data_n 64 --coco_path "$CAPTIONS" \
       --cali_data_path "$WORK/cali_data_${STEPS}steps" --step_size "$STEPS" \
       2>&1 | tee "$OUT.log"
ACKPT=$(newest "$OUT/*/cali_ckpt_activation_w${W}a${A}g8.pth")

# 3. merge
python results/merge.py "$WCKPT" "$ACKPT"
mv "${ACKPT}_merged" "$CKPTS/${MODEL}_w${W}a${A}_s${L}.pth_merged"
sha256sum "$CKPTS/${MODEL}_w${W}a${A}_s${L}.pth_merged" | tee -a "$CKPTS/SHA256SUMS"
