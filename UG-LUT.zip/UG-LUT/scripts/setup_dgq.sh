#!/usr/bin/env bash
# Clone DGQ at the commit used for the experiments and create its environment.
#
#   scripts/setup_dgq.sh                  clone into third_party/DGQ and create the conda env "uglut-dgq"
#   conda activate uglut-dgq
#   source scripts/dgq_env.sh             puts DGQ on PYTHONPATH (every new shell)
#
# The environment is DGQ's own stack (Python 3.9, PyTorch 2.2.2 + CUDA 11.8,
# DGQ's fork of diffusers 0.26) plus this package; see envs/environment-dgq.yml.
set -euo pipefail
cd "$(dirname "$0")/.."

DGQ_REPO=https://github.com/ugonfor/DGQ
DGQ_COMMIT=f449f6ad8052105c72e0bdf5a1cd05bbb98ae037
DEST=third_party/DGQ

if [[ ! -d $DEST/.git ]]; then
  git clone "$DGQ_REPO" "$DEST"
fi
git -C "$DEST" fetch --quiet origin
git -C "$DEST" checkout --quiet "$DGQ_COMMIT"
echo "DGQ at $(git -C "$DEST" rev-parse HEAD)"

if ! conda env list | grep -q '^uglut-dgq '; then
  conda env create -f envs/environment-dgq.yml
fi
echo "next: conda activate uglut-dgq && source scripts/dgq_env.sh"
