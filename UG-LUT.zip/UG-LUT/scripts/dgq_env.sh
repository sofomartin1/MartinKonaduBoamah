# Source this file (bash) inside the uglut-dgq environment: puts the DGQ
# checkout and its src/ folder on PYTHONPATH.
_uglut_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$_uglut_root/third_party/DGQ:$_uglut_root/third_party/DGQ/src${PYTHONPATH:+:$PYTHONPATH}"
unset _uglut_root
