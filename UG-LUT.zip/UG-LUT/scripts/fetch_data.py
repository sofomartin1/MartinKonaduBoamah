#!/usr/bin/env python3
"""Download the public datasets and write the prompt list of every protocol.

    python scripts/fetch_data.py                       # every prompt list
    python scripts/fetch_data.py --only coco_calib64 coco1k
    python scripts/fetch_data.py --reference           # also the COCO val2014 images (FID reference, 6.2 GB)

Writes ``<UGLUT_DATA>/prompts/<protocol>.txt`` (one prompt per line, UTF-8,
in generation order) for every protocol in ``uglut.data.PROTOCOLS`` and a
``SHA256SUMS`` file, so that a later run can confirm it used byte-identical
prompt lists (``cd data/prompts && sha256sum -c SHA256SUMS``).
"""

from __future__ import annotations

import argparse
import hashlib

from uglut import data


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", nargs="*", metavar="PROTOCOL", help="subset of protocols")
    ap.add_argument("--reference", action="store_true", help="download and unpack COCO val2014 images")
    args = ap.parse_args()

    unknown = sorted(set(args.only or []) - set(data.PROTOCOLS))
    if unknown:
        ap.error(f"unknown protocol(s) {unknown}; choose from {sorted(data.PROTOCOLS)}")

    out = data.data_root() / "prompts"
    out.mkdir(parents=True, exist_ok=True)
    sums = {}
    sums_file = out / "SHA256SUMS"
    if sums_file.exists():
        for line in sums_file.read_text().splitlines():
            h, name = line.split(maxsplit=1)
            sums[name] = h
    for proto in args.only or data.PROTOCOLS:
        prompts = data.sample(proto)
        path = out / f"{proto}.txt"
        data.write_prompts(prompts, path)
        h = hashlib.sha256(path.read_bytes()).hexdigest()
        sums[path.name] = h
        sums_file.write_text("".join(f"{v}  {k}\n" for k, v in sorted(sums.items())))
        print(f"{proto:16s} {len(prompts):6d} prompts  sha256 {h[:16]}")
    if args.reference:
        print("reference images:", data.coco_reference_images())


if __name__ == "__main__":
    main()
