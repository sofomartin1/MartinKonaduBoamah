#!/usr/bin/env bash
# Experiment driver.  Every table of the paper is produced by one sub-command;
# `report` renders all tables from the records the runs leave behind.
#
#   scripts/run_experiments.sh calibrate               codebooks of every table (FP16 profiling)
#   scripts/run_experiments.sh table1                  W8A8: SD v1.4 30K (bootstrap), SDXL-Turbo, SD3, FLUX.1 1K
#   scripts/run_experiments.sh table2                  = the SD v1.4 30K block of table1
#   scripts/run_experiments.sh table3                  SD v1.4 1K, W8A8 and W8A6, seeds 42 / 137 / 2024
#   scripts/run_experiments.sh table4                  SD v1.4 1K W8A8 with Q-Diffusion and TFMQ-DM (BASELINES)
#   scripts/run_experiments.sh table5                  W8A8/W8A6/W4A8/W4A6 on both U-Nets; 64 and 16 score levels
#   scripts/run_experiments.sh table6                  per-layer attention-score MSE
#   scripts/run_experiments.sh table7                  latency, 30 timed runs per configuration
#   scripts/run_experiments.sh table8                  ablations on 200 captions and the codebook-size study
#   scripts/run_experiments.sh report                  ledger, tables and the record bundle
#   scripts/run_experiments.sh run MODEL PROTOCOL METHOD [--wbits W --abits A --levels L --calib C --variant V --seed S]
#
# Environment variables
#   RUNS        output root                                                       default runs
#   BACKEND     weight/activation back-end of the U-Nets: dgq or reference         default dgq
#   DGQ_CKPTS   merged DGQ checkpoints, <model>_w<W>a<A>_s<L>.pth_merged
#               (made by scripts/dgq_quantize.sh)                                 default checkpoints/dgq
#   BASELINES   folder with <method>/ PNGs of Q-Diffusion and TFMQ-DM (table4)   default baselines
#   SHARDS, SHARD   split generation over GPUs: run every shard with EVAL=0, then
#               the same command once with ONLY_EVAL=1                            default 1, 0
#
# Each run folder holds images/, one generation record per shard, metrics.json
# and logs/.  The U-Net rows with BACKEND=dgq run in the DGQ environment, the
# SD3 / FLUX.1 rows in the DiT environment (see README, "Environments").
set -euo pipefail
cd "$(dirname "$0")/.."

RUNS=${RUNS:-runs}
BACKEND=${BACKEND:-dgq}
DGQ_CKPTS=${DGQ_CKPTS:-checkpoints/dgq}
BASELINES=${BASELINES:-baselines}
SHARDS=${SHARDS:-1}
SHARD=${SHARD:-0}
SEED=42; WB=8; AB=8; LEVELS=256; CALIB=64; VARIANT=standard
SEEDS=(42 137 2024)

what=${1:?usage: see the header of this script}; shift || true
pos=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --seed)    SEED=$2;    shift 2 ;;
    --wbits)   WB=$2;      shift 2 ;;
    --abits)   AB=$2;      shift 2 ;;
    --levels)  LEVELS=$2;  shift 2 ;;
    --calib)   CALIB=$2;   shift 2 ;;
    --variant) VARIANT=$2; shift 2 ;;
    *) pos+=("$1"); shift ;;
  esac
done

# ------------------------------------------------------------------ helpers
is_unet() { [[ $1 == sd14 || $1 == sdxl ]]; }

logged() {  # logfile command... : run a command, appending stdout and stderr to logfile
  local log=$1; shift
  mkdir -p "$(dirname "$log")"
  echo "# $(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> "$log"
  "$@" 2>&1 | tee -a "$log"
}

snapshot_env() {  # environment of this invocation, kept with the records
  local d="$RUNS/env" name
  name="$(python -c 'import sys; print(sys.prefix.rstrip("/").split("/")[-1])')-$(hostname -s)"
  mkdir -p "$d"
  { echo "python $(python -V 2>&1)"; echo "repository $(git rev-parse HEAD 2>/dev/null || echo unknown)"
    python -m pip freeze; command -v nvidia-smi > /dev/null && nvidia-smi -q | head -40; } > "$d/$name.txt" 2>&1 || true
}

codebooks() {  # model -> path of the codebook file (fitted on first use)
  local model=$1 out="$RUNS/codebooks/${1}_L${LEVELS}_c${CALIB}_${VARIANT}.npz"
  if [[ ! -f $out ]]; then
    logged "$RUNS/codebooks/logs/$(basename "$out" .npz).log" \
      uglut-calibrate --model "$model" --protocol "coco_calib${CALIB}" --levels "$LEVELS" \
                      --variant "$VARIANT" --out "$out" >&2
  fi
  echo "$out"
}

run_dir() {  # model protocol method -> output folder
  local model=$1 proto=$2 method=$3 tag
  if [[ $method == fp16 ]]; then tag=fp16
  elif is_unet "$model" && [[ $method == uglut || $method == bucketize ]]; then tag="w${WB}a${AB}_s${LEVELS}_c${CALIB}"
  elif is_unet "$model"; then tag="w${WB}a${AB}_s${LEVELS}"
  else tag="w${WB}a${AB}"; fi
  [[ $VARIANT != standard && ( $method == uglut || $method == bucketize ) ]] && tag="${tag}_${VARIANT}"
  echo "$RUNS/$model/$proto/$tag/seed$SEED/$method"
}

setting_args() {  # model method -> quantization arguments of uglut-generate / uglut-latency
  local model=$1 method=$2
  [[ $method == fp16 ]] && return 0
  if is_unet "$model" && [[ $BACKEND == dgq ]]; then
    echo --backend dgq --dgq-ckpt "$DGQ_CKPTS/${model}_w${WB}a${AB}_s${LEVELS}.pth_merged"
  else
    echo --backend reference
  fi
  echo --wbits "$WB" --abits "$AB" --score-levels "$LEVELS" --variant "$VARIANT"
  if is_unet "$model" && [[ $method == uglut || $method == bucketize ]]; then
    echo --codebooks "$(codebooks "$model")"
  fi
}

n_prompts() { python -c "from uglut.data import PROTOCOLS; print(PROTOCOLS['$1'])"; }

generate() {  # model protocol method out
  [[ ${ONLY_EVAL:-0} == 1 ]] && return 0
  local model=$1 proto=$2 method=$3 out=$4 n per
  n=$(n_prompts "$proto"); per=$(( (n + SHARDS - 1) / SHARDS ))
  # shellcheck disable=SC2046
  logged "$out/logs/generate_$(printf %05d $(( SHARD * per ))).log" \
    uglut-generate --model "$model" --protocol "$proto" --method "$method" --seed "$SEED" \
                   --start $(( SHARD * per )) --count "$per" --out "$out" $(setting_args "$model" "$method")
}

evaluate() {  # out protocol [extra uglut-eval arguments]
  [[ ${EVAL:-1} == 1 ]] || return 0
  local out=$1 proto=$2; shift 2
  logged "$out/logs/eval.log" uglut-eval all --images "$out/images" --protocol "$proto" --out "$out/metrics.json" "$@"
}

run() {  # model protocol method [extra uglut-eval arguments]
  local model=$1 proto=$2 method=$3 out; shift 3
  out=$(run_dir "$model" "$proto" "$method")
  generate "$model" "$proto" "$method" "$out"
  evaluate "$out" "$proto" "$@"
}

latency() {  # model method
  local model=$1 method=$2 out tag
  tag=$([[ $method == fp16 ]] && echo fp16 || echo "w${WB}a${AB}_s${LEVELS}")
  out="$RUNS/latency/$model/$tag/$method.json"
  # shellcheck disable=SC2046
  logged "$RUNS/latency/logs/${model}_${tag}_${method}.log" \
    uglut-latency --model "$model" --method "$method" --runs 30 --warmup 5 --out "$out" $(setting_args "$model" "$method")
}

# ------------------------------------------------------------- experiments
snapshot_env
case "$what" in
  run)
    run "${pos[0]:?model}" "${pos[1]:?protocol}" "${pos[2]:?method}" ;;

  calibrate)
    codebooks sd14 > /dev/null; codebooks sdxl > /dev/null
    for L in 64 16; do LEVELS=$L codebooks sd14 > /dev/null; done
    for C in 4 8 16 32; do CALIB=$C codebooks sd14 > /dev/null; done
    for V in tsadaptive selfcross; do CALIB=8 VARIANT=$V codebooks sd14 > /dev/null; done
    for L in 16 64 1024; do CALIB=8 LEVELS=$L codebooks sd14 > /dev/null; done ;;

  table1|table2)
    for m in fp16 dgq uglut; do run sd14 coco30k "$m" --bootstrap 1000; done
    [[ $what == table2 ]] && exit 0
    for m in fp16 dgq uglut; do run sdxl coco1k "$m"; done
    for model in sd3 flux; do
      for m in fp16 dgq uglut; do run "$model" coco1k "$m"; done
      [[ ${ONLY_EVAL:-0} == 1 || $SHARDS == 1 ]] && \
        uglut-digest compare "$(run_dir "$model" coco1k dgq)" "$(run_dir "$model" coco1k uglut)" \
                     --out "$RUNS/$model/coco1k/digest_w${WB}a${AB}_seed${SEED}.json"
    done ;;

  table3)
    for s in "${SEEDS[@]}"; do
      for wa in "8 8" "8 6"; do
        read -r w a <<< "$wa"
        for m in dgq uglut; do SEED=$s WB=$w AB=$a run sd14 coco1k "$m"; done
      done
    done ;;

  table4)
    for m in fp16 dgq uglut; do run sd14 coco1k "$m"; done
    for m in qdiffusion tfmqdm; do
      [[ -d $BASELINES/$m ]] || { echo "no $BASELINES/$m: generate it with the official code (README)" >&2; continue; }
      out=$(run_dir sd14 coco1k "$m")
      uglut-digest hash "$BASELINES/$m" --model sd14 --protocol coco1k --method "$m" --wbits 8 --abits 8 \
                   --seed "$SEED" --source "$(cat "$BASELINES/$m/SOURCE" 2>/dev/null || echo "$m")" --out "$out"
      mkdir -p "$out/images" && cp -n "$BASELINES/$m"/*.png "$out/images/"
      evaluate "$out" coco1k
    done ;;

  table5)
    for model in sd14 sdxl; do
      for wa in "8 8" "8 6" "4 8" "4 6"; do
        read -r w a <<< "$wa"
        for m in dgq uglut; do WB=$w AB=$a run "$model" coco1k "$m"; done
      done
    done
    # reduced score precision for both methods, at W8A8
    for L in 64 16; do for m in dgq uglut; do WB=8 AB=8 LEVELS=$L run sd14 coco1k "$m"; done; done ;;

  table6)
    cb=$(codebooks sd14)
    logged "$RUNS/intrinsic/logs/sd14_L${LEVELS}.log" \
      uglut-intrinsic --model sd14 --protocol coco_calib64 --codebooks "$cb" --levels "$LEVELS" \
                      --out "$RUNS/intrinsic/sd14_L${LEVELS}.json" ;;

  table7)
    for m in fp16 dgq uglut bucketize; do latency sd14 "$m"; done
    for model in sdxl sd3 flux; do for m in dgq uglut; do latency "$model" "$m"; done; done ;;

  table8)
    CALIB=8
    run sd14 coco200 uglut
    for V in tsadaptive selfcross; do VARIANT=$V run sd14 coco200 uglut; done
    for C in 4 16 32 64; do CALIB=$C run sd14 coco200 uglut; done
    for L in 16 64 1024; do LEVELS=$L run sd14 coco200 uglut; done
    scores="$RUNS/codebooks/sd14_L256_c64_standard_scores.npz"
    [[ -f $scores ]] || CALIB=64 codebooks sd14 > /dev/null
    logged "$RUNS/sizes/logs/sizes.log" uglut-sizes --scores "$scores" --out "$RUNS/sizes/sd14_calibration.json"
    logged "$RUNS/sizes/logs/sizes.log" uglut-sizes --scores "$scores" --source moment-matched \
                                                    --out "$RUNS/sizes/sd14_moment_matched.json" ;;

  report)
    uglut-report "$RUNS" --backend "$BACKEND"
    uglut-bundle create "$RUNS" --out "$RUNS/uglut-records-$(date -u +%Y%m%d).tar.gz" ;;

  *) echo "unknown experiment '$what' (see the header of $0)" >&2; exit 2 ;;
esac
