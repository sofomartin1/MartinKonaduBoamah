# UG-LUT: Lookup-Table-Based Cross-Attention Quantization for Low-Bit Diffusion Models

[![Python](https://img.shields.io/badge/python-3.9%2B-blue.svg)](https://www.python.org/)
[![License: Apache 2.0](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)

Code for the paper **Enhancing Text-Image Alignment in Low-Bit Diffusion Models through Lookup-Table-Based Cross-Attention Quantization** (Prince Clement Addo and Martin Konadu Boamah).

Low-bit text-to-image diffusion models quantize the post-softmax cross-attention probabilities that bind image regions to words. These scores are heavy-tailed and concentrated near zero. **UG-LUT** (uniform-grid lookup table) replaces the fixed logarithmic score quantizer of [DGQ](https://github.com/ugonfor/DGQ) with a **per-layer Lloyd-Max codebook** fitted to the empirical score distribution, and compiles each codebook into a **4,096-entry uniform grid** so that every score is quantized in O(1). DGQ's weight and activation quantization is kept unchanged, so a comparison between the two is a comparison of the score quantizer alone. The evaluation covers two U-Nets (Stable Diffusion v1.4, SDXL-Turbo) and two diffusion transformers (Stable Diffusion 3 Medium, FLUX.1-schnell).

---

## Contents

1. [Method](#1-method)
2. [Repository structure](#2-repository-structure)
3. [Environments and installation](#3-environments-and-installation)
4. [Datasets](#4-datasets)
5. [Models](#5-models)
6. [Weight and activation quantization with DGQ](#6-weight-and-activation-quantization-with-dgq)
7. [Running the experiments](#7-running-the-experiments)
8. [Baselines: Q-Diffusion and TFMQ-DM](#8-baselines-q-diffusion-and-tfmq-dm)
9. [Metrics and statistics](#9-metrics-and-statistics)
10. [Results records](#10-results-records)
11. [Reproducibility](#11-reproducibility)
12. [Tests](#12-tests)
13. [Troubleshooting](#13-troubleshooting)
14. [Citation](#14-citation)
15. [License and acknowledgements](#15-license-and-acknowledgements)

---

## 1. Method

For every cross-attention layer *l* (the `attn2` modules: 16 in SD v1.4, 70 in SDXL-Turbo), following Algorithm 1 of the paper:

```
Phase 1 - profiling (FP16 model, 64 calibration captions, every denoising step)
  x   <- A[..., 1:] / max(A[..., 1:])                 <start> column dropped, per-call normalization
  X_l <- X_l ∪ subsample(x)                           seeded; 200,000 scores per layer for the fit

Phase 2 - codebook fit and grid compilation
  c   <- L levels spaced uniformly on [0, max X_l]    L = 256 (8-bit scores)
  repeat at most 50 times:
      assign every score to its nearest level          (Eq. 5)
      move every level to the mean of its scores       (Eq. 6)
      every empty cell: split the most populous cell at its median
      stop when max|c_t - c_{t-1}| / max|c_{t-1}| < 1e-4
  G_l[j] <- index of the level nearest to j/(M-1),  j = 0..M-1,  M = 4,096   (Eq. 7)

Inference (every cross-attention call)
  s         <- max(A[..., 1:])
  Â[..., 1:] <- c[ G_l[ round(A[..., 1:] / s · (M-1)) ] ] · s                (Eq. 8)
  Â[..., 0]  <- A[..., 0]                             <start> column in full precision
```

Why re-seeding: the scores crowd into the first few percent of their range, so a uniform start leaves many upper cells with no data, and the textbook centroid update then takes the mean of an empty set (NaN). Re-seeding keeps all levels populated at every codebook size from 16 to 1,024 levels.

**Score precision.** The attention-score quantizer is a stage separate from the linear-layer activations. Its number of levels, `--score-levels` (default 256), applies to **both** methods: DGQ's logarithmic quantizer runs at `log2(L)` bits and UG-LUT's codebook has `L` levels. At W8A6, for example, both methods quantize the scores at 256 levels while the activations use 6 bits; the reduced-precision rows use 64 or 16 levels for both.

**Ablation variants.** `standard` (one codebook per cross-attention layer), `tsadaptive` (one codebook per layer and denoising phase: early for timesteps *t* ≥ 2T/3, mid for T/3 ≤ *t* < 2T/3, late below, with T = 1,000; with 25 DDIM steps this is 8/8/9 steps), and `selfcross` (codebooks on the self-attention `attn1` layers as well, all columns quantized).

**Architectural boundary.** SD3 and FLUX.1 compute joint attention over the concatenated image and text tokens, so no separable cross-attention tensor exists: both score quantizers install nothing (`install` returns 0) and the DGQ and UG-LUT pipelines are bit-identical, which the experiments verify image by image with SHA-256 digests.

| Component | Code |
|---|---|
| Lloyd-Max fitting, empty-cell re-seeding | [`src/uglut/codebook.py`](src/uglut/codebook.py) |
| Uniform-grid compilation, table memory | [`src/uglut/grid.py`](src/uglut/grid.py) |
| Attention processors, phase tracking, score-error measurement | [`src/uglut/attention.py`](src/uglut/attention.py) |
| UG-LUT inside DGQ's quantized U-Net | [`src/uglut/integrations/dgq.py`](src/uglut/integrations/dgq.py) |
| Uniform, log₂ and Lloyd-Max level placements (Table 6) | [`src/uglut/quantizers.py`](src/uglut/quantizers.py) |

---

## 2. Repository structure

```
UG-LUT/
├── src/uglut/
│   ├── codebook.py          Lloyd-Max fitting (uniform start, re-seeding), codebook I/O
│   ├── grid.py              uniform-grid compilation, compilation error, table memory
│   ├── quantizers.py        uniform / log2 / Lloyd-Max placements, moment-matched reconstruction
│   ├── attention.py         score-quantizing attention processors for diffusers U-Nets
│   ├── profiling.py         calibration score sampler, per-layer score-error log
│   ├── pipeline.py          models, weight/activation back-ends, method assembly, seeded generation
│   ├── integrations/dgq.py  DGQ back-end: score precision, LUT installation, pipeline loader
│   ├── data.py              prompt protocols and the FID reference set
│   ├── metrics.py           FID (clean-fid), IS (CLIP ViT-B/32), CLIP score (ViT-L/14)
│   ├── stats.py             paired / Welch t, sign test, Clopper-Pearson, bootstrap, MDD
│   ├── records.py           run records, provenance, results ledger
│   ├── report.py            Tables 1-8 rendered from the ledger
│   ├── bundle.py            record archive with a SHA-256 manifest
│   └── cli.py               the uglut-* command-line tools
├── scripts/
│   ├── fetch_data.py        prompt lists of every protocol (+ SHA256SUMS), COCO reference images
│   ├── setup_dgq.sh         DGQ at the pinned commit + its environment
│   ├── dgq_env.sh           puts DGQ on PYTHONPATH
│   ├── dgq_quantize.sh      merged DGQ checkpoint for one W/A/score setting
│   └── run_experiments.sh   one sub-command per table of the paper
├── notebooks/uglut_walkthrough.ipynb
├── tests/                   pytest suite (CPU); DGQ tests run against DGQ's own modules
├── envs/
│   ├── requirements-dit.txt  SD3 / FLUX.1 environment
│   └── environment-dgq.yml   DGQ back-end environment
├── requirements.txt          main environment
├── pyproject.toml            package metadata and the uglut-* entry points
├── CITATION.cff  LICENSE  NOTICE  Makefile
└── .github/workflows/tests.yml   CI: core, main, DiT and DGQ environments
```

Command-line tools (each writes a JSON record next to its outputs, see [§10](#10-results-records)):

| Tool | Purpose |
|---|---|
| `uglut-calibrate` | profile attention scores of the FP16 model and fit per-layer codebooks |
| `uglut-generate` | generate the images of a prompt protocol for one method and setting |
| `uglut-eval` | FID / IS / CLIP score of a folder of images |
| `uglut-intrinsic` | per-layer attention-score MSE of the uniform, log₂ and Lloyd-Max quantizers (Table 6) |
| `uglut-sizes` | codebook-size study: re-seeded and empty cells, MSE against log₂ (Table 8) |
| `uglut-latency` | end-to-end latency per image over repeated runs (Table 7) |
| `uglut-digest` | compare per-image digests of two runs; hash images generated by other code bases |
| `uglut-report` | results ledger and Tables 1–8 |
| `uglut-bundle` | archive of all records with a SHA-256 manifest; verification |

---

## 3. Environments and installation

The experiments use three environments, because their pinned software stacks are mutually incompatible:

| Environment | Used for | Stack | Install |
|---|---|---|---|
| **main** | codebook calibration, Table 6, the reference back-end, evaluation, report, notebook | Python 3.9–3.11, PyTorch 2.4.0, diffusers 0.27.0 | [`requirements.txt`](requirements.txt) |
| **DiT** | SD3 and FLUX.1-schnell rows (Tables 1, 7) | PyTorch 2.4.0, diffusers 0.31.0 | [`envs/requirements-dit.txt`](envs/requirements-dit.txt) |
| **DGQ** | every SD v1.4 / SDXL-Turbo row with DGQ's weight/activation quantization; DGQ checkpoints | Python 3.9, PyTorch 2.2.2 (CUDA 11.8), DGQ's fork of diffusers 0.26 | [`envs/environment-dgq.yml`](envs/environment-dgq.yml) |

diffusers 0.27.0 has no SD3 or FLUX.1 pipeline (added in 0.29 and 0.30), and DGQ's rewritten U-Net needs DGQ's own fork of diffusers 0.26, hence the separate environments. All three are exercised by CI (CPU) with the versions pinned in the files above.

```bash
git clone https://github.com/<organisation>/UG-LUT.git && cd UG-LUT

# main
python -m venv .venv && source .venv/bin/activate
pip install torch==2.4.0 torchvision==0.19.0 --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt && pip install -e . --no-deps

# DiT
python -m venv .venv-dit && source .venv-dit/bin/activate
pip install torch==2.4.0 torchvision==0.19.0 --index-url https://download.pytorch.org/whl/cu121
pip install -r envs/requirements-dit.txt && pip install -e . --no-deps

# DGQ (conda): clones DGQ at the pinned commit into third_party/DGQ, then creates "uglut-dgq"
scripts/setup_dgq.sh
conda activate uglut-dgq && source scripts/dgq_env.sh
```

`pip install -e .` alone installs the NumPy/SciPy core (codebooks, grid, statistics, records, report). Log in to the Hugging Face Hub (`huggingface-cli login`) before the first model download; SD3 Medium is gated.

---

## 4. Datasets

All downloads go to `$UGLUT_DATA` (default `./data`, git-ignored). `scripts/fetch_data.py` writes the prompt list of every protocol to `data/prompts/<protocol>.txt` with a `SHA256SUMS` file; every tool reads these lists, and every record stores the SHA-256 of the prompt list it used.

```bash
python scripts/fetch_data.py               # all prompt lists
python scripts/fetch_data.py --reference   # also the 40,504 val2014 images (FID reference, 6.2 GB)
```

| Dataset | Content | Used for | Source | Licence |
|---|---|---|---|---|
| MS-COCO 2014 validation captions | 202,654 captions of 40,504 images (first caption per image is used) | calibration captions | [cocodataset.org](https://cocodataset.org/#download) · [annotations_trainval2014.zip](http://images.cocodataset.org/annotations/annotations_trainval2014.zip) (241 MB) | CC BY 4.0 (annotations) |
| MS-COCO 2014 validation images | 40,504 images | FID reference set | [val2014.zip](http://images.cocodataset.org/zips/val2014.zip) (6.2 GB) | Flickr terms of use |
| MS-COCO 30K caption list | 30,000 (image, caption) pairs of val2014, the benchmark of BK-SDM and DGQ | evaluation prompts | [metadata.csv](https://netspresso-research-code-release.s3.us-east-2.amazonaws.com/data/mscoco_val2014_30k/metadata.csv) (DGQ, `scripts/get_mscoco_files.sh`) | as MS-COCO |

Protocols ([`src/uglut/data.py`](src/uglut/data.py)):

| Protocol | Prompts | Definition | Used in |
|---|---|---|---|
| `coco30k` | 30,000 | the 30K list, in file order | Tables 1, 2 |
| `coco1k` | 1,000 | its first 1,000 captions | Tables 1, 3, 4, 5 |
| `coco200` | 200 | its first 200 captions | Table 8 |
| `coco_calib64` | 64 | seeded sample (seed 0) of first captions of val2014 images **outside** the 30K list | codebooks of Tables 1–7, Table 6, DGQ calibration |
| `coco_calib4/8/16/32` | 4–32 | the first 4, 8, 16, 32 of `coco_calib64` | Table 8 (8 is the ablation default) |

The evaluation lists are nested (200 ⊂ 1K ⊂ 30K), the calibration lists are nested (4 ⊂ 8 ⊂ … ⊂ 64), and no calibration caption belongs to an evaluated image.

---

## 5. Models

| Key | Model | Hub id | Steps | Guidance | Resolution | Licence |
|---|---|---|---|---|---|---|
| `sd14` | Stable Diffusion v1.4 | [`CompVis/stable-diffusion-v1-4`](https://huggingface.co/CompVis/stable-diffusion-v1-4) | 25 (DDIM) | 7.5 | 512 | CreativeML OpenRAIL-M |
| `sdxl` | SDXL-Turbo | [`stabilityai/sdxl-turbo`](https://huggingface.co/stabilityai/sdxl-turbo) | 4 | 0.0 | 512 | Stability AI Community |
| `sd3` | Stable Diffusion 3 Medium | [`stabilityai/stable-diffusion-3-medium-diffusers`](https://huggingface.co/stabilityai/stable-diffusion-3-medium-diffusers) | 28 | 7.0 | 1024 | Stability AI Community (gated) |
| `flux` | FLUX.1-schnell | [`black-forest-labs/FLUX.1-schnell`](https://huggingface.co/black-forest-labs/FLUX.1-schnell) | 4 | 0.0 | 1024 | Apache 2.0 |

The safety checker is disabled for every model and method, as in DGQ's evaluation code, so that no image is replaced by a blank one before the metrics are computed.

---

## 6. Weight and activation quantization with DGQ

The reported U-Net rows use the official DGQ implementation (`--backend dgq`): channel-wise weights refined by block reconstruction with learned rounding (BRECQ + AdaRound), DGQ's outlier-preserving group-wise activation quantizer (8 groups) with time-aware ranges, and DGQ's logarithmic, real-time, start-peak score quantizer. UG-LUT then replaces **only** `attn2.aqtizer_w` of every DGQ transformer block (`uglut.integrations.dgq.install_lut`).

DGQ's own scripts tie the score precision to the activation bit-width (`SOFTMAX_A_BIT=$A_BITS`). Here it is set from the score levels, for calibration and inference alike:

```bash
conda activate uglut-dgq && source scripts/dgq_env.sh
scripts/dgq_quantize.sh sd14 8 8 256     # -> checkpoints/dgq/sd14_w8a8_s256.pth_merged
scripts/dgq_quantize.sh sd14 8 6 256     # W8A6 with 256-level scores for both methods
scripts/dgq_quantize.sh sd14 8 8 64      # reduced score precision (Table 5)
```

| Checkpoints needed | Settings |
|---|---|
| Tables 1–5 | `sd14` and `sdxl` at `w8a8`, `w8a6`, `w4a8`, `w4a6` with `s256`; `sd14_w8a8_s64`, `sd14_w8a8_s16` |
| Table 8 (LUT size) | `sd14_w8a8_s16`, `_s64`, `_s256`, `_s1024` |

The script calibrates with the 64 calibration captions of this repository, stores the weight-only checkpoint once per model and weight bit-width, and appends the SHA-256 of every merged checkpoint to `checkpoints/dgq/SHA256SUMS`; each generation record also stores the SHA-256 of the checkpoint it loaded and the DGQ commit. Reconstruction of SDXL-Turbo weights needs an 80 GB GPU (`DGQ_NO_RECON=True` uses DGQ's min-max weights instead). With the DGQ back-end SD v1.4 samples with DDIM, and DGQ's time-aware ranges are indexed by `(1000 - t) // 40`, one range set per DDIM step.

The `reference` back-end (`--backend reference`) is the linear-layer hook of Algorithm 1: per-output-channel symmetric min-max weights on every `nn.Linear` and `nn.Conv2d` and a per-tensor symmetric min-max activation hook on every `nn.Linear`, calibrated on the calibration captions. It runs on every model and is the back-end of the SD3 and FLUX.1 rows, where DGQ does not apply. Naive symmetric W4 collapses on SD v1.4, so the W4 rows use the DGQ back-end.

---

## 7. Running the experiments

[`scripts/run_experiments.sh`](scripts/run_experiments.sh) has one sub-command per table. Each run writes `images/`, one generation record per shard, `metrics.json` and `logs/` to `runs/<model>/<protocol>/<setting>/seed<S>/<method>/`; codebooks go to `runs/codebooks/`.

| Paper | Command | Environment | What runs |
|---|---|---|---|
| — | `scripts/run_experiments.sh calibrate` | main or DGQ | all codebooks (FP16 profiling on `coco_calib*`) |
| Tables 1, 2 | `scripts/run_experiments.sh table1` | DGQ (U-Nets), DiT (SD3, FLUX.1) | W8A8: SD v1.4 30K with 1,000 bootstrap resamples; SDXL-Turbo, SD3, FLUX.1 1K; digest comparison of DGQ and UG-LUT on SD3 / FLUX.1 |
| Table 3 | `scripts/run_experiments.sh table3` | DGQ | SD v1.4 1K, W8A8 and W8A6, seeds 42, 137, 2024 |
| Table 4 | `scripts/run_experiments.sh table4` | DGQ | SD v1.4 1K W8A8: FP16, DGQ, UG-LUT, and the evaluation of Q-Diffusion / TFMQ-DM images ([§8](#8-baselines-q-diffusion-and-tfmq-dm)) |
| Table 5 | `scripts/run_experiments.sh table5` | DGQ | both U-Nets at W8A8/W8A6/W4A8/W4A6 (256 score levels); SD v1.4 W8A8 at 64 and 16 levels for both methods |
| Table 6 | `scripts/run_experiments.sh table6` | main | per-layer score MSE of uniform, log₂ and Lloyd-Max on the 64 calibration captions |
| Table 7 | `scripts/run_experiments.sh table7` | DGQ, DiT | 5 warm-up + 30 timed runs: SD v1.4 FP16, DGQ (log₂), UG-LUT (grid), UG-LUT (bucketize), all quantized rows on the DGQ W8A8 back-end; DGQ vs UG-LUT on SDXL-Turbo, SD3, FLUX.1 |
| Table 8 | `scripts/run_experiments.sh table8` | DGQ | 200 captions, W8A8: standard / timestep-adaptive / self + cross; 4–64 calibration prompts; 16–1,024 levels; codebook-size study |
| all tables | `scripts/run_experiments.sh report` | any | ledger, Tables 1–8, record archive |

Options: `--seed`, `--wbits`, `--abits`, `--levels`, `--calib`, `--variant`; environment variables `RUNS`, `BACKEND` (`dgq` or `reference`), `DGQ_CKPTS`, `BASELINES`. To split generation over GPUs, run every shard with `SHARDS=N SHARD=i EVAL=0`, then the same command once with `ONLY_EVAL=1`:

```bash
for i in 0 1 2 3; do CUDA_VISIBLE_DEVICES=$i SHARDS=4 SHARD=$i EVAL=0 scripts/run_experiments.sh table1 & done; wait
ONLY_EVAL=1 scripts/run_experiments.sh table1
```

Single runs with the tools directly:

```bash
uglut-calibrate --model sd14 --protocol coco_calib64 --levels 256 --out runs/codebooks/sd14_L256_c64_standard.npz
uglut-generate  --model sd14 --protocol coco1k --method uglut --backend dgq \
                --dgq-ckpt checkpoints/dgq/sd14_w8a6_s256.pth_merged --wbits 8 --abits 6 --score-levels 256 \
                --codebooks runs/codebooks/sd14_L256_c64_standard.npz --seed 42 --out runs/example/uglut
uglut-eval all  --images runs/example/uglut/images --protocol coco1k --bootstrap 1000
uglut-latency   --model sd14 --method dgq --backend dgq --dgq-ckpt checkpoints/dgq/sd14_w8a8_s256.pth_merged \
                --runs 30 --warmup 5 --out runs/latency/sd14/dgq.json
```

`uglut-generate` refuses inconsistent settings: a codebook whose size differs from `--score-levels`, a codebook of another variant or model, or the DGQ back-end on SD3 / FLUX.1.

---

## 8. Baselines: Q-Diffusion and TFMQ-DM

Q-Diffusion ([code](https://github.com/Xiuyu-Li/q-diffusion)) and TFMQ-DM ([code](https://github.com/ModelTC/TFMQ-DM)) images are generated with their official code at W8A8 on SD v1.4, one image per `data/prompts/coco1k.txt` line in file order, 25 steps, guidance 7.5, 512 px, image *i* with seed 42 + *i*, saved as `baselines/<method>/<index:05d>.png` with the code base and commit in `baselines/<method>/SOURCE`. `scripts/run_experiments.sh table4` then records their digests (`uglut-digest hash`) and evaluates them with the same metric code as every other row.

---

## 9. Metrics and statistics

| Metric | Implementation |
|---|---|
| FID | [clean-fid](https://github.com/GaParmar/clean-fid) (mode `clean`) against the 40,504 val2014 images; reference statistics cached once; 95% percentile bootstrap over generated images (1,000 resamples) on the 30K rows |
| IS | zero-shot CLIP ViT-B/32 (OpenAI weights) over the 1,000 ImageNet classes; **fixed** split assignment (image *i* in split *i* mod 10); the value is the mean of the 10 splits, `is_sd` their SD, and the bootstrap resamples images and recomputes the **same 10-split estimate**, so the point value and its interval describe one estimator |
| CLIP score | mean cosine similarity of open_clip ViT-L/14 (OpenAI weights) image and prompt embeddings (not ×100) |
| Score MSE | squared error, in attention-probability units, between the FP16 scores and each quantizer's output, measured on the FP16 trajectory (all quantizers see identical scores), pooled per layer (Table 6) |

Statistics ([`src/uglut/stats.py`](src/uglut/stats.py), rendered by `uglut-report`): paired t test and t interval over seeds, minimum detectable paired difference (non-central t, α = 0.05, power 0.80), exact two-sided sign test over bit-width settings, Welch's t test on latency, Clopper–Pearson bound on the rate of non-finite codebooks.

---

## 10. Results records

Every tool writes a self-describing JSON record ([`src/uglut/records.py`](src/uglut/records.py)):

| Record | Written by | Contents |
|---|---|---|
| `codebook` | `uglut-calibrate` → `<codebooks>.json` | fit configuration; per layer: iterations, convergence, re-seeded and empty cells, distortion trajectory; table memory; SHA-256 of the codebook and score files |
| `generation` | `uglut-generate` → `generate_<start>.json` | condition, installed quantizers, DGQ commit, SHA-256 of codebooks / DGQ checkpoint / prompt list, SHA-256 of **every image** |
| `metrics` | `uglut-eval` → `metrics.json` | FID, IS, CLIP (with intervals), digest of the evaluated image set |
| `intrinsic`, `codebook_sizes`, `latency`, `digest_comparison` | the matching tools | per-layer MSE; size study; per-run timings, GPU, LUT memory; bit-identity counts |

Each record also holds the provenance: command line, git commit of this repository, Python and package versions, GPU and UTC time. `scripts/run_experiments.sh` keeps a log of every command in the run folder and a `pip freeze` snapshot per environment in `runs/env/`.

```bash
uglut-report runs                                              # runs/report/{ledger.csv, ledger.json, tables.md, table1..8.csv}
uglut-bundle create runs --out uglut-records-<date>.tar.gz     # records, codebooks, logs, report; no images
uglut-bundle verify uglut-records-<date>.tar.gz
```

The ledger joins every run's generation and metric records (a metric whose evaluated image set differs from the generated one is flagged), and every table cell is read from it by configuration, never typed by hand. The record archive is attached to the GitHub release of the paper version, and `runs/report/` is committed under `results/` with it; the generated images are identified by their digests and are available on request.

---

## 11. Reproducibility

* **Seeds.** Image *i* of a run uses a generator seeded with `seed + i` (42 by default; 137 and 2024 for the multi-seed rows), so sharded and resumed runs produce the same images as a single pass. Calibration uses seed 0; the bootstrap uses seed 0.
* **Determinism.** TF32 and cuDNN benchmarking are disabled. Given the same GPU model, driver and environment, a rerun reproduces the recorded PNG digests; `uglut-digest compare` checks two runs image by image.
* **Pinned code.** DGQ is pinned to commit `f449f6ad8052105c72e0bdf5a1cd05bbb98ae037`; the three environments pin their packages; every record stores the versions it ran with.
* **Hardware.** The paper's runs used one NVIDIA A100 80 GB. SD v1.4 and SDXL-Turbo need ≥ 16 GB of GPU memory for generation, SD3 and FLUX.1 ≥ 24 GB, SDXL-Turbo weight reconstruction 80 GB. Storage: 6.2 GB for the COCO images, roughly 10–15 GB per 30K image folder at 512 px.

---

## 12. Tests

```bash
pytest                                            # main or DiT environment
source scripts/dgq_env.sh && pytest -m dgq -v     # DGQ environment: tests against DGQ's own modules
```

The suite runs on the CPU with no downloads: Lloyd fitting (uniform start, stopping rule, re-seeding, textbook NaN), grid compilation and memory, the three level placements, the processors on a small randomly initialized diffusers U-Net (standard, timestep-adaptive and self + cross variants, score-level validation, the measurement processor), the reference back-end, SD3 / FLUX.1 transformers (no module replaced, bit-identical outputs; DiT environment), the ledger, report and record archive, the IS estimator, and the experiment plan of `scripts/run_experiments.sh` (with the `uglut-*` tools replaced by stubs, the tests check the model, method, bit-widths, score levels, seeds, codebooks and DGQ checkpoint of every run that Tables 3, 5, 7 and 8 issue). The DGQ tests build DGQ's `QuantBasicTransformerBlock` with the configuration of `load_dgq_pipeline` and check that the score precision follows `--score-levels` rather than the activation bits, that `log2_quant` equals DGQ's `T2ILogQuantizer`, and that UG-LUT inside DGQ's attention forward receives the scores without the `<start>` column. CI ([`.github/workflows/tests.yml`](.github/workflows/tests.yml)) runs the core tests on Python 3.9–3.11 and the full suite in each of the three environments, and executes the notebook.

The notebook [`notebooks/uglut_walkthrough.ipynb`](notebooks/uglut_walkthrough.ipynb) walks through the method (score distributions, level placement, Lloyd fitting and re-seeding, codebook sizes, the lookup grid, the processors and variants) and renders the tables when run records exist. It runs on a CPU; with a GPU it profiles SD v1.4 directly, and with a calibrated `*_scores.npz` it uses the exact populations the codebooks were fitted on.

---

## 13. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| `ImportError: cannot import name 'cached_download'` | huggingface_hub ≥ 0.26 with diffusers 0.27; use the pinned `huggingface_hub==0.25.2` |
| `DGQ is not importable` | activate `uglut-dgq` and `source scripts/dgq_env.sh` |
| `the codebooks have 64 levels but --score-levels is 256` | fit a codebook with `--levels` equal to the score levels of the run |
| `the DGQ back-end supports sd14 and sdxl` | use `--backend reference` for SD3 and FLUX.1 (DiT environment) |
| `401` / `GatedRepoError` for SD3 | accept the SD3 Medium licence on the Hub and `huggingface-cli login` |
| CUDA out of memory in SDXL-Turbo weight reconstruction | an 80 GB GPU, or `DGQ_NO_RECON=True scripts/dgq_quantize.sh ...` |
| `manifest mismatch` from `uglut-bundle verify` | the archive was modified after it was written; recreate it from the run folder |

---

## 14. Citation

```bibtex
@article{addo2026uglut,
  title  = {Enhancing Text-Image Alignment in Low-Bit Diffusion Models through
            Lookup-Table-Based Cross-Attention Quantization},
  author = {Addo, Prince Clement and Boamah, Martin Konadu},
  year   = {2026}
}
```

See also [`CITATION.cff`](CITATION.cff).

---

## 15. License and acknowledgements

Released under the [Apache License 2.0](LICENSE) (see also [`NOTICE`](NOTICE)).

The DGQ back-end uses the code of [DGQ](https://github.com/ugonfor/DGQ) (Ryu, Park and Shim, ICLR 2025), which is cloned at a pinned commit and not redistributed here. The pipelines come from [diffusers](https://github.com/huggingface/diffusers); FID from [clean-fid](https://github.com/GaParmar/clean-fid); CLIP models from [open_clip](https://github.com/mlfoundations/open_clip). Model weights and datasets are subject to their own licences (§4, §5).
