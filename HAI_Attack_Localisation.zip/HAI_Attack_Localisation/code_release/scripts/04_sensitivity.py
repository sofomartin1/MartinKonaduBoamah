"""Sensitivity runs on HAI 21.03: Ridge lag sets, unstandardised residuals, past-only training.

Past-only training uses train1 alone (11-12 July 2020 after de-duplication), which precedes
test3-test5; those 25 episodes are the evaluation set for the chronology comparison.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc.data import Data  # noqa: E402
from hailoc import scoring as S  # noqa: E402

LAGSETS = {"_L10": list(range(1, 11)), "_L30": [1, 2, 3, 5, 10, 15, 20, 30],
           "_L120": C.RIDGE_LAGS + [90, 120]}


def exists(version, method, seed, tag):
    return Path(str(S.run_path(version, method, seed, tag)) + ".npz").exists()


if __name__ == "__main__":
    C.ensure_dirs()
    v = C.PRIMARY
    logf = open(C.LOGS / "04_sensitivity.log", "a", encoding="utf-8")

    def log(m):
        print(m, flush=True); logf.write(m + "\n"); logf.flush()

    D = Data(v)
    for tag, lags in LAGSETS.items():
        if not exists(v, "RIDGE", 0, tag):
            S.residual_method(D, "RIDGE", 0, lags=lags, tag=tag, log=log)
    for m in ["ZSCORE", "PERSIST", "PCA", "RIDGE"]:
        if not exists(v, m, 0, "_RAW"):
            S.residual_method(D, m, 0, tag="_RAW", standardise=False, log=log)
    for m in ["PERSIST", "PCA", "RIDGE", "TCN"]:
        if not exists(v, m, 0, "_T1"):
            S.residual_method(D, m, 0, train_files=[0], tag="_T1", log=log)
