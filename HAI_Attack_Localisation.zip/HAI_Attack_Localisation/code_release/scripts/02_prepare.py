"""Select channels, standardise with training statistics, split validation, align attack episodes."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc.data import prepare  # noqa: E402

if __name__ == "__main__":
    C.ensure_dirs()
    for version in C.VERSIONS:
        eps = prepare(version)
        print(version, "episodes:", len(eps), "processes:", eps["processes"].value_counts().to_dict())
