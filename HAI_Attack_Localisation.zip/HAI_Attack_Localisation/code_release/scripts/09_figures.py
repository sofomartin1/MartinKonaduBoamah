"""Build every manuscript figure (outputs/figures/*.png) plus a registry with captions."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc import plotting as P  # noqa: E402
from hailoc.plotting import SHORT, COLOR, MARKER  # noqa: E402
from hailoc.data import Data  # noqa: E402
from hailoc.scoring import load_run, context_rows  # noqa: E402
from hailoc import schematic  # noqa: E402
from hailoc import stats as S  # noqa: E402

A = C.ANALYSIS
REG = []
TYPE_COLOR = {"Setpoint manipulation": "#2a78d6", "Actuator manipulation": "#eda100", "Sensor spoofing": "#e34948"}


def reg(fid, title):
    REG.append(dict(id=fid, title=title))


def primary(ep):
    return ep[(ep["agg"] == "max") & (ep.seed == 0)]


def load_ep(prefix="A"):
    ep = pd.read_csv(A / f"{prefix}_episode.csv")
    meta = pd.read_csv(A / f"{prefix}_episodes_meta.csv")
    return ep.merge(meta[["ep", "attack_id", "processes", "controllers", "attack_type", "combined", "length"]],
                    on="ep", how="left", suffixes=("", "_m"))


def methods_present(df, roster=C.METHODS):
    return [m for m in roster if m in set(df.method)]


# ------------------------------------------------------------------ F01 design
def f_design():
    sa, sb = json.load(open(A / "A_setup.json")), json.load(open(A / "B_setup.json"))
    na, nb = len(pd.read_csv(A / "A_episodes_meta.csv")), len(pd.read_csv(A / "B_episodes_meta.csv"))
    P.save(schematic.pipeline(sa["n_channels"], sb["n_channels"], na, nb), "F01_design")
    reg("F01_design", "Study design: data preparation, evidence generators, episode-level localisation and evaluation")


# ------------------------------------------------------------------ F02 coverage
def f_coverage():
    s = json.load(open(A / "A_setup.json"))
    tab = pd.read_csv(C.DATA_PROC / C.PRIMARY / "attack_table.csv")
    meta = pd.read_csv(A / "A_episodes_meta.csv")
    loops = s["loop_names"]
    kinds = ["Setpoint manipulation", "Actuator manipulation", "Sensor spoofing"]
    M = np.zeros((len(meta), len(loops)))
    for i, no in enumerate(sorted(tab.no.unique())):
        for r in tab[tab.no == no].itertuples():
            M[i, loops.index(r.controller)] = kinds.index(r.kind) + 1
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 6.2), gridspec_kw=dict(width_ratios=[2.4, 1.3, 1.3], wspace=0.08))
    ax = axes[0]
    cmap = ListedColormap(["#ffffff"] + [TYPE_COLOR[k] for k in kinds])
    ax.imshow(M, aspect="auto", cmap=cmap, norm=BoundaryNorm([-0.5, 0.5, 1.5, 2.5, 3.5], 4), interpolation="none")
    ax.set_xticks(range(len(loops))); ax.set_xticklabels(loops, rotation=60, ha="right")
    ax.set_yticks(range(len(meta))); ax.set_yticklabels(meta.attack_id, fontsize=5.5)
    ax.set_xticks(np.arange(-.5, len(loops)), minor=True); ax.set_yticks(np.arange(-.5, len(meta)), minor=True)
    ax.grid(which="minor", color="#e1e0d9", lw=0.4); ax.grid(which="major", visible=False)
    ax.tick_params(which="minor", length=0)
    ax.set_title("Targeted control loops")
    ax.legend(handles=[Patch(color=TYPE_COLOR[k], label=k) for k in kinds], loc="upper center",
              bbox_to_anchor=(0.5, -0.13), ncol=1, fontsize=6.5)
    P.panel_label(ax, "a")
    ax = axes[1]
    y = np.arange(len(meta))
    ax.barh(y, meta.length, color=[TYPE_COLOR[t] for t in meta.attack_type], height=0.7)
    ax.set_ylim(len(meta) - 0.5, -0.5); ax.set_yticks([])
    ax.set_xlabel("Episode length (s)"); ax.set_title("Duration")
    P.panel_label(ax, "b")
    ax = axes[2]
    ax.barh(y, meta.n_tags_candidate, color="#52514e", height=0.7)
    ax.set_ylim(len(meta) - 0.5, -0.5); ax.set_yticks([])
    ax.set_xlabel("Recorded varying targets"); ax.set_title("Tag ground truth")
    ax.set_xticks(range(0, int(meta.n_tags_candidate.max()) + 1))
    P.panel_label(ax, "c")
    P.save(fig, "F02_coverage")
    reg("F02_coverage", "HAI 21.03 attack episodes: (a) control loops targeted by each episode, coloured by primitive type; "
        "(b) labelled duration; (c) number of documented targets that are recorded and vary in training")


# ------------------------------------------------------------------ F03 examples
def f_examples(D):
    run, _ = load_run(C.PRIMARY, "PERSIST", 0)
    rows, offs = context_rows(D)
    order = np.argsort([D.loops.index(l) * 100 + i for i, l in enumerate(D.loop)], kind="stable")
    picks = ["A202", "A215"]
    fig, axes = plt.subplots(2, 2, figsize=(7.4, 5.6), sharex="col", gridspec_kw=dict(height_ratios=[1, 2.2], hspace=0.12, wspace=0.25))
    for j, aid in enumerate(picks):
        k = int(np.flatnonzero(D.episodes.attack_id.values == aid)[0])
        e = D.episodes.iloc[k]
        a, b = offs[k], offs[k + 1]
        t0 = rows[a]
        t = rows[a:b] - e.start
        ax = axes[0, j]
        for tag in [x for x in str(e.tags_candidate).split(";") if x and x != "nan"]:
            c = D.channels.index(tag)
            ax.plot(t, D.Xte[rows[a:b], c], lw=1.1, label=tag)
        ax.axvspan(0, e.length - 1, color="#e34948", alpha=0.10, lw=0)
        ax.set_ylabel("z-score"); ax.tick_params(labelbottom=False)
        ax.set_title(f"{aid}: {e.scenario}", fontsize=8)
        ax.legend(loc="lower left", fontsize=6.5, ncol=2, frameon=True, facecolor="white", edgecolor=P.GRID, framealpha=0.9)
        P.panel_label(ax, "ab"[j])
        ax = axes[1, j]
        Sx = run["S_ctx"][a:b][:, order].T
        im = ax.imshow(np.log1p(Sx), aspect="auto", cmap=P.FIRE, interpolation="none",
                       extent=[t[0] - 0.5, t[-1] + 0.5, len(order) - 0.5, -0.5], vmin=0, vmax=np.log1p(20))
        loops_sorted = [D.loop[i] for i in order]
        bounds = [i for i in range(1, len(order)) if loops_sorted[i] != loops_sorted[i - 1]]
        for bnd in bounds:
            ax.axhline(bnd - 0.5, color="#0b0b0b", lw=0.5)
        mids = [(s + e_) / 2 - 0.5 for s, e_ in zip([0] + bounds, bounds + [len(order)])]
        ax.set_yticks(mids); ax.set_yticklabels([l for i, l in enumerate(loops_sorted) if i == 0 or i in bounds], fontsize=6.5)
        for l in str(e.controllers).split(";"):
            idx = [i for i, x in enumerate(loops_sorted) if x == l]
            ax.add_patch(plt.Rectangle((t[0] - 0.5, idx[0] - 0.5), t[-1] - t[0] + 1, len(idx), fill=False,
                                       ec="#1baf7a", lw=1.4))
        ax.axvline(0, color="#2a78d6", lw=1); ax.axvline(e.length - 1, color="#2a78d6", lw=1, ls="--")
        ax.set_xlabel("Seconds from labelled onset"); ax.grid(False)
        P.panel_label(ax, "cd"[j])
    cb = fig.colorbar(im, ax=axes.ravel().tolist(), fraction=0.025, pad=0.02, shrink=0.65, anchor=(0.0, 0.1))
    cb.set_label("log(1 + standardised residual)")
    P.save(fig, "F03_examples")
    reg("F03_examples", "Two HAI 21.03 episodes: (a, b) documented target tags (attack interval shaded); (c, d) "
        "standardised persistence residuals of all 57 candidate tags grouped by control loop, with the targeted loop "
        "outlined in green and onset / end marked in blue")


# ------------------------------------------------------------------ F04 RQ1 forest
def f_rq1():
    s = pd.read_csv(A / "S_main.csv").set_index("method")
    ms = [m for m in C.METHODS if m in s.index]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.8), sharey=True, gridspec_kw=dict(wspace=0.08))
    for ax, col, lab, rnd in ((axes[0], "proc_hit", "Process top-1 accuracy (%)", True),
                              (axes[1], "loop_hit1", "Control-loop top-1 accuracy (%)", True)):
        y = np.arange(len(ms))[::-1]
        for yi, m in zip(y, ms):
            v = s.loc[m, col]
            if pd.isna(v):
                continue
            ax.errorbar(100 * v, yi, xerr=[[100 * (v - s.loc[m, col + "_lo"])], [100 * (s.loc[m, col + "_hi"] - v)]],
                        fmt=MARKER[m], color=COLOR[m], ms=6, capsize=2.5, lw=1.3)
        ax.axvline(100 * s.loc["RANDOM", col], color=COLOR["RANDOM"], ls="--", lw=1.1)
        ax.text(100 * s.loc["RANDOM", col] + 1, len(ms) - 0.6, "random", fontsize=6.5, color=P.MUTED)
        if col == "proc_hit":
            ax.axvline(100 * s.loc["MAJORITY", col], color=COLOR["MAJORITY"], ls=":", lw=1.1)
            ax.text(100 * s.loc["MAJORITY", col] + 1, len(ms) - 0.6, "always P1", fontsize=6.5, color=P.INK2)
        ax.set_xlim(0, 103); ax.set_xlabel(lab)
        ax.set_yticks(np.arange(len(ms))[::-1]); ax.set_yticklabels([SHORT[m] for m in ms])
    P.panel_label(axes[0], "a"); P.panel_label(axes[1], "b")
    P.save(fig, "F04_rq1_accuracy")
    reg("F04_rq1_accuracy", "Episode-level localisation accuracy on HAI 21.03 with 95% bootstrap intervals: (a) process "
        "top-1; (b) control-loop top-1 (seed 0, maximum aggregation; dashed = random ranking, dotted = always P1)")


# ------------------------------------------------------------------ F05 confusion
def f_confusion():
    c = pd.read_csv(A / "S_confusion.csv")
    picks = [m for m in ("PERSIST", "RIDGE", "TCN", "SHAP_IF", "CORR", "GBDT_PROC") if m in set(c.method)]
    gts = ["P1", "P2", "P3", "P1+P2", "P1+P3", "P2+P3"]
    preds = ["P1", "P2", "P3", "P4"]
    fig, axes = plt.subplots(2, 3, figsize=(7.4, 5.0), gridspec_kw=dict(hspace=0.45, wspace=0.12))
    for ax, m in zip(axes.flat, picks):
        M = np.zeros((len(gts), len(preds)))
        for r in c[c.method == m].itertuples():
            M[gts.index(r.gt), preds.index(r.proc_pred)] = r.n
        frac = M / np.maximum(M.sum(1, keepdims=True), 1)
        ax.imshow(frac, cmap=P.SEQ, vmin=0, vmax=1)
        for i in range(len(gts)):
            for j in range(len(preds)):
                if M[i, j]:
                    ok = preds[j] in gts[i].split("+")
                    ax.text(j, i, int(M[i, j]), ha="center", va="center", fontsize=7,
                            color="#ffffff" if frac[i, j] > 0.55 else P.INK, fontweight="bold" if ok else "normal")
        ax.set_xticks(range(len(preds))); ax.set_xticklabels(preds)
        ax.set_yticks(range(len(gts))); ax.set_yticklabels(gts if ax in axes[:, 0] else [])
        ax.set_title(SHORT[m]); ax.grid(False)
        ax.set_xlabel("Predicted process", fontsize=7)
    for ax in axes.flat[len(picks):]:
        ax.axis("off")
    P.save(fig, "F05_confusion")
    reg("F05_confusion", "Targeted process (rows) versus top-ranked process (columns) over the 50 HAI 21.03 episodes; cell "
        "shading = row proportion, bold counts = correct calls (seed 0, maximum aggregation)")


# ------------------------------------------------------------------ F06 per-episode map
def f_episode_map(ep):
    d = primary(ep)
    ms = [m for m in methods_present(d) if m != "GBDT_PROC"]
    meta = pd.read_csv(A / "A_episodes_meta.csv")
    M = np.zeros((len(ms), len(meta)))
    for i, m in enumerate(ms):
        x = d[d.method == m].set_index("ep")
        M[i] = [2 if x.loc[e, "loop_hit1"] else (1 if x.loc[e, "proc_hit"] else 0) for e in meta.ep]
    fig = plt.figure(figsize=(7.4, 3.6))
    gs = fig.add_gridspec(2, 1, height_ratios=[0.35, len(ms)], hspace=0.05)
    ax0 = fig.add_subplot(gs[0]); ax = fig.add_subplot(gs[1], sharex=ax0)
    tcol = [TYPE_COLOR[t] for t in meta.attack_type]
    ax0.bar(range(len(meta)), 1, color=tcol, width=1.0); ax0.axis("off")
    cmap = ListedColormap(["#52514e", "#f6e7c6", "#1baf7a"])
    ax.imshow(M, aspect="auto", cmap=cmap, vmin=0, vmax=2, interpolation="none")
    ax.set_yticks(range(len(ms))); ax.set_yticklabels([SHORT[m] for m in ms])
    ax.set_xticks(range(len(meta))); ax.set_xticklabels(meta.attack_id, rotation=90, fontsize=5.3)
    ax.set_xticks(np.arange(-.5, len(meta)), minor=True); ax.set_yticks(np.arange(-.5, len(ms)), minor=True)
    ax.grid(which="minor", color="#ffffff", lw=0.6); ax.grid(which="major", visible=False)
    ax.tick_params(which="minor", length=0)
    h = [Patch(color="#1baf7a", label="loop correct"), Patch(color="#f6e7c6", label="process only"),
         Patch(color="#52514e", label="process wrong")] + [Patch(color=v, label=k) for k, v in TYPE_COLOR.items()]
    ax.legend(handles=h, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=6, fontsize=6.3)
    P.save(fig, "F06_episode_map")
    reg("F06_episode_map", "Whole-episode localisation outcome per method and HAI 21.03 episode (top strip: attack type)")


# ------------------------------------------------------------------ F07 hit@k
def f_hitk(ep):
    d = primary(ep)
    d = d[d.tag_rank.notna()]
    ms = [m for m in methods_present(d) if m != "GBDT_PROC"]
    s = json.load(open(A / "A_setup.json"))
    K = s["n_channels"]
    ks = np.arange(1, 21)
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.2), gridspec_kw=dict(wspace=0.25))
    ax = axes[0]
    for m in ms:
        r = d[d.method == m].tag_rank.values
        ax.plot(ks, [100 * (r <= k).mean() for k in ks], color=COLOR[m], marker=MARKER[m], ms=3.5, lw=1.3, label=SHORT[m])
    g = d[d.method == ms[0]].n_tags_candidate.values if "n_tags_candidate" in d else None
    meta = pd.read_csv(A / "A_episodes_meta.csv").set_index("ep")
    gsz = meta.loc[d[d.method == ms[0]].ep, "n_tags_candidate"].values
    from hailoc.localise import p_random_topk
    ax.plot(ks, [100 * np.mean([p_random_topk(K, x, k) for x in gsz]) for k in ks], color=COLOR["RANDOM"], ls="--",
            lw=1.2, label="Random")
    ax.set_xlabel("k (tags inspected)"); ax.set_ylabel("Hit@k (%)"); ax.set_ylim(0, 102); ax.set_xticks([1, 5, 10, 15, 20])
    P.panel_label(ax, "a")
    fig.legend(*ax.get_legend_handles_labels(), loc="lower center", bbox_to_anchor=(0.5, -0.13), ncol=6, fontsize=6.3)
    ax = axes[1]
    data = [d[d.method == m].tag_rank.values for m in ms]
    bp = ax.boxplot(data, orientation="horizontal", patch_artist=True, widths=0.6, showfliers=True,
                    flierprops=dict(marker=".", ms=3, mec=P.MUTED))
    for patch, m in zip(bp["boxes"], ms):
        patch.set_facecolor(COLOR[m]); patch.set_alpha(0.75); patch.set_edgecolor(P.INK2)
    for med in bp["medians"]:
        med.set_color(P.INK)
    ax.set_yticks(range(1, len(ms) + 1)); ax.set_yticklabels([SHORT[m] for m in ms])
    ax.set_xscale("log"); ax.set_xlabel("Rank of best target tag (log)"); ax.invert_yaxis()
    P.panel_label(ax, "b")
    P.save(fig, "F07_rq2_hitk")
    reg("F07_rq2_hitk", "Tag-level localisation on HAI 21.03: (a) hit@k as a function of the number of tags inspected; "
        "(b) distribution of the rank of the best-ranked manipulated tag among 57 candidates")


# ------------------------------------------------------------------ F08 by attack type
def f_type():
    b = pd.read_csv(A / "S_bytype.csv")
    b = b[(b.factor == "attack_type") & (b.method != "GBDT_PROC")]
    ms = methods_present(b)
    types = ["Setpoint manipulation", "Actuator manipulation", "Sensor spoofing"]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.3), sharey=True, gridspec_kw=dict(wspace=0.06))
    w = 0.8 / len(types)
    for ax, col, lab in ((axes[0], "loop_hit1", "Control-loop top-1 (%)"), (axes[1], "tag_hit3", "Tag hit@3 (%)")):
        for k, t in enumerate(types):
            g = b[b.level == t].set_index("method")
            vals = [100 * g.loc[m, col] if m in g.index else np.nan for m in ms]
            n = int(g.n_tag.iloc[0]) if col == "tag_hit3" else int(g.n.iloc[0])
            ax.barh(np.arange(len(ms)) + (k - 1) * w, vals, height=w, color=TYPE_COLOR[t], label=f"{t} (n = {n})")
        ax.set_xlabel(lab); ax.set_xlim(0, 100)
        ax.set_yticks(range(len(ms))); ax.set_yticklabels([SHORT[m] for m in ms])
        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.16), fontsize=6, ncol=1)
    axes[0].invert_yaxis()
    P.panel_label(axes[0], "a"); P.panel_label(axes[1], "b")
    P.save(fig, "F08_rq2_type")
    reg("F08_rq2_type", "Localisation accuracy by attack type on HAI 21.03: (a) control-loop top-1; (b) tag hit@3 over "
        "episodes with a recorded varying target")


# ------------------------------------------------------------------ F09 observability
def f_observability(ep):
    ob = pd.read_csv(A / "A_observability.csv")
    dev = ob[ob.recorded].groupby("ep").max_dev.max()
    d = primary(ep)
    picks = [m for m in ("PERSIST", "RIDGE", "TCN", "SHAP_IF") if m in set(d.method)]
    fig, axes = plt.subplots(1, len(picks), figsize=(7.4, 2.6), sharey=True, gridspec_kw=dict(wspace=0.07))
    for ax, m in zip(np.atleast_1d(axes), picks):
        x = d[(d.method == m) & d.tag_rank.notna()].set_index("ep")
        xs = dev.reindex(x.index).values
        ax.scatter(np.maximum(xs, 0.05), x.tag_rank, s=16, c=[TYPE_COLOR[t] for t in x.attack_type], edgecolor="white",
                   lw=0.4)
        ax.axvline(3, color=P.MUTED, ls="--", lw=1); ax.axhline(3.5, color=P.MUTED, ls=":", lw=1)
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_title(SHORT[m])
        ax.set_yticks([1, 3, 10, 30]); ax.set_yticklabels(["1", "3", "10", "30"])
        rho, p = S.spearman(xs, x.tag_rank.values)
        ax.text(0.97, 0.95, f"ρ = {rho:.2f}", transform=ax.transAxes, ha="right", va="top", fontsize=7)
    np.atleast_1d(axes)[0].set_ylabel("Rank of best target tag")
    fig.supxlabel("Largest deviation of a target tag from its pre-onset median (training SD; log)", fontsize=8, y=-0.06)
    h = [Line2D([], [], marker="o", ls="", color=v, label=k) for k, v in TYPE_COLOR.items()]
    fig.legend(handles=h, loc="lower center", bbox_to_anchor=(0.5, -0.22), ncol=3, fontsize=6.5)
    P.save(fig, "F09_observability")
    reg("F09_observability", "Visibility of the manipulation in the logged target tag versus the rank achieved by the "
        "target (HAI 21.03; dashed: 3-SD visibility threshold; dotted: top-3; ρ = Spearman correlation)")


# ------------------------------------------------------------------ F10 accuracy vs tau
def f_tau():
    c = pd.read_csv(A / "S_curves.csv")
    ms = methods_present(c)
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 3.0), sharey=True, gridspec_kw=dict(wspace=0.07))
    for ax, col, lab in ((axes[0], "proc_hit", "Process top-1"), (axes[1], "loop_hit1", "Loop top-1"),
                         (axes[2], "tag_hit3", "Tag hit@3")):
        for m in ms:
            g = c[c.method == m].sort_values("tau")
            if col not in g or g[col].isna().all():
                continue
            ax.plot(g.tau, 100 * g[col], color=COLOR[m], marker=MARKER[m], ms=3.2, lw=1.2, label=SHORT[m])
        ax.set_xscale("log"); ax.set_xticks([5, 10, 30, 60, 120, 240]); ax.set_xticklabels([5, 10, 30, 60, 120, 240])
        ax.set_xlabel("Seconds since onset (τ)"); ax.set_title(lab); ax.set_ylim(0, 102)
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend(fontsize=5.8, ncol=2, loc="lower right")
    for k, ax in enumerate(axes):
        P.panel_label(ax, "abc"[k])
    P.save(fig, "F10_rq3_tau")
    reg("F10_rq3_tau", "Localisation accuracy as a function of the evidence accumulated since onset on HAI 21.03 "
        "(seed 0, maximum aggregation)")


# ------------------------------------------------------------------ F11 Kaplan-Meier
def f_km():
    k = pd.read_csv(A / "S_km.csv")
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.2), sharey=True, gridspec_kw=dict(wspace=0.07))
    for ax, kind, lab in ((axes[0], "proc", "Process"), (axes[1], "loop", "Control loop")):
        for m in methods_present(k):
            g = k[(k.method == m) & (k.kind == kind)]
            if g.empty:
                continue
            ax.step(g.t, 100 * (1 - g.surv), where="post", color=COLOR[m], lw=1.3, label=SHORT[m])
        ax.set_xscale("symlog", linthresh=10); ax.set_xlim(0, 450)
        ax.set_xticks([0, 5, 10, 30, 60, 120, 240]); ax.set_xticklabels([0, 5, 10, 30, 60, 120, 240])
        ax.set_xlabel("Seconds since onset"); ax.set_title(f"{lab} localised")
    axes[0].set_ylabel("Cumulative episodes localised (%)")
    fig.legend(*axes[1].get_legend_handles_labels(), loc="lower center", bbox_to_anchor=(0.5, -0.14), ncol=5, fontsize=6.3)
    P.panel_label(axes[0], "a"); P.panel_label(axes[1], "b")
    P.save(fig, "F11_rq3_km")
    reg("F11_rq3_km", f"Kaplan–Meier cumulative incidence of correct, stable ({C.STABILITY} s) localisation after "
        "onset on HAI 21.03: (a) process; (b) control loop")


# ------------------------------------------------------------------ F12 RMST + Cox
def f_rmst():
    s = pd.read_csv(A / "S_main.csv").set_index("method")
    cox = pd.read_csv(A / "R_cox.csv") if (A / "R_cox.csv").exists() else None
    ms = [m for m in C.METHODS if m in s.index and pd.notna(s.loc[m, "rmst_loop"])]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.4), sharey=True, gridspec_kw=dict(wspace=0.07))
    y = np.arange(len(ms))[::-1]
    for kind, off, mk in (("proc", 0.15, "o"), ("loop", -0.15, "s")):
        for yi, m in zip(y, ms):
            v, lo, hi = s.loc[m, f"rmst_{kind}"], s.loc[m, f"rmst_{kind}_lo"], s.loc[m, f"rmst_{kind}_hi"]
            axes[0].errorbar(v, yi + off, xerr=[[v - lo], [hi - v]], fmt=mk, color=COLOR[m],
                             mfc=COLOR[m] if kind == "loop" else "white", capsize=2, ms=5, lw=1.1)
    axes[0].set_xlabel("RMST₁₂₀ (s), lower = faster"); axes[0].set_yticks(y); axes[0].set_yticklabels([SHORT[m] for m in ms])
    axes[0].legend(handles=[Line2D([], [], marker="o", mfc="white", color=P.INK2, ls="", label="process"),
                            Line2D([], [], marker="s", color=P.INK2, ls="", label="control loop")], loc="upper right")
    P.panel_label(axes[0], "a")
    ax = axes[1]
    if cox is not None:
        for yi, m in zip(y, ms):
            if m == "RIDGE":
                ax.plot(1, yi, "D", color=COLOR[m], ms=5)
                continue
            h = cox[(cox.kind == "loop") & (cox.term == "method" + m)]
            if len(h):
                ax.errorbar(h.hr.iloc[0], yi, xerr=[[h.hr.iloc[0] - h.hr_lo.iloc[0]], [h.hr_hi.iloc[0] - h.hr.iloc[0]]],
                            fmt="s", color=COLOR[m], capsize=2, ms=5)
        ax.axvline(1, color=P.MUTED, ls="--", lw=1)
        ax.set_xscale("log"); ax.set_xlabel("Hazard ratio of loop localisation vs Ridge-VAR")
        ax.set_xticks([0.25, 0.5, 1, 2, 4]); ax.set_xticklabels(["0.25", "0.5", "1", "2", "4"]); ax.minorticks_off()
    P.panel_label(ax, "b")
    P.save(fig, "F12_rq3_rmst_cox")
    reg("F12_rq3_rmst_cox", "Speed of localisation on HAI 21.03: (a) restricted mean time-to-localise up to 120 s with 95% "
        "bootstrap intervals; (b) hazard ratios of control-loop localisation from a Cox model stratified by episode "
        "(> 1 = faster than Ridge-VAR)")


# ------------------------------------------------------------------ F13 Pareto
def f_pareto():
    cmp_ = pd.read_csv(A / "A_compute.csv")
    s = pd.read_csv(A / "S_main.csv").set_index("method")
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.3), sharey=True, gridspec_kw=dict(wspace=0.07))
    for ax, xcol, lab in ((axes[0], "cost_us", "Scoring + attribution cost (µs per step, log)"),
                          (axes[1], "fit_s", "Fit time (s, log)")):
        pts = []
        for m in C.METHODS:
            if m not in s.index or m == "GBDT_PROC" or pd.isna(s.loc[m, "loop_hit1"]):
                continue
            c = cmp_[cmp_.method == ("TCN" if m == "IG_TCN" else m)]
            inf = np.nanmean(c.infer_us_per_step) if "infer_us_per_step" in c and c.infer_us_per_step.notna().any() else 0
            att = cmp_[cmp_.method == m]
            att = np.nanmean(att.attr_us_per_step) if "attr_us_per_step" in att and att.attr_us_per_step.notna().any() else 0
            cost = max(inf + att, 0.05)
            fit = max(np.nanmean(c.fit_s) if c.fit_s.notna().any() else 0.0, 0.01)
            x = cost if xcol == "cost_us" else fit
            ax.scatter(x, 100 * s.loc[m, "loop_hit1"], s=55, color=COLOR[m], marker=MARKER[m], edgecolor="white", lw=0.5,
                       zorder=3)
            off = {"SHAP_GBDT": (6, -12), "LSTM": (-6, 6), "SHAP_IF": (-10, 6)}.get(m, (4, 3))
            ax.annotate(SHORT[m], (x, 100 * s.loc[m, "loop_hit1"]), xytext=off, textcoords="offset points", fontsize=6.3,
                        ha="right" if off[0] < 0 else "left")
            pts.append((x, 100 * s.loc[m, "loop_hit1"]))
        pts.sort()
        front, best = [], -1
        for x, yv in pts:
            if yv > best:
                front.append((x, yv)); best = yv
        ax.step([p[0] for p in front], [p[1] for p in front], where="post", color=P.MUTED, ls="--", lw=1, zorder=1)
        ax.set_xscale("log"); ax.set_xlabel(lab); ax.margins(x=0.12)
    axes[0].set_ylabel("Control-loop top-1 (%)")
    P.panel_label(axes[0], "a"); P.panel_label(axes[1], "b")
    P.save(fig, "F13_rq4_pareto")
    reg("F13_rq4_pareto", "Accuracy–cost trade-off on HAI 21.03: control-loop top-1 accuracy versus (a) per-step scoring "
        "and attribution cost and (b) fitting time; dashed line = Pareto front")


# ------------------------------------------------------------------ F14 aggregator / sensitivity heatmap
def f_aggregator():
    a = pd.read_csv(A / "S_aggregator.csv")
    a = a[a.method != "GBDT_PROC"]
    ms = methods_present(a)
    aggs = ["max", "top2", "mean", "sum", "cal"]
    labs = ["Max", "Top-2", "Mean", "Sum", "Calibrated"]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.6), gridspec_kw=dict(wspace=0.35))
    for ax, col, title in ((axes[0], "proc_hit", "Process top-1 (%)"), (axes[1], "loop_hit1", "Loop top-1 (%)")):
        M = np.full((len(ms), len(aggs)), np.nan)
        for i, m in enumerate(ms):
            g = a[a.method == m].set_index("agg")
            for j, ag in enumerate(aggs):
                if ag in g.index:
                    M[i, j] = 100 * g.loc[ag, col]
        im = ax.imshow(M, cmap=P.HEAT, vmin=0, vmax=100, aspect="auto")
        for i in range(len(ms)):
            for j in range(len(aggs)):
                if not np.isnan(M[i, j]):
                    ax.text(j, i, f"{M[i, j]:.0f}", ha="center", va="center", fontsize=6.8,
                            color="white" if (M[i, j] < 25 or M[i, j] > 85) else P.INK)
        ax.set_xticks(range(len(aggs))); ax.set_xticklabels(labs, rotation=30, ha="right")
        ax.set_yticks(range(len(ms))); ax.set_yticklabels([SHORT[m] for m in ms]); ax.set_title(title); ax.grid(False)
    fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02)
    P.panel_label(axes[0], "a"); P.panel_label(axes[1], "b")
    P.save(fig, "F14_aggregator")
    reg("F14_aggregator", "Sensitivity of (a) process and (b) control-loop top-1 accuracy to the rule aggregating channel "
        "evidence into group scores (HAI 21.03, seed 0; blank = not applicable)")


# ------------------------------------------------------------------ F15 detection vs localisation
def f_det_loc():
    det = pd.read_csv(A / "S_detection.csv")
    s = pd.read_csv(A / "S_main.csv").set_index("method")
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.2), gridspec_kw=dict(wspace=0.28))
    d0 = det[det.seed == 0].set_index("method")
    for m in d0.index:
        if m not in s.index or m == "GBDT_PROC":
            continue
        x = d0.loc[m, "eTaF1"]; y = 100 * s.loc[m, "loop_hit1"]
        axes[0].scatter(x, y, s=50, color=COLOR[m], marker=MARKER[m], edgecolor="white", zorder=3)
        axes[0].annotate(SHORT[m], (x, y), xytext=(4, 3), textcoords="offset points", fontsize=6.3)
    axes[0].set_xlabel("Detection eTaF1 (calibrated threshold)"); axes[0].set_ylabel("Control-loop top-1 (%)")
    P.panel_label(axes[0], "a")
    ax = axes[1]
    ms = [m for m in C.METHODS if m in d0.index and m != "GBDT_PROC"]
    y = np.arange(len(ms))
    for yi, m in zip(y, ms):
        if d0.loc[m, "alarm_rate"] == 0:
            ax.text(1, yi, "no alarm at the calibrated threshold", va="center", fontsize=6.3, color=P.MUTED)
    ax.barh(y - 0.2, [100 * d0.loc[m, "loop_hit_at"] if pd.notna(d0.loc[m].get("loop_hit_at")) else 0 for m in ms],
            height=0.4, color=[COLOR[m] for m in ms], alpha=0.55, label="10 s before alarm")
    ax.barh(y + 0.2, [100 * d0.loc[m, "loop_hit_plus30"] if pd.notna(d0.loc[m].get("loop_hit_plus30")) else 0 for m in ms],
            height=0.4, color=[COLOR[m] for m in ms], label="30 s after alarm")
    ax.set_yticks(y); ax.set_yticklabels([SHORT[m] for m in ms]); ax.invert_yaxis()
    ax.set_xlabel("Loop top-1 among alarmed episodes (%)"); ax.set_xlim(0, 100)
    ax.legend(handles=[Patch(color=P.INK2, alpha=0.55, label="10 s ending at alarm"),
                       Patch(color=P.INK2, label="30 s after alarm")], loc="lower right", fontsize=6.3)
    P.panel_label(ax, "b")
    P.save(fig, "F15_detection_localisation")
    reg("F15_detection_localisation", "Detection and localisation on HAI 21.03: (a) detection eTaF1 versus control-loop "
        "accuracy; (b) control-loop accuracy when localisation is triggered by each method's own first alarm")


# ------------------------------------------------------------------ F16 replication
def f_replication():
    p = A / "S_replication.csv"
    if not p.exists():
        return
    r = pd.read_csv(p)
    ms = [m for m in C.REPL_METHODS if m in set(r.method)]
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 3.2), sharey=True, gridspec_kw=dict(wspace=0.07))
    for ax, col, lab in ((axes[0], "proc_hit", "Process top-1 (%)"), (axes[1], "loop_hit1", "Loop top-1 (%)"),
                         (axes[2], "tag_hit3", "Tag hit@3 (%)")):
        for i, m in enumerate(ms):
            g = r[r.method == m].set_index("version")
            a = 100 * g.loc[C.PRIMARY, col]; b = 100 * g.loc[C.REPLICATION, col] if C.REPLICATION in g.index else np.nan
            ax.plot([a, b], [i, i], color=P.GRID, lw=2.5, zorder=1)
            ax.scatter(a, i, color=COLOR[m], s=36, zorder=3, marker="o")
            ax.scatter(b, i, color="white", edgecolor=COLOR[m], s=36, zorder=3, marker="o", lw=1.4)
        ax.set_xlim(0, 102); ax.set_xlabel(lab)
        ax.set_yticks(range(len(ms))); ax.set_yticklabels([SHORT[m] for m in ms])
    axes[0].invert_yaxis()
    axes[2].legend(handles=[Line2D([], [], marker="o", ls="", color=P.INK2, label="HAI 21.03"),
                            Line2D([], [], marker="o", ls="", mfc="white", color=P.INK2, label="HAI 22.04")],
                   loc="lower right", fontsize=6.5)
    for k, ax in enumerate(axes):
        P.panel_label(ax, "abc"[k])
    P.save(fig, "F16_replication")
    reg("F16_replication", "Replication on HAI 22.04 (open circles) against HAI 21.03 (filled circles) for the unsupervised "
        "methods (seed 0, maximum aggregation)")


# ------------------------------------------------------------------ F17 seeds
def f_seeds(ep):
    d = ep[(ep["agg"] == "max") & ep.method.isin(C.STOCHASTIC)]
    g = d.groupby(["method", "seed"])[["proc_hit", "loop_hit1", "tag_hit3"]].mean().reset_index()
    ms = [m for m in C.METHODS if m in set(g.method)]
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.8), sharey=True, gridspec_kw=dict(wspace=0.07))
    for ax, col, lab in ((axes[0], "proc_hit", "Process top-1 (%)"), (axes[1], "loop_hit1", "Loop top-1 (%)"),
                         (axes[2], "tag_hit3", "Tag hit@3 (%)")):
        for i, m in enumerate(ms):
            v = 100 * pd.to_numeric(g[g.method == m][col], errors="coerce").values.astype(float)
            if np.all(np.isnan(v)):
                continue
            ax.plot([np.nanmin(v), np.nanmax(v)], [i, i], color=COLOR[m], lw=2, alpha=0.4)
            ax.scatter(v, [i] * len(v), color=COLOR[m], s=22, marker=MARKER[m], zorder=3)
        ax.set_xlim(0, 102); ax.set_xlabel(lab)
        ax.set_yticks(range(len(ms))); ax.set_yticklabels([SHORT[m] for m in ms])
    axes[0].invert_yaxis()
    for k, ax in enumerate(axes):
        P.panel_label(ax, "abc"[k])
    P.save(fig, "F17_seeds")
    reg("F17_seeds", "Seed-to-seed variability of the stochastic methods on HAI 21.03 (seeds 0–2; bars span the range)")


# ------------------------------------------------------------------ F18 propagation
def f_propagation(D):
    rows, offs = context_rows(D)
    ep = D.episodes
    picks = [m for m in ("PERSIST", "TCN") if Path(str(C.RUNS / C.PRIMARY / f"{m}_s0.npz")).exists()]
    procs = ["P1", "P2", "P3", "P4"]
    groups = [np.flatnonzero(D.process == p) for p in procs]
    taus = np.arange(1, 241)
    fig, axes = plt.subplots(len(picks), 3, figsize=(7.4, 2.4 * len(picks)), sharex=True, sharey=True,
                             gridspec_kw=dict(wspace=0.07, hspace=0.25))
    axes = np.atleast_2d(axes)
    for i, m in enumerate(picks):
        run, _ = load_run(C.PRIMARY, m, 0)
        for j, gt in enumerate(["P1", "P2", "P3"]):
            ax = axes[i, j]
            sel = [k for k, e in enumerate(ep.itertuples()) if e.processes == gt]
            share = np.full((len(sel), len(taus), 4), np.nan)
            for a_, k in enumerate(sel):
                e = ep.iloc[k]
                on = e.start - rows[offs[k]]
                X = run["S_ctx"][offs[k] + on: offs[k] + on + e.length].astype(float)
                E = np.cumsum(X, 0) / np.arange(1, len(X) + 1)[:, None]
                Gp = np.stack([E[:, g].max(1) for g in groups], 1)
                Gp = Gp / Gp.sum(1, keepdims=True)
                n = min(len(Gp), len(taus))
                share[a_, :n] = Gp[:n]
            valid = (~np.isnan(share[:, :, 0])).sum(0) >= max(2, int(np.ceil(len(sel) / 2)))
            mean = np.where(valid[:, None], np.nansum(share, 0) / np.maximum((~np.isnan(share)).sum(0), 1), np.nan)
            for q, p in enumerate(procs):
                ax.plot(taus, 100 * mean[:, q], color=P.PROC_COLOR[p], lw=1.4, label=p)
            ax.set_xscale("log"); ax.set_title(f"{SHORT[m]}: {gt} attacks (n = {len(sel)})", fontsize=7.5)
            ax.set_xticks([1, 10, 100]); ax.set_xticklabels(["1", "10", "100"])
            if j == 0:
                ax.set_ylabel("Share of group evidence (%)")
            if i == len(picks) - 1:
                ax.set_xlabel("Seconds since onset")
    axes[0, 2].legend(fontsize=6.5, loc="upper right")
    P.save(fig, "F18_propagation")
    reg("F18_propagation", "Propagation of evidence across processes after single-process attacks on HAI 21.03: mean share "
        "of each process in the summed group scores (maximum aggregation) as evidence accumulates; curves stop when fewer "
        "than half of the episodes are still active")


if __name__ == "__main__":
    P.setup()
    D = Data(C.PRIMARY)
    ep = load_ep("A")
    f_design(); f_coverage(); f_examples(D); f_rq1(); f_confusion(); f_episode_map(ep); f_hitk(ep); f_type()
    f_observability(ep); f_tau(); f_km(); f_rmst(); f_pareto(); f_aggregator(); f_det_loc(); f_replication()
    f_seeds(ep); f_propagation(D)
    json.dump(REG, open(C.FIGURES / "registry.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"{len(REG)} figures written")
