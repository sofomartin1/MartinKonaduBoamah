"""Fit every localisation method and store per-channel evidence on episode context rows.

Resumable: a method/seed whose run files already exist is skipped.
usage: python scripts/03_scores.py [--version hai-21.03] [--methods RIDGE TCN ...] [--seeds 0 1 2]
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc.data import Data  # noqa: E402
from hailoc import scoring as S, attribution as A  # noqa: E402


def exists(version, method, seed, tag=""):
    return Path(str(S.run_path(version, method, seed, tag)) + ".npz").exists()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", default=None)
    ap.add_argument("--methods", nargs="*", default=None)
    ap.add_argument("--seeds", nargs="*", type=int, default=None)
    a = ap.parse_args()
    C.ensure_dirs()
    versions = [a.version] if a.version else [C.PRIMARY, C.REPLICATION]
    for version in versions:
        logf = open(C.LOGS / f"03_scores_{version}.log", "a", encoding="utf-8")

        def log(msg):
            print(msg, flush=True); logf.write(msg + "\n"); logf.flush()

        D = Data(version)
        primary = version == C.PRIMARY
        roster = a.methods or (C.METHODS if primary else C.REPL_METHODS)
        seeds = a.seeds or (C.SEEDS if primary else [0])
        for m in ["ZSCORE", "PERSIST", "PCA", "RIDGE"]:
            if m in roster and not exists(version, m, 0):
                S.residual_method(D, m, 0, log=log)
        if "CORR" in roster and not exists(version, "CORR", 0):
            S.corr_method(D, log=log)
        for seed in seeds:
            if "LSTM" in roster and not exists(version, "LSTM", seed):
                S.residual_method(D, "LSTM", seed, log=log)
            if ("TCN" in roster or "IG_TCN" in roster) and not (exists(version, "TCN", seed) and exists(version, "IG_TCN", seed)):
                model, _ = S.residual_method(D, "TCN", seed, log=log)
                A.ig_tcn(D, seed, model, log=log)
            if "SHAP_IF" in roster and not exists(version, "SHAP_IF", seed):
                A.shap_iforest(D, seed, log=log)
            if primary and ("SHAP_GBDT" in roster or "GBDT_PROC" in roster) and not exists(version, "SHAP_GBDT", seed):
                A.supervised(D, seed, log=log)
        logf.close()


if __name__ == "__main__":
    main()
