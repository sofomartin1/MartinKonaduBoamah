"""Summary statistics for every research question (primary condition: seed 0, max aggregator)."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc import stats as S  # noqa: E402

A = C.ANALYSIS
NONINF_MARGIN = 0.10  # five of fifty episodes


def load(prefix):
    ep = pd.read_csv(A / f"{prefix}_episode.csv")
    meta = pd.read_csv(A / f"{prefix}_episodes_meta.csv")
    return ep.merge(meta[["ep", "attack_id", "processes", "controllers", "attack_type", "combined", "short_term",
                          "long_term", "n_processes", "n_tags_candidate", "length"]], on="ep", how="left")


def primary(ep, agg="max", seed=0):
    return ep[(ep["agg"] == agg) & (ep.seed == seed)]


def per_process_recall(d):
    out = {}
    for p in ("P1", "P2", "P3"):
        sub = d[d.processes.str.contains(p)]
        out[p] = sub.proc_hit.mean() if len(sub) else np.nan
    out["macro"] = np.nanmean(list(out.values()))
    return out


def main_table(ep, prefix, methods):
    rows = []
    base = pd.read_csv(A / f"{prefix}_baselines.csv")
    for m in methods:
        d = primary(ep[ep.method == m])
        if d.empty:
            continue
        r = dict(method=m)
        for col in ["proc_hit", "loop_hit1", "loop_hit3", "tag_hit1", "tag_hit3", "tag_hit5", "tag_hit10", "mrr"]:
            if col in d and d[col].notna().any():
                r[col], r[col + "_lo"], r[col + "_hi"] = S.boot_ci(d[col].astype(float))
                r[col + "_n"] = int(d[col].notna().sum())
        if m in C.STOCHASTIC:
            allseeds = ep[(ep.method == m) & (ep["agg"] == "max")]
            for col in ("proc_hit", "loop_hit1", "tag_hit3"):
                if col in allseeds and allseeds[col].notna().any():
                    g = allseeds.groupby("seed")[col].apply(lambda x: x.astype(float).mean())
                    r[col + "_seedmean"], r[col + "_seedsd"] = g.mean(), g.std(ddof=1)
        ppr = per_process_recall(d)
        r.update({f"recall_{k}": v for k, v in ppr.items()})
        r["p4_rate"] = d.p4_pred.mean()
        r["both_top2"] = d.proc_both_top2.mean()
        r["n_multi"] = int(d.proc_both_top2.notna().sum())
        for kind in ("proc", "loop"):
            if f"ttl_{kind}" in d and d[f"ttl_{kind}"].notna().any():
                km = S.km(d[f"ttl_{kind}"], d[f"event_{kind}"])
                r[f"median_ttl_{kind}"] = S.km_median(km)
                r[f"rmst_{kind}"], r[f"rmst_{kind}_lo"], r[f"rmst_{kind}_hi"] = S.rmst_ci(d[f"ttl_{kind}"], d[f"event_{kind}"])
                r[f"event_{kind}"] = d[f"event_{kind}"].mean()
        rows.append(r)
    for b in ("MAJORITY", "RANDOM"):
        d = base[base.method == b]
        r = dict(method=b)
        for col in ["proc_hit", "loop_hit1", "loop_hit3", "tag_hit1", "tag_hit3", "tag_hit5", "tag_hit10"]:
            if col in d and d[col].notna().any():
                r[col] = d[col].mean(); r[col + "_n"] = int(d[col].notna().sum())
        rows.append(r)
    return pd.DataFrame(rows)


def seed_table(ep):
    rows = []
    for m in C.METHODS:
        if m not in C.STOCHASTIC:
            continue
        d = ep[(ep.method == m) & (ep["agg"] == "max")]
        g = d.groupby("seed")[["proc_hit", "loop_hit1", "tag_hit3", "mrr"]].mean()
        if g.empty:
            continue
        r = dict(method=m, n_seeds=len(g))
        for col in g.columns:
            if g[col].notna().any():
                r[col + "_mean"], r[col + "_sd"] = g[col].mean(), g[col].std(ddof=1)
                r[col + "_min"], r[col + "_max"] = g[col].min(), g[col].max()
        rows.append(r)
    return pd.DataFrame(rows)


def pairwise(ep, col, methods, ref="RIDGE"):
    d = primary(ep)
    piv = d.pivot(index="ep", columns="method", values=col)
    ms = [m for m in methods if m in piv and piv[m].notna().all()]
    q, pq, dfq = S.cochran(piv[ms].astype(int).values)
    rows = []
    for m in ms:
        if m == ref:
            continue
        b, c, p = S.mcnemar_exact(piv[m].values, piv[ref].values)
        diff, lo, hi = S.paired_boot_diff(piv[m].astype(float), piv[ref].astype(float))
        _, _, _, slo, shi, _ = S.tango(piv[m].astype(float), piv[ref].astype(float))
        rows.append(dict(metric=col, method=m, ref=ref, only_method=b, only_ref=c, p=p, diff=diff, diff_lo=lo, diff_hi=hi,
                         diff_lo_score=slo, diff_hi_score=shi))
    out = pd.DataFrame(rows)
    out["p_holm"] = S.holm(out.p.values)
    out["cochran_q"], out["cochran_p"], out["cochran_df"], out["n_methods"] = q, pq, dfq, len(ms)
    return out


def by_type(ep):
    d = primary(ep)
    rows = []
    for m in C.METHODS:
        x = d[d.method == m]
        if x.empty:
            continue
        for fac in ("attack_type", "combined", "short_term"):
            for lev, g in x.groupby(fac):
                r = dict(method=m, factor=fac, level=str(lev), n=len(g), proc_hit=g.proc_hit.mean())
                if "loop_hit1" in g and g.loop_hit1.notna().any():
                    r["loop_hit1"] = g.loop_hit1.mean()
                if "tag_hit3" in g and g.tag_hit3.notna().any():
                    t = g[g.tag_hit3.notna()]
                    r.update(n_tag=len(t), tag_hit1=t.tag_hit1.mean(), tag_hit3=t.tag_hit3.mean(),
                             tag_hit10=t.tag_hit10.mean(), mrr=t.mrr.mean())
                rows.append(r)
    return pd.DataFrame(rows)


def by_loop(ep):
    d = primary(ep)
    d = d[~d.controllers.str.contains(";")]
    rows = []
    for (m, l), g in d.groupby(["method", "controllers"]):
        rows.append(dict(method=m, loop=l, n=len(g), proc_hit=g.proc_hit.mean(),
                         loop_hit1=g.loop_hit1.mean() if "loop_hit1" in g else np.nan,
                         loop_hit3=g.loop_hit3.mean() if "loop_hit3" in g else np.nan))
    return pd.DataFrame(rows)


def curves(prefix):
    cu = pd.read_csv(A / f"{prefix}_curve.csv")
    cu = cu[(cu["agg"] == "max") & (cu.seed == 0)]
    rows = []
    for (m, tau), g in cu.groupby(["method", "tau"]):
        r = dict(method=m, tau=tau)
        for col in ("proc_hit", "loop_hit1", "tag_hit3"):
            if col in g and g[col].notna().any():
                r[col], r[col + "_lo"], r[col + "_hi"] = S.boot_ci(g[col].astype(float))
        rows.append(r)
    return pd.DataFrame(rows)


def km_curves(ep, prefix):
    d = primary(ep)
    rows = []
    for m, g in d.groupby("method"):
        for kind in ("proc", "loop"):
            if f"ttl_{kind}" in g and g[f"ttl_{kind}"].notna().any():
                k = S.km(g[f"ttl_{kind}"], g[f"event_{kind}"])
                k["method"], k["kind"] = m, kind
                rows.append(k)
    return pd.concat(rows)


def noninferiority(ep):
    d = primary(ep)
    piv = {c: d.pivot(index="ep", columns="method", values=c) for c in ("proc_hit", "loop_hit1", "tag_hit3", "ttl_loop")}
    rows = []
    for light in ("PERSIST", "RIDGE"):
        for deep in ("LSTM", "TCN"):
            for c in ("proc_hit", "loop_hit1", "tag_hit3"):
                a, b = piv[c][light].astype(float), piv[c][deep].astype(float)
                diff, lo, hi = S.paired_boot_diff(a, b)
                n10, n01, _, slo, shi, p_ni = S.tango(a, b, margin=-NONINF_MARGIN)
                # decision rule: lower bound of the two-sided 95% bootstrap interval above -margin
                # (equivalent to a one-sided test at 2.5%); the score interval is a robustness check
                rows.append(dict(light=light, deep=deep, metric=c, n=int((a.notna() & b.notna()).sum()),
                                 only_light=n10, only_deep=n01, diff=diff, lo=lo, hi=hi,
                                 lo_score=slo, hi_score=shi, p_ni_score=p_ni,
                                 margin=-NONINF_MARGIN, noninferior=lo > -NONINF_MARGIN, superior=lo > 0,
                                 noninferior_score=slo > -NONINF_MARGIN))
    return pd.DataFrame(rows)


def gt_sensitivity(ep, prefix):
    """Loop and process accuracy under alternative ground-truth scorings and episode subsets."""
    d = primary(ep)
    meta = pd.read_csv(A / f"{prefix}_episodes_meta.csv")
    ob = A / f"{prefix}_observability.csv"
    vis = set()
    if ob.exists():
        o = pd.read_csv(ob)
        vis = set(o[o.recorded & o.visible].ep)
    single_loop = set(meta[~meta.controllers.str.contains(";")].ep)
    subsets = [
        ("all", "All episodes", set(meta.ep), "loop_hit1"),
        ("strict", "All episodes, strict: every targeted loop in the top m", set(meta.ep), "loop_all_topm"),
        ("single_primitive", "Single-primitive episodes", set(meta[~meta.combined].ep), "loop_hit1"),
        ("combined", "Combined episodes, lenient: any targeted loop first", set(meta[meta.combined].ep), "loop_hit1"),
        ("combined_strict", "Combined episodes, strict", set(meta[meta.combined].ep), "loop_all_topm"),
        ("single_loop", "Episodes targeting one control loop", single_loop, "loop_hit1"),
        ("doc_consistent", "Episodes without documentation conflicts", set(meta[meta.doc_consistent].ep), "loop_hit1"),
        ("visible", "Episodes with a visibly manipulated recorded target", vis, "loop_hit1"),
    ]
    rows = []
    for m, g in d.groupby("method"):
        if "loop_hit1" not in g or g.loop_hit1.isna().all():
            continue
        for key, label, eps, col in subsets:
            x = g[g.ep.isin(eps)]
            if x.empty:
                continue
            v, lo, hi = S.boot_ci(x[col].astype(float))
            rows.append(dict(method=m, subset=key, label=label, n=len(x), loop=v, loop_lo=lo, loop_hi=hi,
                             proc_hit=x.proc_hit.mean()))
    return pd.DataFrame(rows)


def ttl_operational(prefix, methods):
    """Kaplan-Meier summaries of time-to-localise anchored at each method's own first alarm (seed 0)."""
    at = pd.read_csv(A / f"{prefix}_at_alarm.csv")
    at = at[at.seed == 0].assign(detector="own")
    cx = A / f"{prefix}_cross_alarm.csv"
    if cx.exists():
        at = pd.concat([at, pd.read_csv(cx)])
    ep = primary(load(prefix))
    rows = []
    for (det, m), g in at.groupby(["detector", "method"], sort=False):
        if m not in methods:
            continue
        al = g[g.alarm.astype(bool)]
        r = dict(detector=det, method=m, n=len(g), alarm_rate=g.alarm.astype(bool).mean(),
                 median_delay=al.delay.median(),
                 loop_hit_at=al.loop_hit_at.astype(float).mean() if "loop_hit_at" in al and len(al) else np.nan)
        for kind in ("proc", "loop"):
            col = f"ttl_{kind}_op"
            if col not in g or g[col].isna().all():
                continue
            k = S.km(g[col], g[f"event_{kind}_op"])
            r[f"event_{kind}_op"] = g[f"event_{kind}_op"].mean()
            r[f"median_{kind}_op"] = S.km_median(k)
            r[f"rmst_{kind}_op"], r[f"rmst_{kind}_op_lo"], r[f"rmst_{kind}_op_hi"] = S.rmst_ci(g[col], g[f"event_{kind}_op"])
            o = ep[ep.method == m]
            if f"ttl_{kind}" in o and o[f"ttl_{kind}"].notna().any():
                r[f"rmst_{kind}_onset"] = S.rmst(o[f"ttl_{kind}"], o[f"event_{kind}"])
                r[f"event_{kind}_onset"] = o[f"event_{kind}"].mean()
        rows.append(r)
    return pd.DataFrame(rows)


def aggregator_table(ep):
    d = ep[ep.seed == 0]
    rows = []
    for (m, agg), g in d.groupby(["method", "agg"]):
        r = dict(method=m, agg=agg, proc_hit=g.proc_hit.mean())
        if "loop_hit1" in g:
            r.update(loop_hit1=g.loop_hit1.mean(), loop_hit3=g.loop_hit3.mean(), p4_rate=g.p4_pred.mean())
        rows.append(r)
    return pd.DataFrame(rows)


def confusion(ep):
    d = primary(ep)
    d = d.assign(gt=d.processes.str.replace(";", "+"))
    return d.groupby(["method", "gt", "proc_pred"]).size().rename("n").reset_index()


def detection_tables(prefix):
    det = pd.read_csv(A / f"{prefix}_detection.csv")
    al = pd.read_csv(A / f"{prefix}_alarm.csv")
    at = pd.read_csv(A / f"{prefix}_at_alarm.csv")
    g = al.groupby(["method", "seed"]).agg(alarm_rate=("alarm", "mean"), median_delay=("delay", "median")).reset_index()
    hits = [c for c in at.columns if c.startswith(("proc_hit", "loop_hit", "tag_hit3"))]
    at[hits] = at[hits].astype(float)
    h = at[at.alarm.astype(bool)].groupby(["method", "seed"])[hits].mean().reset_index()
    h = h[[c for c in h.columns if c in ("method", "seed") or c.startswith(("proc_hit", "loop_hit", "tag_hit3"))]]
    return det.merge(g, on=["method", "seed"]).merge(h, on=["method", "seed"], how="left")


def sensitivity_tables(ep):
    sr = pd.read_csv(A / "A_sensitivity_runs.csv")
    meta = pd.read_csv(A / "A_episodes_meta.csv")
    late = set(meta[meta.file.isin(["test3", "test4", "test5"])].ep)
    rows = []
    base = primary(ep)
    for name, g in sr.groupby("method"):
        m, tag = name.split("_", 1)
        sub = g[g.ep.isin(late)] if tag == "T1" else g
        ref = base[(base.method == m) & (base.ep.isin(sub.ep))]
        rows.append(dict(variant=tag, method=m, n=len(sub), proc_hit=sub.proc_hit.mean(), loop_hit1=sub.loop_hit1.mean(),
                         tag_hit3=sub.tag_hit3.mean(), ref_proc_hit=ref.proc_hit.mean(),
                         ref_loop_hit1=ref.loop_hit1.mean(), ref_tag_hit3=ref.tag_hit3.mean()))
    ev = pd.read_csv(A / "A_evidence.csv"); stb = pd.read_csv(A / "A_stability.csv")
    for (m, kind), g in ev.groupby(["method", "evidence"]):
        ref = base[base.method == m]
        rows.append(dict(variant="evidence_" + kind, method=m, n=len(g), proc_hit=g.proc_hit.mean(),
                         loop_hit1=g.loop_hit1.mean() if "loop_hit1" in g else np.nan,
                         tag_hit3=g.tag_hit3.mean() if "tag_hit3" in g else np.nan,
                         ref_proc_hit=ref.proc_hit.mean(), ref_loop_hit1=ref.loop_hit1.mean(), ref_tag_hit3=ref.tag_hit3.mean()))
    stab = []
    for (m, s), g in pd.concat([stb, primary(ep).assign(stability=C.STABILITY)]).groupby(["method", "stability"]):
        k = S.km(g.ttl_proc, g.event_proc)
        stab.append(dict(method=m, stability=s, median_ttl_proc=S.km_median(k), rmst_proc=S.rmst(g.ttl_proc, g.event_proc),
                         event_proc=g.event_proc.mean()))
    return pd.DataFrame(rows), pd.DataFrame(stab)


def observability_effect(ep):
    ob = pd.read_csv(A / "A_observability.csv")
    vis = ob[ob.recorded].groupby("ep").visible.any().rename("target_visible").reset_index()
    d = primary(ep).merge(vis, on="ep", how="left")
    d["target_visible"] = d.target_visible.fillna(False)
    rows = []
    for (m, v), g in d.groupby(["method", "target_visible"]):
        t = g[g.tag_hit3.notna()] if "tag_hit3" in g else g.iloc[:0]
        rows.append(dict(method=m, target_visible=bool(v), n=len(g), proc_hit=g.proc_hit.mean(),
                         loop_hit1=g.loop_hit1.mean() if "loop_hit1" in g else np.nan,
                         n_tag=len(t), tag_hit3=t.tag_hit3.mean() if len(t) else np.nan,
                         mrr=t.mrr.mean() if len(t) else np.nan))
    return pd.DataFrame(rows)


def replication(epA, epB):
    rows = []
    for m in C.REPL_METHODS:
        for lab, ep in (("hai-21.03", epA), ("hai-22.04", epB)):
            d = primary(ep[ep.method == m])
            if d.empty:
                continue
            r = dict(method=m, version=lab, n=len(d))
            for col in ("proc_hit", "loop_hit1", "loop_hit3", "tag_hit3", "mrr"):
                r[col], r[col + "_lo"], r[col + "_hi"] = S.boot_ci(d[col].astype(float))
            k = S.km(d.ttl_proc, d.event_proc)
            r["median_ttl_proc"] = S.km_median(k)
            r["rmst_proc"] = S.rmst(d.ttl_proc, d.event_proc)
            r["p4_rate"] = d.p4_pred.mean()
            rows.append(r)
    return pd.DataFrame(rows)


if __name__ == "__main__":
    epA = load("A")
    main_table(epA, "A", C.METHODS).to_csv(A / "S_main.csv", index=False)
    seed_table(epA).to_csv(A / "S_seeds.csv", index=False)
    pw = [pairwise(epA, c, [m for m in C.METHODS if m != "GBDT_PROC" or c == "proc_hit"]) for c in ("proc_hit", "loop_hit1")]
    pd.concat(pw).to_csv(A / "S_pairwise.csv", index=False)
    by_type(epA).to_csv(A / "S_bytype.csv", index=False)
    by_loop(epA).to_csv(A / "S_byloop.csv", index=False)
    curves("A").to_csv(A / "S_curves.csv", index=False)
    km_curves(epA, "A").to_csv(A / "S_km.csv", index=False)
    noninferiority(epA).to_csv(A / "S_noninferiority.csv", index=False)
    aggregator_table(epA).to_csv(A / "S_aggregator.csv", index=False)
    confusion(epA).to_csv(A / "S_confusion.csv", index=False)
    detection_tables("A").to_csv(A / "S_detection.csv", index=False)
    sens, stab = sensitivity_tables(epA)
    sens.to_csv(A / "S_sensitivity.csv", index=False); stab.to_csv(A / "S_stability.csv", index=False)
    observability_effect(epA).to_csv(A / "S_observability.csv", index=False)
    ttl_operational("A", C.METHODS).to_csv(A / "S_ttl_operational.csv", index=False)
    gts = [gt_sensitivity(epA, "A").assign(version=C.PRIMARY)]
    if (A / "B_episode.csv").exists():
        epB = load("B")
        gts.append(gt_sensitivity(epB, "B").assign(version=C.REPLICATION))
        ttl_operational("B", C.REPL_METHODS).to_csv(A / "S_ttl_operational_B.csv", index=False)
    pd.concat(gts).to_csv(A / "S_gt_sensitivity.csv", index=False)
    if (A / "B_episode.csv").exists():
        replication(epA, epB).to_csv(A / "S_replication.csv", index=False)
        main_table(epB, "B", C.REPL_METHODS).to_csv(A / "S_main_B.csv", index=False)
        detection_tables("B").to_csv(A / "S_detection_B.csv", index=False)
        by_type(epB).to_csv(A / "S_bytype_B.csv", index=False)
    print("stats written")
