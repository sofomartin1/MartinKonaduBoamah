"""Cross-check every table and figure against the underlying episode records and run files.

Exits with status 1 if any check fails; writes outputs/logs/consistency_report.csv.
"""
import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc import stats as S  # noqa: E402
from hailoc.data import Data  # noqa: E402
from hailoc.scoring import load_run, context_rows  # noqa: E402
from hailoc.localise import Evaluator, p_random_topk  # noqa: E402
from hailoc.etapr import etapr  # noqa: E402
from hailoc.plotting import SHORT  # noqa: E402

A, T = C.ANALYSIS, C.TABLES
RES = []


def check(name, ok, detail=""):
    RES.append(dict(check=name, passed=bool(ok), detail=str(detail)[:300]))
    print(("PASS " if ok else "FAIL ") + name + (f" — {detail}" if not ok else ""))


def tab(tid):
    return pd.read_csv(T / f"{tid}.csv", dtype=str, keep_default_na=False)


def first_num(s):
    m = re.search(r"[-+−]?\d+(?:\.\d+)?", str(s).replace("−", "-"))
    return float(m.group()) if m else np.nan


def close(a, b, tol=0.051):
    return (np.isnan(a) and np.isnan(b)) or abs(a - b) <= tol


def main():
    epA = pd.read_csv(A / "A_episode.csv")
    meta = pd.read_csv(A / "A_episodes_meta.csv")
    prim = epA[(epA["agg"] == "max") & (epA.seed == 0)]
    smain = pd.read_csv(A / "S_main.csv").set_index("method")

    # ---------------- data and ground truth
    D = Data(C.PRIMARY)
    check("21.03 has 50 episodes", len(D.episodes) == 50, len(D.episodes))
    lab = D.meta
    for p in ("P1", "P2", "P3"):
        n_lab = sum(lab[f"attack_{p}"].values[e.start:e.end + 1].any() for e in D.episodes.itertuples())
        n_gt = D.episodes.processes.str.contains(p).sum()
        check(f"per-process label count {p} equals ground truth", n_lab == n_gt, (n_lab, n_gt))
    tab21 = pd.read_csv(C.DATA_PROC / C.PRIMARY / "attack_table.csv")
    check("21.03 documentation rows map one-to-one to episodes", tab21.no.nunique() == len(D.episodes))
    info = json.load(open(C.DATA_PROC / C.PRIMARY / "channels.json"))
    check("no training timestamp occurs in a test file",
          True if not info else sum(info["train_rows_removed_test_overlap"]) == 43202, info["train_rows_removed_test_overlap"])
    eb = pd.read_csv(C.DATA_PROC / C.REPLICATION / "episodes.csv")
    check("22.04 has 58 episodes", len(eb) == 58, len(eb))
    check("candidate channels 57 / 68", (len(D.channels), len(json.load(open(C.DATA_PROC / C.REPLICATION / "channels.json"))["channels"])) == (57, 68))

    # ---------------- run files
    rows, offs = context_rows(D)
    for m in C.METHODS:
        seeds = C.SEEDS if m in C.STOCHASTIC else [0]
        for s in seeds:
            p = C.RUNS / C.PRIMARY / f"{m}_s{s}.npz"
            ok = p.exists()
            if ok:
                r, _ = load_run(C.PRIMARY, m, s)
                key = "P_ctx" if m == "GBDT_PROC" else "S_ctx"
                ok = r[key].shape[0] == len(rows) and np.isfinite(r[key]).all() and len(r["det_te"]) == len(D.Xte)
            check(f"run file {m} s{s} complete and finite", ok)
    for m in C.REPL_METHODS:
        check(f"replication run {m} s0 exists", (C.RUNS / C.REPLICATION / f"{m}_s0.npz").exists())

    # ---------------- episode records
    for m in C.METHODS:
        for s in (C.SEEDS if m in C.STOCHASTIC else [0]):
            n = len(epA[(epA.method == m) & (epA.seed == s) & (epA["agg"] == "max")])
            check(f"{m} s{s}: 50 episode records", n == 50, n)

    # recompute a stored episode outcome from the raw run file
    ev = Evaluator(D)
    for m in ("PERSIST", "RIDGE", "TCN"):
        run, _ = load_run(C.PRIMARY, m, 0)
        r, _ = ev.evaluate(run, m, 0, aggs=("max",))
        st = prim[prim.method == m].set_index("ep")
        rr = r.set_index("ep")
        bad = [c for c in ("proc_hit", "loop_hit1", "ttl_proc", "tag_rank", "mrr", "ttl_loop")
               if not (np.isclose(rr[c].astype(float), st[c].astype(float), rtol=0, atol=1e-12)
                       | (rr[c].isna() & st[c].isna())).all()]
        check(f"{m}: re-evaluation reproduces stored episode records", not bad, bad)

    # ---------------- summary statistics vs records
    for m in C.METHODS:
        d = prim[prim.method == m]
        for col in ("proc_hit", "loop_hit1", "loop_hit3", "tag_hit1", "tag_hit3", "tag_hit10", "mrr"):
            if col in d and d[col].notna().any():
                check(f"S_main {m} {col} equals record mean", close(smain.loc[m, col], d[col].astype(float).mean(), 1e-9))
        if d.ttl_proc.notna().any():
            check(f"S_main {m} RMST(process) recomputes",
                  close(smain.loc[m, "rmst_proc"], S.rmst(d.ttl_proc, d.event_proc), 1e-9))
            lo, hi = smain.loc[m, "proc_hit_lo"], smain.loc[m, "proc_hit_hi"]
            check(f"S_main {m} process CI brackets estimate", lo <= smain.loc[m, "proc_hit"] <= hi)
    base = pd.read_csv(A / "A_baselines.csv")
    K = len(ev.loop_names)
    exp_loop = np.mean([len(e["loops"]) / K for e in ev.eps])
    check("random loop baseline analytic", close(base[base.method == "RANDOM"].loop_hit1.mean(), exp_loop, 1e-9))
    check("random tag hit@3 analytic", close(base[base.method == "RANDOM"].tag_hit3.mean(),
                                             np.nanmean([p_random_topk(57, len(e["tags"]), 3) if e["tags"] else np.nan for e in ev.eps]), 1e-9))
    check("majority baseline = share of episodes involving P1",
          close(smain.loc["MAJORITY", "proc_hit"], meta.processes.str.contains("P1").mean(), 1e-9))

    # ---------------- tables vs statistics
    t7 = tab("T07_rq1_main")
    for _, r in t7.iterrows():
        m = {v: k for k, v in SHORT.items()}[r["Method"]]
        check(f"T07 {m} process value", close(first_num(r["Process top-1 (%)"]), 100 * smain.loc[m, "proc_hit"]))
        if r["Loop top-1 (%)"] != "–":
            check(f"T07 {m} loop value", close(first_num(r["Loop top-1 (%)"]), 100 * smain.loc[m, "loop_hit1"]))
    t11 = tab("T11_rq2_tags")
    for _, r in t11.iterrows():
        m = {v: k for k, v in SHORT.items()}[r["Method"]]
        check(f"T11 {m} hit@3", close(first_num(r["Hit@3 (%)"]), 100 * smain.loc[m, "tag_hit3"]))
        check(f"T11 {m} hit@10", close(first_num(r["Hit@10 (%)"]), 100 * smain.loc[m, "tag_hit10"]))
    t17 = tab("T17_rq4_compute")
    for _, r in t17.iterrows():
        m = {v: k for k, v in SHORT.items()}[r["Method"]]
        if r["Loop top-1 (%)"] != "–":
            check(f"T17 {m} loop equals T07", close(first_num(r["Loop top-1 (%)"]), 100 * smain.loc[m, "loop_hit1"]))
    t15 = tab("T15_rq3_ttl")
    for _, r in t15.iterrows():
        m = {v: k for k, v in SHORT.items()}[r["Method"]]
        check(f"T15 {m} RMST process", close(first_num(r["Process: RMST₁₂₀ (s)"]), smain.loc[m, "rmst_proc"]))
    curves = pd.read_csv(A / "S_curves.csv")
    t14 = tab("T14_rq3_tau")
    for _, r in t14.iterrows():
        m = {v: k for k, v in SHORT.items()}[r["Method"]]
        v = curves[(curves.method == m) & (curves.tau == 60)].proc_hit.iloc[0]
        check(f"T14 {m} process at 60 s", close(first_num(r["τ = 60 s"]), 100 * v))
    # curve at tau >= length equals whole-episode call
    cu = pd.read_csv(A / "A_curve.csv")
    cu = cu[(cu["agg"] == "max") & (cu.seed == 0) & (cu.tau == 240)].merge(prim[["method", "ep", "proc_hit", "L"]],
                                                                           on=["method", "ep"], suffixes=("_c", ""))
    sub = cu[cu.L <= 240]
    check("curve at τ ≥ length equals whole-episode call", (sub.proc_hit_c == sub.proc_hit).all())
    # noninferiority = difference of means
    ni = pd.read_csv(A / "S_noninferiority.csv")
    for r in ni.itertuples():
        dd = smain.loc[r.light, r.metric] - smain.loc[r.deep, r.metric]
        check(f"non-inferiority Δ {r.light}-{r.deep} {r.metric}", close(r.diff, dd, 1e-9))
        check(f"non-inferiority discordant counts {r.light}-{r.deep} {r.metric}",
              close((r.only_light - r.only_deep) / r.n, r.diff, 1e-9))
        check(f"non-inferiority score CI brackets Δ {r.light}-{r.deep} {r.metric}", r.lo_score <= r.diff <= r.hi_score)
        check(f"non-inferiority decision = bootstrap bound vs margin {r.light}-{r.deep} {r.metric}",
              bool(r.noninferior) == (r.lo > r.margin))
    # operational time-to-localise: first call equals the alarm-time call; never earlier than the alarm
    at = pd.read_csv(A / "A_at_alarm.csv")
    at0 = at[(at.seed == 0) & at.alarm.astype(bool) & (at.method != "GBDT_PROC")]
    check("operational TTL never precedes the first alarm",
          (at0[at0.event_loop_op == 1].ttl_loop_op >= at0[at0.event_loop_op == 1].delay).all())
    first_ok = at0[(at0.event_loop_op == 1) & (at0.ttl_loop_op == at0.delay)]
    check("operational TTL at the alarm second implies a correct alarm-time call", first_ok.loop_hit_at.astype(bool).all())
    check("operational TTL censored for every non-alarmed episode",
          (at[~at.alarm.astype(bool)].event_proc_op == 0).all())
    gts = pd.read_csv(A / "S_gt_sensitivity.csv")
    for m in ("PERSIST", "RIDGE", "LSTM"):
        v = gts[(gts.version == C.PRIMARY) & (gts.method == m) & (gts.subset == "all")].loop.iloc[0]
        check(f"ground-truth sensitivity 'all' equals primary loop accuracy {m}", close(v, smain.loc[m, "loop_hit1"], 1e-9))
        s_ = gts[(gts.version == C.PRIMARY) & (gts.method == m) & (gts.subset == "strict")].loop.iloc[0]
        check(f"strict loop scoring not above lenient {m}", s_ <= v + 1e-12)
    single = prim[~prim.ep.isin(meta[meta.controllers.str.contains(";")].ep) & prim.loop_hit1.notna()]
    check("strict equals lenient scoring in single-loop episodes", (single.loop_all_topm == single.loop_hit1).all())
    # seeds: seed-0 member equals primary
    for m in C.STOCHASTIC:
        g = epA[(epA.method == m) & (epA["agg"] == "max")].groupby("seed").proc_hit.mean()
        check(f"{m}: three seeds evaluated", len(g) == 3, len(g))
    seeds_t = pd.read_csv(A / "S_seeds.csv").set_index("method")
    for m in C.STOCHASTIC:
        for col in ("proc_hit", "loop_hit1", "tag_hit3"):
            if col + "_seedmean" in smain and pd.notna(smain.loc[m].get(col + "_seedmean")):
                check(f"{m} {col}: seed mean in main table equals seed table",
                      close(smain.loc[m, col + "_seedmean"], seeds_t.loc[m, col + "_mean"], 1e-9))
    for _, r in tab("T07_rq1_main").iterrows():
        m = {v: k for k, v in SHORT.items()}[r["Method"]]
        if r["Loop top-1, 3 seeds (%)"] != "–":
            check(f"T07 {m} 3-seed loop value", close(first_num(r["Loop top-1, 3 seeds (%)"]), 100 * seeds_t.loc[m, "loop_hit1_mean"]))
    # confusion sums
    conf = pd.read_csv(A / "S_confusion.csv")
    for m, g in conf.groupby("method"):
        check(f"confusion {m} sums to 50", g.n.sum() == 50, g.n.sum())
    # by-type counts
    bt = pd.read_csv(A / "S_bytype.csv")
    for m, g in bt[bt.factor == "attack_type"].groupby("method"):
        check(f"by-type {m} counts sum to 50", g.n.sum() == 50)
    # sensitivity: past-only on 25 episodes
    sens = pd.read_csv(A / "S_sensitivity.csv")
    check("past-only training evaluated on 25 episodes", (sens[sens.variant == "T1"].n == 25).all())
    for r in sens[sens.variant != "T1"].itertuples():
        check(f"sensitivity ref {r.method} {r.variant} equals primary", close(r.ref_proc_hit, smain.loc[r.method, "proc_hit"], 1e-9))
    # detection recompute for one method
    det = pd.read_csv(A / "S_detection.csv")
    run, _ = load_run(C.PRIMARY, "RIDGE", 0)
    row, al = ev.detection(run, "RIDGE", 0)
    d0 = det[(det.method == "RIDGE") & (det.seed == 0)].iloc[0]
    check("eTaF1 Ridge recomputes", close(row["eTaF1"], d0.eTaF1, 1e-9))
    check("alarm rate Ridge recomputes", close(al.alarm.mean(), d0.alarm_rate, 1e-9))
    t6 = tab("T06_detection").set_index("Method")
    check("T06 Ridge eTaF1 matches", close(first_num(t6.loc["Ridge-VAR", "eTaF1"]), d0.eTaF1, 0.0006))
    # replication
    if (A / "S_replication.csv").exists():
        rep = pd.read_csv(A / "S_replication.csv")
        epB = pd.read_csv(A / "B_episode.csv")
        pb = epB[(epB["agg"] == "max") & (epB.seed == 0)]
        for m in C.REPL_METHODS:
            v = rep[(rep.method == m) & (rep.version == C.REPLICATION)]
            check(f"replication {m}: 58 records and mean matches",
                  len(pb[pb.method == m]) == 58 and close(v.loop_hit1.iloc[0], pb[pb.method == m].loop_hit1.mean(), 1e-9))
            v = rep[(rep.method == m) & (rep.version == C.PRIMARY)]
            check(f"replication {m}: 21.03 column equals primary", close(v.loop_hit1.iloc[0], smain.loc[m, "loop_hit1"], 1e-9))

    # ---------------- registries, files, wording
    treg = json.load(open(T / "registry.json", encoding="utf-8"))
    freg = json.load(open(C.FIGURES / "registry.json", encoding="utf-8"))
    check("every registered table has a CSV", all((T / f"{r['id']}.csv").exists() for r in treg))
    check("every registered figure has a PNG", all((C.FIGURES / f"{r['id']}.png").exists() for r in freg))
    banned = re.compile(r"hypothetic|simulat|synthetic|placeholder|dummy|edited|modified|nan\b", re.I)
    bad = []
    for r in treg:
        txt = (T / f"{r['id']}.csv").read_text(encoding="utf-8") + r["title"] + (r["note"] or "")
        if banned.search(txt):
            bad.append(r["id"])
    for r in freg:
        if banned.search(r["title"]):
            bad.append(r["id"])
    check("no prohibited wording or NaN in tables / captions", not bad, bad)
    empty = [r["id"] for r in treg if (tab(r["id"]) == "").any().any()]
    check("no empty cells in any table", not empty, empty)
    docx = C.OUT / "Tables_and_Figures.docx"
    if docx.exists():
        from docx import Document
        doc = Document(str(docx))
        caps = [p.text for p in doc.paragraphs if re.match(r"^(Table|Figure) \d+\.", p.text)]
        tn = [int(re.match(r"Table (\d+)", c).group(1)) for c in caps if c.startswith("Table")]
        fn = [int(re.match(r"Figure (\d+)", c).group(1)) for c in caps if c.startswith("Figure")]
        check("document table numbering sequential", tn == list(range(1, len(treg) + 1)), (len(tn), len(treg)))
        check("document figure numbering sequential", fn == list(range(1, len(freg) + 1)), (len(fn), len(freg)))
        check("document has one Word table per registered table", len(doc.tables) == len(treg), len(doc.tables))
        check("document has one picture per registered figure", len(doc.inline_shapes) == len(freg), len(doc.inline_shapes))
    out = pd.DataFrame(RES)
    out.to_csv(C.LOGS / "consistency_report.csv", index=False)
    print(f"\n{out.passed.sum()}/{len(out)} checks passed")
    sys.exit(0 if out.passed.all() else 1)


if __name__ == "__main__":
    main()
