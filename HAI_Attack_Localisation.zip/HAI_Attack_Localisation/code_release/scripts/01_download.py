"""Download HAI 21.03 and HAI 22.04 from the official GitHub repository and verify them.

HAI 21.03 files are stored as gzip blobs; HAI 22.04 files are Git-LFS objects whose SHA-256
is published in the LFS pointer file and is checked here.
"""
import hashlib
import json
import sys
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402


def fetch(url, dst, tries=6):
    for k in range(tries):
        try:
            tmp = dst.with_suffix(dst.suffix + ".part")
            with urllib.request.urlopen(url, timeout=120) as r, open(tmp, "wb") as f:
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
            tmp.replace(dst)
            return
        except Exception as e:  # network hiccups
            print(f"  retry {k + 1}: {e}")
            time.sleep(5 * (k + 1))
    raise RuntimeError(f"failed: {url}")


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    C.ensure_dirs()
    manifest = {}
    doc = C.DATA_RAW / "hai_dataset_technical_details.pdf"
    if not doc.exists():
        fetch(f"{C.RAW_BASE}/hai_dataset_technical_details.pdf", doc)
    manifest["hai_dataset_technical_details.pdf"] = sha256(doc)
    for version, v in C.VERSIONS.items():
        d = C.DATA_RAW / version
        d.mkdir(parents=True, exist_ok=True)
        for name in v["train"] + v["test"]:
            fn = name + v["ext"]
            dst = d / fn
            if v["lfs"]:
                ptr = urllib.request.urlopen(f"{C.RAW_BASE}/{version}/{fn}", timeout=60).read().decode().split()
                oid = ptr[ptr.index("oid") + 1].split(":")[1]
                if not dst.exists() or sha256(dst) != oid:
                    print("downloading", version, fn)
                    fetch(f"{C.LFS_BASE}/{version}/{fn}", dst)
                assert sha256(dst) == oid, f"checksum mismatch {dst}"
            elif not dst.exists():
                print("downloading", version, fn)
                fetch(f"{C.RAW_BASE}/{version}/{fn}", dst)
            manifest[f"{version}/{fn}"] = sha256(dst)
            print("ok", version, fn)
    json.dump(manifest, open(C.DATA_RAW / "sha256_manifest.json", "w"), indent=1)


if __name__ == "__main__":
    main()
