"""Evaluate every stored run: episode-level localisation, curves, detection, alarm-time localisation."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc.data import Data  # noqa: E402
from hailoc.scoring import load_run, run_path  # noqa: E402
from hailoc.localise import Evaluator, AGGS  # noqa: E402


def has(version, m, s, tag=""):
    return Path(str(run_path(version, m, s, tag)) + ".npz").exists()


def observability(D, ev):
    """Largest deviation of each documented candidate tag from its pre-onset median (training-SD units)."""
    rows = []
    for e, epi in zip(ev.eps, D.episodes.itertuples()):
        for t in [x for x in str(epi.tags).split(";") if x]:
            if t in ev.ch_index:
                c = ev.ch_index[t]
                pre = D.Xte[max(epi.start - 120, 0):epi.start, c]
                dur = D.Xte[epi.start:epi.end + 1, c]
                dev = float(np.abs(dur - np.median(pre)).max())
                rows.append(dict(ep=epi.ep, attack_id=epi.attack_id, tag=t, recorded=True, max_dev=dev, visible=dev >= 3.0))
            else:
                rows.append(dict(ep=epi.ep, attack_id=epi.attack_id, tag=t, recorded=False, max_dev=np.nan, visible=False))
    return pd.DataFrame(rows)


def evaluate_version(version, methods, seeds_for, prefix):
    D = Data(version)
    ev = Evaluator(D)
    E, CU, DET, ALM, AT, CMP = [], [], [], [], [], []
    for m in methods:
        for s in seeds_for(m):
            if not has(version, m, s):
                print("missing", version, m, s); continue
            run, info = load_run(version, m, s)
            aggs = AGGS if m in C.RESIDUAL else (("max",) if m == "GBDT_PROC" else ("max", "mean", "top2", "sum"))
            r, c = ev.evaluate(run, m, s, aggs=aggs)
            E.append(r); CU.append(c)
            det, al = ev.detection(run, m, s, supervised=m in C.SUPERVISED)
            DET.append(det); ALM.append(al)
            AT.append(ev.at_alarm(run, al, m, s))
            info = {k: v for k, v in info.items() if not isinstance(v, (list, dict))}
            CMP.append(info)
            print(version, m, s, "process acc", round(r[r["agg"] == "max"].proc_hit.mean(), 3), flush=True)
    # localisation triggered by another method's alarms (separate detector and localiser), primary seed
    XT = []
    alarms0 = {a.method.iloc[0]: a for a in ALM if a.seed.iloc[0] == 0}
    for det in [d for d in C.TRIGGER_DETECTORS if d in alarms0]:
        for m in methods:
            if m == "GBDT_PROC" or not has(version, m, 0):
                continue
            run, _ = load_run(version, m, 0)
            XT.append(ev.at_alarm(run, alarms0[det], m, 0).assign(detector=det))
    out = C.ANALYSIS
    if XT:
        pd.concat(XT).to_csv(out / f"{prefix}_cross_alarm.csv", index=False)
    pd.concat(E).to_csv(out / f"{prefix}_episode.csv", index=False)
    pd.concat(CU).to_csv(out / f"{prefix}_curve.csv", index=False)
    pd.DataFrame(DET).to_csv(out / f"{prefix}_detection.csv", index=False)
    pd.concat(ALM).to_csv(out / f"{prefix}_alarm.csv", index=False)
    pd.concat(AT).to_csv(out / f"{prefix}_at_alarm.csv", index=False)
    pd.DataFrame(CMP).to_csv(out / f"{prefix}_compute.csv", index=False)
    b, maj = ev.baselines()
    b.to_csv(out / f"{prefix}_baselines.csv", index=False)
    observability(D, ev).to_csv(out / f"{prefix}_observability.csv", index=False)
    D.episodes.to_csv(out / f"{prefix}_episodes_meta.csv", index=False)
    json.dump({"proc_names": ev.proc_names, "loop_names": ev.loop_names, "n_channels": len(D.channels),
               "majority": maj, "channels": D.channels,
               "loop_sizes": {l: int(len(g)) for l, g in zip(ev.loop_names, ev.loop_groups)},
               "proc_sizes": {p: int(len(g)) for p, g in zip(ev.proc_names, ev.proc_groups)}},
              open(out / f"{prefix}_setup.json", "w"), indent=1)
    return D, ev


def sensitivity(D, ev):
    v = D.version
    rows, ev_rows, st_rows = [], [], []
    for tag in ["_L10", "_L30", "_L120", "_RAW", "_T1"]:
        for m in ["ZSCORE", "PERSIST", "PCA", "RIDGE", "TCN"]:
            if has(v, m, 0, tag):
                run, _ = load_run(v, m, 0, tag)
                r, _ = ev.evaluate(run, m + tag, 0, aggs=("max",))
                rows.append(r)
    # evidence accumulation and stability window, primary seed, max aggregator
    for m in C.METHODS:
        if m == "GBDT_PROC" or not has(v, m, 0):
            continue
        run, _ = load_run(v, m, 0)
        for kind in ("trailing10", "ewma"):
            r, _ = ev.evaluate(run, m, 0, aggs=("max",), evidence=kind)
            r["evidence"] = kind; ev_rows.append(r)
        for S in (1, 10, 60):
            r, _ = ev.evaluate(run, m, 0, aggs=("max",), stability=S)
            r["stability"] = S; st_rows.append(r)
    pd.concat(rows).to_csv(C.ANALYSIS / "A_sensitivity_runs.csv", index=False)
    pd.concat(ev_rows).to_csv(C.ANALYSIS / "A_evidence.csv", index=False)
    pd.concat(st_rows).to_csv(C.ANALYSIS / "A_stability.csv", index=False)


if __name__ == "__main__":
    C.ensure_dirs()
    D, ev = evaluate_version(C.PRIMARY, C.METHODS, lambda m: C.SEEDS if m in C.STOCHASTIC else [0], "A")
    sensitivity(D, ev)
    if has(C.REPLICATION, "RIDGE", 0):
        evaluate_version(C.REPLICATION, C.REPL_METHODS, lambda m: [0], "B")
