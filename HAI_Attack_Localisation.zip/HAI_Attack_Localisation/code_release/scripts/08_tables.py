"""Build every manuscript table as CSV (outputs/tables) plus a registry with titles and notes."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc import groundtruth as G  # noqa: E402
from hailoc.plotting import SHORT  # noqa: E402

A = C.ANALYSIS
REG = []
PRIMARY_NOTE = ("Primary condition: seed 0, maximum aggregation over the channels of a group, evidence = cumulative "
                "mean of per-second channel scores from the labelled onset to the end of the episode.")


def pct(x):
    return "–" if pd.isna(x) else f"{100 * x:.1f}"


def pct_ci(x, lo, hi):
    return "–" if pd.isna(x) else f"{100 * x:.1f} [{100 * lo:.1f}, {100 * hi:.1f}]"


def f1(x):
    return "–" if pd.isna(x) else f"{x:.1f}"


def f2(x):
    return "–" if pd.isna(x) else f"{x:.2f}"


def f3(x):
    return "–" if pd.isna(x) else f"{x:.3f}"


def pval(p):
    return "–" if pd.isna(p) else ("< .001" if p < 0.001 else f"{p:.3f}".replace("0.", ".", 1))


def seedcell(r, col):
    mu = getattr(r, col + "_seedmean", np.nan)
    if pd.isna(mu):
        return "–"
    return f"{100 * mu:.1f} ± {100 * getattr(r, col + '_seedsd'):.1f}"


def name(m):
    return SHORT.get(m, m)


def save(tid, df, title, note):
    C.TABLES.mkdir(parents=True, exist_ok=True)
    df.to_csv(C.TABLES / f"{tid}.csv", index=False)
    REG.append(dict(id=tid, title=title, note=note))


def setup(prefix):
    return json.load(open(A / f"{prefix}_setup.json"))


# ------------------------------------------------------------------ data and design
def t_datasets():
    rows = []
    for v, prefix in ((C.PRIMARY, "A"), (C.REPLICATION, "B")):
        info = json.load(open(C.DATA_PROC / v / "channels.json"))
        ep = pd.read_csv(C.DATA_PROC / v / "episodes.csv")
        n_tags = len(info["channels"]) + len(info["dropped_constant"])
        q1, q3 = ep.length.quantile([0.25, 0.75])
        rows += [
            (v, "Training files (normal operation)", f"{len(info['train_files'])} ({sum(info['train_rows_per_file']):,} s)"),
            (v, "Training rows removed (duplicated in test)", f"{sum(info['train_rows_removed_test_overlap']):,}"),
            (v, "Model-fitting / calibration rows", f"{info['n_fit_rows']:,} / {info['n_val_rows']:,}"),
            (v, "Test files / rows", f"{len(info['test_files'])} / {info['n_test_rows']:,}"),
            (v, "Recorded tags / varying in training", f"{n_tags} / {len(info['channels'])}"),
            (v, "Attack episodes (single / combined)", f"{len(ep)} ({(~ep.combined).sum()} / {ep.combined.sum()})"),
            (v, "Episodes by targeted processes",
             "; ".join(f"{k.replace(';', '+')} {n}" for k, n in ep.processes.value_counts().sort_index().items())),
            (v, "Episodes by attack type",
             "; ".join(f"{k} {n}" for k, n in ep.attack_type.value_counts().sort_index().items())),
            (v, "Episode length, median (IQR), s", f"{ep.length.median():.0f} ({q1:.0f}–{q3:.0f})"),
            (v, "Episodes with a recorded varying target tag", f"{(ep.n_tags_candidate > 0).sum()}"),
        ]
    df = pd.DataFrame(rows, columns=["Dataset", "Characteristic", "Value"])
    save("T01_datasets", df, "Characteristics of the HAI datasets used for localisation benchmarking",
         "Rows are 1-Hz samples. Tags constant throughout the training files carry no learnable normal behaviour and were "
         "excluded from the candidate set; documented targets among them (for example P2_ASD, P2_VTR01, P2_RTR in HAI 21.03) "
         "therefore cannot be ranked at tag level. Sensor spoofing denotes primitives that include a process-variable (PV) "
         "manipulation; actuator manipulation denotes control-output (CO) primitives without PV spoofing.")


def t_episodes():
    ep = pd.read_csv(A / "A_episodes_meta.csv")
    ob = pd.read_csv(A / "A_observability.csv")
    vis = ob[ob.recorded].groupby("ep").max_dev.max()
    df = pd.DataFrame({
        "No.": ep.ep, "ID": ep.attack_id, "File": ep.file, "Start": ep.start_time.str[5:16].str.replace(" ", "\u00a0"), "Length (s)": ep.length,
        "Scenario": ep.scenario, "Processes": ep.processes.str.replace(";", "+"),
        "Control loops": ep.controllers.str.replace(";", ", "),
        "Candidate target tags": ep.tags_candidate.fillna("–").str.replace(";", ", "),
        "Attack type": ep.attack_type.str.replace(" manipulation", "").str.replace("Sensor spoofing", "Sensor spoof"),
        "Max target deviation (SD)": [f1(vis.get(e, np.nan)) for e in ep.ep]})
    save("T02_episodes", df, "Attack episodes in HAI 21.03 with ground-truth processes, control loops and target tags",
         "Ground truth follows the scenario codes of the official technical manual. Processes agree with the per-process "
         "labels (attack_P1–attack_P3) for all 50 episodes. Candidate target tags are documented targets recorded with "
         "non-constant training values. Maximum target deviation is the largest absolute difference between a target tag "
         "and its 120-s pre-onset median during the episode, in training standard deviations; values below 3 indicate a "
         "manipulation that is not visible in the logged tag.")


def t_loops():
    s = setup("A")
    tg = G.tag_groups()
    amap = G.alias_map(C.PRIMARY)
    inv = {v: k for k, v in amap.items()}
    ep = pd.read_csv(A / "A_episodes_meta.csv")
    rows = []
    for loop in s["loop_names"]:
        tags = [c for c in s["channels"] if tg.set_index("tag").loop.get(inv.get(c, c)) == loop]
        n_ep = int(ep.controllers.str.split(";").apply(lambda x: loop in x).sum())
        desc = {"P1-PC": "Boiler pressure control", "P1-LC": "Boiler return-tank level control",
                "P1-FC": "Boiler outflow control", "P1-TC": "Boiler temperature control",
                "P2-SC": "Turbine speed control", "P2-TC": "Turbine trip / vibration monitoring",
                "P3-LC": "Water-treatment level control", "P4-ST": "HIL steam-turbine model and grid load",
                "P4-HT": "HIL hydro-turbine model"}[loop]
        rows.append(dict(Process=loop[:2], **{"Control loop": loop, "Function": desc, "Tags (n)": len(tags),
                         "Candidate tags": ", ".join(t.split("_", 1)[1] for t in tags), "Episodes targeting": n_ep}))
    save("T03_loops", pd.DataFrame(rows), "Grouping of the HAI 21.03 candidate tags into processes and control loops",
         "Grouping follows the control architecture of the HAI technical manual (feedback loops P1-PC, P1-LC, P1-FC, P1-TC, "
         "P2-SC, P2-TC and P3-LC; HIL models P4). Tag names omit the process prefix. P4 groups are never attacked and act as "
         "decoys: ranking a P4 group first is always a localisation error. Episodes targeting counts combined attacks once per "
         "loop involved.")


def t_methods():
    cmp_ = pd.read_csv(A / "A_compute.csv")
    s0 = cmp_[cmp_.seed == 0].set_index("method")
    rows = [
        ("ZSCORE", "Deviation", "|z(t,c)| standardised on calibration rows", "Training mean and SD", "–"),
        ("PCA", "Reconstruction", "|x − x̂| from PCA reconstruction", f"{C.PCA_VAR:.0%} variance retained", ""),
        ("PERSIST", "Forecast residual", "|x(t) − x(t−1)|", "None", "–"),
        ("RIDGE", "Forecast residual", "|x(t) − x̂(t)|, linear in 11 lags (1–60 s)", "Ridge, α by calibration MSE", ""),
        ("LSTM", "Forecast residual", "|x(t) − x̂(t)|, 60-s window", "2 layers × 64, Adam, early stopping", ""),
        ("TCN", "Forecast residual", "|x(t) − x̂(t)|, 60-s window", "4 dilated blocks × 64, Adam, early stopping", ""),
        ("CORR", "Correlation break", "Mean |ρ(t) − ρ̄| / σρ over partners, 60-s window", "Reference from 20,000 windows", ""),
        ("IG_TCN", "Gradient attribution", "Positive IG of the TCN anomaly score", f"{C.IG_STEPS} steps, mean baseline", ""),
        ("SHAP_IF", "SHAP attribution", "Negative TreeSHAP of iForest path length",
         f"{C.IF_PARAMS['n_estimators']} trees, ψ = {C.IF_PARAMS['max_samples']}", ""),
        ("SHAP_GBDT", "SHAP attribution", "Positive TreeSHAP of attack probability", "LightGBM, leave-one-file-out", ""),
        ("GBDT_PROC", "Supervised classifier", "Per-process attack probability", "LightGBM, leave-one-file-out", ""),
    ]
    out = []
    for m, fam, ev, cfg, _ in rows:
        extra = ""
        if m == "PCA" and m in s0.index:
            extra = f"; k = {int(s0.loc[m, 'components'])}" if "components" in s0 else ""
        if m == "RIDGE" and m in s0.index and "alpha" in s0:
            extra = f"; α = {s0.loc[m, 'alpha']:g}"
        out.append({"Method": name(m), "Family": fam, "Channel evidence s(t, c)": ev, "Configuration": cfg + extra,
                    "Uses attack labels": "Yes" if m in C.SUPERVISED else "No"})
    save("T04_methods", pd.DataFrame(out), "Localisation methods compared",
         "All unsupervised models are fitted on normal training rows only; residual-type scores are standardised with the "
         "mean and SD of the calibration residuals. Supervised references are trained on the other four test files plus "
         f"{C.GBDT_PARAMS['normal_rows']:,} normal training rows and evaluated on the held-out file (features: z-scores "
         f"and {C.GBDT_PARAMS['diff_lag']}-s differences). Stochastic methods were run with seeds 0, 1 and 2.")


def t_audit():
    rows = []
    for v in (C.PRIMARY, C.REPLICATION):
        tab = pd.read_csv(C.DATA_PROC / v / "attack_table.csv")
        for r in tab[~tab.doc_consistent].itertuples():
            rows.append({"Dataset": v, "Attack": f"{r.attack_id} (part {r.part})", "Scenario": r.scenario,
                         "Documented points": r.doc_points.replace(";", ", "),
                         "Points implied by scenario": r.points_canon.replace(";", ", "),
                         "Resolution": "Scenario code used"})
        ep = pd.read_csv(C.DATA_PROC / v / "episodes.csv")
        for r in ep.itertuples():
            if abs(r.length - r.doc_duration_s) > 1:
                rows.append({"Dataset": v, "Attack": r.attack_id, "Scenario": r.scenario,
                             "Documented points": f"Duration {r.doc_duration_s} s",
                             "Points implied by scenario": f"Labelled duration {r.length} s",
                             "Resolution": "Labels used"})
        info = json.load(open(C.DATA_PROC / v / "channels.json"))
        if sum(info["train_rows_removed_test_overlap"]):
            rows.append({"Dataset": v, "Attack": "–", "Scenario": "train1 vs test3/test2",
                         "Documented points": "Separate files",
                         "Points implied by scenario": f"{sum(info['train_rows_removed_test_overlap']):,} identical rows",
                         "Resolution": "Rows removed from training"})
    rows.append({"Dataset": C.REPLICATION, "Attack": "A209", "Scenario": "P1-PC-SP1PV1PV2",
                 "Documented points": "P1_FIT01", "Points implied by scenario": "Tag not recorded",
                 "Resolution": "Excluded from tag ranking"})
    save("T05_audit", pd.DataFrame(rows), "Audit of the ground-truth sources and the resolution adopted",
         "Documented points are those printed in the attack tables of the HAI technical manual; points implied by the "
         "scenario code follow the attack-primitive definitions of the same manual. P2_LCV01D does not exist in either "
         "dataset and is read as P3_LCV01D (controller P3-LC). Duration differences of one second reflect inclusive label "
         "boundaries and are not listed.")


# ------------------------------------------------------------------ fidelity and detection
def t_fidelity():
    det = pd.read_csv(A / "S_detection.csv")
    cmp_ = pd.read_csv(A / "A_compute.csv")
    rows = []
    for m in C.METHODS:
        d = det[(det.method == m) & (det.seed == 0)]
        if d.empty:
            continue
        d = d.iloc[0]
        c = cmp_[(cmp_.method == m) & (cmp_.seed == 0)]
        mse = c.val_mse.iloc[0] if ("val_mse" in c and len(c) and pd.notna(c.val_mse.iloc[0])) else np.nan
        rows.append({"Method": name(m), "Calibration MSE (z²)": f3(mse), "eTaP": f3(d.eTaP), "eTaR": f3(d.eTaR),
                     "eTaF1": f3(d.eTaF1), "Best eTaF1": f3(d.best_eTaF1), "FPR (%)": f2(100 * d.fpr),
                     "Episodes alarmed (%)": pct(d.alarm_rate), "Median delay (s)": f1(d.median_delay)})
    save("T06_detection", pd.DataFrame(rows), "Normal-model fidelity and detection performance on HAI 21.03 (seed 0)",
         f"Detection score = mean squared channel score, {C.DET_SMOOTH}-s causal moving average; alarm threshold = "
         f"{C.DET_QUANTILE:.1%} quantile of the calibration scores (0.5 probability for supervised methods). eTaPR with "
         f"θp = {C.ETAPR_THETA_P}, θr = {C.ETAPR_THETA_R}, δ = 0. Best eTaF1 is the maximum over 60 thresholds and is an "
         "optimistic reference. IG-TCN shares the TCN detector. Delay = seconds from labelled onset to the first alarm "
         "within the episode.")


# ------------------------------------------------------------------ RQ1
def t_rq1():
    s = pd.read_csv(A / "S_main.csv")
    rows = []
    for r in s.itertuples():
        base = r.method in ("RANDOM", "MAJORITY")
        rows.append({"Method": name(r.method),
                     "Process top-1 (%)": pct(r.proc_hit) if base else pct_ci(r.proc_hit, r.proc_hit_lo, r.proc_hit_hi),
                     "Macro recall P1–P3 (%)": pct(getattr(r, "recall_macro", np.nan)),
                     "Loop top-1 (%)": pct(r.loop_hit1) if base else pct_ci(r.loop_hit1, r.loop_hit1_lo, r.loop_hit1_hi),
                     "Loop top-3 (%)": pct(r.loop_hit3),
                     "Loop top-1, 3 seeds (%)": seedcell(r, "loop_hit1"),
                     "HIL (P4) ranked first (%)": pct(getattr(r, "p4_rate", np.nan)),
                     "Both processes in top-2 (%)": pct(getattr(r, "both_top2", np.nan))})
    save("T07_rq1_main", pd.DataFrame(rows),
         "Process-level and control-loop-level localisation accuracy over the 50 HAI 21.03 episodes (RQ1)",
         PRIMARY_NOTE + " Values in brackets are 95% percentile bootstrap intervals over episodes (2,000 resamples). "
         "A top-1 call is correct when the highest-ranked process (loop) is among the targeted ones. Macro recall averages "
         "accuracy over episodes involving P1, P2 and P3. Both processes in top-2 is computed over the 14 two-process "
         "episodes. Random = expected accuracy of a uniformly random ranking of 4 processes and 9 loops; Majority = always "
         "predicting P1. The supervised GBDT-process classifier yields process scores only. Loop top-1, 3 seeds = mean ± SD "
         "over seeds 0–2 for the stochastic methods (– = deterministic method).")


def t_rq1_tests():
    pw = pd.read_csv(A / "S_pairwise.csv")
    rows = []
    for r in pw.itertuples():
        rows.append({"Outcome": "Process top-1" if r.metric == "proc_hit" else "Loop top-1", "Method": name(r.method),
                     "Δ vs Ridge-VAR (pp)": f"{100 * r.diff:+.1f} [{100 * r.diff_lo:+.1f}, {100 * r.diff_hi:+.1f}]",
                     "Score 95% CI (pp)": f"[{100 * r.diff_lo_score:+.1f}, {100 * r.diff_hi_score:+.1f}]",
                     "Discordant (method / Ridge)": f"{r.only_method} / {r.only_ref}",
                     "McNemar p": pval(r.p), "Holm p": pval(r.p_holm)})
    q = pw.groupby("metric").first()
    qtxt = "; ".join(f"{'process' if k == 'proc_hit' else 'loop'}: Q = {v.cochran_q:.1f}, df = {int(v.cochran_df)}, "
                     f"p = {pval(v.cochran_p)}" for k, v in q.iterrows())
    save("T08_rq1_tests", pd.DataFrame(rows), "Paired comparisons of each method with the Ridge-VAR forecaster (RQ1)",
         f"Exact McNemar tests on episode-level hits (n = 50), Holm-adjusted within outcome; differences are paired "
         f"bootstrap means with 95% percentile intervals; score 95% CI = Tango's score interval for paired proportions. "
         f"Neither interval is adjusted for multiplicity. Cochran's Q across all methods — {qtxt}.")


def t_glmm():
    p = A / "R_glmm.csv"
    if not p.exists():
        return
    g = pd.read_csv(p)
    rows = []
    for r in g.itertuples():
        if r.term == "(Intercept)":
            continue
        term = r.term.replace("method", "").replace("attack_type", "Type: ")
        rows.append({"Outcome": "Loop top-1" if r.outcome == "loop_hit1" else "Tag hit@3",
                     "Term": name(term) if term in SHORT else term,
                     "Odds ratio [95% CI]": f"{r.odds_ratio:.2f} [{r.or_lo:.2f}, {r.or_hi:.2f}]", "z": f2(r.z),
                     "p": pval(r.p)})
    sd = g.groupby("outcome").re_sd.first()
    save("T09_rq1_glmm", pd.DataFrame(rows),
         "Mixed-effects logistic regression of localisation hits on method and attack type",
         "Binomial GLMM with a random intercept per episode (lme4, Wald intervals); reference levels are Ridge-VAR and "
         "actuator manipulation. Random-intercept SD: " + "; ".join(
             f"{'loop' if k == 'loop_hit1' else 'tag'} {v:.2f}" for k, v in sd.items()) +
         ". Supervised methods are included; GBDT-process is excluded because it produces no loop or tag ranking.")


def t_byloop():
    b = pd.read_csv(A / "S_byloop.csv")
    b = b[b.method != "GBDT_PROC"]
    piv = b.pivot(index="loop", columns="method", values="loop_hit1")
    n = b.groupby("loop").n.first()
    df = pd.DataFrame({"Targeted loop": piv.index, "n": n.loc[piv.index].values})
    for m in [m for m in C.METHODS if m in piv]:
        df[name(m)] = [pct(x) for x in piv[m]]
    save("T10_rq1_byloop", df, "Control-loop top-1 accuracy (%) by targeted loop for single-loop episodes",
         PRIMARY_NOTE + " Only episodes whose primitives all target one control loop are included.")


# ------------------------------------------------------------------ RQ2
def t_rq2():
    s = pd.read_csv(A / "S_main.csv")
    rows = []
    for r in s.itertuples():
        if r.method in ("GBDT_PROC", "MAJORITY"):
            continue
        base = r.method == "RANDOM"
        rows.append({"Method": name(r.method),
                     "Hit@1 (%)": pct(r.tag_hit1), "Hit@3 (%)": pct(r.tag_hit3) if base else pct_ci(r.tag_hit3, r.tag_hit3_lo, r.tag_hit3_hi),
                     "Hit@5 (%)": pct(r.tag_hit5), "Hit@10 (%)": pct(r.tag_hit10),
                     "MRR": "–" if base else f3(r.mrr), "Hit@3, 3 seeds (%)": seedcell(r, "tag_hit3")})
    n = int(s.loc[s.method == "RIDGE", "tag_hit3_n"].iloc[0])
    save("T11_rq2_tags", pd.DataFrame(rows), "Ranking of the manipulated tags among the candidate tags (RQ2)",
         PRIMARY_NOTE + f" Computed over the {n} episodes with at least one recorded, varying target tag "
         "(57 candidates). Hit@k = at least one target tag among the k highest-ranked tags; MRR = mean reciprocal rank of the "
         "best-ranked target tag. Random = expected value of a uniformly random ranking. Hit@3, 3 seeds = mean ± SD over "
         "seeds 0–2 for the stochastic methods.")


def t_rq2_type():
    b = pd.read_csv(A / "S_bytype.csv")
    b = b[(b.factor == "attack_type") & (b.method != "GBDT_PROC")]
    rows = []
    for lev in sorted(b.level.unique()):
        g = b[b.level == lev].set_index("method")
        row = {"Attack type": lev, "n (tag n)": f"{int(g.n.iloc[0])} ({int(g.n_tag.iloc[0]) if 'n_tag' in g and pd.notna(g.n_tag.iloc[0]) else 0})"}
        for m in [m for m in C.METHODS if m in g.index]:
            row[name(m)] = f"{pct(g.loc[m, 'loop_hit1'])} / {pct(g.loc[m, 'tag_hit3'])}"
        rows.append(row)
    save("T12_rq2_type", pd.DataFrame(rows), "Control-loop top-1 / tag hit@3 accuracy (%) by attack type (RQ2)",
         PRIMARY_NOTE + " Each cell gives loop top-1 accuracy over all episodes of the type, then tag hit@3 over the "
         "episodes of the type with a recorded varying target tag (count in parentheses). Episode type is sensor spoofing "
         "if any primitive spoofs a process variable, otherwise actuator manipulation if any primitive alters a control "
         "output, otherwise setpoint manipulation.")


def t_observability():
    o = pd.read_csv(A / "S_observability.csv")
    o = o[o.method != "GBDT_PROC"]
    rows = []
    for vis in (True, False):
        g = o[o.target_visible == vis].set_index("method")
        if g.empty:
            continue
        row = {"Target visible in log": "Yes (≥ 3 SD)" if vis else "No (< 3 SD or unrecorded)",
               "n (tag n)": f"{int(g.n.iloc[0])} ({int(g.n_tag.iloc[0])})"}
        for m in [m for m in C.METHODS if m in g.index]:
            row[name(m)] = f"{pct(g.loc[m, 'loop_hit1'])} / {pct(g.loc[m, 'tag_hit3'])}"
        rows.append(row)
    save("T13_rq2_observability", pd.DataFrame(rows),
         "Localisation when the manipulated tag is, or is not, visibly altered in the logged data",
         PRIMARY_NOTE + " Visible: at least one documented target tag deviates by 3 or more training SDs from its 120-s "
         "pre-onset median during the episode. Cells give loop top-1 / tag hit@3 (%); tag hit@3 is undefined for episodes "
         "whose targets are all unrecorded or constant in training.")


# ------------------------------------------------------------------ RQ3
def t_rq3_tau():
    c = pd.read_csv(A / "S_curves.csv")
    taus = [5, 10, 30, 60, 120, 240]
    rows = []
    for m in C.METHODS:
        g = c[c.method == m].set_index("tau")
        if g.empty:
            continue
        row = {"Method": name(m)}
        for t in taus:
            row[f"τ = {t} s"] = f"{pct(g.loc[t, 'proc_hit'])} / {pct(g.loc[t, 'loop_hit1']) if 'loop_hit1' in g and pd.notna(g.loc[t, 'loop_hit1']) else '–'}"
        rows.append(row)
    save("T14_rq3_tau", pd.DataFrame(rows), "Process / control-loop top-1 accuracy (%) as evidence accumulates after onset (RQ3)",
         PRIMARY_NOTE + " τ = seconds of evidence since the labelled onset; episodes shorter than τ contribute their "
         "whole-episode call (n = 50 at every τ).")


def t_rq3_ttl():
    s = pd.read_csv(A / "S_main.csv")
    cox = pd.read_csv(A / "R_cox.csv") if (A / "R_cox.csv").exists() else pd.DataFrame()
    rows = []
    for r in s.itertuples():
        if r.method in ("RANDOM", "MAJORITY"):
            continue
        row = {"Method": name(r.method),
               "Process: localised (%)": pct(r.event_proc), "Process: median TTL (s)": f1(r.median_ttl_proc),
               "Process: RMST₁₂₀ (s)": f"{r.rmst_proc:.1f} [{r.rmst_proc_lo:.1f}, {r.rmst_proc_hi:.1f}]"}
        if pd.notna(getattr(r, "rmst_loop", np.nan)):
            row.update({"Loop: localised (%)": pct(r.event_loop), "Loop: median TTL (s)": f1(r.median_ttl_loop),
                        "Loop: RMST₁₂₀ (s)": f"{r.rmst_loop:.1f} [{r.rmst_loop_lo:.1f}, {r.rmst_loop_hi:.1f}]"})
            if len(cox):
                h = cox[(cox.kind == "loop") & (cox.term == "method" + r.method)]
                row["Loop: HR vs Ridge-VAR"] = "1 (ref.)" if r.method == "RIDGE" else (
                    f"{h.hr.iloc[0]:.2f} [{h.hr_lo.iloc[0]:.2f}, {h.hr_hi.iloc[0]:.2f}]" if len(h) else "–")
        rows.append(row)
    lr = cox[cox.term == "logrank_overall"] if len(cox) else pd.DataFrame()
    lrt = "; ".join(f"{k}: χ² = {v.hr_lo:.1f}, df = {int(v.hr_hi)}, p = {pval(v.p)}" for k, v in lr.set_index("kind").iterrows())
    save("T15_rq3_ttl", pd.DataFrame(rows).fillna("–"), "Time-to-localise after attack onset (RQ3)",
         PRIMARY_NOTE + f" Time-to-localise (TTL) = first τ from which the top-1 call stays correct for {C.STABILITY} s "
         "(or until the episode ends); episodes never localised are censored at their length. Medians are Kaplan–Meier "
         "estimates; RMST₁₂₀ = restricted mean TTL up to 120 s with bootstrap 95% intervals (lower is faster). HR = hazard "
         "ratio of localisation from a Cox model stratified by episode (HR > 1: faster than Ridge-VAR). Log-rank tests "
         f"across methods — {lrt}.")


def t_alarm():
    det = pd.read_csv(A / "S_detection.csv")
    rows = []
    for m in C.METHODS:
        d = det[(det.method == m) & (det.seed == 0)]
        if d.empty:
            continue
        d = d.iloc[0]
        rows.append({"Method": name(m), "Episodes alarmed (%)": pct(d.alarm_rate), "Median delay (s)": f1(d.median_delay),
                     "Process at alarm (%)": pct(d.get("proc_hit_at")), "Loop at alarm (%)": pct(d.get("loop_hit_at")),
                     "Tag hit@3 at alarm (%)": pct(d.get("tag_hit3_at")),
                     "Process +30 s (%)": pct(d.get("proc_hit_plus30")), "Loop +30 s (%)": pct(d.get("loop_hit_plus30")),
                     "Tag hit@3 +30 s (%)": pct(d.get("tag_hit3_plus30"))})
    save("T16_alarm", pd.DataFrame(rows), "Localisation triggered by each method's own first alarm",
         "At the first alarm inside an episode the ranking uses the 10 s of evidence ending at the alarm (no knowledge of "
         "the onset); '+30 s' uses the 30 s following the alarm. Accuracies are over alarmed episodes; thresholds as in the "
         "detection table.")


# ------------------------------------------------------------------ RQ4
def t_compute():
    cmp_ = pd.read_csv(A / "A_compute.csv")
    s = pd.read_csv(A / "S_main.csv").set_index("method")
    rows = []
    for m in C.METHODS:
        c = cmp_[cmp_.method == m]
        if c.empty:
            continue
        fit = c.fit_s.mean() if "fit_s" in c and c.fit_s.notna().any() else np.nan
        inf = c.infer_us_per_step.mean() if "infer_us_per_step" in c and c.infer_us_per_step.notna().any() else np.nan
        att = c.attr_us_per_step.mean() if "attr_us_per_step" in c and c.attr_us_per_step.notna().any() else np.nan
        par = c.n_params.iloc[0] if "n_params" in c and pd.notna(c.n_params.iloc[0]) else np.nan
        if m == "IG_TCN":
            t = cmp_[cmp_.method == "TCN"]
            fit, inf, par = t.fit_s.mean(), t.infer_us_per_step.mean(), t.n_params.iloc[0]
        rows.append({"Method": name(m), "Parameters": "–" if pd.isna(par) or par == 0 else f"{int(par):,}",
                     "Fit time (s)": f1(fit), "Scoring (µs per step)": f1(inf), "Attribution (µs per step)": f1(att),
                     "Process top-1 (%)": pct(s.loc[m, "proc_hit"]) if m in s.index else "–",
                     "Loop top-1 (%)": pct(s.loc[m, "loop_hit1"]) if m in s.index else "–",
                     "Tag hit@3 (%)": pct(s.loc[m, "tag_hit3"]) if m in s.index else "–"})
    save("T17_rq4_compute", pd.DataFrame(rows), "Computational cost and localisation accuracy (RQ4)",
         f"Wall-clock times on one Intel Core i5-1145G7 CPU with {C.THREADS} threads, averaged over seeds; scoring = full "
         "test stream (402,005 steps), attribution = episode context rows. Fit time of the supervised references sums the "
         "five leave-one-file-out folds; GBDT-process is trained in the same folds and is not timed separately. IG-TCN "
         "reuses the trained TCN, so its fitting and scoring costs are those of the TCN. Parameters: model weights (Ridge "
         "coefficients, network weights, iForest tree nodes); – = no fitted parameters or not applicable.")


def t_noninf():
    n = pd.read_csv(A / "S_noninferiority.csv")
    rows = []
    for r in n.itertuples():
        rows.append({"Lightweight": name(r.light), "Deep": name(r.deep),
                     "Outcome": {"proc_hit": "Process top-1", "loop_hit1": "Loop top-1", "tag_hit3": "Tag hit@3"}[r.metric],
                     "n": r.n, "Discordant (light / deep)": f"{r.only_light} / {r.only_deep}",
                     "Δ (pp) [95% bootstrap CI]": f"{100 * r.diff:+.1f} [{100 * r.lo:+.1f}, {100 * r.hi:+.1f}]",
                     "95% score CI (pp)": f"[{100 * r.lo_score:+.1f}, {100 * r.hi_score:+.1f}]",
                     "One-sided p (Δ ≤ −10 pp)": pval(r.p_ni_score),
                     "Non-inferior": ("Yes" if r.noninferior and r.noninferior_score else
                                      "Bootstrap only" if r.noninferior else "No"),
                     "Superior (lower bound > 0)": "Yes" if r.superior else "No"})
    save("T18_rq4_noninferiority", pd.DataFrame(rows),
         "Non-inferiority of lightweight forecasters relative to the deep forecasters (RQ4)",
         PRIMARY_NOTE + " Δ = lightweight minus deep accuracy, paired over episodes; discordant = episodes correct for only "
         "one of the two methods. Margin = −10 percentage points (five of 50 episodes), applied to every comparison. "
         "Decision rule: non-inferior when the lower bound of the two-sided 95% paired bootstrap interval (2,000 resamples) "
         "exceeds the margin, which corresponds to a one-sided test at α = 0.025; Tango's score interval and the one-sided "
         "score test against the margin are reported as a check of the bootstrap (Bootstrap only = the score interval "
         "does not confirm). Non-inferiority is not inferred from a non-significant difference test.")


def t_gt_sensitivity():
    g = pd.read_csv(A / "S_gt_sensitivity.csv")
    rows = []
    for v in (C.PRIMARY, C.REPLICATION):
        gv = g[g.version == v]
        for key in gv.subset.unique():
            s = gv[gv.subset == key].set_index("method")
            row = {"Dataset": v.replace("hai-", "HAI "), "Scoring / episode subset": s.label.iloc[0], "n": int(s.n.iloc[0])}
            for m in [m for m in C.METHODS if m in s.index]:
                row[name(m)] = pct(s.loc[m, "loop"])
            rows.append(row)
    save("T25_gt_sensitivity", pd.DataFrame(rows).fillna("–"),
         "Control-loop top-1 accuracy (%) under alternative ground-truth scorings and episode subsets",
         "Seed 0, maximum aggregation. Lenient (primary) scoring counts a call as correct when the top-ranked loop is any "
         "targeted loop; strict scoring requires all m targeted loops to occupy the m highest ranks. Documentation "
         "conflicts are the episodes listed in the audit table (scenario code and printed points disagree); visible = at "
         "least one recorded target deviates by ≥ 3 training SDs. Supervised references are not available for HAI 22.04.")


def t_ttl_operational():
    s = pd.read_csv(A / "S_ttl_operational.csv")
    s = s[s.method != "GBDT_PROC"]
    det_lab = {"own": "own alarm", "RIDGE": "Ridge-VAR alarm", "PCA": "PCA alarm"}
    rows = []
    for m in [m for m in C.METHODS if m in set(s.method)]:
        g = s[s.method == m].set_index("detector")
        row = {"Localiser": name(m)}
        for det in ("own", "RIDGE", "PCA"):
            if det not in g.index:
                continue
            x = g.loc[det]
            row[f"Localised, {det_lab[det]} (%)"] = pct(x.event_loop_op)
            row[f"RMST₁₂₀, {det_lab[det]} (s)"] = f"{x.rmst_loop_op:.1f} [{x.rmst_loop_op_lo:.1f}, {x.rmst_loop_op_hi:.1f}]"
        row["Localised, known onset (%)"] = pct(g.loc["own", "event_loop_onset"])
        row["RMST₁₂₀, known onset (s)"] = f1(g.loc["own", "rmst_loop_onset"])
        rows.append(row)
    alarm_txt = "; ".join(f"{name(r.detector)} {pct(r.alarm_rate)}% (median delay {f1(r.median_delay)} s)"
                          for r in s[(s.detector != "own") & (s.method == s.detector)].itertuples())
    save("T26_ttl_operational", pd.DataFrame(rows).fillna("–"),
         "Operational control-loop time-to-localise when localisation is triggered by an alarm",
         f"Seed 0, maximum aggregation, HAI 21.03. Evidence accumulates from 10 s before the first alarm inside the "
         f"episode, raised either by the localiser's own detector or by the Ridge-VAR or PCA detector; time is counted "
         f"from the labelled onset to the first second from which the loop call stays correct for {C.STABILITY} s (or "
         "until the episode ends), so it includes the detection delay. Episodes without an alarm or without a stable "
         "correct call are censored at their length. RMST₁₂₀ = restricted mean up to 120 s with bootstrap 95% intervals "
         "(lower is faster). Known onset = primary analysis with evidence accumulated from the labelled onset. Episodes "
         f"alarmed by the triggering detectors: {alarm_txt}.")


def t_seeds():
    s = pd.read_csv(A / "S_seeds.csv")
    rows = []
    for r in s.itertuples():
        def ms(col):
            mu, sd = getattr(r, col + "_mean", np.nan), getattr(r, col + "_sd", np.nan)
            return "–" if pd.isna(mu) else f"{100 * mu:.1f} ± {100 * sd:.1f}"
        rows.append({"Method": name(r.method), "Seeds": r.n_seeds, "Process top-1 (%)": ms("proc_hit"),
                     "Loop top-1 (%)": ms("loop_hit1"), "Tag hit@3 (%)": ms("tag_hit3"),
                     "MRR": "–" if pd.isna(getattr(r, "mrr_mean", np.nan)) else f"{r.mrr_mean:.3f} ± {r.mrr_sd:.3f}"})
    save("T19_seeds", pd.DataFrame(rows), "Seed variability of the stochastic methods",
         "Mean ± SD across seeds 0, 1 and 2 (maximum aggregation). Seeds change network initialisation and window "
         "sampling, iForest subsampling, and LightGBM bagging.")


def t_aggregator():
    a = pd.read_csv(A / "S_aggregator.csv")
    a = a[a.method != "GBDT_PROC"]
    rows = []
    for m in [m for m in C.METHODS if m in set(a.method)]:
        g = a[a.method == m].set_index("agg")
        row = {"Method": name(m)}
        for agg, lab in (("max", "Max"), ("top2", "Top-2 mean"), ("mean", "Mean"), ("sum", "Sum"), ("cal", "Calibrated max")):
            row[lab] = f"{pct(g.loc[agg, 'proc_hit'])} / {pct(g.loc[agg, 'loop_hit1'])}" if agg in g.index else "–"
        rows.append(row)
    save("T20_aggregator", pd.DataFrame(rows), "Sensitivity of process / control-loop top-1 accuracy (%) to the group aggregator",
         "Seed 0. Max, top-2 mean, mean and sum aggregate the cumulative channel evidence of each group; calibrated max "
         "standardises each group's per-second maximum by its calibration-set mean and SD before accumulation (available "
         "for methods with calibration scores).")


def t_sensitivity():
    s = pd.read_csv(A / "S_sensitivity.csv")
    lab = {"L10": "Lags 1–10 s", "L30": "Lags 1–30 s", "L120": "Lags 1–120 s", "RAW": "Unstandardised residuals",
           "T1": "Past-only training (train1)", "evidence_trailing10": "Trailing 10-s evidence",
           "evidence_ewma": "Exponential evidence (λ = 0.1)"}
    rows = []
    for r in s.itertuples():
        rows.append({"Variant": lab.get(r.variant, r.variant), "Method": name(r.method), "Episodes": r.n,
                     "Process top-1 (%)": f"{pct(r.proc_hit)} ({pct(r.ref_proc_hit)})",
                     "Loop top-1 (%)": f"{pct(r.loop_hit1)} ({pct(r.ref_loop_hit1)})",
                     "Tag hit@3 (%)": f"{pct(r.tag_hit3)} ({pct(r.ref_tag_hit3)})"})
    df = pd.DataFrame(rows)
    order = list(lab.values())
    df["_o"] = df.Variant.map({v: i for i, v in enumerate(order)})
    df["_m"] = df.Method.map({name(m): i for i, m in enumerate(C.METHODS)})
    df = df.sort_values(["_o", "_m"]).drop(columns=["_o", "_m"])
    save("T21_sensitivity", df, "Sensitivity of localisation to model and evidence choices",
         "Values in parentheses are the primary-condition results on the same episodes. Past-only training fits and "
         "calibrates on train1 only (11–12 July 2020), which precedes test3–test5; it is evaluated on those 25 episodes. "
         "Primary Ridge-VAR uses lags {1, 2, 3, 4, 5, 10, 15, 20, 30, 45, 60} s.")


def t_stability():
    s = pd.read_csv(A / "S_stability.csv")
    rows = []
    for m in [m for m in C.METHODS if m in set(s.method)]:
        g = s[s.method == m].set_index("stability")
        row = {"Method": name(m)}
        for k in (1, 10, 30, 60):
            if k in g.index:
                row[f"{k} s"] = f"{f1(g.loc[k, 'median_ttl_proc'])} / {f1(g.loc[k, 'rmst_proc'])}"
        rows.append(row)
    save("T22_stability", pd.DataFrame(rows).fillna("–"),
         "Process time-to-localise (Kaplan–Meier median / RMST₁₂₀, s) under different stability requirements",
         "Seed 0, maximum aggregation. Column = number of seconds a correct top-1 call must persist to count as localised.")


def t_replication():
    p = A / "S_replication.csv"
    if not p.exists():
        return
    r = pd.read_csv(p)
    rows = []
    for m in C.REPL_METHODS:
        g = r[r.method == m].set_index("version")
        if g.empty:
            continue
        row = {"Method": name(m)}
        for v in (C.PRIMARY, C.REPLICATION):
            if v in g.index:
                x = g.loc[v]
                short = v.replace("hai-", "")
                row[f"{short} process (%)"] = pct(x.proc_hit)
                row[f"{short} loop top-1 (%)"] = pct_ci(x.loop_hit1, x.loop_hit1_lo, x.loop_hit1_hi)
                row[f"{short} tag hit@3 (%)"] = pct(x.tag_hit3)
                row[f"{short} RMST₁₂₀ (s)"] = f1(x.rmst_proc)
        rows.append(row)
    ep = pd.read_csv(C.DATA_PROC / C.REPLICATION / "episodes.csv")
    save("T23_replication", pd.DataFrame(rows), "Replication of the benchmark on HAI 22.04",
         f"Seed 0, maximum aggregation. HAI 22.04: {len(ep)} episodes, {setup('B')['n_channels']} candidate tags, 10 control-"
         "loop groups (adds P1-CC); ground truth from the scenario codes because the release has no per-process labels. "
         "Supervised references are omitted because the 22.04 labels do not identify processes.")


def t_bytype_22():
    p = A / "S_bytype_B.csv"
    if not p.exists():
        return
    b = pd.read_csv(p)
    b = b[b.factor == "attack_type"]
    rows = []
    for lev in sorted(b.level.unique()):
        g = b[b.level == lev].set_index("method")
        row = {"Attack type": lev, "n": int(g.n.iloc[0])}
        for m in [m for m in C.REPL_METHODS if m in g.index]:
            row[name(m)] = f"{pct(g.loc[m, 'loop_hit1'])} / {pct(g.loc[m, 'tag_hit3'])}"
        rows.append(row)
    save("T24_replication_type", pd.DataFrame(rows), "HAI 22.04: control-loop top-1 / tag hit@3 accuracy (%) by attack type",
         "Seed 0, maximum aggregation; definitions as for HAI 21.03.")


if __name__ == "__main__":
    for f in (t_datasets, t_episodes, t_loops, t_methods, t_audit, t_fidelity, t_rq1, t_rq1_tests, t_glmm, t_byloop,
              t_rq2, t_rq2_type, t_observability, t_rq3_tau, t_rq3_ttl, t_alarm, t_compute, t_noninf, t_seeds,
              t_aggregator, t_sensitivity, t_stability, t_replication, t_bytype_22, t_gt_sensitivity,
              t_ttl_operational):
        f()
    json.dump(REG, open(C.TABLES / "registry.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"{len(REG)} tables written")
