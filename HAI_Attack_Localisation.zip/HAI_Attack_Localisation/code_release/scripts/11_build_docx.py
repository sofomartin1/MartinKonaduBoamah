"""Assemble all tables and figures into one Word document (outputs/Tables_and_Figures.docx)."""
import json
import sys
from pathlib import Path

import pandas as pd
from docx.shared import Pt

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hailoc import config as C  # noqa: E402
from hailoc import docx_utils as DU  # noqa: E402

LAYOUT = [
    ("Data, ground truth and study design", [("F", "F01_design"), ("T", "T01_datasets"), ("F", "F02_coverage"),
                                             ("T", "T02_episodes"), ("T", "T03_loops"), ("T", "T05_audit"),
                                             ("T", "T04_methods"), ("F", "F03_examples")]),
    ("Normal-model fidelity and detection", [("T", "T06_detection")]),
    ("RQ1: Process and control-loop localisation", [("T", "T07_rq1_main"), ("F", "F04_rq1_accuracy"),
                                                    ("T", "T08_rq1_tests"), ("T", "T09_rq1_glmm"),
                                                    ("F", "F05_confusion"), ("T", "T10_rq1_byloop"),
                                                    ("F", "F06_episode_map"), ("F", "F18_propagation"),
                                                    ("T", "T25_gt_sensitivity")]),
    ("RQ2: Manipulated-tag ranking and attack type", [("T", "T11_rq2_tags"), ("F", "F07_rq2_hitk"),
                                                      ("T", "T12_rq2_type"), ("F", "F08_rq2_type"),
                                                      ("T", "T13_rq2_observability"), ("F", "F09_observability")]),
    ("RQ3: Time-to-localise", [("T", "T14_rq3_tau"), ("F", "F10_rq3_tau"), ("T", "T15_rq3_ttl"), ("F", "F11_rq3_km"),
                               ("F", "F12_rq3_rmst_cox"), ("T", "T16_alarm"), ("T", "T26_ttl_operational"),
                               ("F", "F15_detection_localisation")]),
    ("RQ4: Lightweight versus deep forecasters", [("T", "T17_rq4_compute"), ("F", "F13_rq4_pareto"),
                                                  ("T", "T18_rq4_noninferiority")]),
    ("Robustness and replication", [("T", "T19_seeds"), ("F", "F17_seeds"), ("T", "T20_aggregator"),
                                    ("F", "F14_aggregator"), ("T", "T21_sensitivity"), ("T", "T22_stability"),
                                    ("T", "T23_replication"), ("F", "F16_replication"), ("T", "T24_replication_type")]),
]
LANDSCAPE = {"T02_episodes", "T03_loops", "T05_audit", "T04_methods", "T06_detection", "T07_rq1_main", "T08_rq1_tests",
             "T10_rq1_byloop", "T12_rq2_type", "T13_rq2_observability", "T14_rq3_tau", "T15_rq3_ttl", "T16_alarm",
             "T17_rq4_compute", "T20_aggregator", "T23_replication", "T24_replication_type", "T22_stability",
             "T18_rq4_noninferiority", "T25_gt_sensitivity", "T26_ttl_operational"}


def main():
    treg = {r["id"]: r for r in json.loads((C.TABLES / "registry.json").read_text(encoding="utf-8"))}
    freg = {r["id"]: r for r in json.loads((C.FIGURES / "registry.json").read_text(encoding="utf-8"))}
    used = [i for _, items in LAYOUT for _, i in items]
    assert sorted(used) == sorted(list(treg) + list(freg)), set(used) ^ (set(treg) | set(freg))
    doc = DU.new_document()
    p = doc.add_paragraph()
    r = p.add_run(C.TITLE)
    r.bold = True
    r.font.size = Pt(12)
    p = doc.add_paragraph()
    p.add_run("Tables and figures").font.size = Pt(10)
    tn = fn = 0
    landscape = False
    numbering = []
    for sec, items in LAYOUT:
        first_kind, first_id = items[0]
        want = first_kind == "T" and first_id in LANDSCAPE
        if want != landscape:
            (DU.landscape_section if want else DU.portrait_section)(doc)
            landscape = want
        doc.add_heading(sec, level=1)
        for kind, iid in items:
            if kind == "T":
                tn += 1
                want = iid in LANDSCAPE
                if want != landscape:
                    (DU.landscape_section if want else DU.portrait_section)(doc)
                    landscape = want
                df = pd.read_csv(C.TABLES / f"{iid}.csv", dtype=str, keep_default_na=False)
                DU.apa_table(doc, df, tn, treg[iid]["title"], treg[iid]["note"], total_width_cm=25.5 if landscape else 17.0)
                numbering.append(dict(section=sec, label=f"Table {tn}", file=f"tables/{iid}.csv", title=treg[iid]["title"]))
            else:
                fn += 1
                if landscape:
                    DU.portrait_section(doc)
                    landscape = False
                DU.figure(doc, C.FIGURES / f"{iid}.png", fn, freg[iid]["title"])
                numbering.append(dict(section=sec, label=f"Figure {fn}", file=f"figures/{iid}.png", title=freg[iid]["title"]))
    out = C.OUT / "Tables_and_Figures.docx"
    doc.save(out)
    pd.DataFrame(numbering).to_csv(C.OUT / "document_numbering.csv", index=False)
    print(f"[done] {out} ({tn} tables, {fn} figures)")


if __name__ == "__main__":
    main()
