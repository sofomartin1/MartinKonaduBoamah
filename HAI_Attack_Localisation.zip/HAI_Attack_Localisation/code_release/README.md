# Actionable attack localisation in an industrial control testbed

Code release for the study **"Actionable attack localisation in an industrial control testbed: An episode-level
benchmark of control-loop accuracy and time-to-localise on HAI"**. It is an empirical evaluation of existing method
families, not a new detection algorithm.

The benchmark asks *where* an attack on an industrial control system is, not only *whether* one is happening. Using the
official HAI security datasets, it scores eleven localisation methods on every labelled attack episode at three levels of
granularity — the attacked **process** (boiler P1, turbine P2, water treatment P3; the HIL simulator P4 acts as a decoy),
the attacked **control loop** (P1-PC, P1-LC, P1-FC, P1-TC, P1-CC, P2-SC, P2-TC, P3-LC) and the manipulated **tags** — and
measures how quickly the correct answer emerges after attack onset and after a real detector alarm.

Repository: https://github.com/sofomartin1/MartinKonaduBoamah

---

## 1. Research questions

| RQ | Question | Main outputs |
|----|----------|--------------|
| RQ1 | How accurately do residual-based, attribution-based and correlation-break methods identify the attacked process and control loop? | Tables T07–T10, T25 (ground-truth sensitivity), Figures F04–F06, F18 |
| RQ2 | What top-k accuracy is achieved when ranking the manipulated tags, and how does it vary by attack type (setpoint, actuator, sensor spoofing)? | T11–T13, F07–F09 |
| RQ3 | How does localisation accuracy evolve with time since onset, and how long does it take to localise correctly, from the onset and from a real alarm? | T14–T16, T26 (operational time-to-localise), F10–F12, F15 |
| RQ4 | Does a lightweight linear (or zero-parameter) forecaster localise as well as LSTM/TCN forecasters at a fraction of the compute? | T17–T18, F13 |
| Robustness | Seeds, aggregation rule, evidence window, stability window, lag set, residual standardisation, past-only training, replication on HAI 22.04 | T19–T24, F14, F16, F17 |

## 2. Datasets

Both datasets are public, released by the Affiliated Institute of ETRI under CC BY-SA 4.0, and are downloaded
automatically by `scripts/01_download.py` from the official repository <https://github.com/icsdataset/hai>
(mirror: <https://www.kaggle.com/datasets/icsdataset/hai-security-dataset>).

| | HAI 21.03 (primary) | HAI 22.04 (replication) |
|---|---|---|
| Source | `hai-21.03/*.csv.gz` | `hai-22.04/*.csv` (Git LFS; SHA-256 verified against the LFS pointers) |
| Sampling | 1 Hz | 1 Hz |
| Training files (normal operation) | train1–train3 (921,603 rows) | train1–train6 (1,004,402 rows) |
| Test files | test1–test5 (402,005 rows) | test1–test4 (361,200 rows) |
| Recorded tags | 78 (+ time, 4 labels) | 86 (+ time, 1 label) |
| Labels | `attack`, `attack_P1`, `attack_P2`, `attack_P3` | `Attack` |
| Attack episodes | 50 (25 single primitives, 25 combinations) | 58 (33 single, 25 combinations) |

Processes: **P1** boiler (Emerson Ovation DCS), **P2** turbine (GE Mark VIe), **P3** water treatment (Siemens S7-300),
**P4** hardware-in-the-loop steam-turbine and pumped-storage hydropower models (dSPACE SCALEXIO). Attacks target
setpoints (SP), control outputs (CO) and process variables (PV, sensor spoofing) of the P1–P3 feedback loops.

**Ground truth.** The attack tables of the official technical manual
(`hai_dataset_technical_details.pdf`, downloaded alongside the data) give, for every attack, a scenario code such as
`P1-FC-CO1PV1-ST` (controller `P1-FC`, primitives `CO1` + `PV1`, short-term variant). The code determines the targeted
control loop, the process, and — through the attack-primitive definitions of the same manual — the manipulated points.
These tables are transcribed in `meta/attacks_hai2103.csv` and `meta/attacks_hai2204.csv`; primitive definitions are in
`meta/primitives.csv`; the grouping of tags into processes and control loops (from the control-architecture section of
the manual) is in `meta/tag_groups.csv`. For HAI 21.03 the processes implied by the manual are asserted to equal the
per-process labels for all 50 episodes.

**Data-quality findings handled by the pipeline** (reported in Table T05):

* HAI 21.03 `train1` repeats the first 12 h of `test3` row for row (43,201 identical rows) and one boundary row of
  `test2`; training rows whose timestamp appears in any test file are removed (43,202 rows).
* The manual lists the point `P2_LCV01D` for `P3-LC-CO2` attacks; no such tag exists, and the scenario code is used
  (`P3_LCV01D`).
* In HAI 22.04 the documented points of attacks A301–A306 are misaligned with their scenario codes; the scenario code is
  used throughout.
* Attack A209 (HAI 21.03) is documented as 159 s but labelled for 199 s; labels are used.
* Tags that are constant throughout training (e.g. `P2_ASD`, `P2_VTR01`, `P2_RTR` in HAI 21.03) are excluded from the
  candidate set. Several documented targets are among them; those manipulations are concealed in the logged data and can
  only be localised through their downstream effects.

## 3. Methods compared

| Family | Method | Per-channel evidence |
|---|---|---|
| Deviation | Z-score | absolute z-score w.r.t. training statistics |
| Reconstruction | PCA | absolute PCA reconstruction error (95% variance) |
| Forecast residual | Persistence | \|x(t) − x(t−1)\| (no fitted parameters) |
| Forecast residual | Ridge-VAR | linear one-step forecast from 11 lags (1–60 s) |
| Forecast residual | LSTM | 2 × 64 LSTM, 60-s window |
| Forecast residual | TCN | 4 dilated causal blocks × 64, 60-s window |
| Correlation break | Corr-break | mean deviation of 60-s rolling correlations from the normal reference |
| Gradient attribution | IG-TCN | Integrated Gradients of the TCN anomaly score |
| SHAP attribution | SHAP-iForest | TreeSHAP of an Isolation Forest |
| SHAP attribution (supervised) | SHAP-GBDT | TreeSHAP of a LightGBM attack detector, leave-one-test-file-out |
| Supervised classifier | GBDT-process | per-process LightGBM detectors, leave-one-test-file-out (process level only) |

Residual-type scores are standardised with calibration residuals (last 10% of every training file). For every episode the
per-second channel scores are averaged from the labelled onset to time τ; groups (processes, loops) are scored by the
maximum over their channels; tags are ranked directly. A call is correct when the top-ranked group is among the targeted
ones; time-to-localise is the first τ from which the call stays correct for 30 s. Detection is scored with eTaPR
(θp = 0.5, θr = 0.1), re-implemented in `src/hailoc/etapr.py` from the reference package
<https://github.com/wshw4ng/eTaPR> (MIT licence) and verified against it.

## 4. Repository layout

```
run_all.py                  one-command pipeline (resumable steps)
requirements.txt            pinned Python packages (+ R packages)
meta/                       ground truth transcribed from the official manual
  attacks_hai2103.csv       50 attacks (75 primitive rows) with scenario codes and documented points
  attacks_hai2204.csv       58 attacks (83 primitive rows)
  primitives.csv            controller/variable -> point definitions
  tag_groups.csv            tag -> process, control loop, role, description (+ HAI 21.03 aliases)
src/hailoc/
  config.py                 paths, constants, method roster
  groundtruth.py            scenario parsing, episode alignment, documentation audit
  data.py                   loading, de-duplication, channel selection, standardisation
  models.py                 persistence, Ridge-VAR, PCA, LSTM, TCN
  scoring.py                residual and correlation-break evidence, run storage
  attribution.py            IG-TCN, SHAP-iForest, SHAP-GBDT, GBDT-process
  localise.py               episode evaluation, time-to-localise, first-alarm and operational (alarm-anchored) localisation
  etapr.py                  eTaPR (delta = 0)
  stats.py                  bootstrap, McNemar, Cochran's Q, Tango score interval/test for paired proportions, Kaplan-Meier, RMST
  plotting.py, schematic.py, docx_utils.py
scripts/
  01_download.py            data + manual, SHA-256 manifest
  02_prepare.py             processed arrays, episodes, attack tables
  03_scores.py              all methods and seeds (resumable)
  04_sensitivity.py         lag sets, unstandardised residuals, past-only training
  05_evaluate.py            episode records, curves, detection, alarm-time localisation, cross-detector triggering
  06_stats.py               summaries and tests
  08_tables.py              26 tables (CSV + registry)
  09_figures.py             18 figures (PNG, 300 dpi + registry)
  10_consistency_checks.py  re-derives every reported number and checks the Word document
  11_build_docx.py          Tables_and_Figures.docx
R/07_models.R               mixed-effects logistic regression, Cox models, log-rank tests
notebooks/walkthrough.ipynb end-to-end example for one method and episode
```

## 5. Installation

```bash
python -m venv .venv
.venv\Scripts\activate            # Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

R (≥ 4.3) with `lme4`, `survival` and `emmeans` is needed for step `rmodels`:
`install.packages(c("lme4", "survival", "emmeans"))`. `run_all.py` finds `Rscript` on the PATH or in the default
Windows install location.

## 6. Reproducing the results

```bash
python run_all.py                       # download -> prepare -> scores -> ... -> docx -> checks
```

Data, run files and outputs are written below the repository root, or below the folder named by the environment
variable `HAILOC_ROOT` if it is set. Steps can be run individually, e.g. `python run_all.py --from evaluate` re-analyses
stored runs in a few minutes. `03_scores.py` skips any method/seed whose run file already exists.

| Step | Output | Time on a 4-core laptop CPU |
|---|---|---|
| download | `data/raw/` (~0.9 GB) + `sha256_manifest.json` | network-bound |
| prepare | `data/processed/<version>/` | ~3 min |
| scores | `runs/<version>/<METHOD>_s<seed>.npz/.json` | ~4–5 h (HAI 21.03, 3 seeds) + ~1 h (HAI 22.04) |
| sensitivity | `runs/hai-21.03/*_{L10,L30,L120,RAW,T1}_s0.*` | ~20 min |
| evaluate … checks | `outputs/analysis`, `outputs/tables`, `outputs/figures`, `outputs/Tables_and_Figures.docx`, `outputs/logs/consistency_report.csv` | ~10 min |

All randomness is seeded (NumPy, PyTorch, scikit-learn, LightGBM; seeds 0, 1, 2). Deep models run on CPU with a fixed
number of threads; re-running on different hardware or library builds can change the last digits of the neural-network
results, while all other steps are deterministic.

## 7. Key results

HAI 21.03, 50 episodes, seed 0, maximum aggregation (95% bootstrap intervals in `outputs/tables`):

| Method | Process top-1 | Loop top-1 (3 seeds) | Tag hit@3 | Loop RMST₁₂₀ (s) |
|---|---|---|---|---|
| Persistence (0 parameters) | 98.0% | 84.0% | 60.5% | 16.2 |
| Ridge-VAR | 94.0% | 66.0% | 58.1% | 45.5 |
| LSTM | 96.0% | 78.0% (82.7 ± 4.2) | 60.5% | 21.3 |
| TCN | 92.0% | 74.0% (64.0 ± 10.0) | 62.8% | 17.6 |
| IG on TCN | 98.0% | 84.0% (83.3 ± 1.2) | 65.1% | 22.5 |
| SHAP on iForest | 76.0% | 52.0% (28.7 ± 20.4) | 23.3% | 60.3 |
| SHAP on GBDT (supervised) | 98.0% | 78.0% (78.7 ± 1.2) | 69.8% | 19.2 |
| Correlation break | 92.0% | 56.0% | 14.0% | 63.8 |
| Always P1 / random ranking | 68.0% / 32.0% | – / 16.0% | – / 9.2% | – |

* Process-level localisation is close to ceiling for most methods; the control loop and the tag are where methods
  differ.
* The zero-parameter persistence residual is non-inferior to the LSTM and TCN forecasters at loop level (margin −10
  percentage points; bootstrap and Tango score intervals agree, one-sided score p = .003 and .005; table T18). Its lead
  over Ridge-VAR (+18 pp) is not significant after Holm adjustment (McNemar p = .064, Holm p = .572) and comes from
  combined attacks scored leniently; under strict scoring IG-TCN leads (76%) and persistence equals the LSTM (62%) (T25).
* From the labelled onset, persistence localises the loop fastest (RMST₁₂₀ 16.2 s vs 45.5 s for Ridge-VAR). As its own
  detector it alarms in only 52% of episodes (RMST₁₂₀ 85.9 s from onset); triggered by the Ridge-VAR detector it reaches
  88% localised and 29.2 s, on par with TCN/IG-TCN/LSTM (29.8–32.0 s). This gain does not replicate on HAI 22.04 (T26).
* Setpoint manipulations hide the setpoint change, so the logged setpoint keeps its normal value: their loops are found
  through downstream effects, but the manipulated tag is rarely ranked in the top 3 (0 of 6 episodes for persistence,
  LSTM and TCN).
* Residual standardisation is essential (persistence loop accuracy falls from 84% to 36% without it); TCN accuracy
  collapses when only the earliest training file is available (loop 72% → 32% on the same 25 episodes).
* SHAP on an Isolation Forest is the least accurate and least stable method; correlation breaks never cross a
  calibrated alarm threshold.
* On HAI 22.04 (58 episodes) the ranking of methods changes: Ridge-VAR reaches the highest loop accuracy (75.9%),
  persistence 67.2%, LSTM 72.4%.

## 8. Scope and limitations

Attribution identifies where the evidence of an attack concentrates; it does not establish physical causality. Ground
truth is limited to the targets documented in the official manual. HAI attacks are executed on a single testbed with a
hardware-in-the-loop coupling, so effects propagate across processes; generalisation to other plants requires
re-validation. Several documented targets are constant in the logged training data or concealed by the attack itself,
which bounds the achievable tag-level accuracy.

## 9. Revision history

* **Revision 1 (2026-10-27).** In response to peer review: Tango score intervals and one-sided score tests added to the
  paired comparisons and non-inferiority analysis (`stats.tango`, T08, T18); strict scoring of combined attacks
  (`loop_all_topm`) and a ground-truth sensitivity table (T25: single-primitive, single-loop, documentation-consistent and
  visible-target subsets, both releases); operational time-to-localise anchored at the first alarm of the method itself
  or of the Ridge-VAR/PCA detector (`Evaluator._ttl_operational`, `A_cross_alarm.csv`, T26); 405 consistency checks. All
  previously reported values are unchanged.

## 10. Citation

If you use this code, please cite the accompanying article and the HAI datasets:

* Shin, H.-K., Lee, W., Yun, J.-H., & Min, B.-G. (2021). Two ICS security datasets and anomaly detection contest on
  the HIL-based augmented ICS testbed. *Cyber Security Experimentation and Test Workshop (CSET '21)*, 36–40.
  https://doi.org/10.1145/3474718.3474719
* Hwang, W.-S., Yun, J.-H., Kim, J., & Min, B.-G. (2022). "Do you know existing accuracy metrics overrate time-series
  anomaly detections?" *Proceedings of the 37th ACM/SIGAPP Symposium on Applied Computing*, 403–412.
  https://doi.org/10.1145/3477314.3507024

## 11. Licence

Code: MIT (see `LICENSE`). Data: CC BY-SA 4.0, © The Affiliated Institute of ETRI; the data are not redistributed here.
