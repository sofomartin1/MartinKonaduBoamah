# Episode-level inferential models (HAI 21.03, seed 0, max aggregator).
#   1. Mixed-effects logistic regression: hit ~ method + attack_type + (1 | episode)
#   2. Cox proportional-hazards model of time-to-localise stratified by episode
#   3. Log-rank test across methods
# usage: Rscript R/07_models.R <analysis_dir>
suppressPackageStartupMessages({
  library(lme4)
  library(survival)
  library(emmeans)
})
args <- commandArgs(trailingOnly = TRUE)
adir <- if (length(args) > 0) args[1] else file.path(Sys.getenv("HAILOC_ROOT", "."), "outputs", "analysis")

ep <- read.csv(file.path(adir, "A_episode.csv"))
meta <- read.csv(file.path(adir, "A_episodes_meta.csv"))
d <- merge(ep[ep$agg == "max" & ep$seed == 0, ], meta[, c("ep", "attack_type", "combined")], by = "ep")
d <- d[d$method != "GBDT_PROC", ]
d$method <- relevel(factor(d$method), ref = "RIDGE")
d$attack_type <- factor(d$attack_type)
d$ep <- factor(d$ep)

glmm_rows <- list()
for (outcome in c("loop_hit1", "tag_hit3")) {
  dd <- d[!is.na(d[[outcome]]), ]
  dd$y <- as.integer(as.logical(dd[[outcome]]))
  f <- glmer(y ~ method + attack_type + (1 | ep), data = dd, family = binomial,
             control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 2e5)))
  co <- summary(f)$coefficients
  ci <- confint(f, parm = "beta_", method = "Wald")
  for (nm in rownames(co)) {
    glmm_rows[[length(glmm_rows) + 1]] <- data.frame(
      outcome = outcome, term = nm, estimate = co[nm, 1], se = co[nm, 2], z = co[nm, 3], p = co[nm, 4],
      odds_ratio = exp(co[nm, 1]), or_lo = exp(ci[nm, 1]), or_hi = exp(ci[nm, 2]),
      re_sd = sqrt(as.numeric(VarCorr(f)$ep)), n = nrow(dd), singular = isSingular(f))
  }
  em <- emmeans(f, ~ method, type = "response")
  write.csv(as.data.frame(em), file.path(adir, paste0("R_emmeans_", outcome, ".csv")), row.names = FALSE)
}
write.csv(do.call(rbind, glmm_rows), file.path(adir, "R_glmm.csv"), row.names = FALSE)

cox_rows <- list()
for (kind in c("proc", "loop")) {
  tt <- d[[paste0("ttl_", kind)]]; ev <- d[[paste0("event_", kind)]]
  dd <- d[!is.na(tt), ]
  dd$tt <- dd[[paste0("ttl_", kind)]]; dd$ev <- as.integer(dd[[paste0("event_", kind)]])
  fit <- coxph(Surv(tt, ev) ~ method + strata(ep), data = dd, ties = "efron")
  s <- summary(fit)
  for (nm in rownames(s$coefficients)) {
    cox_rows[[length(cox_rows) + 1]] <- data.frame(
      kind = kind, term = nm, hr = s$coefficients[nm, "exp(coef)"], p = s$coefficients[nm, "Pr(>|z|)"],
      hr_lo = s$conf.int[nm, "lower .95"], hr_hi = s$conf.int[nm, "upper .95"],
      n = s$n, events = s$nevent, concordance = unname(s$concordance[1]))
  }
  lr <- survdiff(Surv(tt, ev) ~ method, data = dd)
  df <- length(lr$n) - 1
  cox_rows[[length(cox_rows) + 1]] <- data.frame(
    kind = kind, term = "logrank_overall", hr = NA, p = 1 - pchisq(lr$chisq, df), hr_lo = lr$chisq, hr_hi = df,
    n = sum(lr$n), events = sum(lr$obs), concordance = NA)
}
write.csv(do.call(rbind, cox_rows), file.path(adir, "R_cox.csv"), row.names = FALSE)
cat("R models written\n")
