"""Run the full pipeline in order. Steps can be selected with --from / --to.

python run_all.py                      # everything (download -> docx)
python run_all.py --from evaluate      # re-analyse stored runs only
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STEPS = [
    ("download", [sys.executable, "scripts/01_download.py"]),
    ("prepare", [sys.executable, "scripts/02_prepare.py"]),
    ("scores", [sys.executable, "scripts/03_scores.py"]),
    ("sensitivity", [sys.executable, "scripts/04_sensitivity.py"]),
    ("evaluate", [sys.executable, "scripts/05_evaluate.py"]),
    ("stats", [sys.executable, "scripts/06_stats.py"]),
    ("rmodels", ["Rscript", "R/07_models.R"]),
    ("tables", [sys.executable, "scripts/08_tables.py"]),
    ("figures", [sys.executable, "scripts/09_figures.py"]),
    ("docx", [sys.executable, "scripts/11_build_docx.py"]),
    ("checks", [sys.executable, "scripts/10_consistency_checks.py"]),
]


def rscript():
    exe = shutil.which("Rscript")
    if exe:
        return exe
    for base in (Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "R").glob("R-*"):
        cand = base / "bin" / "Rscript.exe"
        if cand.exists():
            return str(cand)
    raise SystemExit("Rscript not found: install R (>= 4.3) with lme4, survival and emmeans")


def main():
    names = [s for s, _ in STEPS]
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="start", default=names[0], choices=names)
    ap.add_argument("--to", dest="stop", default=names[-1], choices=names)
    a = ap.parse_args()
    i, j = names.index(a.start), names.index(a.stop)
    for name, cmd in STEPS[i:j + 1]:
        if cmd[0] == "Rscript":
            cmd = [rscript()] + cmd[1:]
        print(f"=== {name}: {' '.join(cmd)}", flush=True)
        subprocess.run(cmd, cwd=HERE, check=True)


if __name__ == "__main__":
    main()
