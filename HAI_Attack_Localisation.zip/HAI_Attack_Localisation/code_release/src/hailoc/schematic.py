"""Study-design schematic (pipeline figure) drawn with matplotlib patches."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from . import plotting as P


def _box(ax, x, y, w, h, title, lines, fc, ec, fs=6.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.012", fc=fc, ec=ec, lw=1.1))
    ax.text(x + w / 2, y + h - 0.022, title, ha="center", va="top", fontsize=8.0, fontweight="bold", color=P.INK)
    ax.text(x + w / 2, y + h - 0.068, "\n".join(lines), ha="center", va="top", fontsize=fs, color=P.INK2,
            linespacing=1.38)


def _arrow(ax, a, b, rad=0.0):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=11, lw=1.2, color=P.INK2,
                                 shrinkA=1, shrinkB=1, connectionstyle=f"arc3,rad={rad}"))


def pipeline(n_ch_a, n_ch_b, n_ep_a, n_ep_b):
    fig, ax = plt.subplots(figsize=(9.0, 5.6))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    blue, blue_e = "#eaf2fc", "#2a78d6"
    green, green_e = "#e6f6ef", "#1baf7a"
    amber, amber_e = "#fdf3dc", "#eda100"
    red, red_e = "#fcebeb", "#e34948"
    grey, grey_e = "#f2f1ee", "#898781"
    y1, h1, w = 0.60, 0.38, 0.225
    xs = [0.01, 0.262, 0.514, 0.766]
    _box(ax, xs[0], y1, w, h1, "HAI testbed data", [
        "HAI 21.03 (primary)", f"{n_ep_a} attack episodes", f"{n_ch_a} varying tags", "",
        "HAI 22.04 (replication)", f"{n_ep_b} attack episodes", f"{n_ch_b} varying tags"], blue, blue_e)
    _box(ax, xs[1], y1, w, h1, "Preparation", [
        "train rows duplicated in test", "removed", "train-constant tags dropped",
        "z-score with training statistics", "last 10% of every training file", "= calibration set"], blue, blue_e)
    _box(ax, xs[2], y1, w, h1, "Evidence generators", [
        "Deviation: Z-score", "Reconstruction: PCA", "Forecast residual: Persistence,", "Ridge-VAR, LSTM, TCN",
        "Correlation break", "Attribution: IG-TCN, SHAP-iForest", "Supervised (leave-one-file-out):",
        "SHAP-GBDT, GBDT-process"], green, green_e)
    _box(ax, xs[3], y1, w, h1, "Episode localisation", [
        "per-second channel score s(t, c)", "cumulative evidence since onset", "E(tau, c) = mean s(t, c), t <= tau",
        "group aggregation (max)", "ranked processes P1-P4", "ranked control loops", "ranked tags",
        "first-alarm localisation"], amber, amber_e)
    y2, h2 = 0.17, 0.33
    _box(ax, 0.01, y2, 0.30, h2, "Ground truth", [
        "official technical manual: scenario code", "-> controller (control loop)", "-> process (P1-P3)",
        "-> manipulated points (tags)", "21.03 per-process labels agree", "with the manual for 50/50 episodes"],
         grey, grey_e)
    _box(ax, 0.35, y2, 0.30, h2, "Evaluation protocol", [
        "episode = labelled attack interval", "top-1 / top-k hit at every tau", "time-to-localise: correct for 30 s",
        "bootstrap 95% CIs over episodes", "McNemar / Cochran Q, GLMM, Cox", "eTaPR for detection"], grey, grey_e)
    _box(ax, 0.69, y2, 0.30, h2, "Research questions", [
        "RQ1 process and control-loop accuracy", "RQ2 tag hit@k by attack type", "RQ3 accuracy vs time since onset,",
        "time-to-localise", "RQ4 accuracy vs compute,", "non-inferiority of linear models"], red, red_e)
    ax.add_patch(FancyBboxPatch((0.01, 0.005), 0.98, 0.095, boxstyle="round,pad=0.006,rounding_size=0.012",
                                fc="#ffffff", ec=grey_e, lw=1.0, ls="--"))
    ax.text(0.5, 0.052, "Robustness: three seeds | aggregator | evidence window | stability window | lag set |\n"
            "residual standardisation | past-only training | documentation audit | target observability | HAI 22.04",
            ha="center", va="center", fontsize=6.6, color=P.INK2)
    for a, b in zip(xs[:-1], xs[1:]):
        _arrow(ax, (a + w + 0.002, y1 + h1 / 2), (b - 0.002, y1 + h1 / 2))
    _arrow(ax, (xs[3] + w / 2, y1 - 0.004), (0.50, y2 + h2 + 0.004), rad=-0.15)
    _arrow(ax, (0.31 + 0.002, y2 + h2 / 2), (0.35 - 0.002, y2 + h2 / 2))
    _arrow(ax, (0.65 + 0.002, y2 + h2 / 2), (0.69 - 0.002, y2 + h2 / 2))
    return fig
