"""Episode-level statistics: bootstrap intervals, paired tests, Kaplan-Meier and RMST."""
import numpy as np
import pandas as pd
from scipy import stats as st
from scipy.optimize import brentq
from statsmodels.stats.contingency_tables import mcnemar, cochrans_q
from statsmodels.stats.multitest import multipletests
from . import config as C


def boot_ci(x, B=C.N_BOOT, seed=0, stat=np.mean):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if len(x) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    bs = stat(x[rng.integers(0, len(x), (B, len(x)))], axis=1)
    return float(stat(x)), float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))


def paired_boot_diff(a, b, B=C.N_BOOT, seed=0):
    a, b = np.asarray(a, float), np.asarray(b, float)
    ok = ~(np.isnan(a) | np.isnan(b))
    d = a[ok] - b[ok]
    rng = np.random.default_rng(seed)
    bs = d[rng.integers(0, len(d), (B, len(d)))].mean(1)
    return float(d.mean()), float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))


def mcnemar_exact(a, b):
    a, b = np.asarray(a, bool), np.asarray(b, bool)
    tab = [[(a & b).sum(), (a & ~b).sum()], [(~a & b).sum(), (~a & ~b).sum()]]
    r = mcnemar(tab, exact=True)
    return int(tab[0][1]), int(tab[1][0]), float(r.pvalue)


def _tango_z(n10, n01, n, theta):
    """Tango (1998) score statistic for H0: p10 - p01 = theta in a paired 2x2 table."""
    m = n - n10 - n01
    lo, hi = max(0.0, -theta) + 1e-12, (1.0 - theta) / 2.0 - 1e-12
    if hi <= lo:
        return np.inf if n10 - n01 > n * theta else -np.inf

    def dlogl(p):
        return n10 / (p + theta) + n01 / p - 2 * m / (1 - 2 * p - theta)

    if dlogl(lo) * dlogl(hi) < 0:
        p = brentq(dlogl, lo, hi)
    else:
        p = lo if abs(dlogl(lo)) < abs(dlogl(hi)) else hi
    var = n * (2 * p + theta * (1 - theta))
    if n10 - n01 - n * theta == 0:
        return 0.0
    return (n10 - n01 - n * theta) / np.sqrt(max(var, 1e-300))


def tango(a, b, margin=None, alpha=0.05):
    """Paired difference mean(a) - mean(b) of binary outcomes with Tango's score interval.

    Returns (n10, n01, diff, lo, hi, p_ni) where p_ni is the one-sided score-test p-value of
    H0: diff <= margin (non-inferiority); nan when margin is None.
    """
    a, b = np.asarray(a, float), np.asarray(b, float)
    ok = ~(np.isnan(a) | np.isnan(b))
    a, b = a[ok].astype(bool), b[ok].astype(bool)
    n, n10, n01 = len(a), int((a & ~b).sum()), int((~a & b).sum())
    z = st.norm.ppf(1 - alpha / 2)
    d = (n10 - n01) / n
    eps = 1e-9

    def f(th, target):
        return _tango_z(n10, n01, n, th) - target

    # Z(theta) decreases in theta and equals 0 at theta = d
    lo = -1.0 if d <= -1 + eps or f(-1 + eps, z) <= 0 else brentq(f, -1 + eps, d, args=(z,))
    hi = 1.0 if d >= 1 - eps or f(1 - eps, -z) >= 0 else brentq(f, d, 1 - eps, args=(-z,))
    p_ni = np.nan if margin is None else float(1 - st.norm.cdf(_tango_z(n10, n01, n, margin)))
    return n10, n01, float(d), float(lo), float(hi), p_ni


def cochran(mat):
    r = cochrans_q(np.asarray(mat, int))
    return float(r.statistic), float(r.pvalue), mat.shape[1] - 1


def holm(p):
    return multipletests(p, method="holm")[1]


def km(times, events):
    """Kaplan-Meier estimate of P(not yet localised) -> DataFrame(t, surv)."""
    t = np.asarray(times, float); e = np.asarray(events, int)
    ut = np.unique(t[e == 1])
    s, rows = 1.0, [(0.0, 1.0)]
    for u in ut:
        n = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        s *= 1 - d / n
        rows.append((float(u), s))
    return pd.DataFrame(rows, columns=["t", "surv"])


def km_median(curve):
    below = curve[curve.surv <= 0.5]
    return float(below.t.iloc[0]) if len(below) else np.nan


def rmst(times, events, horizon=C.RMST_HORIZON):
    c = km(times, events)
    tt = np.r_[c.t.values, horizon]
    tt = np.clip(tt, 0, horizon)
    return float(np.sum(np.diff(tt) * c.surv.values))


def rmst_ci(times, events, horizon=C.RMST_HORIZON, B=C.N_BOOT, seed=0):
    t, e = np.asarray(times, float), np.asarray(events, int)
    rng = np.random.default_rng(seed)
    bs = [rmst(t[i], e[i], horizon) for i in rng.integers(0, len(t), (B, len(t)))]
    return rmst(t, e, horizon), float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))


def wilson(k, n, z=1.96):
    if n == 0:
        return np.nan, np.nan
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


def spearman(a, b):
    r = st.spearmanr(a, b, nan_policy="omit")
    return float(r.statistic), float(r.pvalue)
