"""Ground truth: official attack tables -> episode-level process, loop and tag targets."""
import re
import numpy as np
import pandas as pd
from . import config as C

_VAR = re.compile(r"(SP|PV|CO)(\d)")


def tag_groups():
    return pd.read_csv(C.META / "tag_groups.csv").fillna("")


def primitives():
    p = pd.read_csv(C.META / "primitives.csv")
    return {(r.controller, r.variable): r.point for r in p.itertuples()}


def alias_map(version):
    """canonical tag name -> column name used in the given dataset version"""
    tg = tag_groups()
    if version == "hai-21.03":
        return {r.tag: r.alias_hai2103 for r in tg.itertuples() if r.alias_hai2103}
    return {r.tag: r.tag for r in tg.itertuples()}


def parse_scenario(code):
    """'P1-FC-CO1PV1-ST10' -> controller 'P1-FC', variables ['CO1','PV1'], modifier 'ST'."""
    parts = code.split("-")
    ctrl = "-".join(parts[:2])
    vars_ = ["".join(m) for m in _VAR.findall(parts[2])]
    mod = ""
    if len(parts) > 3:
        mod = re.sub(r"\d+$", "", parts[3])
    return ctrl, vars_, mod


def scenario_points(code, version):
    prim = primitives()
    amap = alias_map(version)
    ctrl, vars_, _ = parse_scenario(code)
    canon = [prim[(ctrl, v)] for v in vars_]
    return canon, [amap.get(t, t) for t in canon]


def part_kind(code):
    _, vars_, _ = parse_scenario(code)
    kinds = {v[:2] for v in vars_}
    if "PV" in kinds:
        return "Sensor spoofing"
    if "CO" in kinds:
        return "Actuator manipulation"
    return "Setpoint manipulation"


def load_table(version):
    t = pd.read_csv(C.META / C.VERSIONS[version]["meta"])
    rows = []
    for r in t.itertuples():
        canon, cols = scenario_points(r.scenario, version)
        ctrl, vars_, mod = parse_scenario(r.scenario)
        # the manual writes the cooling setpoint as P1_PP04_SP; the data column is P1_PP04SP
        doc = [p.strip().replace("P1_PP04_SP", "P1_PP04SP") for p in str(r.doc_points).split(";")]
        rows.append(dict(no=r.no, attack_id=r.attack_id, part=r.part, scenario=r.scenario,
                         controller=ctrl, process=ctrl[:2], modifier=mod, kind=part_kind(r.scenario),
                         doc_points=";".join(doc), points_canon=";".join(canon), points=";".join(cols),
                         doc_consistent=sorted(doc) == sorted(canon), doc_duration_s=r.doc_duration_s))
        if version == "hai-21.03":
            assert r.controller == ctrl
            assert sorted(r.points.split(";")) == sorted(cols), (r.attack_id, r.points, cols)
    return pd.DataFrame(rows)


def label_runs(lab):
    lab = np.asarray(lab).astype(int)
    st = np.flatnonzero(np.diff(np.r_[0, lab]) == 1)
    en = np.flatnonzero(np.diff(np.r_[lab, 0]) == -1)
    return st, en


def episode_type(kinds):
    ks = set(kinds)
    if "Sensor spoofing" in ks:
        return "Sensor spoofing"
    if "Actuator manipulation" in ks:
        return "Actuator manipulation"
    return "Setpoint manipulation"


def build_episodes(version, test_meta, channels):
    """Align labelled runs in the concatenated test stream with the documentation table.

    test_meta: DataFrame with columns file, time, attack (+ attack_P1..P3 for 21.03).
    channels: retained candidate channels (dataset column names).
    """
    tab = load_table(version)
    st, en = label_runs(test_meta["attack"].values)
    nos = sorted(tab["no"].unique())
    assert len(st) == len(nos), (len(st), len(nos))
    eps = []
    for k, (s, e) in enumerate(zip(st, en)):
        parts = tab[tab["no"] == nos[k]]
        ctrls = sorted(set(parts["controller"]))
        procs_doc = sorted({c[:2] for c in ctrls})
        if "attack_P1" in test_meta:
            procs = sorted(p for p in ("P1", "P2", "P3") if test_meta[f"attack_{p}"].values[s:e + 1].any())
            assert procs == procs_doc, (parts["attack_id"].iloc[0], procs, procs_doc)
            onset_by_proc = {p: int(np.argmax(test_meta[f"attack_{p}"].values[s:e + 1])) for p in procs}
        else:
            procs = procs_doc
            onset_by_proc = {p: 0 for p in procs}
        tags = sorted({t for pts in parts["points"] for t in pts.split(";")})
        obs = [t for t in tags if t in channels]
        eps.append(dict(
            version=version, ep=k + 1, attack_id=parts["attack_id"].iloc[0], file=test_meta["file"].values[s],
            start=int(s), end=int(e), length=int(e - s + 1), start_time=str(test_meta["time"].values[s]),
            doc_duration_s=int(parts["doc_duration_s"].iloc[0]), n_parts=len(parts),
            scenario=" + ".join(parts["scenario"]), controllers=";".join(ctrls), processes=";".join(procs),
            n_processes=len(procs), tags=";".join(tags), tags_candidate=";".join(obs), n_tags_candidate=len(obs),
            attack_type=episode_type(parts["kind"]), combined=len(parts) > 1,
            short_term=bool((parts["modifier"] == "ST").any()), long_term=bool((parts["modifier"] == "LT").any()),
            primary_process=procs[0] if len(procs) == 1 else min(procs, key=lambda p: onset_by_proc[p]),
            second_onset_s=max(onset_by_proc.values()) if len(procs) > 1 else 0,
            doc_consistent=bool(parts["doc_consistent"].all()),
        ))
    return pd.DataFrame(eps), tab
