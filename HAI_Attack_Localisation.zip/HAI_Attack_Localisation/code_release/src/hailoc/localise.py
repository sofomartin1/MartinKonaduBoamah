"""Episode-level localisation: process, control-loop and tag rankings as evidence accumulates."""
import numpy as np
import pandas as pd
from math import comb
from . import config as C
from .data import Data
from .scoring import context_rows
from .etapr import etapr

AGGS = ["max", "mean", "top2", "sum", "cal"]


def _split(v):
    return [] if (not isinstance(v, str) or v == "") else v.split(";")


def group_scores(E, groups, agg):
    """E: (T, C) evidence; groups: list of channel-index arrays -> (T, G)."""
    out = np.empty((E.shape[0], len(groups)))
    for g, ix in enumerate(groups):
        sub = E[:, ix]
        if agg == "max":
            out[:, g] = sub.max(1)
        elif agg == "mean":
            out[:, g] = sub.mean(1)
        elif agg == "sum":
            out[:, g] = sub.sum(1)
        elif agg == "top2":
            k = min(2, sub.shape[1])
            out[:, g] = np.sort(sub, 1)[:, -k:].mean(1)
        else:
            raise ValueError(agg)
    return out


def ttl(hits, stability=C.STABILITY):
    """First 1-based tau from which the call is correct for `stability` s (or until the episode ends)."""
    L = len(hits)
    bad = np.flatnonzero(~hits)
    for t in np.flatnonzero(hits):
        stop = min(L, t + stability)
        nb = bad[(bad > t) & (bad < stop)]
        if len(nb) == 0:
            return t + 1, 1
    return L, 0


def p_random_topk(K, g, k):
    if g <= 0:
        return 0.0
    k = min(k, K)
    return 1.0 - comb(K - g, k) / comb(K, k) if K - g >= k else 1.0


class Evaluator:
    def __init__(self, D: Data):
        self.D = D
        self.rows, self.offs = context_rows(D)
        ch = np.array(D.channels)
        self.proc_names = [p for p in C.PROCESSES if (D.process == p).any()]
        self.proc_groups = [np.flatnonzero(D.process == p) for p in self.proc_names]
        self.loop_names = list(D.loops)
        self.loop_groups = [np.flatnonzero(D.loop == l) for l in self.loop_names]
        self.ch_index = {c: i for i, c in enumerate(ch)}
        ep = D.episodes
        self.eps = []
        for k, e in enumerate(ep.itertuples()):
            a = self.offs[k]
            ctx_start = self.rows[a]
            self.eps.append(dict(
                k=k, ep=e.ep, a=a, b=self.offs[k + 1], on=e.start - ctx_start, L=e.length,
                procs=_split(e.processes), loops=_split(e.controllers),
                tags=[self.ch_index[t] for t in _split(e.tags_candidate)]))

    # ------------------------------------------------------------------ per run
    def evaluate(self, run, method, seed, aggs=("max",), stability=C.STABILITY, evidence="cumulative"):
        rng = np.random.default_rng(12345)
        recs, curves = [], []
        S = run.get("S_ctx")
        Pp = run.get("P_ctx")
        cal = self._calibration(run) if ("cal" in aggs and "S_va" in run) else None
        for e in self.eps:
            noise_p = rng.random(len(self.proc_names)) * 1e-9
            noise_l = rng.random(len(self.loop_groups)) * 1e-9
            noise_c = rng.random(len(self.ch_index)) * 1e-9
            for agg in aggs:
                if agg == "cal" and cal is None:
                    continue
                if Pp is not None:
                    Gp = self._evidence(Pp[e["a"]:e["b"]], e, evidence)
                    Gp = np.c_[Gp, np.zeros((len(Gp), len(self.proc_names) - Gp.shape[1]))]
                    Gl = Ec = None
                else:
                    X = S[e["a"]:e["b"]].astype(np.float64)
                    if agg == "cal":
                        gp_t = (group_scores(X, self.proc_groups, "max") - cal["pm"]) / cal["ps"]
                        gl_t = (group_scores(X, self.loop_groups, "max") - cal["lm"]) / cal["ls"]
                        Gp = self._evidence(gp_t, e, evidence); Gl = self._evidence(gl_t, e, evidence)
                        Ec = self._evidence(X, e, evidence)
                    else:
                        Ec = self._evidence(X, e, evidence)
                        Gp = group_scores(Ec, self.proc_groups, agg)
                        Gl = group_scores(Ec, self.loop_groups, agg)
                rec, curve = self._score_episode(e, Gp, Gl, Ec, noise_p, noise_l, noise_c, stability)
                rec.update(method=method, seed=seed, agg=agg)
                recs.append(rec)
                for tau, vals in curve.items():
                    curves.append(dict(method=method, seed=seed, agg=agg, ep=e["ep"], tau=tau, **vals))
        return pd.DataFrame(recs), pd.DataFrame(curves)

    def _calibration(self, run):
        Sv = np.minimum(run["S_va"].astype(np.float64), 65000.0)
        gp = group_scores(Sv, self.proc_groups, "max"); gl = group_scores(Sv, self.loop_groups, "max")
        return dict(pm=gp.mean(0), ps=gp.std(0) + 1e-6, lm=gl.mean(0), ls=gl.std(0) + 1e-6)

    @staticmethod
    def _evidence(X, e, kind):
        seg = X[e["on"]:e["on"] + e["L"]]
        if kind == "cumulative":
            return np.cumsum(seg, 0) / np.arange(1, len(seg) + 1)[:, None]
        if kind == "trailing10":
            cs = np.cumsum(np.r_[np.zeros((1, seg.shape[1])), seg], 0)
            t = np.arange(1, len(seg) + 1)
            lo = np.maximum(t - 10, 0)
            return (cs[t] - cs[lo]) / (t - lo)[:, None]
        if kind == "ewma":
            out = np.empty_like(seg); acc = seg[0].copy()
            for i in range(len(seg)):
                acc = seg[i] if i == 0 else 0.9 * acc + 0.1 * seg[i]
                out[i] = acc
            return out
        raise ValueError(kind)

    def _score_episode(self, e, Gp, Gl, Ec, noise_p, noise_l, noise_c, stability):
        L = e["L"]
        pn = np.array(self.proc_names)
        pred_p = pn[np.argmax(Gp + noise_p, 1)]
        hit_p = np.isin(pred_p, e["procs"])
        rec = dict(ep=e["ep"], L=L, proc_pred=pred_p[-1], proc_hit=bool(hit_p[-1]), p4_pred=bool(pred_p[-1] == "P4"))
        order_p = np.argsort(-(Gp[-1] + noise_p))
        rec["proc_both_top2"] = bool(set(e["procs"]) <= set(pn[order_p[:2]])) if len(e["procs"]) > 1 else np.nan
        rec["ttl_proc"], rec["event_proc"] = ttl(hit_p, stability)
        curve = {}
        taus = sorted(set(C.TAU_GRID))
        for tau in taus:
            curve[tau] = dict(proc_hit=bool(hit_p[min(tau, L) - 1]))
        if Gl is not None:
            ln = np.array(self.loop_names)
            ranked = np.argsort(-(Gl + noise_l), 1)
            gt = np.isin(ln[ranked], e["loops"])
            hit_l1 = gt[:, 0]; hit_l3 = gt[:, :3].any(1)
            rec.update(loop_pred=ln[ranked[-1, 0]], loop_hit1=bool(hit_l1[-1]), loop_hit3=bool(hit_l3[-1]))
            # strict scoring: every targeted loop occupies the top-m ranks (m = number of targeted loops)
            m_t = len(set(e["loops"]))
            rec["loop_all_topm"] = bool(set(e["loops"]) <= set(ln[ranked[-1, :m_t]]))
            rec["ttl_loop"], rec["event_loop"] = ttl(hit_l1, stability)
            for tau in taus:
                curve[tau].update(loop_hit1=bool(hit_l1[min(tau, L) - 1]))
        if Ec is not None and len(e["tags"]):
            order = np.argsort(-(Ec + noise_c), 1)
            pos = np.argsort(order, 1)
            best = pos[:, e["tags"]].min(1) + 1
            rec.update(tag_rank=int(best[-1]), mrr=1.0 / best[-1],
                       **{f"tag_hit{k}": bool(best[-1] <= k) for k in (1, 3, 5, 10)})
            rec["ttl_tag3"], rec["event_tag3"] = ttl(best <= 3, stability)
            for tau in taus:
                curve[tau].update(tag_hit3=bool(best[min(tau, L) - 1] <= 3))
        return rec, curve

    # ------------------------------------------------------------------ detection
    def detection(self, run, method, seed, supervised=False):
        D = self.D
        sm = lambda x: pd.Series(x).rolling(C.DET_SMOOTH, min_periods=1).mean().values
        det = run["det_te"].astype(np.float64)
        dte = np.concatenate([sm(det[D.seg_te == f]) for f in np.unique(D.seg_te)])
        if supervised or len(run.get("det_va", [])) == 0:
            thr = 0.5
        else:
            dva = np.concatenate([sm(run["det_va"][D.seg_va == f]) for f in np.unique(D.seg_va)])
            thr = float(np.quantile(dva, C.DET_QUANTILE))
        y = D.meta["attack"].values.astype(int)
        res = etapr(y, dte > thr, C.ETAPR_THETA_P, C.ETAPR_THETA_R)
        best = dict(eTaF1=-1)
        for q in np.unique(np.quantile(dte, np.linspace(0.90, 0.9995, 60))):
            r = etapr(y, dte > q, C.ETAPR_THETA_P, C.ETAPR_THETA_R)
            if r["eTaF1"] > best["eTaF1"]:
                best = dict(r, thr=float(q))
        row = dict(method=method, seed=seed, threshold=thr, **res,
                   best_eTaF1=best["eTaF1"], best_eTaP=best["eTaP"], best_eTaR=best["eTaR"],
                   fpr=float(((dte > thr) & (y == 0)).sum() / max((y == 0).sum(), 1)))
        # per-episode first alarm (within the labelled interval)
        alarms = []
        for e, epi in zip(self.eps, D.episodes.itertuples()):
            seg = dte[epi.start:epi.end + 1] > thr
            first = int(np.argmax(seg)) if seg.any() else -1
            alarms.append(dict(method=method, seed=seed, ep=e["ep"], alarm=first >= 0,
                               delay=first + 1 if first >= 0 else np.nan))
        return row, pd.DataFrame(alarms)

    def at_alarm(self, run, alarms, method, seed, agg="max"):
        """Localise with evidence available at first alarm: trailing 10 s, and the 30 s after it."""
        S, Pp = run.get("S_ctx"), run.get("P_ctx")
        X = Pp if Pp is not None else S
        out = []
        pn = np.array(self.proc_names)
        for e, a in zip(self.eps, alarms.itertuples()):
            if not a.alarm:
                cens = {f"{k}_{lvl}_op": (e["L"] if k == "ttl" else 0) for k in ("ttl", "event")
                        for lvl in (("proc",) if Pp is not None else ("proc", "loop"))}
                out.append(dict(method=method, seed=seed, ep=e["ep"], alarm=False, **cens)); continue
            t = e["on"] + int(a.delay) - 1
            blk = X[e["a"]:e["b"]].astype(np.float64)
            rec = dict(method=method, seed=seed, ep=e["ep"], alarm=True, delay=a.delay)
            for name, lo, hi in (("at", t - 9, t + 1), ("plus30", t, min(t + 30, e["on"] + e["L"]))):
                ev = blk[max(lo, 0):hi].mean(0, keepdims=True)
                if Pp is not None:
                    gp = np.c_[ev, np.zeros((1, len(pn) - ev.shape[1]))]
                    rec[f"proc_hit_{name}"] = bool(pn[np.argmax(gp[0])] in e["procs"])
                    continue
                gp = group_scores(ev, self.proc_groups, agg)[0]
                gl = group_scores(ev, self.loop_groups, agg)[0]
                rec[f"proc_hit_{name}"] = bool(pn[np.argmax(gp)] in e["procs"])
                rec[f"loop_hit_{name}"] = bool(np.array(self.loop_names)[np.argmax(gl)] in e["loops"])
                if e["tags"]:
                    rank = np.argsort(np.argsort(-ev[0]))[e["tags"]].min() + 1
                    rec[f"tag_hit3_{name}"] = bool(rank <= 3)
            rec.update(self._ttl_operational(X, e, t, int(a.delay), Pp is not None, agg))
            out.append(rec)
        return pd.DataFrame(out)

    def _ttl_operational(self, X, e, t, delay, proc_only, agg, stability=C.STABILITY):
        """Time from onset to a stable correct call when evidence accumulates from 10 s before the first alarm.

        No knowledge of the onset is used for the call itself; episodes without a stable correct call before the
        episode ends are censored at the episode length.
        """
        lo, end = max(t - 9, 0), e["on"] + e["L"]
        seg = X[e["a"]:e["b"]][lo:end].astype(np.float64)
        cum = (np.cumsum(seg, 0) / np.arange(1, len(seg) + 1)[:, None])[t - lo:]
        pn = np.array(self.proc_names)
        out = {}
        if proc_only:
            gp = np.c_[cum, np.zeros((len(cum), len(pn) - cum.shape[1]))]
            levels = (("proc", pn[np.argmax(gp, 1)], e["procs"]),)
        else:
            levels = (("proc", pn[np.argmax(group_scores(cum, self.proc_groups, agg), 1)], e["procs"]),
                      ("loop", np.array(self.loop_names)[np.argmax(group_scores(cum, self.loop_groups, agg), 1)],
                       e["loops"]))
        for kind, pred, truth in levels:
            j, ev_ = ttl(np.isin(pred, truth), stability)
            out[f"ttl_{kind}_op"] = delay + j - 1 if ev_ else e["L"]
            out[f"event_{kind}_op"] = ev_
        return out

    # ------------------------------------------------------------------ chance references
    def baselines(self):
        K_p, K_l, K_c = len(self.proc_names), len(self.loop_names), len(self.ch_index)
        maj = pd.Series([p for e in self.eps for p in e["procs"]]).value_counts().idxmax()
        recs = []
        for e in self.eps:
            gp, gl, gc = len(e["procs"]), len(e["loops"]), len(e["tags"])
            recs.append(dict(method="RANDOM", ep=e["ep"], proc_hit=gp / K_p, loop_hit1=gl / K_l,
                             loop_hit3=p_random_topk(K_l, gl, 3),
                             **{f"tag_hit{k}": (p_random_topk(K_c, gc, k) if gc else np.nan) for k in (1, 3, 5, 10)}))
            recs.append(dict(method="MAJORITY", ep=e["ep"], proc_hit=float(maj in e["procs"])))
        return pd.DataFrame(recs), maj
