"""Attribution-based localisation: Integrated Gradients on the TCN detector score, TreeSHAP on an
Isolation Forest, and TreeSHAP on supervised gradient-boosting detectors (leave-one-file-out)."""
import time
import numpy as np
import torch
import lightgbm as lgb
import shap
from sklearn.ensemble import IsolationForest
from . import config as C
from .data import Data, segment_starts, windows, valid_targets
from .scoring import context_rows, run_path, save_run, load_run
from . import models as M


# ---------------------------------------------------------------- Integrated Gradients
def ig_tcn(D: Data, seed, model, steps=C.IG_STEPS, batch=128, log=print):
    """IG of g(W, x) = mean_c ((x_c - f(W)_c - m_c) / s_c)^2 w.r.t. (W, x); baseline = training mean (0)."""
    run, _ = load_run(D.version, "TCN", seed)
    m = torch.from_numpy(run["m"]); s = torch.from_numpy(run["s"])
    net = model.net.eval()
    st_te = segment_starts(D.seg_te)
    rows, _ = context_rows(D)
    alphas = (torch.arange(steps, dtype=torch.float32) + 0.5) / steps
    out = np.empty((len(rows), D.Xte.shape[1]), np.float32)
    t0 = time.perf_counter()
    for k in range(0, len(rows), batch):
        j = rows[k:k + batch]
        W = torch.from_numpy(windows(D.Xte, st_te, j)); x = torch.from_numpy(D.Xte[j])
        b = len(j)
        Wa = (alphas[:, None, None, None] * W[None]).reshape(steps * b, *W.shape[1:]).requires_grad_(True)
        xa = (alphas[:, None, None] * x[None]).reshape(steps * b, -1).requires_grad_(True)
        g = (((xa - net(Wa) - m) / s) ** 2).mean(1).sum()
        gW, gx = torch.autograd.grad(g, [Wa, xa])
        gW = gW.reshape(steps, b, *W.shape[1:]).mean(0); gx = gx.reshape(steps, b, -1).mean(0)
        attr = (W * gW).sum(1) + x * gx
        out[k:k + batch] = attr.clamp(min=0).detach().numpy()
    dt = time.perf_counter() - t0
    info = dict(method="IG_TCN", seed=seed, version=D.version, attr_s=dt, attr_us_per_step=1e6 * dt / len(rows),
                n_params=int(model.n_params), steps=steps)
    det = load_run(D.version, "TCN", seed)[0]
    save_run(run_path(D.version, "IG_TCN", seed), info, S_ctx=out, det_te=det["det_te"], det_va=det["det_va"])
    log(f"{D.version} IG_TCN s{seed}: {dt:.1f}s ({info['attr_us_per_step']:.0f} us/step)")
    return info


# ---------------------------------------------------------------- SHAP on Isolation Forest
def shap_iforest(D: Data, seed, log=print):
    P = C.IF_PARAMS
    rng = np.random.default_rng(seed)
    sub = D.Xtr[rng.choice(len(D.Xtr), P["train_rows"], replace=False)]
    t0 = time.perf_counter()
    iso = IsolationForest(n_estimators=P["n_estimators"], max_samples=P["max_samples"],
                          random_state=seed, n_jobs=C.THREADS).fit(sub)
    fit_s = time.perf_counter() - t0
    t1 = time.perf_counter()
    det_te = -iso.score_samples(D.Xte).astype(np.float32)
    inf_s = time.perf_counter() - t1
    det_va = -iso.score_samples(D.Xva).astype(np.float32)
    rows, _ = context_rows(D)
    ex = shap.TreeExplainer(iso)
    t2 = time.perf_counter()
    sv = ex.shap_values(D.Xte[rows])
    dt = time.perf_counter() - t2
    # TreeExplainer explains the expected path length: negative contributions shorten paths (more anomalous)
    S = np.clip(-sv, 0, None).astype(np.float32)
    info = dict(method="SHAP_IF", seed=seed, version=D.version, fit_s=fit_s, infer_s=inf_s,
                infer_us_per_step=1e6 * inf_s / len(D.Xte), attr_s=dt, attr_us_per_step=1e6 * dt / len(rows),
                n_params=int(sum(e.tree_.node_count for e in iso.estimators_)))
    save_run(run_path(D.version, "SHAP_IF", seed), info, S_ctx=S, det_te=det_te, det_va=det_va)
    log(f"{D.version} SHAP_IF s{seed}: fit {fit_s:.1f}s shap {dt:.1f}s")
    return info


# ---------------------------------------------------------------- supervised GBDT (leave-one-file-out)
def gbdt_features(X, seg, lag):
    st = segment_starts(seg)
    prev = X[np.maximum(np.arange(len(X)) - lag, st)]
    return np.concatenate([X, X - prev], 1)


def _lgb(seed, objective="binary"):
    P = {k: v for k, v in C.GBDT_PARAMS.items() if k not in ("normal_rows", "diff_lag")}
    return lgb.LGBMClassifier(objective=objective, random_state=seed, n_jobs=C.THREADS, verbose=-1, **P)


def supervised(D: Data, seed, log=print):
    """SHAP_GBDT (binary attack detector) and, for HAI 21.03, GBDT_PROC (per-process detectors)."""
    lag = C.GBDT_PARAMS["diff_lag"]
    Fte = gbdt_features(D.Xte, D.seg_te, lag)
    rng = np.random.default_rng(seed)
    nsub = rng.choice(len(D.Xtr), C.GBDT_PARAMS["normal_rows"], replace=False)
    Ftr_norm = gbdt_features(D.Xtr, D.seg_tr, lag)[nsub]
    y_att = D.meta["attack"].values.astype(int)
    procs = [p for p in ("P1", "P2", "P3") if f"attack_{p}" in D.meta]
    rows, _ = context_rows(D)
    c = D.Xte.shape[1]
    det = np.zeros(len(D.Xte), np.float32)
    S = np.zeros((len(rows), c), np.float32)
    Pp = np.zeros((len(rows), len(procs)), np.float32)
    detp = np.zeros((len(D.Xte), len(procs)), np.float32)
    fit_s = attr_s = 0.0
    for f in np.unique(D.seg_te):
        held = D.seg_te == f
        Xf = np.concatenate([Ftr_norm, Fte[~held]])
        yf = np.r_[np.zeros(len(Ftr_norm), int), y_att[~held]]
        t0 = time.perf_counter()
        clf = _lgb(seed).fit(Xf, yf)
        fit_s += time.perf_counter() - t0
        det[held] = clf.predict_proba(Fte[held])[:, 1]
        r = rows[held[rows]]
        t1 = time.perf_counter()
        contrib = clf.booster_.predict(Fte[r], pred_contrib=True)[:, :-1]
        attr_s += time.perf_counter() - t1
        S[held[rows]] = np.clip(contrib[:, :c], 0, None) + np.clip(contrib[:, c:], 0, None)
        for k, p in enumerate(procs):
            yp = np.r_[np.zeros(len(Ftr_norm), int), D.meta[f"attack_{p}"].values[~held].astype(int)]
            cp = _lgb(seed).fit(Xf, yp)
            detp[held, k] = cp.predict_proba(Fte[held])[:, 1]
        log(f"  {D.version} supervised s{seed} fold {f} done")
    Pp = detp[rows]
    info = dict(method="SHAP_GBDT", seed=seed, version=D.version, fit_s=fit_s, attr_s=attr_s,
                attr_us_per_step=1e6 * attr_s / len(rows), n_params=0, folds=int(len(np.unique(D.seg_te))))
    save_run(run_path(D.version, "SHAP_GBDT", seed), info, S_ctx=S, det_te=det, det_va=np.zeros(0, np.float32))
    if procs:
        info2 = dict(method="GBDT_PROC", seed=seed, version=D.version, processes=procs)
        save_run(run_path(D.version, "GBDT_PROC", seed), info2, P_ctx=Pp, det_te=detp.max(1),
                 det_va=np.zeros(0, np.float32))
    log(f"{D.version} supervised s{seed}: fit {fit_s:.1f}s")
    return info
