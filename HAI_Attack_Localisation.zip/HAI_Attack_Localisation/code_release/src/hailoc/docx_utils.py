"""Word helpers: APA-style three-line tables (9 pt, repeated header rows) and
figure blocks with 9-pt captions."""
import re

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


def new_document():
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.font.size = Pt(10)
    for s in doc.sections:
        s.left_margin = s.right_margin = Cm(2.0)
        s.top_margin = s.bottom_margin = Cm(2.0)
    for lvl in (1, 2):
        hs = doc.styles[f"Heading {lvl}"]
        hs.font.name = "Times New Roman"
        rf = hs.element.rPr.rFonts
        for att in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
            if rf.get(qn(att)) is not None:
                del rf.attrib[qn(att)]
        for att in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
            rf.set(qn(att), "Times New Roman")
        hs.font.size = Pt(10)
        hs.font.bold = True
        hs.font.italic = False
        hs.font.color.rgb = RGBColor(0, 0, 0)
        hs.paragraph_format.space_before = Pt(12)
        hs.paragraph_format.space_after = Pt(6)
        hs.paragraph_format.keep_with_next = True
    return doc


def _border(cell, **edges):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = tcPr.find(qn("w:tcBorders"))
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tcPr.append(borders)
    for edge, val in edges.items():
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), val.get("val", "single"))
        el.set(qn("w:sz"), str(val.get("sz", 8)))
        el.set(qn("w:color"), "000000")
        borders.append(el)


def _no_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "nil")
        b.append(el)
    tblPr.append(b)


def _fix_layout(table, widths_cm):
    """Fixed table layout with explicit grid widths so Word keeps the column widths."""
    tblPr = table._tbl.tblPr
    lay = OxmlElement("w:tblLayout")
    lay.set(qn("w:type"), "fixed")
    tblPr.append(lay)
    tw = OxmlElement("w:tblW")
    tw.set(qn("w:w"), str(int(sum(widths_cm) * 567)))
    tw.set(qn("w:type"), "dxa")
    for old in tblPr.findall(qn("w:tblW")):
        tblPr.remove(old)
    tblPr.append(tw)
    grid = table._tbl.tblGrid
    for gc, w in zip(grid.findall(qn("w:gridCol")), widths_cm):
        gc.set(qn("w:w"), str(int(w * 567)))


def _keep_row(row, with_next):
    """Rows never split across pages; all but the last stay with the next row (keeps short tables whole)."""
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:cantSplit")
    el.set(qn("w:val"), "true")
    trPr.append(el)
    for c in row.cells:
        for par in c.paragraphs:
            par.paragraph_format.keep_with_next = with_next


def _repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    trPr.append(el)


def _cell_text(cell, text, bold=False, italic=False, size=9, align="center"):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.space_after = Pt(1)
    p.alignment = {"center": WD_ALIGN_PARAGRAPH.CENTER, "left": WD_ALIGN_PARAGRAPH.LEFT}[align]
    r = p.add_run(str(text))
    r.font.size = Pt(size)
    r.bold, r.italic = bold, italic


def caption(doc, kind, num, title, size=9):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8 if kind == "Table" else 2)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = kind == "Table"
    r = p.add_run(f"{kind} {num}")
    r.bold = True
    r.font.size = Pt(size)
    r2 = p.add_run(f". {title}")
    r2.font.size = Pt(size)
    return p


def note(doc, text, size=8):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(8)
    r = p.add_run("Note. ")
    r.italic = True
    r.bold = True
    r.font.size = Pt(size)
    r2 = p.add_run(text)
    r2.italic = True
    r2.font.size = Pt(size)


def _auto_widths(df, total_cm):
    """Column widths: never narrower than the longest single word (header or cell),
    remaining space shared in proportion to typical content length."""
    cm_per_char = 0.21                       # 9-pt Times, bold header (conservative)
    mins, wants = [], []
    for c in df.columns:
        vals = df[c].astype(str)
        words = str(c).split(" ") + [w for v in vals for w in v.split(" ")]  # non-breaking spaces bind words
        longest = max((len(w) for w in words), default=1)
        mins.append(min(longest, 18) * cm_per_char + 0.5)          # + cell margins
        wants.append(max(mins[-1], min(vals.str.len().quantile(0.9), 70) * cm_per_char * 0.9))
    if sum(wants) <= total_cm:
        return [w * total_cm / sum(wants) for w in wants]
    extra = total_cm - sum(mins)
    if extra <= 0:
        return [m * total_cm / sum(mins) for m in mins]
    surplus = [w - m for w, m in zip(wants, mins)]
    return [m + extra * s / sum(surplus) for m, s in zip(mins, surplus)]


_NUM = re.compile(r"^\s*[-+−<>≥≤~]?\s*[\d.,]+|^\s*[–-]\s*$|^\s*\[|^\s*∞")


def _is_numeric_col(series):
    vals = series.astype(str)
    return (vals.map(lambda v: bool(_NUM.match(v))).mean()) >= 0.6


def apa_table(doc, df, num, title, note_text=None, first_col_left=True, col_widths=None, bold_cells=None,
              total_width_cm=17.0):
    """APA three-line table. Long-text columns are left-aligned; widths follow content length."""
    caption(doc, "Table", num, title)
    t = doc.add_table(rows=1, cols=len(df.columns))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    _no_borders(t)
    text_col = [not _is_numeric_col(df[c]) for c in df.columns]
    align = ["left" if (j == 0 and first_col_left) or text_col[j] else "center" for j in range(len(df.columns))]
    hdr = t.rows[0]
    _repeat_header(hdr)
    for j, c in enumerate(df.columns):
        _cell_text(hdr.cells[j], c, bold=True, align=align[j])
        _border(hdr.cells[j], top={"sz": 12}, bottom={"sz": 6})
    bold_cells = bold_cells or set()
    for i, (_, row) in enumerate(df.iterrows()):
        cells = t.add_row().cells
        for j, c in enumerate(df.columns):
            _cell_text(cells[j], row[c], bold=(i, c) in bold_cells, align=align[j])
            if i == len(df) - 1:
                _border(cells[j], bottom={"sz": 12})
    for r in t.rows[:-1]:
        _keep_row(r, with_next=True)
    _keep_row(t.rows[-1], with_next=False)
    widths = col_widths or _auto_widths(df, total_width_cm)
    _fix_layout(t, widths)
    for j, w in enumerate(widths):
        for r in t.rows:
            r.cells[j].width = Cm(w)
    if note_text:
        note(doc, note_text)
    else:
        doc.add_paragraph().paragraph_format.space_after = Pt(4)
    return t


def figure(doc, path, num, title, width_cm=16.5):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(str(path), width=Cm(width_cm))
    caption(doc, "Figure", num, title)


def landscape_section(doc):
    s = doc.add_section()
    s.orientation = WD_ORIENT.LANDSCAPE
    s.page_width, s.page_height = s.page_height, s.page_width
    return s


def portrait_section(doc):
    s = doc.add_section()
    s.orientation = WD_ORIENT.PORTRAIT
    if s.page_width > s.page_height:
        s.page_width, s.page_height = s.page_height, s.page_width
    return s
