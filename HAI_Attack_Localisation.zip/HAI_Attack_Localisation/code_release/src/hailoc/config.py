"""Central configuration for the HAI attack-localisation benchmark."""
import os
from pathlib import Path

ROOT = Path(os.environ.get("HAILOC_ROOT", Path(__file__).resolve().parents[2]))
META = Path(__file__).resolve().parents[2] / "meta"
DATA_RAW = ROOT / "data" / "raw"
DATA_PROC = ROOT / "data" / "processed"
RUNS = ROOT / "runs"
OUT = ROOT / "outputs"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
ANALYSIS = OUT / "analysis"
LOGS = OUT / "logs"

TITLE = ("Actionable attack localisation in an industrial control testbed: An episode-level benchmark of "
         "control-loop accuracy and time-to-localise on HAI")

HAI_GITHUB = "https://github.com/icsdataset/hai"
RAW_BASE = "https://raw.githubusercontent.com/icsdataset/hai/master"
LFS_BASE = "https://media.githubusercontent.com/media/icsdataset/hai/master"

VERSIONS = {
    "hai-21.03": {
        "train": ["train1", "train2", "train3"],
        "test": ["test1", "test2", "test3", "test4", "test5"],
        "ext": ".csv.gz", "lfs": False, "time_col": "time",
        "label_cols": ["attack", "attack_P1", "attack_P2", "attack_P3"],
        "meta": "attacks_hai2103.csv",
    },
    "hai-22.04": {
        "train": ["train1", "train2", "train3", "train4", "train5", "train6"],
        "test": ["test1", "test2", "test3", "test4"],
        "ext": ".csv", "lfs": True, "time_col": "timestamp",
        "label_cols": ["Attack"],
        "meta": "attacks_hai2204.csv",
    },
}
PRIMARY = "hai-21.03"
REPLICATION = "hai-22.04"

# experimental constants
VAL_FRAC = 0.10          # trailing fraction of every training file held out for calibration
WINDOW = 60              # seconds of history used by the forecasters
SEEDS = [0, 1, 2]
THREADS = 4
CONTEXT_PRE = 300        # seconds stored before each attack onset
CONTEXT_POST = 120       # seconds stored after each attack end
DET_SMOOTH = 10          # causal moving-average length of the detection score (s)
DET_QUANTILE = 0.999     # validation quantile defining the alarm threshold
ETAPR_THETA_P = 0.5
ETAPR_THETA_R = 0.1
STABILITY = 30           # seconds a correct top-1 call must persist to count as localised
TAU_GRID = [5, 10, 20, 30, 60, 90, 120, 180, 240]
RMST_HORIZON = 120
N_BOOT = 2000
PROCESSES = ["P1", "P2", "P3", "P4"]

RIDGE_LAGS = [1, 2, 3, 4, 5, 10, 15, 20, 30, 45, 60]
RIDGE_ALPHAS = [0.1, 1.0, 10.0, 100.0, 1000.0]
PCA_VAR = 0.95
DEEP = dict(hidden=64, epochs=15, patience=3, batch=256, lr=1e-3,
            windows_per_epoch=60000, train_stride=5, val_stride=5)
IF_PARAMS = dict(n_estimators=200, max_samples=512, train_rows=60000)
GBDT_PARAMS = dict(n_estimators=300, learning_rate=0.05, num_leaves=31, subsample=0.8,
                   subsample_freq=1, colsample_bytree=0.8, min_child_samples=50,
                   normal_rows=150000, diff_lag=10)
IG_STEPS = 16

# method roster (order used in every table and figure)
METHODS = ["ZSCORE", "PCA", "PERSIST", "RIDGE", "LSTM", "TCN", "CORR", "IG_TCN", "SHAP_IF", "SHAP_GBDT", "GBDT_PROC"]
LABEL = {
    "ZSCORE": "Z-score deviation", "PCA": "PCA residual", "PERSIST": "Persistence residual",
    "RIDGE": "Ridge-VAR residual", "LSTM": "LSTM residual", "TCN": "TCN residual",
    "CORR": "Correlation break", "IG_TCN": "IG on TCN score", "SHAP_IF": "SHAP on iForest",
    "SHAP_GBDT": "SHAP on GBDT (supervised)", "GBDT_PROC": "GBDT process classifier (supervised)",
    "RANDOM": "Random ranking", "MAJORITY": "Majority process",
}
FAMILY = {
    "ZSCORE": "Deviation", "PCA": "Reconstruction", "PERSIST": "Forecast residual",
    "RIDGE": "Forecast residual", "LSTM": "Forecast residual", "TCN": "Forecast residual",
    "CORR": "Correlation break", "IG_TCN": "Gradient attribution", "SHAP_IF": "SHAP attribution",
    "SHAP_GBDT": "SHAP attribution", "GBDT_PROC": "Supervised classifier",
}
STOCHASTIC = {"LSTM", "TCN", "IG_TCN", "SHAP_IF", "SHAP_GBDT", "GBDT_PROC"}
RESIDUAL = {"ZSCORE", "PCA", "PERSIST", "RIDGE", "LSTM", "TCN", "CORR"}
SUPERVISED = {"SHAP_GBDT", "GBDT_PROC"}
# detectors whose first alarms trigger every localiser in the separate detector-localiser analysis
TRIGGER_DETECTORS = ["RIDGE", "PCA"]
REPL_METHODS = ["ZSCORE", "PCA", "PERSIST", "RIDGE", "LSTM", "TCN", "CORR", "IG_TCN", "SHAP_IF"]


def ensure_dirs():
    for p in (DATA_RAW, DATA_PROC, RUNS, TABLES, FIGURES, ANALYSIS, LOGS):
        p.mkdir(parents=True, exist_ok=True)
