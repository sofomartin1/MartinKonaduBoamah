"""Loading raw HAI files and building the processed, standardised arrays."""
import json
import numpy as np
import pandas as pd
from . import config as C
from . import groundtruth as G


def raw_path(version, name):
    return C.DATA_RAW / version / (name + C.VERSIONS[version]["ext"])


def read_raw(version, name):
    v = C.VERSIONS[version]
    d = pd.read_csv(raw_path(version, name))
    d = d.rename(columns={v["time_col"]: "time"})
    if version == "hai-22.04":
        d = d.rename(columns={"Attack": "attack"})
    return d


def label_columns(version):
    return ["attack", "attack_P1", "attack_P2", "attack_P3"] if version == "hai-21.03" else ["attack"]


def prepare(version):
    v = C.VERSIONS[version]
    labs = label_columns(version)
    tr_parts, va_parts, seg_tr, seg_va = [], [], [], []
    trains = [read_raw(version, f) for f in v["train"]]
    tests = []
    for i, f in enumerate(v["test"]):
        d = read_raw(version, f)
        d["file"] = f
        d["file_id"] = i
        tests.append(d)
    # HAI 21.03 train1 repeats the first 12 h of test3 (and one boundary row of test2):
    # rows whose timestamp also occurs in a test file are removed from the training data
    test_times = set(pd.concat([d["time"] for d in tests]))
    removed = []
    for i, d in enumerate(trains):
        dup = d["time"].isin(test_times).values
        removed.append(int(dup.sum()))
        trains[i] = d.loc[~dup].reset_index(drop=True)
    tags = [c for c in trains[0].columns if c != "time" and c not in labs]
    full = pd.concat(trains)[tags]
    channels = [c for c in tags if full[c].nunique() > 1]
    dropped = [c for c in tags if c not in channels]
    for i, d in enumerate(trains):
        n = len(d)
        cut = int(round(n * (1 - C.VAL_FRAC)))
        tr_parts.append(d[channels].values[:cut]); seg_tr.append(np.full(cut, i))
        va_parts.append(d[channels].values[cut:]); seg_va.append(np.full(n - cut, i))
    Xtr = np.concatenate(tr_parts).astype(np.float64)
    mu = Xtr.mean(0)
    sd = Xtr.std(0)
    rng = full[channels].max().values - full[channels].min().values
    sd = np.maximum(sd, 1e-3 * rng)
    sd[sd == 0] = 1.0
    te = pd.concat(tests, ignore_index=True)
    z = lambda a: ((a - mu) / sd).astype(np.float32)
    out = C.DATA_PROC / version
    out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / "arrays.npz",
                        Xtr=z(Xtr), seg_tr=np.concatenate(seg_tr).astype(np.int8),
                        Xva=z(np.concatenate(va_parts).astype(np.float64)), seg_va=np.concatenate(seg_va).astype(np.int8),
                        Xte=z(te[channels].values.astype(np.float64)), seg_te=te["file_id"].values.astype(np.int8))
    te[["file", "time"] + labs].to_csv(out / "test_meta.csv.gz", index=False)
    json.dump({"channels": channels, "dropped_constant": dropped, "mu": mu.tolist(), "sd": sd.tolist(),
               "n_train_rows": int(len(full)), "n_fit_rows": int(len(Xtr)),
               "n_val_rows": int(sum(len(p) for p in va_parts)), "n_test_rows": int(len(te)),
               "train_files": v["train"], "test_files": v["test"],
               "train_rows_removed_test_overlap": removed,
               "train_rows_per_file": [len(d) for d in trains],
               "test_rows_per_file": [int((te["file"] == f).sum()) for f in v["test"]],
               "train_span": [[str(d["time"].iloc[0]), str(d["time"].iloc[-1])] for d in trains],
               "test_span": [[str(d["time"].iloc[0]), str(d["time"].iloc[-1])] for d in tests]},
              open(out / "channels.json", "w"), indent=1)
    eps, tab = G.build_episodes(version, te[["file", "time"] + labs], channels)
    eps.to_csv(out / "episodes.csv", index=False)
    tab.to_csv(out / "attack_table.csv", index=False)
    return eps


class Data:
    """Processed arrays and metadata for one dataset version."""

    def __init__(self, version):
        self.version = version
        p = C.DATA_PROC / version
        a = np.load(p / "arrays.npz")
        self.Xtr, self.seg_tr = a["Xtr"], a["seg_tr"]
        self.Xva, self.seg_va = a["Xva"], a["seg_va"]
        self.Xte, self.seg_te = a["Xte"], a["seg_te"]
        self.info = json.load(open(p / "channels.json"))
        self.channels = self.info["channels"]
        self.meta = pd.read_csv(p / "test_meta.csv.gz")
        self.episodes = pd.read_csv(p / "episodes.csv")
        tg = G.tag_groups()
        amap = G.alias_map(version)
        inv = {v: k for k, v in amap.items()}
        canon = [inv.get(c, c) for c in self.channels]
        row = tg.set_index("tag").loc[canon]
        self.canon = canon
        self.process = row["process"].values
        self.loop = row["loop"].values
        self.loops = sorted(set(self.loop))

def segment_starts(seg):
    """Index of the first row of the segment that each row belongs to (segments are contiguous)."""
    seg = np.asarray(seg)
    first = np.r_[0, np.flatnonzero(np.diff(seg) != 0) + 1]
    owner = np.searchsorted(first, np.arange(len(seg)), side="right") - 1
    return first[owner]


def windows(X, starts, idx, w=C.WINDOW):
    """History windows X[t-w:t] for target indices idx, edge-padded at segment starts."""
    ii = idx[:, None] + np.arange(-w, 0)[None, :]
    ii = np.maximum(ii, starts[idx][:, None])
    return X[ii]


def valid_targets(starts, w=C.WINDOW):
    """Rows with a complete history window inside their own segment."""
    return np.flatnonzero(np.arange(len(starts)) - starts >= w)
