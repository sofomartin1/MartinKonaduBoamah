"""Normal-behaviour models: persistence, Ridge-VAR, PCA, LSTM and TCN forecasters."""
import time
import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import PCA
from . import config as C
from .data import windows, valid_targets


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)


# ---------------------------------------------------------------- Ridge-VAR
class RidgeVAR:
    """Linear forecaster of x_t - x_{t-1} from a sparse set of lagged values."""

    def __init__(self, lags=C.RIDGE_LAGS, alphas=C.RIDGE_ALPHAS):
        self.lags, self.alphas = list(lags), list(alphas)

    def _feat(self, X, starts, idx):
        cols = [X[np.maximum(idx - l, starts[idx])] for l in self.lags]
        return np.concatenate(cols + [np.ones((len(idx), 1), X.dtype)], 1).astype(np.float64)

    def fit(self, Xtr, st_tr, Xva, st_va, stride=2, chunk=20000):
        idx = valid_targets(st_tr, max(self.lags))[::stride]
        p = len(self.lags) * Xtr.shape[1] + 1
        A = np.zeros((p, p)); B = np.zeros((p, Xtr.shape[1]))
        for k in range(0, len(idx), chunk):
            j = idx[k:k + chunk]
            F = self._feat(Xtr, st_tr, j)
            Y = (Xtr[j] - Xtr[j - 1]).astype(np.float64)
            A += F.T @ F; B += F.T @ Y
        vidx = valid_targets(st_va, max(self.lags))
        Fv = self._feat(Xva, st_va, vidx); Yv = (Xva[vidx] - Xva[vidx - 1]).astype(np.float64)
        best = None
        self.val_curve = {}
        for a in self.alphas:
            reg = a * np.eye(p); reg[-1, -1] = 0.0
            W = np.linalg.solve(A + reg, B)
            mse = float(((Fv @ W - Yv) ** 2).mean())
            self.val_curve[a] = mse
            if best is None or mse < best[0]:
                best = (mse, a, W)
        _, self.alpha, self.W = best
        self.n_params = int(self.W.size)
        return self

    def predict(self, X, starts, idx, chunk=50000):
        out = np.empty((len(idx), X.shape[1]), np.float32)
        for k in range(0, len(idx), chunk):
            j = idx[k:k + chunk]
            out[k:k + chunk] = X[np.maximum(j - 1, starts[j])] + self._feat(X, starts, j) @ self.W
        return out


class Persistence:
    n_params = 0

    def fit(self, *a, **k):
        return self

    def predict(self, X, starts, idx):
        return X[np.maximum(idx - 1, starts[idx])]


class PCARecon:
    """Static reconstruction model (no temporal context)."""

    def fit(self, Xtr, seed=0, rows=200000):
        rng = np.random.default_rng(seed)
        sub = Xtr[rng.choice(len(Xtr), min(rows, len(Xtr)), replace=False)]
        full = PCA(random_state=seed).fit(sub)
        self.k = int(np.searchsorted(np.cumsum(full.explained_variance_ratio_), C.PCA_VAR) + 1)
        self.pca = PCA(n_components=self.k, random_state=seed).fit(sub)
        self.n_params = int(self.pca.components_.size + self.pca.mean_.size)
        return self

    def predict(self, X, starts, idx):
        return self.pca.inverse_transform(self.pca.transform(X[idx])).astype(np.float32)


# ---------------------------------------------------------------- deep forecasters
class LSTMNet(nn.Module):
    def __init__(self, c, h):
        super().__init__()
        self.rnn = nn.LSTM(c, h, num_layers=2, batch_first=True)
        self.head = nn.Linear(h, c)

    def forward(self, w):
        o, _ = self.rnn(w)
        return w[:, -1] + self.head(o[:, -1])


class CausalBlock(nn.Module):
    def __init__(self, cin, cout, k, d):
        super().__init__()
        self.pad = (k - 1) * d
        self.c1 = nn.Conv1d(cin, cout, k, dilation=d)
        self.c2 = nn.Conv1d(cout, cout, k, dilation=d)
        self.act = nn.ReLU()
        self.skip = nn.Conv1d(cin, cout, 1) if cin != cout else nn.Identity()

    def forward(self, x):
        y = self.act(self.c1(nn.functional.pad(x, (self.pad, 0))))
        y = self.act(self.c2(nn.functional.pad(y, (self.pad, 0))))
        return self.act(y + self.skip(x))


class TCNNet(nn.Module):
    def __init__(self, c, h, k=3, dil=(1, 2, 4, 8)):
        super().__init__()
        layers, cin = [], c
        for d in dil:
            layers.append(CausalBlock(cin, h, k, d)); cin = h
        self.net = nn.Sequential(*layers)
        self.head = nn.Linear(h, c)

    def forward(self, w):
        y = self.net(w.transpose(1, 2))
        return w[:, -1] + self.head(y[:, :, -1])


class DeepForecaster:
    def __init__(self, kind, seed):
        self.kind, self.seed = kind, seed

    def fit(self, Xtr, st_tr, Xva, st_va, log=print):
        set_seed(self.seed)
        torch.set_num_threads(C.THREADS)
        P = C.DEEP
        c = Xtr.shape[1]
        self.net = (LSTMNet if self.kind == "LSTM" else TCNNet)(c, P["hidden"])
        self.n_params = int(sum(p.numel() for p in self.net.parameters()))
        opt = torch.optim.Adam(self.net.parameters(), lr=P["lr"])
        tr_idx = valid_targets(st_tr)[::P["train_stride"]]
        va_idx = valid_targets(st_va)[::P["val_stride"]]
        rng = np.random.default_rng(self.seed)
        best, bad, self.history = np.inf, 0, []
        Xt = torch.from_numpy(Xtr); Xv = torch.from_numpy(Xva)
        for ep in range(P["epochs"]):
            self.net.train()
            sel = rng.choice(tr_idx, min(P["windows_per_epoch"], len(tr_idx)), replace=False)
            tl = 0.0
            for k in range(0, len(sel), P["batch"]):
                j = sel[k:k + P["batch"]]
                w = torch.from_numpy(windows(Xtr, st_tr, j)); y = Xt[j]
                loss = ((self.net(w) - y) ** 2).mean()
                opt.zero_grad(); loss.backward(); opt.step()
                tl += loss.item() * len(j)
            vl = float(((self.predict(Xva, st_va, va_idx) - Xva[va_idx]) ** 2).mean())
            self.history.append((ep + 1, tl / len(sel), vl))
            log(f"  {self.kind} s{self.seed} epoch {ep + 1} train {tl / len(sel):.5f} val {vl:.5f}")
            if vl < best - 1e-6:
                best, bad = vl, 0
                self.state = {k: v.clone() for k, v in self.net.state_dict().items()}
            else:
                bad += 1
                if bad >= P["patience"]:
                    break
        self.net.load_state_dict(self.state)
        self.epochs_run = len(self.history)
        return self

    @torch.no_grad()
    def predict(self, X, starts, idx, batch=2048):
        self.net.eval()
        out = np.empty((len(idx), X.shape[1]), np.float32)
        for k in range(0, len(idx), batch):
            j = idx[k:k + batch]
            out[k:k + batch] = self.net(torch.from_numpy(windows(X, starts, j))).numpy()
        return out


def timed(fn, *a, **k):
    t0 = time.perf_counter()
    r = fn(*a, **k)
    return r, time.perf_counter() - t0
