"""Per-channel evidence scores for residual, reconstruction and correlation-break methods."""
import json
import time
import numpy as np
from . import config as C
from .data import Data, segment_starts, windows, valid_targets
from . import models as M


F16_MAX = 65000.0  # calibration scores are stored as float16 (largest finite value 65504)


def context_rows(D: Data):
    """Rows stored for every episode: [onset - CONTEXT_PRE, end + CONTEXT_POST] within its file."""
    st = segment_starts(D.seg_te)
    ends = {}
    for s in np.unique(st):
        ends[s] = np.flatnonzero(st == s)[-1]
    rows, offs = [], [0]
    for e in D.episodes.itertuples():
        a = max(st[e.start], e.start - C.CONTEXT_PRE)
        b = min(ends[st[e.start]], e.end + C.CONTEXT_POST)
        rows.append(np.arange(a, b + 1))
        offs.append(offs[-1] + b - a + 1)
    return np.concatenate(rows), np.array(offs)


def run_path(version, method, seed=0, tag=""):
    p = C.RUNS / version
    p.mkdir(parents=True, exist_ok=True)
    return p / f"{method}{tag}_s{seed}"


def save_run(path, info, **arrays):
    np.savez_compressed(str(path) + ".npz", **arrays)
    json.dump(info, open(str(path) + ".json", "w"), indent=1)


def load_run(version, method, seed=0, tag=""):
    p = run_path(version, method, seed, tag)
    a = np.load(str(p) + ".npz")
    return {k: a[k] for k in a.files}, json.load(open(str(p) + ".json"))


def _standardise(res_va, res):
    m = res_va.mean(0)
    s = res_va.std(0)
    s[s < 1e-6] = 1e-6
    return m, s


def residual_method(D: Data, method, seed=0, train_files=None, lags=None, tag="", standardise=True, log=print):
    """Fit a normal-behaviour model and score every test row by standardised absolute residuals.

    train_files restricts both the fitting rows and the calibration (validation) rows to the
    listed training-file indices.
    """
    Xtr, seg_tr, Xva, seg_va = D.Xtr, D.seg_tr, D.Xva, D.seg_va
    if train_files is not None:
        mt, mv = np.isin(seg_tr, train_files), np.isin(seg_va, train_files)
        Xtr, seg_tr, Xva, seg_va = Xtr[mt], seg_tr[mt], Xva[mv], seg_va[mv]
    st_tr, st_va, st_te = segment_starts(seg_tr), segment_starts(seg_va), segment_starts(D.seg_te)
    extra = {}
    t0 = time.perf_counter()
    if method == "ZSCORE":
        model = M.Persistence(); model.n_params = 2 * Xtr.shape[1]
        pred = lambda X, st, idx: np.zeros((len(idx), X.shape[1]), np.float32)
    elif method == "PERSIST":
        model = M.Persistence(); pred = model.predict
    elif method == "RIDGE":
        model = M.RidgeVAR(lags=lags or C.RIDGE_LAGS).fit(Xtr, st_tr, Xva, st_va)
        pred = model.predict
        extra = {"alpha": model.alpha, "val_curve": {str(k): v for k, v in model.val_curve.items()},
                 "lags": model.lags}
    elif method == "PCA":
        model = M.PCARecon().fit(Xtr, seed=seed); pred = model.predict
        extra = {"components": model.k}
    elif method in ("LSTM", "TCN"):
        model = M.DeepForecaster(method, seed).fit(Xtr, st_tr, Xva, st_va, log=log)
        pred = model.predict
        extra = {"epochs_run": model.epochs_run, "history": model.history}
    else:
        raise ValueError(method)
    fit_s = time.perf_counter() - t0
    va_idx = np.arange(len(Xva))
    res_va = Xva - pred(Xva, st_va, va_idx)
    te_idx = np.arange(len(D.Xte))
    t1 = time.perf_counter()
    res_te = D.Xte - pred(D.Xte, st_te, te_idx)
    inf_s = time.perf_counter() - t1
    ok_va = valid_targets(st_va)
    if standardise:
        m, s = _standardise(res_va[ok_va], res_te)
    else:
        m, s = np.zeros(res_va.shape[1], np.float32), np.ones(res_va.shape[1], np.float32)
    S_te = np.abs((res_te - m) / s).astype(np.float32)
    S_va = np.abs((res_va - m) / s).astype(np.float32)
    rows, offs = context_rows(D)
    mse_va = (res_va[ok_va] ** 2).mean(0)
    info = dict(method=method, seed=seed, version=D.version, fit_s=fit_s, infer_s=inf_s,
                infer_us_per_step=1e6 * inf_s / len(te_idx), n_params=int(getattr(model, "n_params", 0)),
                val_mse=float(mse_va.mean()), val_mse_per_channel=mse_va.tolist(),
                val_mae=float(np.abs(res_va[ok_va]).mean()), standardised=standardise, **extra)
    out = dict(S_ctx=S_te[rows], det_te=(S_te ** 2).mean(1), det_va=(S_va ** 2).mean(1),
               S_va=np.minimum(S_va, F16_MAX).astype(np.float16), m=m.astype(np.float32), s=s.astype(np.float32))
    save_run(run_path(D.version, method, seed, tag), info, **out)
    log(f"{D.version} {method}{tag} s{seed}: fit {fit_s:.1f}s infer {inf_s:.1f}s val_mse {info['val_mse']:.4f}")
    return model, info


# ---------------------------------------------------------------- correlation break
def trailing(X, starts, idx, w):
    """Windows X[t-w+1 .. t] that include the current row, edge-padded at segment starts."""
    ii = idx[:, None] + np.arange(-w + 1, 1)[None, :]
    return X[np.maximum(ii, starts[idx][:, None])]


def _window_corr_batch(W, eps=1e-4):
    """W: (n, w, c) -> correlation matrices (n, c, c) and validity mask (n, c)."""
    Wc = W - W.mean(1, keepdims=True)
    var = (Wc ** 2).mean(1)
    ok = var > eps
    sd = np.sqrt(np.where(ok, var, 1.0))
    Z = Wc / sd[:, None, :]
    R = np.einsum("nwi,nwj->nij", Z, Z, optimize=True) / W.shape[1]
    return R, ok


def _rolling_corr_scores(X, starts, rbar, rsd, w, chunk=4000, eps=1e-4):
    """Per-row channel score: mean over partners of |rho_t - rho_bar| / rho_sd (valid pairs only)."""
    n, c = X.shape
    out = np.zeros((n, c), np.float32)
    for a in range(0, n, chunk):
        idx = np.arange(a, min(n, a + chunk))
        W = trailing(X, starts, idx, w)
        R, ok = _window_corr_batch(W.astype(np.float64), eps)
        D = np.abs(R - rbar[None]) / rsd[None]
        pair_ok = ok[:, :, None] & ok[:, None, :]
        pair_ok &= ~np.eye(c, dtype=bool)[None]
        D = np.where(pair_ok, D, 0.0)
        cnt = np.maximum(pair_ok.sum(2), 1)
        out[idx] = (D.sum(2) / cnt).astype(np.float32)
    return out


def corr_method(D: Data, w=C.WINDOW, n_ref=20000, seed=0, log=print):
    st_tr, st_va, st_te = segment_starts(D.seg_tr), segment_starts(D.seg_va), segment_starts(D.seg_te)
    t0 = time.perf_counter()
    rng = np.random.default_rng(seed)
    ref = rng.choice(valid_targets(st_tr, w), n_ref, replace=False)
    R, ok = _window_corr_batch(trailing(D.Xtr, st_tr, ref, w).astype(np.float64))
    pair_ok = (ok[:, :, None] & ok[:, None, :]).astype(np.float64)
    cnt = np.maximum(pair_ok.sum(0), 1)
    rbar = (R * pair_ok).sum(0) / cnt
    rsd = np.sqrt(((R - rbar) ** 2 * pair_ok).sum(0) / cnt) + 0.05
    fit_s = time.perf_counter() - t0
    c_va = _rolling_corr_scores(D.Xva, st_va, rbar, rsd, w)
    t1 = time.perf_counter()
    c_te = _rolling_corr_scores(D.Xte, st_te, rbar, rsd, w)
    inf_s = time.perf_counter() - t1
    ok_va = valid_targets(st_va, w)
    m, s = c_va[ok_va].mean(0), c_va[ok_va].std(0)
    s[s < 1e-6] = 1e-6
    S_te = np.clip((c_te - m) / s, 0, None).astype(np.float32)
    S_va = np.clip((c_va - m) / s, 0, None).astype(np.float32)
    rows, _ = context_rows(D)
    info = dict(method="CORR", seed=0, version=D.version, fit_s=fit_s, infer_s=inf_s,
                infer_us_per_step=1e6 * inf_s / len(D.Xte), n_params=int(rbar.size + rsd.size), window=w)
    save_run(run_path(D.version, "CORR", 0), info, S_ctx=S_te[rows], det_te=(S_te ** 2).mean(1),
             det_va=(S_va ** 2).mean(1), S_va=np.minimum(S_va, F16_MAX).astype(np.float16))
    log(f"{D.version} CORR: fit {fit_s:.1f}s infer {inf_s:.1f}s")
    return info
