"""Enhanced time-series aware precision and recall (eTaPR; Hwang et al., 2022), delta = 0.

Vectorised re-implementation of the reference package (https://github.com/wshw4ng/eTaPR, MIT
licence). With delta = 0 the overlap score of an anomaly/prediction pair is their overlap length.
"""
import numpy as np


def ranges(binary):
    b = np.asarray(binary).astype(np.int8)
    st = np.flatnonzero(np.diff(np.r_[0, b]) == 1)
    en = np.flatnonzero(np.diff(np.r_[b, 0]) == -1)
    return np.stack([st, en], 1) if len(st) else np.zeros((0, 2), int)


def overlap_matrix(A, P):
    lo = np.maximum(A[:, None, 0], P[None, :, 0])
    hi = np.minimum(A[:, None, 1], P[None, :, 1])
    return np.clip(hi - lo + 1, 0, None).astype(float)


def etapr(y_true, y_pred, theta_p=0.5, theta_r=0.1):
    A, P = ranges(y_true), ranges(y_pred)
    out = dict(eTaP=0.0, eTaR=0.0, eTaF1=0.0, eTaPd=0.0, eTaRd=0.0, n_alarm_ranges=len(P),
               precision=0.0, recall=0.0, f1=0.0)
    if len(A) == 0 or len(P) == 0:
        return out
    O = overlap_matrix(A, P)
    la = (A[:, 1] - A[:, 0] + 1).astype(float)
    lp = (P[:, 1] - P[:, 0] + 1).astype(float)
    E = O.copy()
    while True:
        tar = E.sum(1) / la
        ea = np.flatnonzero((tar < theta_r) & (tar != 0))
        E[ea] = 0
        tap = E.sum(0) / lp
        ep = np.flatnonzero((tap < theta_p) & (tap != 0))
        E[:, ep] = 0
        if len(ea) == 0 and len(ep) == 0:
            break
    sa = E.sum(1) / la
    da = (sa >= theta_r).astype(float)
    eTaR = float(((da + da * np.minimum(sa, 1.0)) / 2).mean())
    sp = E.sum(0) / lp
    dp = (sp >= theta_p).astype(float)
    w = np.sqrt(lp)
    eTaP = float((w * (dp + dp * sp) / 2).sum() / w.sum())
    out.update(eTaP=eTaP, eTaR=eTaR, eTaF1=0.0 if eTaP + eTaR == 0 else 2 * eTaP * eTaR / (eTaP + eTaR),
               eTaPd=float((w * dp).sum() / w.sum()), eTaRd=float(da.mean()))
    yt, yp = np.asarray(y_true).astype(bool), np.asarray(y_pred).astype(bool)
    tp = float((yt & yp).sum())
    pr = tp / max(yp.sum(), 1); rc = tp / max(yt.sum(), 1)
    out.update(precision=pr, recall=rc, f1=0.0 if pr + rc == 0 else 2 * pr * rc / (pr + rc))
    return out
