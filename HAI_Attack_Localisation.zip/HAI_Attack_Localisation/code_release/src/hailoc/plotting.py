"""Shared figure style: one fixed colour per method, ramps for heatmaps."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402

from . import config as C  # noqa: E402

INK, INK2, MUTED, GRID, AXIS, SURFACE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#ffffff"
COLOR = {"ZSCORE": "#898781", "PCA": "#b07aa1", "PERSIST": "#1baf7a", "RIDGE": "#2a78d6", "LSTM": "#eda100",
         "TCN": "#e34948", "CORR": "#8c564b", "IG_TCN": "#e87ba4", "SHAP_IF": "#6250d6", "SHAP_GBDT": "#0d366b",
         "GBDT_PROC": "#2f2f2f", "RANDOM": "#c3c2b7", "MAJORITY": "#52514e"}
MARKER = {"ZSCORE": "X", "PCA": "P", "PERSIST": "o", "RIDGE": "s", "LSTM": "D", "TCN": "^", "CORR": "v",
          "IG_TCN": "<", "SHAP_IF": "h", "SHAP_GBDT": "H", "GBDT_PROC": "*", "RANDOM": ".", "MAJORITY": "_"}
SHORT = {"ZSCORE": "Z-score", "PCA": "PCA", "PERSIST": "Persistence", "RIDGE": "Ridge-VAR", "LSTM": "LSTM",
         "TCN": "TCN", "CORR": "Corr-break", "IG_TCN": "IG-TCN", "SHAP_IF": "SHAP-iForest",
         "SHAP_GBDT": "SHAP-GBDT", "GBDT_PROC": "GBDT-process", "RANDOM": "Random", "MAJORITY": "Majority (P1)"}
PROC_COLOR = {"P1": "#2a78d6", "P2": "#e34948", "P3": "#1baf7a", "P4": "#eda100"}
SEQ = LinearSegmentedColormap.from_list("seq_blue", ["#f4f8fd", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
HEAT = LinearSegmentedColormap.from_list("heat", ["#b42d2c", "#ef9a99", "#f6e7c6", "#86c7a9", "#1baf7a", "#0b6b48"])
FIRE = LinearSegmentedColormap.from_list("fire", ["#ffffff", "#fde8c8", "#f8b46b", "#e8663c", "#b42d2c", "#5c0f10"])


def setup():
    plt.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 300, "font.family": "DejaVu Sans", "font.size": 8.5,
        "axes.titlesize": 9, "axes.labelsize": 8.5, "axes.edgecolor": AXIS, "axes.labelcolor": INK,
        "axes.linewidth": 0.8, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
        "axes.spines.top": False, "axes.spines.right": False, "xtick.color": INK2, "ytick.color": INK2,
        "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5, "legend.frameon": False,
        "lines.linewidth": 1.8, "lines.markersize": 5, "axes.axisbelow": True, "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE, "axes.titleweight": "bold",
        "axes.titlelocation": "left",
    })


def panel_label(ax, s):
    ax.text(-0.02, 1.04, s, transform=ax.transAxes, fontweight="bold", fontsize=10, va="bottom", ha="right", color=INK)


def save(fig, name):
    C.FIGURES.mkdir(parents=True, exist_ok=True)
    fig.savefig(C.FIGURES / f"{name}.png", bbox_inches="tight")
    plt.close(fig)
