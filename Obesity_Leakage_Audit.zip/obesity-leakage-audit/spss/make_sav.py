"""Write spss/obesity_levels_audit.sav: the 2,111 records in file order with both provenance
flags, BMI and the BMI cut-point class, with SPSS variable and value labels. The companion
syntax obesity_levels_audit.sps reproduces the provenance and BMI audit tables in SPSS.

    python spss/make_sav.py
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "src"))

import numpy as np  # noqa: E402
import pyreadstat  # noqa: E402

from obaudit.config import load_config  # noqa: E402
from obaudit.data import bmi, bmi_rule, label_codes, load_dataset, provenance  # noqa: E402

cfg = load_config()
CL = cfg["data"]["classes"]
df = load_dataset()
out = df.copy()
out.insert(0, "RowID", np.arange(1, len(df) + 1))
out["Class"] = label_codes(df["NObeyesdad"]) + 1
out["Authentic_file"] = provenance(df, "file_order").astype(int)
out["Authentic_discrete"] = provenance(df, "discrete").astype(int)
out["BMI"] = bmi(df).round(4)
out["BMI_rule_class"] = bmi_rule(out["BMI"].to_numpy()) + 1
out["BMI_rule_agrees"] = (out["BMI_rule_class"] == out["Class"]).astype(int)
out = out.drop(columns=["NObeyesdad"])
labels = {
    "RowID": "Row position in the distributed UCI file", "Gender": "Gender", "Age": "Age (years)",
    "Height": "Height (m)", "Weight": "Weight (kg)",
    "family_history_with_overweight": "Family history of overweight", "FAVC": "Frequent high-calorie food",
    "FCVC": "Vegetable consumption frequency", "NCP": "Number of main meals", "CAEC": "Food between meals",
    "SMOKE": "Smokes", "CH2O": "Daily water intake", "SCC": "Monitors calorie intake",
    "FAF": "Physical-activity frequency", "TUE": "Time using technology devices", "CALC": "Alcohol consumption",
    "MTRANS": "Mode of transport", "Class": "Obesity level (published label)",
    "Authentic_file": "Authentic record, file-structure rule", "Authentic_discrete": "Authentic record, antecedent discrete rule",
    "BMI": "Body mass index (kg/m2)", "BMI_rule_class": "Class from BMI cut-points", "BMI_rule_agrees": "BMI rule reproduces label",
}
cls = {i + 1: c.replace("_", " ") for i, c in enumerate(CL)}
yn = {0: "No", 1: "Yes"}
vlab = {"Class": cls, "BMI_rule_class": cls, "Authentic_file": yn, "Authentic_discrete": yn, "BMI_rule_agrees": yn}
pyreadstat.write_sav(out, HERE / "obesity_levels_audit.sav", column_labels=labels, variable_value_labels=vlab)
print("wrote obesity_levels_audit.sav", out.shape)
