* Encoding: UTF-8.
* Provenance and label audit of the UCI Estimation of Obesity Levels dataset.
* Open spss/obesity_levels_audit.sav first (File > Open > Data), then run all.
* Output reproduces Table 3 (composition, BMI agreement), the concordance in Table 2,
* the BMI-rule confusion of Figure 2b and the descriptive statistics of Table A1.

DATASET NAME audit WINDOW=FRONT.

* 1. Record provenance by class (Table 3, authentic / synthetic columns).
CROSSTABS /TABLES=Class BY Authentic_file /CELLS=COUNT ROW.

* 2. Concordance of the two provenance rules (Table 2).
CROSSTABS /TABLES=Authentic_file BY Authentic_discrete /CELLS=COUNT TOTAL.

* 3. The survey block is rows 1-498; the synthetic block starts at row 499.
DESCRIPTIVES VARIABLES=RowID /STATISTICS=MIN MAX.
SORT CASES BY Authentic_file.
SPLIT FILE LAYERED BY Authentic_file.
DESCRIPTIVES VARIABLES=RowID /STATISTICS=MIN MAX.
SPLIT FILE OFF.
SORT CASES BY RowID.

* 4. Label provenance: BMI by class and agreement of the cut-point rule (Figure 2, Table 3).
MEANS TABLES=BMI BY Class /CELLS=MEAN STDDEV MIN MAX COUNT.
FREQUENCIES VARIABLES=BMI_rule_agrees.
CROSSTABS /TABLES=Class BY BMI_rule_class /CELLS=COUNT.
CROSSTABS /TABLES=Class BY BMI_rule_agrees BY Authentic_file /CELLS=COUNT ROW.

* 5. Descriptive statistics by provenance (Table A1).
MEANS TABLES=Age Height Weight FCVC NCP CH2O FAF TUE BY Authentic_file /CELLS=MEAN STDDEV COUNT.
NPAR TESTS /M-W= Age Height Weight FCVC NCP CH2O FAF TUE BY Authentic_file(0 1).
CROSSTABS /TABLES=Gender family_history_with_overweight FAVC CAEC SMOKE SCC CALC MTRANS BY Authentic_file
  /STATISTICS=CHISQ PHI /CELLS=COUNT COLUMN.

* 6. Majority-class share among authentic records (57.63% Normal Weight).
TEMPORARY.
SELECT IF (Authentic_file = 1).
FREQUENCIES VARIABLES=Class.
