# Circular Labels and Synthetic Records

**A leakage-audited, behaviour-only re-evaluation of multi-class obesity-level classification on the UCI *Estimation of Obesity Levels* benchmark**

This repository holds the code and working files for the audit. It reproduces every table and figure from the public dataset with one command.

The benchmark has two documented defects that inflate reported accuracy:

1. **A circular label.** The seven-category label is assigned from body mass index (BMI), and BMI is computed from two of the dataset's own inputs, *Height* and *Weight*. Fixed BMI cut-points applied to those two columns reproduce **93.89%** of the published labels: **98.59%** of authentic records and **92.44%** of synthetic ones.
2. **A synthetic majority.** The dataset descriptor states that 77% of records were generated with SMOTE in Weka. The structure of the distributed file locates them exactly:
   - **rows 1–498** are the survey responses;
   - **rows 499–2,111** are 1,613 synthetic records, appended in class-sorted runs. There is no Normal Weight run, because the majority class was not oversampled.

The pipeline quantifies both defects. It recovers record provenance and checks it against four independent signatures, then re-evaluates eight learners plus two baselines in a 2 × 2 design that removes one defect at a time:

| Arm | Records | Attributes | n |
|---|---|---|---|
| A | all | all 16 | 2,111 |
| B | all | behaviour only (Height and Weight removed) | 2,111 |
| C | authentic | all 16 | 498 |
| D | authentic | behaviour only | 498 |

---

## Contents

```
obesity-leakage-audit/
├── README.md                  this file
├── requirements.txt           pinned Python dependencies
├── run_all.py                 runs the 15 pipeline stages in order
├── config/study.yaml          every setting: seed, CV design, hyperparameters, cut-points
├── data/
│   └── cleaned_obesity_levels_dataset.xlsx   the UCI file in its original row order (see Data)
├── src/obaudit/               the analysis library
│   ├── data.py                loading, BMI rule, provenance rules, the four arms
│   ├── models.py              leakage-safe pipelines for every learner and probe
│   ├── cv.py                  repeated stratified cross-validation with out-of-fold storage
│   ├── metrics.py             fold and pooled metrics, calibration, vectorised bootstrap
│   ├── stats.py               corrected resampled t, Holm, permutation p-values
│   ├── store.py, config.py, figstyle.py
├── scripts/                   numbered stages 01–15 (see Pipeline)
├── notebooks/walkthrough.ipynb   step-by-step walkthrough (distributed without outputs)
├── rapidminer/                RapidMiner Studio 7.1 working files
│   ├── make_workbook.py       writes rapidminer_obesity_levels.xlsx (provenance-flagged workbook)
│   ├── make_processes.py      writes processes/Arm{A,B,C,D}_*.rmp for your folder
│   ├── processes/             the four processes (file-structure provenance, 498 authentic)
│   ├── collect_results.py     turns RapidMiner fold logs into a results file
│   ├── antecedent_processes/  the earlier processes (496-record discrete-value rule)
│   ├── antecedent_logs/       their per-fold logs
│   └── antecedent_results/    their aggregated results (compared in Table A10)
├── spss/
│   ├── make_sav.py            writes obesity_levels_audit.sav
│   ├── obesity_levels_audit.sav
│   └── obesity_levels_audit.sps   syntax reproducing the provenance and BMI audit tables
├── tests/test_core.py         unit tests (pytest)
├── LICENSE, CITATION.cff, .gitignore
```

`results/` is created by the pipeline and is not part of the repository.

---

## Data

| Item | Detail |
|---|---|
| Name | Estimation of Obesity Levels Based On Eating Habits and Physical Condition |
| Repository | UCI Machine Learning Repository, dataset 544 |
| Landing page | https://archive.ics.uci.edu/dataset/544/estimation+of+obesity+levels+based+on+eating+habits+and+physical+condition |
| Dataset DOI | https://doi.org/10.24432/C5H31Z |
| Descriptor article | Palechor, F. M., & de la Hoz Manotas, A. (2019). Dataset for estimation of obesity levels based on eating habits and physical condition in individuals from Colombia, Peru and Mexico. *Data in Brief, 25*, 104344. https://doi.org/10.1016/j.dib.2019.104344 |
| Licence | Creative Commons Attribution 4.0 International (CC BY 4.0) |
| Size | 2,111 records, 16 attributes plus the label, no missing values, 24 exact duplicate rows |
| Population | Respondents aged 14–61 from Mexico, Peru and Colombia (survey part); the remainder is SMOTE output |

**File used.** `data/cleaned_obesity_levels_dataset.xlsx` is the UCI CSV `ObesityDataSet_raw_and_data_sinthetic.csv` with:

- **row order preserved**, which the provenance audit relies on;
- labels written with spaces instead of underscores;
- an extra `Authentic` column from an earlier analysis, which the code ignores and recomputes.

To work from the original file instead, download the CSV from the landing page and set `data.file` in `config/study.yaml` to its path. The loader handles either format, and every result is identical.

### Attributes

| Attribute | Description | Type | Group | Arms |
|---|---|---|---|---|
| Gender | Sex of respondent | binary | demographic | A–D |
| Age | Age in years | numeric | demographic | A–D |
| Height | Height in metres | numeric | **label source** | A, C |
| Weight | Weight in kilograms | numeric | **label source** | A, C |
| family_history_with_overweight | Family member has or had overweight | binary | family history | A–D |
| FAVC | Frequent consumption of high-calorie food | binary | dietary | A–D |
| FCVC | Frequency of vegetable consumption (1–3) | numeric (integer scale) | dietary | A–D |
| NCP | Number of main meals (1–4) | numeric (integer scale) | dietary | A–D |
| CAEC | Food between meals (no / Sometimes / Frequently / Always) | nominal | dietary | A–D |
| SMOKE | Smokes | binary | lifestyle | A–D |
| CH2O | Daily water intake (1–3) | numeric (integer scale) | dietary | A–D |
| SCC | Monitors calorie intake | binary | lifestyle | A–D |
| FAF | Physical-activity frequency (0–3) | numeric (integer scale) | activity | A–D |
| TUE | Time using technology devices (0–2) | numeric (integer scale) | activity | A–D |
| CALC | Alcohol consumption (no / Sometimes / Frequently / Always) | nominal | dietary | A–D |
| MTRANS | Usual transport (Automobile, Bike, Motorbike, Public_Transportation, Walking) | nominal | activity | A–D |
| **NObeyesdad** | Label: Insufficient_Weight, Normal_Weight, Overweight_Level_I, Overweight_Level_II, Obesity_Type_I, Obesity_Type_II, Obesity_Type_III | nominal | outcome | – |

**BMI cut-points** used by the label audit: 18.5, 25, 27, 30, 35 and 40 kg/m².

### Record provenance

There are two rules, implemented in `src/obaudit/data.py`.

- **File-structure rule (primary).**
  - *How it works:* the SMOTE output was appended class by class, so the synthetic block starts at the earliest row after which the labels form no more than seven contiguous runs.
  - *Inputs:* the labels only; no row number is hard-coded.
  - *Result:* **498 authentic** records (23.59%) and **1,613 synthetic** records.
- **Discrete-value rule (antecedent).**
  - *How it works:* survey answers are integers, ages whole years, heights two decimals and weights whole kilograms, so a record is flagged synthetic if any value falls off that scale.
  - *Result:* 496 authentic records.
  - *Errors against the file structure:* 17 survey records are flagged synthetic because their weight was recorded to 0.1 kg (13 of them are Normal Weight). 15 synthetic records are flagged authentic because they are exact copies with on-scale values. The rule is kept as sensitivity analysis S1.

Four independent signatures support the file-structure rule:

- every synthetic record lies inside the bounding box of its class's authentic records (1,613 of 1,613);
- synthetic-to-authentic ratios are integer oversampling multiples (7, 4, 4, 26, 107) for five of six classes;
- the share of off-scale values is 0% among authentic records and 99.07% among synthetic ones;
- synthetic records sit beside same-class siblings: 93.4% have a same-class nearest neighbour, against 45.8% of authentic records.

---

## Installation

Python 3.11–3.13. The analysis has been run with Python 3.13 on Linux; Windows and macOS work with the same pinned packages.

```bash
git clone <this repository>
cd obesity-leakage-audit
python -m venv .venv
# Windows: .venv\Scripts\activate      macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
pytest -q                               # 11 tests, about 10 seconds
```

## Reproducing everything

```bash
python run_all.py                 # all 15 stages; about 1–2 hours on a 2-core laptop
python run_all.py --from 12       # resume at a stage
python run_all.py --only 03 04    # selected stages
```

Outputs:

- `results/*.json` holds the estimates;
- `results/tables/` holds the CSV tables, with `display/` holding each display table as printed;
- `results/figures/` holds 300-dpi PNGs;
- `results/consistency_report.json` records the consistency gate;
- `results/Obesity_Leakage_Audit_Tables_and_Figures.docx` is the Word document with all tables and figures.

Raw cross-validation outputs are cached in `results/raw/`; delete `results/` to recompute from scratch. Every random step uses seed **2001** (`config/study.yaml`). Partitions, model seeds, permutation seeds and bootstrap seeds are all derived from it, so a rerun reproduces every number exactly. The one exception is wall-clock timing (Table A11).

### Pipeline

| Stage | Script | What it produces |
|---|---|---|
| 01 | `01_data_audit.py` | completeness, duplicates, class counts, descriptives by provenance, BMI-rule audit |
| 02 | `02_provenance_validation.py` | rule concordance, synthetic-block structure, bounding-box test, off-scale shares, nearest-neighbour geometry |
| 03 | `03_main_cv.py` | 10 × 10 repeated stratified CV for 4 arms × (8 learners + 2 baselines [+ 2 BMI probes in A, C]); fold metrics and out-of-fold probabilities |
| 04 | `04_estimates.py` | means, corrected resampled-t CIs, pooled AUC / Brier / log loss / ECE with bootstrap CIs, confusion matrices, per-class recall |
| 05 | `05_inference.py` | defect decomposition (A−B, C−D, A−C, B−D, A−D, interaction), tests against the majority class, pairwise comparisons, Holm adjustment |
| 06 | `06_permutation.py` | 1,000-permutation label tests in Arms C and D |
| 07 | `07_provenance_aware.py` | authentic-record performance after training on authentic + synthetic or synthetic-only data |
| 08 | `08_importance.py` | held-out permutation importance by attribute |
| 09 | `09_learning_curves.py` | learning curves on fixed test folds |
| 10 | `10_sensitivity.py` | S1 antecedent provenance rule; S2 duplicates removed; S3 coarser outcomes (+ permutation tests); S4 class weights; S5 random-forest feature subsampling; S6 nested tuning |
| 11 | `11_rapidminer_reconciliation.py` | comparison with the antecedent RapidMiner 7.1 results |
| 12 | `12_figures.py` | 13 main and 9 appendix figures (plotted values saved to `figure_data.json`) |
| 13 | `13_tables.py` | 13 main and 14 appendix display tables |
| 14 | `14_consistency.py` | re-derives every displayed number from raw outputs and checks all cross-display identities; stops the pipeline on any failure |
| 15 | `15_build_docx.py` | Word document of all tables and figures |

### Methods in brief

- **Leakage control.** One-hot encoding and range scaling sit inside each learner's pipeline and are fitted on the training fold only. Arms that share records (A/B and C/D) share partitions, so their comparisons are paired.
- **Learners.** Gaussian naive Bayes, multinomial logistic regression, decision tree, bagged trees, random forest, histogram gradient boosting, k-nearest neighbours and an RBF support vector machine. All settings are fixed in `config/study.yaml`; nested tuning is a sensitivity analysis.
- **References.**
  - *Baselines:* majority class and prior-stratified random predictions.
  - *Leakage probes (Arms A and C only):* the fixed BMI cut-point rule and a tree on BMI alone.
- **Metrics.**
  - *Fold level:* accuracy, balanced accuracy (macro recall), macro precision, macro F1, Cohen's κ and MCC, computed on each test fold.
  - *Pooled:* macro one-vs-rest AUC, multi-class Brier score, log loss and top-label ECE, computed on each repetition's out-of-fold predictions.
- **Uncertainty.**
  - *Fold metrics:* corrected resampled t (Nadeau & Bengio, 2003; Bouckaert & Frank, 2004).
  - *Pooled metrics:* percentile bootstrap with 1,000 record resamples.
  - *Across record sets:* Welch combination of the two corrected variances.
  - *Multiplicity:* Holm adjustment within families.
  - *Permutation tests:* p = (1 + exceedances)/(N + 1).

---

## RapidMiner Studio 7.1

The antecedent analysis was run in RapidMiner Studio 7.1.001. To rerun it with the corrected provenance:

```bash
python rapidminer/make_workbook.py                      # writes rapidminer/rapidminer_obesity_levels.xlsx
python rapidminer/make_processes.py --dir "C:\path\to\obesity-leakage-audit\rapidminer"
```

1. Import each `rapidminer/processes/*.rmp` (*File → Import Process*) and run it.
2. Each process writes per-fold logs `rm_log_<Arm>_<Learner>.csv` into the same folder.
3. Collect the logs:

```bash
python rapidminer/collect_results.py --logs rapidminer --out results/rapidminer_results.json
```

`make_processes.py --n-authentic 496` together with `make_workbook.py --rule discrete` rebuilds the antecedent configuration. Two points about the processes:

- The shipped processes point to `C:\obesity-leakage-audit\rapidminer`; regenerate them with `--dir` for another location, or edit the *excel file* parameter of the Read Excel operator.
- RapidMiner's learners differ in implementation from scikit-learn: its logistic regression is a kernel logistic regression fitted one-against-all, and its tree uses gain ratio with pessimistic pruning. Its numbers therefore agree with the Python results in direction and ordering, not to the decimal (Table A10, Figure A7).

## SPSS

`spss/obesity_levels_audit.sav` contains, for every record in file order:

- the row position;
- both provenance flags;
- BMI and the BMI cut-point class;
- full variable and value labels.

Open it and run `spss/obesity_levels_audit.sps` to reproduce Table 3, the rule concordance, the BMI confusion of Figure 2b and the descriptives of Table A1. `python spss/make_sav.py` regenerates the .sav.

---

## Citation

If you use this code, please cite the accompanying article and the dataset (see `CITATION.cff`):

> Estimation of Obesity Levels Based On Eating Habits and Physical Condition [Dataset]. (2019). UCI Machine Learning Repository. https://doi.org/10.24432/C5H31Z

## Licence

Code: MIT (see `LICENSE`). Data: CC BY 4.0, from the UCI Machine Learning Repository; the redistributed workbook keeps the original attribution.
