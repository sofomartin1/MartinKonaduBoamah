"""Unit tests for the provenance audit, metrics and leakage controls.  Run:  pytest -q"""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from obaudit.cv import splits  # noqa: E402
from obaudit.data import (arm_data, bmi, bmi_rule, detect_synthetic_block_start, feature_columns,  # noqa: E402
                          label_codes, load_dataset, provenance)
from obaudit.metrics import (_sk_fold_metrics, bootstrap_pooled, fold_metrics,  # noqa: E402
                             pooled_metrics)
from obaudit.models import make_model  # noqa: E402
from obaudit.stats import corrected_ci, holm, perm_pvalue  # noqa: E402


@pytest.fixture(scope="module")
def df():
    return load_dataset()


def test_dataset_shape_and_classes(df):
    assert df.shape == (2111, 17)
    assert df.isna().sum().sum() == 0
    assert np.bincount(label_codes(df["NObeyesdad"])).tolist() == [272, 287, 290, 290, 351, 297, 324]


def test_synthetic_block_detected_from_labels_alone(df):
    assert detect_synthetic_block_start(df["NObeyesdad"].to_numpy()) == 498


def test_provenance_counts(df):
    assert provenance(df, "file_order").sum() == 498
    assert provenance(df, "discrete").sum() == 496
    fo, dr = provenance(df, "file_order"), provenance(df, "discrete")
    assert (fo & dr).sum() == 481 and (fo & ~dr).sum() == 17 and (~fo & dr).sum() == 15


def test_no_normal_weight_record_is_synthetic(df):
    y = label_codes(df["NObeyesdad"])
    assert ((y == 1) & ~provenance(df)).sum() == 0


def test_bmi_rule_agreement(df):
    agree = bmi_rule(bmi(df)) == label_codes(df["NObeyesdad"])
    assert round(100 * agree.mean(), 2) == 93.89


def test_behaviour_arms_exclude_height_and_weight():
    num, nom = feature_columns("behaviour")
    assert "Height" not in num and "Weight" not in num and len(num) + len(nom) == 14


def test_fast_metrics_equal_sklearn():
    rng = np.random.default_rng(0)
    for _ in range(500):
        n = rng.integers(5, 50)
        yt, yp = rng.integers(0, rng.integers(1, 7), n), rng.integers(0, 7, n)
        a, b = fold_metrics(yt, yp), _sk_fold_metrics(yt, yp)
        assert all(abs(a[k] - b[k]) < 1e-12 for k in a)


def test_vectorised_bootstrap_equals_naive_loop():
    rng = np.random.default_rng(1)
    y = rng.integers(0, 7, 120)
    P = np.round(rng.dirichlet(np.ones(7), (2, 120)), 2)
    fast = bootstrap_pooled(y, P, 3, 7)
    r2 = np.random.default_rng(7)
    for i in range(3):
        ix = r2.integers(0, 120, 120)
        naive = [pooled_metrics(y[ix], P[r][ix]) for r in range(2)]
        for k in fast:
            assert abs(fast[k][i] - np.mean([v[k] for v in naive])) < 1e-12


def test_preprocessing_is_fitted_on_training_fold_only(df):
    X, y, _ = arm_data(df, "A")
    num, nom = feature_columns("all")
    tr, te = splits(y, n_repeats=1)[0][2:]
    m = make_model("LR", num, nom).fit(X.iloc[tr], y[tr])
    scaler = m.named_steps["pre"].named_transformers_["num"]
    assert np.allclose(scaler.data_min_, X.iloc[tr][num].min().to_numpy())


def test_paired_arms_share_partitions(df):
    sa, sb = splits(arm_data(df, "A")[1]), splits(arm_data(df, "B")[1])
    assert all(np.array_equal(a[3], b[3]) for a, b in zip(sa, sb))


def test_statistics_helpers():
    v = np.array([0.1, 0.2, 0.3, 0.4])
    m, lo, hi, se = corrected_ci(v, 1 / 9)
    assert m == pytest.approx(0.25) and lo < m < hi
    assert holm([0.01, 0.04, 0.03]).tolist() == pytest.approx([0.03, 0.06, 0.06])
    assert perm_pvalue(0.5, [0.1, 0.6, 0.2]) == pytest.approx(0.5)
