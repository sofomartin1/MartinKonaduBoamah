"""Write the RapidMiner input workbook with file-structure provenance.

Sheet 1 'cleaned_full' holds all 2,111 records with an 'Authentic' column (Yes/No) and
labels with spaces (as RapidMiner displays them); sheet 2 'cleaned_authentic' holds the
authentic records only. RapidMiner Studio 7.1 cannot open workbooks whose worksheet
relationships use absolute targets, which openpyxl writes, so they are rewritten as relative.

    python rapidminer/make_workbook.py [--rule file_order|discrete]
"""
import argparse
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "src"))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from obaudit.data import load_dataset, provenance  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--rule", default="file_order", choices=["file_order", "discrete"])
ap.add_argument("--out", default=str(HERE / "rapidminer_obesity_levels.xlsx"))
a = ap.parse_args()

df = load_dataset()
auth = provenance(df, a.rule)
out = df.copy()
out.insert(len(out.columns) - 1, "Authentic", np.where(auth, "Yes", "No"))
out["NObeyesdad"] = out["NObeyesdad"].str.replace("_", " ", regex=False)
xlsx = Path(a.out)
with pd.ExcelWriter(xlsx, engine="openpyxl") as w:
    out.to_excel(w, sheet_name="cleaned_full", index=False)
    out[auth].to_excel(w, sheet_name="cleaned_authentic", index=False)

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    with zipfile.ZipFile(xlsx) as z:
        z.extractall(tmp / "x")
    rels = tmp / "x" / "xl" / "_rels" / "workbook.xml.rels"
    rels.write_text(rels.read_text(encoding="utf8").replace('Target="/xl/worksheets/', 'Target="worksheets/'), encoding="utf8")
    fixed = tmp / "fixed.xlsx"
    with zipfile.ZipFile(fixed, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted((tmp / "x").rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(tmp / "x").as_posix())
    shutil.copyfile(fixed, xlsx)
print(f"wrote {xlsx.name}: {len(out)} records, {int(auth.sum())} authentic ({a.rule} rule)")
