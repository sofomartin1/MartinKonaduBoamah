"""
Rebuild the four RapidMiner Studio 7.1.001 process files with every
data-dependent transformation confined to the training portion of each fold.

The first implementation applied dummy coding and range normalisation to the
complete example set before the Cross Validation operator. Selecting rows and
columns before validation is legitimate, because neither decision depends on the
data; estimating a transformation does depend on it, and must therefore happen
inside the fold with the fitted preprocessing model passed through to the test
subprocess. These files do that.

  Arm A  all 2,111 records, all 16 attributes
  Arm B  all 2,111 records, height and weight withheld
  Arm C  authentic records (file-structure provenance), all 16 attributes
  Arm D  authentic records, height and weight withheld

Usage
-----
    python rapidminer/make_workbook.py                       # writes rapidminer/rapidminer_obesity_levels.xlsx
    python rapidminer/make_processes.py --dir "C:\\path\\to\\obesity-leakage-audit\\rapidminer"

--dir is the folder *on the machine that runs RapidMiner* holding the workbook; the
per-fold logs are written to the same folder. Open each .rmp in RapidMiner Studio 7.1
(File > Import Process) and run it; then
    python rapidminer/collect_results.py --logs rapidminer --out results/rapidminer_results.json
"""
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--dir", default=r"C:\obesity-leakage-audit\rapidminer",
                help="folder holding rapidminer_obesity_levels.xlsx on the RapidMiner machine")
ap.add_argument("--out", default=str(Path(__file__).resolve().parent / "processes"))
ap.add_argument("--n-authentic", type=int, default=498,
                help="rows in the authentic sheet (498 file-structure rule; 496 antecedent rule)")
args = ap.parse_args()
OUT = Path(args.out)
OUT.mkdir(parents=True, exist_ok=True)
WIN = args.dir.rstrip("\\")
DATA = WIN + r"\rapidminer_obesity_levels.xlsx"
SEED = 2001
N_ROWS = 2111
N_AUTH = args.n_authentic

COLS = [("Gender", "polynominal"), ("Age", "real"), ("Height", "real"), ("Weight", "real"),
        ("family_history_with_overweight", "polynominal"), ("FAVC", "polynominal"),
        ("FCVC", "real"), ("NCP", "real"), ("CAEC", "polynominal"), ("SMOKE", "polynominal"),
        ("CH2O", "real"), ("SCC", "polynominal"), ("FAF", "real"), ("TUE", "real"),
        ("CALC", "polynominal"), ("MTRANS", "polynominal"), ("Authentic", "polynominal")]
META = "".join(f'<parameter key="{i}" value="{n}.true.{t}.attribute"/>'
               for i, (n, t) in enumerate(COLS)) + \
       f'<parameter key="{len(COLS)}" value="NObeyesdad.true.polynominal.label"/>'

LEARNERS = ["NaiveBayes", "LogisticRegression", "DecisionTree", "BaggedTree"]

def READ_OP(sheet, nrows):
    return f'''<operator activated="true" class="read_excel" compatibility="7.1.001" expanded="true" height="68" name="Read Excel" width="90" x="45" y="34">
<parameter key="excel_file" value="{DATA}"/><parameter key="sheet_number" value="{sheet}"/>
<parameter key="imported_cell_range" value="A1:R{nrows+1}"/><parameter key="encoding" value="SYSTEM"/>
<parameter key="first_row_as_names" value="true"/><list key="annotations"/>
<parameter key="date_format" value=""/><parameter key="time_zone" value="SYSTEM"/>
<parameter key="locale" value="English (United States)"/>
<list key="data_set_meta_data_information">{META}</list>
<parameter key="read_not_matching_values_as_missings" value="true"/>
<parameter key="datamanagement" value="double_array"/></operator>'''


def select_attributes(drop_hw, x, y):
    drop = "Height|Weight|Authentic" if drop_hw else "Authentic"
    return f'''<operator activated="true" class="select_attributes" compatibility="7.1.001" expanded="true" height="82" name="Select Attributes" width="90" x="{x}" y="{y}">
<parameter key="attribute_filter_type" value="subset"/><parameter key="attribute" value=""/>
<parameter key="attributes" value="{drop}"/>
<parameter key="use_except_expression" value="false"/><parameter key="value_type" value="attribute_value"/>
<parameter key="use_value_type_exception" value="false"/><parameter key="except_value_type" value="time"/>
<parameter key="block_type" value="attribute_block"/><parameter key="use_block_type_exception" value="false"/>
<parameter key="except_block_type" value="value_matrix_row_start"/>
<parameter key="invert_selection" value="true"/><parameter key="include_special_attributes" value="false"/></operator>'''


PREPRO = '''<operator activated="true" class="nominal_to_numerical" compatibility="7.1.001" expanded="true" height="103" name="{p}Dummy" width="90" x="45" y="30">
<parameter key="return_preprocessing_model" value="true"/><parameter key="create_view" value="false"/>
<parameter key="attribute_filter_type" value="all"/><parameter key="attribute" value=""/><parameter key="attributes" value=""/>
<parameter key="use_except_expression" value="false"/><parameter key="value_type" value="nominal"/>
<parameter key="use_value_type_exception" value="false"/><parameter key="except_value_type" value="file_path"/>
<parameter key="block_type" value="single_value"/><parameter key="use_block_type_exception" value="false"/>
<parameter key="except_block_type" value="single_value"/><parameter key="invert_selection" value="false"/>
<parameter key="include_special_attributes" value="false"/><parameter key="coding_type" value="dummy coding"/>
<parameter key="use_comparison_groups" value="false"/><list key="comparison_groups"/>
<parameter key="unexpected_value_handling" value="all 0 and warning"/>
<parameter key="use_underscore_in_name" value="false"/></operator>
<operator activated="true" class="normalize" compatibility="7.1.001" expanded="true" height="103" name="{p}Scale" width="90" x="180" y="30">
<parameter key="return_preprocessing_model" value="true"/><parameter key="create_view" value="false"/>
<parameter key="attribute_filter_type" value="all"/><parameter key="attribute" value=""/><parameter key="attributes" value=""/>
<parameter key="use_except_expression" value="false"/><parameter key="value_type" value="numeric"/>
<parameter key="use_value_type_exception" value="false"/><parameter key="except_value_type" value="real"/>
<parameter key="block_type" value="value_series"/><parameter key="use_block_type_exception" value="false"/>
<parameter key="except_block_type" value="value_series_end"/><parameter key="invert_selection" value="false"/>
<parameter key="include_special_attributes" value="false"/><parameter key="method" value="range transformation"/>
<parameter key="min" value="0.0"/><parameter key="max" value="1.0"/></operator>'''

PREPRO_CONN = ('<connect from_port="training" to_op="{p}Dummy" to_port="example set input"/>'
               '<connect from_op="{p}Dummy" from_port="example set output" to_op="{p}Scale" to_port="example set input"/>'
               '<connect from_op="{p}Dummy" from_port="preprocessing model" to_port="through 1"/>'
               '<connect from_op="{p}Scale" from_port="preprocessing model" to_port="through 2"/>')


# The tree hyperparameters below are the ones the published Study 2 results were produced
# with (depth 10, confidence 0.1, pre-pruning on, minimal gain 0.01). An earlier revision of
# this generator relaxed all four, which raised decision-tree accuracy by 7.72 points and the
# bagged tree by 7.34 — a change unrelated to the within-fold correction this file exists to
# make. Do not alter them without re-running every arm and rebuilding the write-ups.
def learner(kind, name):
    if kind == "NaiveBayes":
        return (f'<operator activated="true" class="naive_bayes" compatibility="7.1.001" expanded="true" '
                f'height="82" name="{name}" width="90" x="380" y="30">'
                f'<parameter key="laplace_correction" value="true"/></operator>')
    if kind == "DecisionTree":
        return (f'<operator activated="true" class="decision_tree" compatibility="7.1.001" expanded="true" '
                f'height="82" name="{name}" width="90" x="380" y="30">'
                f'<parameter key="criterion" value="gain_ratio"/><parameter key="maximal_depth" value="10"/>'
                f'<parameter key="apply_pruning" value="true"/><parameter key="confidence" value="0.1"/>'
                f'<parameter key="apply_prepruning" value="true"/><parameter key="minimal_gain" value="0.01"/>'
                f'<parameter key="minimal_leaf_size" value="2"/><parameter key="minimal_size_for_split" value="4"/>'
                f'<parameter key="number_of_prepruning_alternatives" value="3"/></operator>')
    if kind == "BaggedTree":
        inner = learner("DecisionTree", "Inner").replace('x="380"', 'x="45"')
        return f'''<operator activated="true" class="bagging" compatibility="7.1.001" expanded="true" height="76" name="{name}" width="90" x="380" y="30">
<parameter key="sample_ratio" value="0.9"/><parameter key="iterations" value="25"/>
<parameter key="average_confidences" value="true"/><parameter key="use_local_random_seed" value="true"/>
<parameter key="local_random_seed" value="{SEED}"/>
<process expanded="true">{inner}
<connect from_port="training set" to_op="Inner" to_port="training set"/>
<connect from_op="Inner" from_port="model" to_port="model"/>
<portSpacing port="source_training set" spacing="0"/>
<portSpacing port="sink_model" spacing="0"/></process></operator>'''
    if kind == "LogisticRegression":
        return f'''<operator activated="true" class="polynomial_by_binomial_classification" compatibility="7.1.001" expanded="true" height="76" name="{name}" width="90" x="380" y="30">
<parameter key="classification_strategies" value="1 against all"/>
<parameter key="random_code_multiplicator" value="2.0"/>
<parameter key="use_local_random_seed" value="false"/><parameter key="local_random_seed" value="1992"/>
<process expanded="true">
<operator activated="true" class="logistic_regression" compatibility="7.1.001" expanded="true" height="103" name="Inner" width="90" x="45" y="30">
<parameter key="kernel_type" value="dot"/><parameter key="kernel_degree" value="2.0"/>
<parameter key="kernel_sigma1" value="1.0"/><parameter key="kernel_sigma2" value="0.0"/>
<parameter key="kernel_sigma3" value="2.0"/><parameter key="kernel_shift" value="1.0"/>
<parameter key="kernel_a" value="1.0"/><parameter key="kernel_b" value="0.0"/>
<parameter key="kernel_cache" value="200"/><parameter key="C" value="1.0"/>
<parameter key="convergence_epsilon" value="0.001"/><parameter key="max_iterations" value="100000"/>
<parameter key="scale" value="true"/><parameter key="calculate_weights" value="true"/>
<parameter key="return_optimization_performance" value="false"/>
<parameter key="add_bias" value="true"/></operator>
<connect from_port="training set" to_op="Inner" to_port="training set"/>
<connect from_op="Inner" from_port="model" to_port="model"/>
<portSpacing port="source_training set" spacing="0"/>
<portSpacing port="sink_model" spacing="0"/></process></operator>'''
    raise ValueError(kind)


def testing(clf, arm):
    log = WIN + f"\\rm_log_{arm}_{clf}.csv"
    return f'''<process expanded="true">
<operator activated="true" class="apply_model" compatibility="7.1.001" expanded="true" height="82" name="{clf} P1" width="90" x="45" y="30"><list key="application_parameters"/><parameter key="create_view" value="false"/></operator>
<operator activated="true" class="apply_model" compatibility="7.1.001" expanded="true" height="82" name="{clf} P2" width="90" x="180" y="30"><list key="application_parameters"/><parameter key="create_view" value="false"/></operator>
<operator activated="true" class="apply_model" compatibility="7.1.001" expanded="true" height="82" name="{clf} Apply" width="90" x="315" y="30"><list key="application_parameters"/><parameter key="create_view" value="false"/></operator>
<operator activated="true" class="performance_classification" compatibility="7.1.001" expanded="true" height="82" name="{clf} Perf" width="90" x="450" y="120">
<parameter key="main_criterion" value="accuracy"/><parameter key="accuracy" value="true"/>
<parameter key="classification_error" value="false"/><parameter key="kappa" value="true"/>
<parameter key="weighted_mean_recall" value="true"/><parameter key="weighted_mean_precision" value="true"/>
<parameter key="spearman_rho" value="false"/><parameter key="kendall_tau" value="false"/>
<parameter key="absolute_error" value="false"/><parameter key="skip_undefined_labels" value="true"/>
<parameter key="use_example_weights" value="true"/><list key="class_weights"/></operator>
<operator activated="true" class="log" compatibility="7.1.001" expanded="true" height="82" name="{clf} Log" width="90" x="585" y="120">
<parameter key="filename" value="{log}"/><list key="log">
<parameter key="fold" value="operator.{clf} Perf.value.applycount"/>
<parameter key="accuracy" value="operator.{clf} Perf.value.accuracy"/>
<parameter key="kappa" value="operator.{clf} Perf.value.kappa"/>
<parameter key="weighted_mean_recall" value="operator.{clf} Perf.value.weighted_mean_recall"/>
<parameter key="weighted_mean_precision" value="operator.{clf} Perf.value.weighted_mean_precision"/></list>
<parameter key="sorting_type" value="none"/><parameter key="sorting_k" value="100"/>
<parameter key="sorting_dimension" value=""/><parameter key="persistent" value="true"/></operator>
<connect from_port="test set" to_op="{clf} P1" to_port="unlabelled data"/>
<connect from_port="through 1" to_op="{clf} P1" to_port="model"/>
<connect from_port="through 2" to_op="{clf} P2" to_port="model"/>
<connect from_port="model" to_op="{clf} Apply" to_port="model"/>
<connect from_op="{clf} P1" from_port="labelled data" to_op="{clf} P2" to_port="unlabelled data"/>
<connect from_op="{clf} P2" from_port="labelled data" to_op="{clf} Apply" to_port="unlabelled data"/>
<connect from_op="{clf} Apply" from_port="labelled data" to_op="{clf} Perf" to_port="labelled data"/>
<connect from_op="{clf} Perf" from_port="performance" to_op="{clf} Log" to_port="through 1"/>
<connect from_op="{clf} Log" from_port="through 1" to_port="averagable 1"/>
<portSpacing port="source_model" spacing="0"/><portSpacing port="source_test set" spacing="0"/>
<portSpacing port="source_through 1" spacing="0"/><portSpacing port="source_through 2" spacing="0"/>
<portSpacing port="source_through 3" spacing="0"/>
<portSpacing port="sink_averagable 1" spacing="0"/><portSpacing port="sink_averagable 2" spacing="0"/></process>'''


def xval(clf, arm, y):
    p = clf + " "
    training = (f'<process expanded="true">{PREPRO.format(p=p)}{learner(clf, clf + " Learner")}'
                f'{PREPRO_CONN.format(p=p)}'
                f'<connect from_op="{p}Scale" from_port="example set output" to_op="{clf} Learner" to_port="training set"/>'
                f'<connect from_op="{clf} Learner" from_port="model" to_port="model"/>'
                f'<portSpacing port="source_training" spacing="0"/>'
                f'<portSpacing port="sink_model" spacing="0"/>'
                f'<portSpacing port="sink_through 1" spacing="0"/>'
                f'<portSpacing port="sink_through 2" spacing="0"/>'
                f'<portSpacing port="sink_through 3" spacing="0"/></process>')
    return f'''<operator activated="true" class="x_validation" compatibility="7.1.001" expanded="true" height="124" name="{clf}" width="90" x="800" y="{y}">
<parameter key="create_complete_model" value="false"/><parameter key="average_performances_only" value="true"/>
<parameter key="leave_one_out" value="false"/><parameter key="number_of_validations" value="10"/>
<parameter key="sampling_type" value="stratified sampling"/><parameter key="use_local_random_seed" value="true"/>
<parameter key="local_random_seed" value="{SEED}"/>
{training}
{testing(clf, arm)}
<portSpacing port="source_training" spacing="0"/><portSpacing port="sink_averagable 1" spacing="0"/>
<portSpacing port="sink_averagable 2" spacing="0"/></operator>'''


def build(arm, authentic_only, drop_hw):
    sheet, nrows = (2, N_AUTH) if authentic_only else (1, N_ROWS)
    ops = [READ_OP(sheet, nrows)]
    conns = []
    prev, port = "Read Excel", "output"
    ops.append(select_attributes(drop_hw, 330, 34))
    conns.append(f'<connect from_op="{prev}" from_port="{port}" to_op="Select Attributes" to_port="example set input"/>')
    ops.append('<operator activated="true" class="multiply" compatibility="7.1.001" expanded="true" '
               'height="103" name="Fanout" width="90" x="620" y="100"/>')
    conns.append('<connect from_op="Select Attributes" from_port="example set output" to_op="Fanout" to_port="input"/>')
    for i, clf in enumerate(LEARNERS):
        ops.append(xval(clf, arm, 30 + i * 150))
        conns.append(f'<connect from_op="Fanout" from_port="output {i+1}" to_op="{clf}" to_port="training"/>')
        conns.append(f'<connect from_op="{clf}" from_port="averagable 1" to_port="result {i+1}"/>')
    body = "".join(ops) + "".join(conns)
    spacing = "".join(f'<portSpacing port="sink_result {i}" spacing="0"/>' for i in range(1, 6))
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<process version="7.1.001"><context><input/><output/><macros/></context>
<operator activated="true" class="process" compatibility="7.1.001" expanded="true" name="Process">
<parameter key="logverbosity" value="init"/><parameter key="random_seed" value="{SEED}"/>
<parameter key="send_mail" value="never"/><parameter key="notification_email" value=""/>
<parameter key="process_duration_for_mail" value="30"/><parameter key="encoding" value="SYSTEM"/>
<process expanded="true">{body}<portSpacing port="source_input 1" spacing="0"/>{spacing}</process>
</operator></process>'''


ARMS = [("ArmA_Full_AllAttributes", "ArmA", False, False),
        ("ArmB_Full_BehaviourOnly", "ArmB", False, True),
        ("ArmC_Authentic_AllAttributes", "ArmC", True, False),
        ("ArmD_Authentic_BehaviourOnly", "ArmD", True, True)]

for fname, arm, auth, drop in ARMS:
    (OUT / (fname + ".rmp")).write_text(build(arm, auth, drop), encoding="utf8")
    print("wrote", fname + ".rmp")
