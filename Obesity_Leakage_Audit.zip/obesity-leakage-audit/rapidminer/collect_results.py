"""
Turn RapidMiner output into the results table used in the paper.

Reads the per-fold CSV logs written automatically by the Log operator nested in
each classifier's testing subprocess, and reports the 2 x 2 decomposition that
separates the study's two defects:

    circular label      = Arm A - Arm B   (Height and Weight removed)
    synthetic records   = Arm A - Arm C   (SMOTE-generated records removed)
    both                = Arm A - Arm D

RapidMiner reports POPULATION standard deviation (ddof = 0); this script matches
that convention so every printed value equals what appears on screen.

Usage
-----
    python rapidminer/collect_results.py --logs rapidminer --out results/rapidminer_results.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

CLASSIFIERS = ["NaiveBayes", "LogisticRegression", "DecisionTree", "BaggedTree"]
ARMS = {
    "ArmA": "all records, all attributes",
    "ArmB": "all records, behaviour attributes only",
    "ArmC": "authentic records only, all attributes",
    "ArmD": "authentic records only, behaviour attributes only",
}
# Majority-class accuracy on the authentic subset: 287 of 498 records are Normal Weight under
# the file-structure rule (274 of 496 under the antecedent discrete-value rule; pass
# --majority 55.24 when collecting antecedent logs).
MAJORITY_BASELINE = 287 / 498 * 100


def read_logs(folder: Path) -> list[dict]:
    rows = []
    for path in sorted(folder.glob("rm_log_*.csv")):
        arm, classifier = path.stem[len("rm_log_"):].split("_", 1)
        if classifier not in CLASSIFIERS:
            continue  # skip superseded configurations
        folds = pd.read_csv(
            path, sep="\t", comment="#", header=None,
            names=["fold", "accuracy", "kappa", "wmr", "wmp"],
        )
        record = {"arm": arm, "classifier": classifier, "n_folds": len(folds)}
        for column, label in [("accuracy", "acc"), ("kappa", "kappa"),
                              ("wmr", "wmr"), ("wmp", "wmp")]:
            series = folds[column] * (1 if column == "kappa" else 100)
            record[label] = round(series.mean(), 2)
            record[f"{label}_sd"] = round(series.std(ddof=0), 2)
        rows.append(record)
    if not rows:
        raise SystemExit(f"no rm_log_*.csv found in {folder}")
    return rows


def decompose(rows: list[dict]) -> dict:
    g = {(r["arm"], r["classifier"]): r for r in rows}
    out = {}
    for c in CLASSIFIERS:
        if not all((a, c) in g for a in ARMS):
            continue
        out[c] = {
            "circular_label_cost": round(g[("ArmA", c)]["acc"] - g[("ArmB", c)]["acc"], 2),
            "synthetic_record_cost": round(g[("ArmA", c)]["acc"] - g[("ArmC", c)]["acc"], 2),
            "both_defects_cost": round(g[("ArmA", c)]["acc"] - g[("ArmD", c)]["acc"], 2),
            "kappa_A": g[("ArmA", c)]["kappa"], "kappa_D": g[("ArmD", c)]["kappa"],
            "armD_beats_majority_baseline": bool(g[("ArmD", c)]["acc"] > MAJORITY_BASELINE),
        }
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--logs", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--majority", type=float, default=None,
                    help="majority-class accuracy (%%) on the authentic subset")
    args = ap.parse_args()
    global MAJORITY_BASELINE
    if args.majority is not None:
        MAJORITY_BASELINE = args.majority

    rows = read_logs(args.logs)
    dec = decompose(rows)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps({
        "source": "RapidMiner Studio Professional 7.1.001",
        "validation": "stratified 10-fold cross-validation, random seed 2001",
        "sd_convention": "population SD (ddof=0), matching RapidMiner",
        "arms": ARMS,
        "majority_class_baseline_authentic_subset": round(MAJORITY_BASELINE, 2),
        "note": ("Random Forest was replaced by Bagging over the Decision Tree: with the "
                 "predictive signal concentrated in two of ~30 attributes, feature subsampling "
                 "left most trees unable to reach either informative attribute."),
        "aggregate": rows,
        "decomposition": dec,
    }, indent=1), encoding="utf8")

    header = f"{'arm':6s} {'classifier':20s} {'acc':>8} {'kappa':>7} {'macro recall':>13}"
    print(header + "\n" + "-" * len(header))
    for r in sorted(rows, key=lambda x: (x["arm"], x["classifier"])):
        print(f"{r['arm']:6s} {r['classifier']:20s} {r['acc']:8.2f} {r['kappa']:7.2f} {r['wmr']:13.2f}")
    print(f"\nMajority-class baseline on the authentic subset: {MAJORITY_BASELINE:.2f}%")
    print("\nDecomposition (accuracy points attributable to each defect):")
    for c, d in dec.items():
        flag = "" if d["armD_beats_majority_baseline"] else "   <- Arm D BELOW majority baseline"
        print(f"  {c:20s} label {d['circular_label_cost']:6.2f}   synthetic {d['synthetic_record_cost']:6.2f}"
              f"   both {d['both_defects_cost']:6.2f}   kappa {d['kappa_A']:.2f} -> {d['kappa_D']:.2f}{flag}")


if __name__ == "__main__":
    main()
