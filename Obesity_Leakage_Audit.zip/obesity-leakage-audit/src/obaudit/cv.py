"""Repeated stratified cross-validation engine with out-of-fold storage."""
from __future__ import annotations

import time
import warnings

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold

from .config import load_config
from .metrics import fold_metrics
from .models import make_model

N_CLASSES = 7


def splits(y, n_splits=None, n_repeats=None, seed=None):
    cfg = load_config()
    n_splits = n_splits or cfg["cv"]["n_splits"]
    n_repeats = n_repeats or cfg["cv"]["n_repeats"]
    seed = cfg["study"]["seed"] if seed is None else seed
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if n_repeats == 1:
            sk = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        else:
            sk = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=seed)
        return [(i // n_splits, i % n_splits, tr, te)
                for i, (tr, te) in enumerate(sk.split(np.zeros(len(y)), y))]


def _proba_full(model, X):
    P = np.zeros((len(X), N_CLASSES))
    P[:, model.classes_] = model.predict_proba(X)
    return P


def _one_fold(name, X, y, tr, te, numeric, nominal, subgroups, model_kwargs):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model = make_model(name, numeric, nominal, **model_kwargs)
        t0 = time.perf_counter()
        model.fit(X.iloc[tr], y[tr])
        t1 = time.perf_counter()
        pred = np.asarray(model.predict(X.iloc[te]))
        P = _proba_full(model, X.iloc[te])
        t2 = time.perf_counter()
    rec = fold_metrics(y[te], pred)
    rec["fit_s"], rec["predict_s"] = t1 - t0, t2 - t1
    sub = {}
    for g, mask in (subgroups or {}).items():
        m = mask[te]
        if m.sum() > 0:
            sub[g] = fold_metrics(y[te][m], pred[m])
            sub[g]["n_test"] = int(m.sum())
    return te, pred, P, rec, sub


def run_cv(name, X, y, numeric, nominal, subgroups=None, n_splits=None, n_repeats=None,
           seed=None, n_jobs=None, model_kwargs=None, split_list=None):
    """Return a dict with fold-level metrics (DataFrame), subgroup metrics (DataFrame),
    out-of-fold probabilities (repeats x n x 7) and predictions (repeats x n)."""
    cfg = load_config()
    n_jobs = n_jobs or cfg["cv"]["n_jobs"]
    sp = split_list or splits(y, n_splits, n_repeats, seed)
    R = max(s[0] for s in sp) + 1
    out = Parallel(n_jobs=n_jobs)(
        delayed(_one_fold)(name, X, y, tr, te, numeric, nominal, subgroups, model_kwargs or {})
        for (_, _, tr, te) in sp)
    P = np.zeros((R, len(y), N_CLASSES))
    pred = np.full((R, len(y)), -1, dtype=int)
    rows, srows = [], []
    for (r, f, tr, te), (te_, pr, Pr, rec, sub) in zip(sp, out):
        P[r, te_] = Pr
        pred[r, te_] = pr
        rows.append({"repeat": r, "fold": f, "n_train": len(tr), "n_test": len(te), **rec})
        for g, d in sub.items():
            srows.append({"repeat": r, "fold": f, "subgroup": g, **d})
    return {"folds": pd.DataFrame(rows), "subgroups": pd.DataFrame(srows), "proba": P, "pred": pred}
