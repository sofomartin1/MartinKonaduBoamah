"""Inference for cross-validated comparisons.

* Corrected resampled t (Nadeau & Bengio, 2003; Bouckaert & Frank, 2004) for fold-level
  metrics from r x k cross-validation: var_corr = (1/(r k) + n_test/n_train) * s^2.
* Paired version on per-fold differences when two configurations share the same partitions
  (arms A/B, arms C/D, and any two classifiers within an arm).
* Independent combination for comparisons across record sets (arm A vs arm C).
* Holm step-down adjustment.
* Permutation p-values (Ojala & Garriga, 2010) with the +1 correction.
"""
from __future__ import annotations

import numpy as np
from scipy import stats


def corrected_var(values: np.ndarray, test_train_ratio: float) -> float:
    values = np.asarray(values, dtype=float)
    J = len(values)
    return (1.0 / J + test_train_ratio) * values.var(ddof=1)


def corrected_ci(values, test_train_ratio, alpha=0.05):
    values = np.asarray(values, dtype=float)
    m = values.mean()
    se = np.sqrt(corrected_var(values, test_train_ratio))
    t = stats.t.ppf(1 - alpha / 2, len(values) - 1)
    return m, m - t * se, m + t * se, se


def corrected_paired_test(a, b, test_train_ratio, alpha=0.05):
    """Mean difference a-b with corrected CI and two-sided p (fold-aligned arrays)."""
    d = np.asarray(a, float) - np.asarray(b, float)
    m, lo, hi, se = corrected_ci(d, test_train_ratio, alpha)
    df = len(d) - 1
    tval = m / se if se > 0 else (np.inf if m != 0 else 0.0)
    p = 2 * stats.t.sf(abs(tval), df) if np.isfinite(tval) else 0.0
    return {"diff": m, "lo": lo, "hi": hi, "se": se, "t": tval, "p": p}


def independent_diff(a, ratio_a, b, ratio_b, alpha=0.05):
    """Difference of means for two configurations on different record sets."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    va, vb = corrected_var(a, ratio_a), corrected_var(b, ratio_b)
    m = a.mean() - b.mean()
    se = np.sqrt(va + vb)
    # Welch-Satterthwaite degrees of freedom
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
    t = stats.t.ppf(1 - alpha / 2, df)
    tval = m / se
    return {"diff": m, "lo": m - t * se, "hi": m + t * se, "se": se, "t": tval,
            "p": 2 * stats.t.sf(abs(tval), df)}


def combined_diff(parts, alpha=0.05):
    """Linear combination of independent (diff, se) estimates, e.g. an interaction contrast
    (A-B)-(C-D). ``parts`` is a list of (sign, result_dict)."""
    m = sum(s * r["diff"] for s, r in parts)
    se = np.sqrt(sum(r["se"] ** 2 for _, r in parts))
    z = stats.norm.ppf(1 - alpha / 2)
    return {"diff": m, "lo": m - z * se, "hi": m + z * se, "se": se, "t": m / se,
            "p": 2 * stats.norm.sf(abs(m / se))}


def holm(pvals):
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0.0
    m = len(p)
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj


def perm_pvalue(observed, null):
    null = np.asarray(null, float)
    return (1 + np.sum(null >= observed)) / (len(null) + 1)


def bootstrap_ci(values, alpha=0.05):
    v = np.asarray(values, float)
    return np.nanpercentile(v, 100 * alpha / 2), np.nanpercentile(v, 100 * (1 - alpha / 2))
