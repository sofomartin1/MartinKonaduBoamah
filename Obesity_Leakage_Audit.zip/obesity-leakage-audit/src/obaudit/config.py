"""Configuration loading and project paths."""
from __future__ import annotations

from pathlib import Path
from functools import lru_cache

import yaml

ROOT = Path(__file__).resolve().parents[2]


@lru_cache(maxsize=1)
def load_config(path: str | None = None) -> dict:
    """Read config/study.yaml (or an explicit path) and resolve output folders."""
    cfg_path = Path(path) if path else ROOT / "config" / "study.yaml"
    with open(cfg_path, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    for key in ("results", "figures", "tables"):
        p = ROOT / cfg["paths"][key]
        p.mkdir(parents=True, exist_ok=True)
        cfg["paths"][key] = p
    cfg["paths"]["raw"] = ROOT / cfg["paths"]["results"] / "raw"
    cfg["paths"]["raw"].mkdir(parents=True, exist_ok=True)
    cfg["data"]["file"] = ROOT / cfg["data"]["file"]
    return cfg


def results_dir() -> Path:
    return load_config()["paths"]["results"]


def raw_dir() -> Path:
    return load_config()["paths"]["raw"]
