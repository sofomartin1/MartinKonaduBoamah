"""Performance metrics.

Fold-level metrics follow the RapidMiner convention of averaging over test folds. Macro
recall (balanced accuracy), macro precision and macro F1 are averaged over the classes
present in the test fold; a class never predicted contributes a precision of zero.

Pooled metrics are computed on the out-of-fold predictions of one complete repetition of
cross-validation (every record predicted exactly once) and then averaged over repetitions.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import rankdata
from sklearn.metrics import (accuracy_score, cohen_kappa_score, f1_score,
                             matthews_corrcoef, precision_score, recall_score)

FOLD_METRICS = ["accuracy", "balanced_accuracy", "macro_precision", "macro_f1", "kappa", "mcc"]
POOLED_METRICS = ["auc_macro", "brier", "log_loss", "ece"]


def _sk_fold_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Reference implementation with scikit-learn (used by the unit tests)."""
    present = np.unique(y_true)
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": recall_score(y_true, y_pred, labels=present, average="macro",
                                          zero_division=0),
        "macro_precision": precision_score(y_true, y_pred, labels=present, average="macro",
                                           zero_division=0),
        "macro_f1": f1_score(y_true, y_pred, labels=present, average="macro", zero_division=0),
        "kappa": cohen_kappa_score(y_true, y_pred) if len(np.unique(np.r_[y_true, y_pred])) > 1 else 0.0,
        "mcc": matthews_corrcoef(y_true, y_pred) if len(np.unique(np.r_[y_true, y_pred])) > 1 else 0.0,
    }


def fold_metrics(y_true: np.ndarray, y_pred: np.ndarray, n_classes: int = 7) -> dict:
    """Fast confusion-matrix implementation, numerically identical to ``_sk_fold_metrics``."""
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    K = max(n_classes, int(max(y_true.max(), y_pred.max())) + 1)
    C = np.bincount(y_true * K + y_pred, minlength=K * K).reshape(K, K).astype(float)
    n = C.sum()
    tp = np.diag(C)
    t = C.sum(1)
    p = C.sum(0)
    present = t > 0
    rec = np.divide(tp, t, out=np.zeros(K), where=t > 0)
    prec = np.divide(tp, p, out=np.zeros(K), where=p > 0)
    f1 = np.divide(2 * prec * rec, prec + rec, out=np.zeros(K), where=(prec + rec) > 0)
    acc = tp.sum() / n
    pe = float((t * p).sum()) / n ** 2
    if ((t + p) > 0).sum() > 1:
        kappa = (acc - pe) / (1 - pe) if pe < 1 else 0.0
        cov_ytyp = tp.sum() * n - (t * p).sum()
        den = np.sqrt((n * n - (t * t).sum()) * (n * n - (p * p).sum()))
        mcc = cov_ytyp / den if den > 0 else 0.0
    else:
        kappa, mcc = 0.0, 0.0
    return {"accuracy": float(acc), "balanced_accuracy": float(rec[present].mean()),
            "macro_precision": float(prec[present].mean()), "macro_f1": float(f1[present].mean()),
            "kappa": float(kappa), "mcc": float(mcc)}


def _auc_binary(pos_scores: np.ndarray, neg_scores: np.ndarray) -> float:
    """Mann-Whitney AUC with tie correction."""
    n1, n0 = len(pos_scores), len(neg_scores)
    if n1 == 0 or n0 == 0:
        return np.nan
    ranks = rankdata(np.r_[pos_scores, neg_scores])
    return (ranks[:n1].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0)


def auc_ovr_macro(y: np.ndarray, P: np.ndarray) -> float:
    """Macro one-vs-rest AUC over the classes present in y."""
    vals = []
    for k in np.unique(y):
        m = y == k
        vals.append(_auc_binary(P[m, k], P[~m, k]))
    return float(np.nanmean(vals))


def brier_multi(y: np.ndarray, P: np.ndarray) -> float:
    Y = np.zeros_like(P)
    Y[np.arange(len(y)), y] = 1.0
    return float(np.mean(np.sum((P - Y) ** 2, axis=1)))


def log_loss_multi(y: np.ndarray, P: np.ndarray, eps: float = 1e-15) -> float:
    p = np.clip(P[np.arange(len(y)), y], eps, 1.0)
    return float(-np.mean(np.log(p)))


def ece_top_label(y: np.ndarray, P: np.ndarray, bins: int = 10) -> float:
    conf = P.max(axis=1)
    pred = P.argmax(axis=1)
    correct = (pred == y).astype(float)
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(conf, edges[1:-1], right=True), 0, bins - 1)
    e = 0.0
    for b in range(bins):
        m = idx == b
        if m.any():
            e += m.mean() * abs(correct[m].mean() - conf[m].mean())
    return float(e)


def reliability_curve(y, P, bins=10):
    conf = P.max(axis=1)
    correct = (P.argmax(axis=1) == y).astype(float)
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(conf, edges[1:-1], right=True), 0, bins - 1)
    rows = []
    for b in range(bins):
        m = idx == b
        if m.any():
            rows.append((b, conf[m].mean(), correct[m].mean(), int(m.sum())))
    return rows


def pooled_metrics(y: np.ndarray, P: np.ndarray, bins: int = 10) -> dict:
    return {"auc_macro": auc_ovr_macro(y, P), "brier": brier_multi(y, P),
            "log_loss": log_loss_multi(y, P), "ece": ece_top_label(y, P, bins)}


def pooled_hard_metrics(y: np.ndarray, pred: np.ndarray) -> dict:
    """Fold-free versions of the hard metrics on one full set of out-of-fold predictions."""
    return fold_metrics(y, pred)


def per_class_recall(y: np.ndarray, pred: np.ndarray, n_classes: int = 7) -> np.ndarray:
    out = np.full(n_classes, np.nan)
    for k in range(n_classes):
        m = y == k
        if m.any():
            out[k] = (pred[m] == k).mean()
    return out


def confusion(y: np.ndarray, pred: np.ndarray, n_classes: int = 7) -> np.ndarray:
    C = np.zeros((n_classes, n_classes), dtype=int)
    np.add.at(C, (y, pred), 1)
    return C


# ----------------------------------------------------------------- fast bootstrap
def bootstrap_pooled(y: np.ndarray, P: np.ndarray, B: int, seed: int, bins: int = 10) -> dict:
    """Percentile-bootstrap replicates of the repetition-averaged pooled metrics.

    ``P`` has shape (R, n, K). Each replicate resamples records with replacement (multinomial
    weights); the same weights are applied to every repetition and the metric is averaged
    over repetitions, so the replicates are exactly those of the naive resampling loop."""
    R, n, K = P.shape
    rng = np.random.default_rng(seed)
    W = np.stack([np.bincount(rng.integers(0, n, n), minlength=n) for _ in range(B)]).astype(float)  # B x n
    tot = W.sum(1)
    out = {"auc_macro": np.zeros(B), "brier": np.zeros(B), "log_loss": np.zeros(B), "ece": np.zeros(B)}
    Y = np.zeros((n, K))
    Y[np.arange(n), y] = 1.0
    classes = np.unique(y)
    edges = np.linspace(0, 1, bins + 1)
    for r in range(R):
        Pr = P[r]
        brier = np.sum((Pr - Y) ** 2, axis=1)
        ll = -np.log(np.clip(Pr[np.arange(n), y], 1e-15, 1.0))
        out["brier"] += W @ brier / tot
        out["log_loss"] += W @ ll / tot
        conf = Pr.max(1)
        corr = (Pr.argmax(1) == y).astype(float)
        idx = np.clip(np.digitize(conf, edges[1:-1], right=True), 0, bins - 1)
        Bm = np.zeros((n, bins))
        Bm[np.arange(n), idx] = 1.0
        wb = W @ Bm
        wc = W @ (Bm * corr[:, None])
        wf = W @ (Bm * conf[:, None])
        with np.errstate(invalid="ignore", divide="ignore"):
            gap = np.where(wb > 0, np.abs(wc / wb - wf / wb), 0.0)
        out["ece"] += np.sum(wb / tot[:, None] * gap, axis=1)
        aucs = []
        for k in classes:
            s = Pr[:, k]
            order = np.argsort(s, kind="mergesort")
            ss = s[order]
            pos = (y[order] == k).astype(float)
            lvl_start = np.r_[0, np.flatnonzero(np.diff(ss)) + 1]
            Wp = np.add.reduceat(W[:, order] * pos, lvl_start, axis=1)
            Wn = np.add.reduceat(W[:, order] * (1 - pos), lvl_start, axis=1)
            cum_neg_below = np.cumsum(Wn, axis=1) - Wn
            num = np.sum(Wp * (cum_neg_below + 0.5 * Wn), axis=1)
            den = Wp.sum(1) * Wn.sum(1)
            with np.errstate(invalid="ignore", divide="ignore"):
                aucs.append(np.where(den > 0, num / den, np.nan))
        out["auc_macro"] += np.nanmean(np.vstack(aucs), axis=0)
    for k in out:
        out[k] /= R
    return out
