"""One visual system for every figure: colour-blind-safe palette, fonts and export."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

# Okabe-Ito derived palette
ARM_COLORS = {"A": "#0B4F8A", "B": "#56B4E9", "C": "#D55E00", "D": "#CC79A7"}
ARM_LABELS = {"A": "Arm A: all records, all attributes",
              "B": "Arm B: all records, behaviour only",
              "C": "Arm C: authentic records, all attributes",
              "D": "Arm D: authentic records, behaviour only"}
ARM_SHORT = {"A": "A  All / All", "B": "B  All / Behaviour", "C": "C  Authentic / All",
             "D": "D  Authentic / Behaviour"}
PROV_COLORS = {"authentic": "#009E73", "synthetic": "#E69F00"}
CLF_COLORS = {"NB": "#999999", "LR": "#0072B2", "DT": "#E69F00", "BT": "#009E73",
              "RF": "#D55E00", "GB": "#CC79A7", "KNN": "#56B4E9", "SVM": "#7A4F9A",
              "MAJ": "#222222", "PRIOR": "#777777", "BMIRULE": "#8C564B", "BMITREE": "#BCBD22"}
CLASS_SHORT = ["Insuff.", "Normal", "OW I", "OW II", "Ob. I", "Ob. II", "Ob. III"]
CLASS_COLORS = ["#4C9BE8", "#2CA25F", "#FEC44F", "#FE9929", "#EC7014", "#CC4C02", "#8C2D04"]
SCHEME_COLORS = {"random_cv_full_scored_authentic": "#7F7F7F", "synth_plus": "#E69F00",
                 "synth_plus_purged": "#F5C26B", "synth_only": "#D55E00", "synth_only_purged": "#EFA27A",
                 "authentic_only": "#009E73"}


def setup():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9,
        "axes.labelsize": 8.5, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
        "legend.fontsize": 7.5, "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.color": "#E5E5E5", "grid.linewidth": 0.6, "axes.axisbelow": True,
        "figure.dpi": 110, "savefig.dpi": 300, "savefig.bbox": "tight", "savefig.pad_inches": 0.04,
        "axes.edgecolor": "#444444", "axes.linewidth": 0.7, "legend.frameon": False,
    })


def panel_label(ax, text, x=-0.12, y=1.04):
    ax.text(x, y, text, transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom", ha="left")


def save(fig, path):
    fig.savefig(path)
    plt.close(fig)
