"""Persistence helpers for raw cross-validation outputs and derived estimates."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .config import raw_dir, results_dir


def run_key(arm: str, model: str, tag: str = "main") -> str:
    return f"{tag}__{arm}__{model}"


def save_run(key: str, res: dict, index: np.ndarray, y: np.ndarray) -> None:
    d = raw_dir()
    res["folds"].to_csv(d / f"{key}__folds.csv", index=False)
    if len(res["subgroups"]):
        res["subgroups"].to_csv(d / f"{key}__subgroups.csv", index=False)
    np.savez_compressed(d / f"{key}__oof.npz", proba=res["proba"].astype(np.float32),
                        pred=res["pred"].astype(np.int8), index=index, y=y)


def load_folds(key: str) -> pd.DataFrame:
    return pd.read_csv(raw_dir() / f"{key}__folds.csv")


def load_subgroups(key: str) -> pd.DataFrame:
    return pd.read_csv(raw_dir() / f"{key}__subgroups.csv")


def load_oof(key: str) -> dict:
    z = np.load(raw_dir() / f"{key}__oof.npz")
    return {k: z[k] for k in z.files}


def exists(key: str) -> bool:
    return (raw_dir() / f"{key}__oof.npz").exists()


def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if np.isnan(o) else float(o)
    if isinstance(o, float) and np.isnan(o):
        return None
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    if isinstance(o, np.bool_):
        return bool(o)
    return o


def save_json(name: str, obj) -> Path:
    p = results_dir() / f"{name}.json"
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(_clean(obj), fh, indent=1)
    return p


def load_json(name: str):
    with open(results_dir() / f"{name}.json", "r", encoding="utf-8") as fh:
        return json.load(fh)


def save_table(name: str, df: pd.DataFrame) -> Path:
    from .config import load_config
    p = load_config()["paths"]["tables"] / f"{name}.csv"
    df.to_csv(p, index=False)
    return p
