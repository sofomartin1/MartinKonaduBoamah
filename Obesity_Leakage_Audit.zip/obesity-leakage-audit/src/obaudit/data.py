"""Data loading, label- and record-provenance audits, and construction of the four arms.

Record provenance
-----------------
Two independent indicators are implemented.

1. File structure (primary). The distributed UCI file consists of an interleaved block of
   survey responses followed by the SMOTE output, which Weka appends class by class. The
   start of the synthetic block is therefore the earliest row after which the labels form
   no more contiguous runs than there are classes. ``detect_synthetic_block_start`` finds
   it from the labels alone; no row number is hard-coded.
2. Value discreteness (antecedent heuristic). Survey answers are integers, ages whole
   years, heights two decimals and weights whole kilograms; SMOTE interpolation yields
   values between those levels. ``provenance_discrete`` reproduces the antecedent rule and
   allows the weight precision to be relaxed to 0.1 kg.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .config import load_config


# ----------------------------------------------------------------------------- loading
def load_dataset(path: str | Path | None = None) -> pd.DataFrame:
    """Return the 2,111-record dataset in file order with canonical underscore labels.

    Accepts the cleaned workbook in ``data/`` or the raw UCI CSV
    ``ObesityDataSet_raw_and_data_sinthetic.csv``. Any provenance column already present
    in the workbook is dropped so that provenance is always recomputed here.
    """
    cfg = load_config()
    path = Path(path) if path else Path(cfg["data"]["file"])
    if path.suffix.lower() in (".xlsx", ".xls"):
        df = pd.read_excel(path, sheet_name=cfg["data"]["sheet"])
    else:
        df = pd.read_csv(path)
    df = df.drop(columns=[c for c in ("Authentic",) if c in df.columns])
    lab = cfg["data"]["label"]
    df[lab] = df[lab].astype(str).str.strip().str.replace(" ", "_", regex=False)
    unknown = set(df[lab]) - set(cfg["data"]["classes"])
    if unknown:
        raise ValueError(f"Unexpected class labels: {unknown}")
    for c in cfg["data"]["nominal"]:
        df[c] = df[c].astype(str)
    for c in cfg["data"]["numeric"]:
        df[c] = df[c].astype(float)
    return df.reset_index(drop=True)


def label_codes(y: pd.Series) -> np.ndarray:
    """Integer codes 0..6 in ordinal class order."""
    classes = load_config()["data"]["classes"]
    return y.map({c: i for i, c in enumerate(classes)}).to_numpy()


def class_display(name: str) -> str:
    return name.replace("_", " ")


# ----------------------------------------------------------------------- label audit
def bmi(df: pd.DataFrame) -> pd.Series:
    """Body mass index, kg/m^2."""
    return df["Weight"] / df["Height"] ** 2


def bmi_rule(b: np.ndarray | pd.Series) -> np.ndarray:
    """Assign a class index from BMI using the configured cut-points (no fitting)."""
    cuts = load_config()["data"]["bmi_cutpoints"]
    return np.searchsorted(np.asarray(cuts), np.asarray(b, dtype=float), side="right")


# ---------------------------------------------------------------- record provenance
def _runs(labels: np.ndarray) -> int:
    if len(labels) == 0:
        return 0
    return int(1 + np.count_nonzero(labels[1:] != labels[:-1]))


def detect_synthetic_block_start(labels: np.ndarray, n_classes: int = 7) -> int:
    """Earliest index i such that labels[i:] contains at most ``n_classes`` contiguous runs
    and labels[i-1:] does not (i.e. the survey block ends at i-1)."""
    labels = np.asarray(labels)
    n = len(labels)
    # number of runs in each suffix, computed right to left
    change = np.r_[labels[1:] != labels[:-1], False]
    runs_suffix = np.zeros(n + 1, dtype=int)
    for i in range(n - 1, -1, -1):
        runs_suffix[i] = runs_suffix[i + 1] + (1 if (i == n - 1 or change[i]) else 0)
    candidates = np.where(runs_suffix[:n] <= n_classes)[0]
    return int(candidates.min())


def provenance_file_order(df: pd.DataFrame) -> np.ndarray:
    """Primary provenance: True for records in the survey block (before the SMOTE block).

    If the final survey record happened to share the class of the first synthetic run, the
    run-count criterion would place the boundary one record early. The boundary is therefore
    advanced past any record that is fully discrete at survey precision while the record
    after it is not, which leaves the boundary unchanged on the distributed file.
    """
    cfg = load_config()
    lab = df[cfg["data"]["label"]].to_numpy()
    start = detect_synthetic_block_start(lab, len(cfg["data"]["classes"]))
    disc = provenance_discrete(df, weight_dp=1)
    while start + 1 < len(df) and disc[start] and not disc[start + 1] and lab[start] == lab[start + 1]:
        start += 1
    auth = np.zeros(len(df), dtype=bool)
    auth[:start] = True
    return auth


def provenance_discrete(df: pd.DataFrame, weight_dp: int = 0) -> np.ndarray:
    """Antecedent discrete-value heuristic (weight_dp=0) or its 0.1-kg relaxation (weight_dp=1)."""
    cfg = load_config()

    def integral(s: pd.Series, dp: int = 0) -> np.ndarray:
        return np.isclose(s.to_numpy(dtype=float), s.round(dp).to_numpy(dtype=float))

    ok = np.logical_and.reduce([integral(df[c]) for c in cfg["data"]["survey_scale"]])
    ok &= integral(df["Age"]) & integral(df["Height"], 2) & integral(df["Weight"], weight_dp)
    return ok


def provenance(df: pd.DataFrame, rule: str = "file_order") -> np.ndarray:
    if rule == "file_order":
        return provenance_file_order(df)
    if rule == "discrete":
        return provenance_discrete(df, weight_dp=0)
    if rule == "discrete_0.1kg":
        return provenance_discrete(df, weight_dp=1)
    raise ValueError(rule)


# ------------------------------------------------------------------------------ arms
def feature_columns(attributes: str) -> tuple[list[str], list[str]]:
    """(numeric, nominal) columns for 'all' or 'behaviour' attribute sets."""
    cfg = load_config()["data"]
    drop = set(cfg["anthropometric"]) if attributes == "behaviour" else set()
    num = [c for c in cfg["numeric"] if c not in drop]
    nom = [c for c in cfg["nominal"] if c not in drop]
    return num, nom


def arm_data(df: pd.DataFrame, arm: str, rule: str = "file_order", deduplicate: bool = False):
    """Return (X, y, index) for an arm. ``index`` holds positions in the full file."""
    cfg = load_config()
    spec = cfg["arms"][arm]
    idx = np.arange(len(df))
    if spec["records"] == "authentic":
        idx = idx[provenance(df, rule)]
    sub = df.iloc[idx]
    if deduplicate:
        keep = ~sub.duplicated(keep="first").to_numpy()
        sub, idx = sub[keep], idx[keep]
    num, nom = feature_columns(spec["attributes"])
    X = sub[num + nom].reset_index(drop=True)
    y = label_codes(sub[cfg["data"]["label"]])
    return X, y, idx
