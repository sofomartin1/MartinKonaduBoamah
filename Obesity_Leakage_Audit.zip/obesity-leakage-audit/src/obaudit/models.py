"""Classifier factory. Every model is a scikit-learn Pipeline whose preprocessing (one-hot
encoding of nominal attributes, range scaling of numeric attributes) is fitted inside the
training fold only, mirroring the corrected RapidMiner processes."""
from __future__ import annotations

import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import (BaggingClassifier, HistGradientBoostingClassifier,
                              RandomForestClassifier)
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, MinMaxScaler, OneHotEncoder
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from .config import load_config
from .data import bmi_rule

LABELS = {
    "MAJ": "Majority class", "PRIOR": "Prior-stratified random",
    "NB": "Naive Bayes", "LR": "Logistic regression", "DT": "Decision tree",
    "BT": "Bagged tree", "RF": "Random forest", "GB": "Gradient boosting",
    "KNN": "k-nearest neighbours", "SVM": "Support vector machine",
    "BMIRULE": "BMI cut-point rule", "BMITREE": "BMI-only tree",
}
SHORT = {"MAJ": "Majority", "PRIOR": "Prior", "NB": "NB", "LR": "LR", "DT": "DT", "BT": "BT",
         "RF": "RF", "GB": "GB", "KNN": "kNN", "SVM": "SVM", "BMIRULE": "BMI rule",
         "BMITREE": "BMI tree"}


class BMIRuleClassifier(BaseEstimator, ClassifierMixin):
    """Deterministic probe: BMI from raw Height and Weight, class from fixed cut-points.
    ``fit`` only records the class set; nothing is learned."""

    def fit(self, X, y):
        self.classes_ = np.unique(y)
        return self

    def predict(self, X):
        b = X["Weight"].to_numpy() / X["Height"].to_numpy() ** 2
        return bmi_rule(b)

    def predict_proba(self, X):
        pred = self.predict(X)
        P = np.zeros((len(pred), len(self.classes_)))
        pos = {c: i for i, c in enumerate(self.classes_)}
        for r, p in enumerate(pred):
            if p in pos:
                P[r, pos[p]] = 1.0
        return P


def _bmi_column(X):
    return (X["Weight"].to_numpy() / X["Height"].to_numpy() ** 2).reshape(-1, 1)


def _pre(numeric, nominal):
    return ColumnTransformer(
        [("num", MinMaxScaler(), list(numeric)),
         ("nom", OneHotEncoder(handle_unknown="ignore", sparse_output=False), list(nominal))],
        remainder="drop", verbose_feature_names_out=False)


def make_model(name: str, numeric, nominal, seed: int | None = None, class_weight=None,
               overrides: dict | None = None):
    """Build the named classifier as a Pipeline."""
    cfg = load_config()
    seed = cfg["study"]["seed"] if seed is None else seed
    hp = dict(cfg["hyperparameters"].get(name, {}))
    if overrides:
        hp.update(overrides)

    if name == "BMIRULE":
        return BMIRuleClassifier()
    if name == "BMITREE":
        return Pipeline([("bmi", FunctionTransformer(_bmi_column)),
                         ("clf", DecisionTreeClassifier(random_state=seed, **hp))])

    if name == "MAJ":
        clf = DummyClassifier(strategy="most_frequent")
    elif name == "PRIOR":
        clf = DummyClassifier(strategy="stratified", random_state=seed)
    elif name == "NB":
        clf = GaussianNB(**hp)
    elif name == "LR":
        clf = LogisticRegression(random_state=seed, class_weight=class_weight, **hp)
    elif name == "DT":
        clf = DecisionTreeClassifier(random_state=seed, class_weight=class_weight, **hp)
    elif name == "BT":
        base = DecisionTreeClassifier(random_state=seed, **cfg["hyperparameters"]["DT"])
        clf = BaggingClassifier(estimator=base, random_state=seed, n_jobs=1, **hp)
    elif name == "RF":
        clf = RandomForestClassifier(random_state=seed, n_jobs=1, class_weight=class_weight, **hp)
    elif name == "GB":
        clf = HistGradientBoostingClassifier(random_state=seed, early_stopping=False,
                                             class_weight=class_weight, **hp)
    elif name == "KNN":
        clf = KNeighborsClassifier(**hp)
    elif name == "SVM":
        clf = SVC(kernel="rbf", probability=True, random_state=seed,
                  class_weight=class_weight, **hp)
    else:
        raise ValueError(name)
    return Pipeline([("pre", _pre(numeric, nominal)), ("clf", clf)])


def valid_for_arm(name: str, arm: str) -> bool:
    """Leakage probes need Height and Weight, so they run only in arms A and C."""
    if name in ("BMIRULE", "BMITREE"):
        return load_config()["arms"][arm]["attributes"] == "all"
    return True
