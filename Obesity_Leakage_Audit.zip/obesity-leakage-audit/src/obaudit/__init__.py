"""obaudit: provenance audit and leakage-controlled re-evaluation of the UCI Estimation of
Obesity Levels benchmark."""
__version__ = "1.0.0"
