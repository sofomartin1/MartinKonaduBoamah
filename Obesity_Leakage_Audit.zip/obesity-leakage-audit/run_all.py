"""Run the complete pipeline, stage by stage, and stop at the first failure.

    python run_all.py              # everything (about 1-2 hours on a 2-core laptop)
    python run_all.py --from 12    # resume from a stage
    python run_all.py --only 13 14 # selected stages

Raw cross-validation outputs are cached in results/raw/, so re-running a stage that has
already produced them is fast; delete results/ to recompute from scratch.
"""
import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAGES = [
    ("01", "scripts/01_data_audit.py", "Data audit and label-provenance (BMI) audit"),
    ("02", "scripts/02_provenance_validation.py", "Record-provenance validation"),
    ("03", "scripts/03_main_cv.py", "Primary 10x10 cross-validation, four arms"),
    ("04", "scripts/04_estimates.py", "Point estimates, CIs, pooled metrics"),
    ("05", "scripts/05_inference.py", "Defect decomposition and baseline tests"),
    ("06", "scripts/06_permutation.py", "Label-permutation tests"),
    ("07", "scripts/07_provenance_aware.py", "Provenance-aware evaluation"),
    ("08", "scripts/08_importance.py", "Permutation importance"),
    ("09", "scripts/09_learning_curves.py", "Learning curves"),
    ("10", "scripts/10_sensitivity.py", "Sensitivity analyses S1-S6"),
    ("11", "scripts/11_rapidminer_reconciliation.py", "Reconciliation with RapidMiner 7.1"),
    ("12", "scripts/12_figures.py", "Figures"),
    ("13", "scripts/13_tables.py", "Display tables"),
    ("14", "scripts/14_consistency.py", "Consistency gate"),
    ("15", "scripts/15_build_docx.py", "Word document of tables and figures"),
]

ap = argparse.ArgumentParser()
ap.add_argument("--from", dest="start", default="01")
ap.add_argument("--only", nargs="*")
a = ap.parse_args()
for sid, script, desc in STAGES:
    if a.only and sid not in a.only:
        continue
    if not a.only and sid < a.start:
        continue
    print(f"\n=== Stage {sid}: {desc} ===", flush=True)
    t0 = time.time()
    rc = subprocess.call([sys.executable, str(ROOT / script)], cwd=ROOT)
    if rc != 0:
        sys.exit(f"Stage {sid} failed (exit {rc}).")
    print(f"--- stage {sid} finished in {time.time() - t0:.0f}s", flush=True)
print("\nAll requested stages completed.")
