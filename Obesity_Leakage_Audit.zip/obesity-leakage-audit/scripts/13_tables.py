"""Stage 13 - every display table, formatted exactly as it appears in the Word document, written
to results/display_tables.json (and one CSV per table in results/tables/display/)."""
import _common  # noqa: F401
import platform

import numpy as np
import pandas as pd

from obaudit import __version__
from obaudit.config import load_config
from obaudit.data import arm_data, feature_columns, load_dataset
from obaudit.models import LABELS, SHORT, make_model
from obaudit.store import load_json, save_json

cfg = load_config()
CL = cfg["data"]["classes"]
CLD = [c.replace("_", " ") for c in CL]
LEARN = cfg["classifiers"]["primary"] + cfg["classifiers"]["extended"]
ARMS = list(cfg["arms"])
df = load_dataset()
audit = load_json("data_audit")
prov = load_json("provenance_validation")
est = load_json("estimates")
inf = load_json("inference")
perm = load_json("permutation")
pa = load_json("provenance_aware")
imp = load_json("importance")
sens = load_json("sensitivity")
rmr = load_json("rapidminer_reconciliation")
figd = load_json("figure_data")
TABLES = []


def n0(x):
    return f"{int(round(x)):,}"


def f2(x):
    return f"{x:.2f}"


def f3(x):
    return f"{x:.3f}"


def pct(x, d=2):
    return f"{100 * x:.{d}f}"


def ci(m, lo, hi, sc=100, d=2):
    return f"{m * sc:.{d}f} [{lo * sc:.{d}f}, {hi * sc:.{d}f}]"


def pfmt(p):
    return "< .001" if p < 0.001 else f"{p:.3f}".replace("0.", ".", 1)


def E(a, m, met):
    return est[a][m][met]


def add(tid, title, columns, rows, note, section="main", landscape=False, group_rows=None):
    TABLES.append({"id": tid, "title": title, "columns": columns, "rows": rows, "note": note,
                   "section": section, "landscape": landscape, "group_rows": group_rows or []})


# ------------------------------------------------------------------ T1 attributes
DESC = {
    "Gender": ("Sex of respondent", "Demographic"),
    "Age": ("Age (years)", "Demographic"),
    "Height": ("Height (m)", "Anthropometric: label source"),
    "Weight": ("Weight (kg)", "Anthropometric: label source"),
    "family_history_with_overweight": ("Family member has suffered or suffers from overweight", "Family history"),
    "FAVC": ("Frequent consumption of high-calorie food", "Dietary"),
    "FCVC": ("Frequency of vegetable consumption (1-3)", "Dietary"),
    "NCP": ("Number of main meals per day (1-4)", "Dietary"),
    "CAEC": ("Consumption of food between meals", "Dietary"),
    "SMOKE": ("Smokes", "Lifestyle"),
    "CH2O": ("Daily water intake (1-3)", "Dietary"),
    "SCC": ("Monitors calorie intake", "Lifestyle"),
    "FAF": ("Physical-activity frequency (0-3)", "Activity"),
    "TUE": ("Time using technology devices (0-2)", "Activity"),
    "CALC": ("Alcohol consumption", "Dietary"),
    "MTRANS": ("Usual mode of transport", "Activity"),
}
rows = []
for c in cfg["data"]["numeric"] + cfg["data"]["nominal"]:
    if c in cfg["data"]["numeric"]:
        typ = "Numeric"
        vals = f"{df[c].min():g} to {df[c].max():g}"
    else:
        typ = "Nominal" if df[c].nunique() > 2 else "Binary"
        vals = ", ".join(sorted(df[c].unique()))
    arms = "A, C" if c in cfg["data"]["anthropometric"] else "A, B, C, D"
    rows.append([c, DESC[c][0], typ, vals, DESC[c][1], arms])
rows.append(["NObeyesdad", "Obesity level (label)", "Nominal", "7 classes", "Outcome", "A, B, C, D"])
order = {c: i for i, c in enumerate(["Gender", "Age", "Height", "Weight", "family_history_with_overweight", "FAVC",
                                     "FCVC", "NCP", "CAEC", "SMOKE", "CH2O", "SCC", "FAF", "TUE", "CALC", "MTRANS", "NObeyesdad"])}
rows.sort(key=lambda r: order[r[0]])
add("T1", "Attributes of the Estimation of Obesity Levels Dataset and Their Use in the Four Arms",
    ["Attribute", "Description", "Type", "Values (full file)", "Group", "Arms"], rows,
    "Numeric survey attributes were collected on integer scales; non-integral values occur only in synthetic records. "
    "Height and Weight are excluded from Arms B and D because the label is computed from them.", landscape=True)

# ------------------------------------------------------------------ T2 provenance evidence
cd = prov["concordance_discrete"]
nn = {r["provenance"]: r for r in prov["nearest_neighbour"]}
gr = prov["generation_ratio"]
box = prov["box_containment_total"]
boxd = prov["box_containment_total_discrete_rule"]
runs = prov["synthetic_block_runs"]
na, ns, n = audit["n_authentic"], audit["n_synthetic"], audit["n_records"]
rows = [
    ["Composition stated in the dataset descriptor", "23% collected through a web survey; 77% generated with SMOTE in Weka", "Reference value"],
    ["Survey block (file structure)", f"Rows 1\u2013{na}: {na} records ({100 * na / n:.2f}%), labels interleaved in {prov['survey_block_label_runs']} runs",
     "Matches the stated 23% share"],
    ["Synthetic block (file structure)", f"Rows {na + 1}\u2013{n:,}: {ns:,} records ({100 * ns / n:.2f}%) in {len(runs)} class-sorted runs; no Normal Weight run",
     "SMOTE output appended class by class; majority class not oversampled"],
    ["Survey-scale precision", f"{na}/{na} survey-block records on the survey scale (weight to 0.1 kg); "
     f"{prov['concordance_discrete_0.1kg']['both_synthetic']:,}/{ns:,} synthetic-block records ({prov['synthetic_with_any_nonintegral_pct']:.2f}%) off-scale",
     f"The {prov['synthetic_flagged_authentic_are_exact_duplicates']} on-scale synthetic records are exact copies"],
    ["Antecedent discrete-value rule", f"Agrees for {cd['both_authentic'] + cd['both_synthetic']:,} records ({cd['agreement_pct']:.2f}%); "
     f"{cd['file_authentic_rule_synthetic']} survey records labelled synthetic, {cd['file_synthetic_rule_authentic']} synthetic records labelled authentic",
     f"Survey misses are weights recorded to 0.1 kg ({prov['survey_flagged_synthetic_by_class']['Normal_Weight']} Normal Weight)"],
    ["Bounding-box containment", f"{box['in_own_box']:,}/{box['n_synthetic']:,} synthetic records ({box['pct']:.2f}%) inside the box of their own class's authentic records; "
     f"{boxd['in_own_box']:,}/{boxd['n_synthetic']:,} ({boxd['pct']:.2f}%) under the antecedent rule",
     "Consistent with per-attribute SMOTE interpolation"],
    ["Synthetic records per authentic record", ", ".join(f"{CLD[k].replace('Weight', 'Wt').replace('Overweight Level ', 'OW ').replace('Obesity Type ', 'Ob ')} {gr[c]:.2f}" if gr[c] else "Normal Wt 0 (not oversampled)"
                                                        for k, c in enumerate(CL)),
     "Integer oversampling multiples for five of six oversampled classes"],
    ["BMI-rule agreement by provenance", f"Authentic {audit['bmi_rule_agreement_authentic_pct']:.2f}%; synthetic {audit['bmi_rule_agreement_synthetic_pct']:.2f}%",
     "Disagreements arise from interpolated height and weight"],
    ["Nearest-neighbour geometry", f"Median distance to nearest record: synthetic {nn['synthetic']['nn_distance_median']:.3f}, authentic {nn['authentic']['nn_distance_median']:.3f}; "
     f"same-class neighbour: synthetic {nn['synthetic']['nn_same_class_pct']:.1f}%, authentic {nn['authentic']['nn_same_class_pct']:.1f}%",
     "Synthetic records sit beside same-class siblings"],
]
add("T2", "Evidence for Record Provenance in the Distributed File",
    ["Criterion", "Result", "Interpretation"], rows,
    "Distances are Euclidean in the range-scaled, one-hot-encoded attribute space. SMOTE = synthetic minority "
    "oversampling technique; OW = Overweight Level; Ob = Obesity Type; Wt = Weight.", landscape=True)

# ------------------------------------------------------------------ T3 composition
rows = []
bmi_tab = {r["class"]: r for r in audit["bmi_by_class"]}
for k, c in enumerate(CL):
    comp = prov["composition"][k]
    b = bmi_tab[c]
    rows.append([CLD[k], n0(comp["authentic"]), n0(comp["synthetic"]), n0(comp["total"]), f"{comp['synthetic_pct']:.1f}",
                 f"{gr[c]:.2f}", f"{b['bmi_mean']:.2f} ({b['bmi_sd']:.2f})",
                 f"{b['agree_pct_authentic']:.1f}", "-" if b["agree_pct_synthetic"] is None else f"{b['agree_pct_synthetic']:.1f}",
                 f"{comp['authentic_discrete_rule']} / {comp['synthetic_discrete_rule']}"])
t = prov["composition"][7]
rows.append(["Total", n0(t["authentic"]), n0(t["synthetic"]), n0(t["total"]), f"{t['synthetic_pct']:.1f}", f"{t['synthetic'] / t['authentic']:.2f}",
             f"{df.Weight.div(df.Height ** 2).mean():.2f} ({df.Weight.div(df.Height ** 2).std():.2f})",
             f"{audit['bmi_rule_agreement_authentic_pct']:.1f}", f"{audit['bmi_rule_agreement_synthetic_pct']:.1f}",
             f"{t['authentic_discrete_rule']:,} / {t['synthetic_discrete_rule']:,}"])
add("T3", "Record Provenance, Body Mass Index and Label Agreement by Obesity Class",
    ["Class", "Authentic", "Synthetic", "Total", "Synthetic (%)", "Synthetic per authentic", "BMI, M (SD)",
     "BMI rule agrees, authentic (%)", "BMI rule agrees, synthetic (%)", "Antecedent rule (auth. / syn.)"], rows,
    f"Provenance from the file-structure rule. BMI rule = cut-points {', '.join(f'{c:g}' for c in cfg['data']['bmi_cutpoints'])} kg/m² "
    f"applied to Weight/Height²; it reproduces {audit['bmi_rule_agreement_pct']:.2f}% of all labels. The last column gives the counts "
    "under the antecedent discrete-value rule.", landscape=True)

# ------------------------------------------------------------------ T4 arms
rows = []
for a in ARMS:
    X, yv, idx = arm_data(df, a)
    num, nom = feature_columns(cfg["arms"][a]["attributes"])
    pre = make_model("LR", num, nom).named_steps["pre"].fit(X)
    npred = len(pre.get_feature_names_out())
    cnt = np.bincount(yv, minlength=7)
    rows.append([a, cfg["arms"][a]["description"], n0(len(yv)), str(len(num) + len(nom)), str(npred),
                 f"{CLD[int(cnt.argmin())]} ({cnt.min()})",
                 pct(E(a, "MAJ", "accuracy")["mean"]), pct(E(a, "MAJ", "balanced_accuracy")["mean"])])
add("T4", "Design of the Four Experimental Arms",
    ["Arm", "Records and attributes", "n", "Attributes", "Predictors after encoding", "Smallest class (n)",
     "Majority-class accuracy (%)", "Majority-class balanced accuracy (%)"], rows,
    "Majority-class values are 10 × 10 cross-validated means of a classifier that always predicts the most frequent training class. "
    "Balanced accuracy of the majority classifier exceeds 1/7 in Arms C and D because Obesity Type III (3 records) is absent from seven of every ten test folds.")

# ------------------------------------------------------------------ T5 learners
HP = cfg["hyperparameters"]
setting = {
    "MAJ": "Predicts the most frequent training class", "PRIOR": "Samples predictions from the training class distribution",
    "NB": "Gaussian class-conditional densities on encoded predictors",
    "LR": f"Multinomial, L2 penalty, C = {HP['LR']['C']}",
    "DT": f"Entropy criterion, maximum depth {HP['DT']['max_depth']}, minimum leaf {HP['DT']['min_samples_leaf']}, minimum split {HP['DT']['min_samples_split']}",
    "BT": f"{HP['BT']['n_estimators']} decision trees as above, bootstrap fraction {HP['BT']['max_samples']}",
    "RF": f"{HP['RF']['n_estimators']} trees, {HP['RF']['max_features']} features per split",
    "GB": f"Histogram gradient boosting, {HP['GB']['max_iter']} iterations, learning rate {HP['GB']['learning_rate']}",
    "KNN": f"k = {HP['KNN']['n_neighbors']}, Euclidean distance on range-scaled predictors",
    "SVM": f"Radial basis kernel, C = {HP['SVM']['C']}, gamma = {HP['SVM']['gamma']}, Platt probabilities",
    "BMIRULE": "BMI from Height and Weight, fixed cut-points, no fitting",
    "BMITREE": f"Decision tree on BMI alone, maximum depth {HP['BMITREE']['max_depth']}",
}
paradigm = {"MAJ": "Baseline", "PRIOR": "Baseline", "NB": "Probabilistic", "LR": "Linear", "DT": "Tree", "BT": "Tree ensemble (bagging)",
            "RF": "Tree ensemble (bagging + feature subsampling)", "GB": "Tree ensemble (boosting)", "KNN": "Instance-based",
            "SVM": "Kernel", "BMIRULE": "Leakage probe", "BMITREE": "Leakage probe"}
role = {**{c: "Antecedent learner" for c in cfg["classifiers"]["primary"]}, **{c: "Extended learner" for c in cfg["classifiers"]["extended"]},
        "MAJ": "Reference", "PRIOR": "Reference", "BMIRULE": "Arms A and C only", "BMITREE": "Arms A and C only"}
rows = [[SHORT[c], LABELS[c], paradigm[c], setting[c], role[c]]
        for c in cfg["classifiers"]["baselines"] + LEARN + cfg["classifiers"]["leakage_probes"]]
add("T5", "Learners, Baselines and Leakage Probes",
    ["Code", "Learner", "Paradigm", "Settings", "Role"], rows,
    "All learners run inside a pipeline whose one-hot encoding and range scaling are fitted on the training fold only. "
    "Settings were fixed before analysis; tuned variants are reported as a sensitivity analysis. Random seed 2001 throughout.", landscape=True)

# ------------------------------------------------------------------ T6/T7 performance
def perf_rows(arms):
    rows, groups = [], []
    for a in arms:
        groups.append(len(rows))
        models = ["MAJ", "PRIOR"] + LEARN + ([c for c in cfg["classifiers"]["leakage_probes"]] if cfg["arms"][a]["attributes"] == "all" else [])
        for c in models:
            r = est[a][c]
            rows.append([a if c == "MAJ" else "", SHORT[c],
                         ci(r["accuracy"]["mean"], r["accuracy"]["lo"], r["accuracy"]["hi"]),
                         ci(r["balanced_accuracy"]["mean"], r["balanced_accuracy"]["lo"], r["balanced_accuracy"]["hi"]),
                         pct(r["macro_f1"]["mean"]),
                         ci(r["kappa"]["mean"], r["kappa"]["lo"], r["kappa"]["hi"], sc=1, d=3),
                         f3(r["mcc"]["mean"]),
                         f3(r["auc_macro"]["mean"])])
    return rows, groups


cols = ["Arm", "Learner", "Accuracy (%) [95% CI]", "Balanced accuracy (%) [95% CI]", "Macro F1 (%)", "κ [95% CI]", "MCC", "Macro AUC"]
note = ("Means over 10 × 10 stratified cross-validation folds; 95% CIs use the corrected resampled t (Nadeau-Bengio variance correction). "
        "Macro AUC is computed on the pooled out-of-fold probabilities of each repetition and averaged over repetitions. "
        "κ = Cohen's kappa; MCC = Matthews correlation coefficient; Majority = majority-class baseline; Prior = prior-stratified random baseline; "
        "BMI rule and BMI tree use only Height and Weight.")
r6, g6 = perf_rows(["A", "B"])
add("T6", "Performance in the Full-Record Arms (A and B)", cols, r6, note, landscape=True, group_rows=g6)
r7, g7 = perf_rows(["C", "D"])
add("T7", "Performance in the Authentic-Record Arms (C and D)", cols, r7,
    note + f" The majority-class accuracy on authentic records is {audit['majority_baseline_authentic_pct']:.2f}%.", landscape=True, group_rows=g7)

# ------------------------------------------------------------------ T8 decomposition
dec = inf["decomposition"]


def D(c, met, con):
    return next(d for d in dec if d["classifier"] == c and d["metric"] == met and d["contrast"] == con)


rows, groups = [], []
for met, lab in (("accuracy", "Accuracy"), ("balanced_accuracy", "Balanced accuracy")):
    groups.append(len(rows))
    for i, c in enumerate(LEARN):
        cells = []
        for con in ("label_full", "label_authentic", "synthetic_all", "synthetic_behaviour", "both", "interaction"):
            d = D(c, met, con)
            star = "*" if d["p_holm"] < 0.05 else ""
            cells.append(f"{100 * d['diff']:.2f}{star} [{100 * d['lo']:.2f}, {100 * d['hi']:.2f}]")
        rows.append([lab if i == 0 else "", SHORT[c]] + cells)
add("T8", "Accuracy Attributable to Each Defect (Percentage Points)",
    ["Metric", "Learner", "Circular label, full (A − B)", "Circular label, authentic (C − D)", "Synthetic records, all attributes (A − C)",
     "Synthetic records, behaviour (B − D)", "Both defects (A − D)", "Interaction (A − B) − (C − D)"], rows,
    "Positive values are performance lost when the defect is removed. A − B and C − D are paired on identical folds (corrected resampled t); "
    "comparisons across record sets combine the corrected variances of both arms (Welch degrees of freedom); the interaction combines the two paired contrasts. "
    "* Holm-adjusted p < .05 within metric (48 tests).", landscape=True, group_rows=groups)

# ------------------------------------------------------------------ T9 chance and baseline tests
vm = inf["vs_majority"]
ps = perm["summary"]


def V(a, c, met):
    return next(v for v in vm if v["arm"] == a and v["classifier"] == c and v["metric"] == met)


def PS(a, c, s):
    r = [p for p in ps if p["arm"] == a and p["classifier"] == c and p["statistic"] == s]
    return pfmt(r[0]["p"]) if r else "-"


rows, groups = [], []
for a in ("C", "D"):
    groups.append(len(rows))
    for i, c in enumerate(LEARN):
        va, vb, vk = V(a, c, "accuracy"), V(a, c, "balanced_accuracy"), V(a, c, "kappa")
        rows.append([a if i == 0 else "", SHORT[c],
                     f"{100 * va['diff']:.2f} [{100 * va['lo']:.2f}, {100 * va['hi']:.2f}]", pfmt(va["p_holm"]),
                     f"{100 * vb['diff']:.2f} [{100 * vb['lo']:.2f}, {100 * vb['hi']:.2f}]", pfmt(vb["p_holm"]),
                     f"{vk['diff']:.3f} [{vk['lo']:.3f}, {vk['hi']:.3f}]",
                     PS(a, c, "balanced_accuracy"), PS(a, c, "kappa")])
add("T9", "Authentic-Record Performance Against the Majority-Class Baseline and Label-Permutation Nulls",
    ["Arm", "Learner", "Accuracy − majority (pp) [95% CI]", "p (Holm)", "Balanced accuracy − majority (pp) [95% CI]", "p (Holm)",
     "κ [95% CI]", "Permutation p, balanced accuracy", "Permutation p, κ"], rows,
    f"Differences are paired on identical folds against the majority-class classifier (accuracy {audit['majority_baseline_authentic_pct']:.2f}%). "
    f"Permutation tests use {cfg['statistics']['permutations']:,} label permutations with one stratified 10-fold partition each and were run for the four antecedent learners; "
    "p = (1 + exceedances)/(N + 1). Holm adjustment within arm and metric (8 tests).", landscape=True, group_rows=groups)

# ------------------------------------------------------------------ T10 provenance-aware
def PA(attrs, c, s, met="balanced_accuracy"):
    return next(r for r in pa if r["attributes"] == attrs and r["classifier"] == c and r["scheme"] == s and r["metric"] == met)


rows, groups = [], []
for attrs, lab in (("all", "All attributes"), ("behaviour", "Behaviour only")):
    groups.append(len(rows))
    for i, c in enumerate(["MAJ"] + LEARN):
        rc, ao, sp, spp, so, sop = (PA(attrs, c, s) for s in ("random_cv_full_scored_authentic", "authentic_only", "synth_plus",
                                                              "synth_plus_purged", "synth_only", "synth_only_purged"))
        rows.append([lab if i == 0 else "", SHORT[c], pct(rc["mean"]), pct(ao["mean"]), pct(sp["mean"]), pct(spp["mean"]),
                     pct(so["mean"]), pct(sop["mean"]),
                     f"{100 * sp['diff_vs_authentic_only']:.2f} [{100 * sp['diff_lo']:.2f}, {100 * sp['diff_hi']:.2f}]",
                     f"{100 * spp['diff_vs_authentic_only']:.2f} [{100 * spp['diff_lo']:.2f}, {100 * spp['diff_hi']:.2f}]"])
anc = load_json("synthetic_anchors")
add("T10", "Balanced Accuracy on Authentic Records Under Six Training Regimes (%)",
    ["Attributes", "Learner", "Random CV on full file", "Authentic only", "Authentic + synthetic", "Authentic + synthetic, anchor-purged",
     "Synthetic only", "Synthetic only, anchor-purged", "\u0394 authentic + synthetic vs authentic only (pp) [95% CI]",
     "\u0394 anchor-purged vs authentic only (pp) [95% CI]"], rows,
    "All columns are scored on authentic test records only. 'Random CV on full file' scores the authentic records within the Arm A or B folds. "
    "The other regimes share the Arm C/D test folds, so differences are paired (corrected resampled t). Anchor-purged regimes remove from training every "
    "synthetic record whose nearest same-class authentic record lies in the test fold, so no oversampled descendant of a test record informs its prediction; "
    f"the {anc['n_synthetic']:,} synthetic records anchor on {sum(1 for v in anc['anchors_per_authentic'] if v > 0)} of the {len(anc['anchors_per_authentic'])} authentic records.",
    landscape=True, group_rows=groups)

# ------------------------------------------------------------------ T11 calibration
rows, groups = [], []
for a in ARMS:
    groups.append(len(rows))
    for i, c in enumerate(["MAJ", "LR", "BT", "RF", "GB"]):
        r = est[a][c]
        rows.append([a if i == 0 else "", SHORT[c],
                     f"{r['auc_macro']['mean']:.3f} [{r['auc_macro']['lo']:.3f}, {r['auc_macro']['hi']:.3f}]",
                     f"{r['brier']['mean']:.3f} [{r['brier']['lo']:.3f}, {r['brier']['hi']:.3f}]",
                     f"{r['log_loss']['mean']:.3f}",
                     f"{r['ece']['mean']:.3f} ({r['ece']['sd']:.3f})"])
add("T11", "Discrimination and Calibration of Predicted Probabilities",
    ["Arm", "Learner", "Macro AUC [95% CI]", "Brier score [95% CI]", "Log loss", "ECE (SD)"], rows,
    "Computed on pooled out-of-fold probabilities per repetition and averaged over 10 repetitions; CIs from 1,000 bootstrap resamples of records. "
    "Brier score is the multi-class sum of squared errors (range 0-2). Log loss clips probabilities at 10\u207b\u00b9\u2075, which dominates the value for the majority "
    "classifier. ECE = top-label expected calibration error, 10 equal-width bins, with the SD across repetitions (a bootstrap interval is not reported because "
    "resampling inflates ECE).",
    group_rows=groups)

# ------------------------------------------------------------------ T12 contextual comparison
LIT = figd["literature"]
VALID = {"Maulana et al. (2024)": "Not reported in abstract", "Gandhi et al. (2026)": "80/20 hold-out",
         "Görmez et al. (2025)": "100 repeated hold-outs", "Haggouni et al. (2026)": "Hold-out test set (n = 423), cross-validated tuning"}
rows = []
for r in LIT:
    a = r["arm_like"]
    best = max(LEARN, key=lambda c: est[a][c]["accuracy"]["mean"])
    rows.append([r["study"], r["setting"], VALID[r["study"]], r["model"], f"{r['accuracy']:.2f}", a,
                 f"{SHORT[best]} {pct(est[a][best]['accuracy']['mean'])}",
                 pct(est["D"][max(LEARN, key=lambda c: est['D'][c]['accuracy']['mean'])]["accuracy"]["mean"]),
                 pct(est["D"]["MAJ"]["accuracy"]["mean"])])
add("T12", "Published Accuracies on the Benchmark Against the Corresponding Arms of This Study",
    ["Study", "Setting", "Validation", "Model", "Reported accuracy (%)", "Comparable arm", "This study, best learner in that arm (%)",
     "This study, best learner in Arm D (%)", "Majority class, authentic records (%)"], rows,
    "Published values are as reported by the authors and were not re-estimated. Comparable arm: A = full file with Height and Weight; "
    "B = full file without them; C = authentic records with them. No published study evaluated the Arm D setting.", landscape=True)

# ------------------------------------------------------------------ T13 sensitivity summary
def summ(rows_, a, label, maj=None):
    rr = [r for r in rows_ if r["arm"] == a and r["classifier"] in LEARN]
    if maj is None:
        mj = next((r for r in rows_ if r["arm"] == a and r["classifier"] == "MAJ"), None)
        maj = mj["accuracy"] if mj else None
    best_acc = max(rr, key=lambda r: r["accuracy"])
    best_bal = max(rr, key=lambda r: r["balanced_accuracy"])
    above = sum(1 for r in rr if r["accuracy_lo"] > maj) if maj is not None and "accuracy_lo" in rr[0] else None
    return [label, a, pct(maj) if maj is not None else "-",
            f"{SHORT[best_acc['classifier']]} {pct(best_acc['accuracy'])}",
            f"{SHORT[best_bal['classifier']]} {pct(best_bal['balanced_accuracy'])}",
            f"{max(r['kappa'] for r in rr):.3f}", f"{above}/{len(rr)}" if above is not None else "-"]


prim = []
for a in ("C", "D"):
    for c in ["MAJ"] + LEARN:
        r = est[a][c]
        prim.append({"arm": a, "classifier": c, "accuracy": r["accuracy"]["mean"], "accuracy_lo": r["accuracy"]["lo"],
                     "balanced_accuracy": r["balanced_accuracy"]["mean"], "kappa": r["kappa"]["mean"]})
rows = []
for a in ("C", "D"):
    rows.append(summ(prim, a, "Primary analysis"))
    rows.append(summ(sens["S1_discrete_rule"], a, "S1 Antecedent provenance rule (496 records)"))
    rows.append(summ(sens["S2_deduplicated"], a, "S2 Exact duplicates removed"))
    s4 = [dict(r) for r in sens["S4_class_weighted"]]
    rows.append(summ(s4, a, "S4 Class-weighted learners (LR, DT, RF, GB, SVM)", maj=est[a]["MAJ"]["accuracy"]["mean"]))
    s6 = [dict(r, accuracy_lo=-1) for r in sens["S6_nested_tuning"]]
    r6_ = summ(s6, a, "S6 Nested tuning (DT, LR, RF, GB)", maj=est[a]["MAJ"]["accuracy"]["mean"])
    r6_[-1] = "-"
    rows.append(r6_)
add("T13", "Robustness of the Authentic-Record Results to Analytic Choices",
    ["Analysis", "Arm", "Majority-class accuracy (%)", "Best accuracy (%)", "Best balanced accuracy (%)", "Largest κ",
     "Learners whose accuracy CI lies above the majority class"], rows,
    "Each row summarises the learners available in that analysis. S6 uses one outer 10-fold partition with an inner 5-fold grid search on balanced accuracy, "
    "so no corrected CI is computed. Coarser outcome definitions (S3) and the random-forest sweep (S5) are reported in the appendix.", landscape=True)

# ================================================================= appendix tables
desc = audit["descriptives"]
rows = [[d["attribute"].replace("family_history_with_overweight", "Family history"),
         d["type"].capitalize() + (f" ({d['level'].replace('_', ' ')})" if d["type"] == "nominal" else ""), d["full"], d["authentic"], d["synthetic"],
         f"{d['effect']:.2f} ({'d' if d['effect_name'] == 'Cohen d' else 'V'})", pfmt(d["p"]),
         f"{d['n_unique_authentic']:,} / {d['n_unique_synthetic']:,}"] for d in desc]
add("A1", "Descriptive Statistics by Record Provenance",
    ["Attribute", "Type (level shown)", "Full file", "Authentic", "Synthetic", "Effect size", "p", "Distinct values (auth. / syn.)"], rows,
    "Numeric attributes: M (SD), Cohen's d (authentic minus synthetic) and Mann-Whitney p. Nominal attributes: share of the most frequent level, "
    "Cramér's V and chi-square p.", section="appendix", landscape=True)

rows = [[", ".join(str(x) for x in g["rows_1based"]), str(g["n_copies"]), str(g["n_in_survey_block"]), str(g["n_in_synthetic_block"]),
         g["class"].replace("_", " ")] for g in audit["duplicate_groups"]]
rows.append(["Total", str(audit["exact_duplicate_rows_all_copies"]), str(sum(g["n_in_survey_block"] for g in audit["duplicate_groups"])),
             str(sum(g["n_in_synthetic_block"] for g in audit["duplicate_groups"])), ""])
add("A2", "Exact Duplicate Records", ["Rows (1-based)", "Copies", "In survey block", "In synthetic block", "Class"], rows,
    f"{audit['exact_duplicate_rows_extra']} rows duplicate an earlier row ({audit['duplicates_extra_in_survey_block']} in the survey block, "
    f"{audit['duplicates_extra_in_synthetic_block']} in the synthetic block). Duplicates are retained in the primary analysis and removed in sensitivity analysis S2.",
    section="appendix")

rows = [[b["class"].replace("_", " "), str(b["n_authentic"]), str(b["n_synthetic"]),
         "-" if b["synthetic_in_own_box"] is None else f"{b['synthetic_in_own_box']} ({b['synthetic_in_own_box_pct']:.1f})",
         f"{b['other_synthetic_in_box_pct']:.1f}", f"{b['other_authentic_in_box_pct']:.1f}"] for b in prov["box_containment"]]
add("A3", "Bounding-Box Containment of Synthetic Records",
    ["Class", "Authentic", "Synthetic", "Synthetic inside own-class box, n (%)", "Other classes' synthetic inside box (%)", "Other classes' authentic inside box (%)"],
    rows, "The box spans the minimum and maximum of each numeric attribute over the authentic records of the class. The two right-hand columns show how often records "
    "of other classes fall in the same box, which indicates how informative containment is for that class.", section="appendix")

rows = [[r["provenance"].capitalize(), str(r["n"]), f"{r['nn_distance_median']:.3f} [{r['nn_distance_q1']:.3f}, {r['nn_distance_q3']:.3f}]",
         f"{r['nn_same_class_pct']:.1f}", f"{r['nn_is_synthetic_pct']:.1f}", f"{r['nn_distance_zero_pct']:.1f}"] for r in prov["nearest_neighbour"]]
add("A4", "Nearest-Neighbour Geometry by Provenance",
    ["Records", "n", "Distance to nearest record, median [IQR]", "Same-class neighbour (%)", "Neighbour is synthetic (%)", "Zero distance (%)"], rows,
    "Euclidean distance in the range-scaled, one-hot-encoded space of all 16 attributes. The last row recomputes neighbours among authentic records only.",
    section="appendix")

rows, groups = [], []
for a in ("C", "D"):
    groups.append(len(rows))
    sup = est[a]["LR"]["class_support"]
    for i, c in enumerate(["LR", "BT", "RF", "GB"]):
        rec = est[a][c]["per_class_recall"]
        pre_ = est[a][c]["per_class_precision"]
        rows.append([a if i == 0 else "", SHORT[c]] + [f"{100 * rec[k]:.1f} / {'-' if pre_[k] is None else f'{100 * pre_[k]:.1f}'}" for k in range(7)])
add("A5", "Per-Class Recall and Precision on Authentic Records (%)",
    ["Arm", "Learner"] + [f"{s} (n = {n_})" for s, n_ in zip(["Insuff.", "Normal", "OW I", "OW II", "Ob. I", "Ob. II", "Ob. III"], est["C"]["LR"]["class_support"])],
    rows, "Recall / precision from confusion matrices summed over the 10 repetitions. '-' = class never predicted.", section="appendix", landscape=True, group_rows=groups)

pw = [r for r in inf["pairwise"] if r["arm"] == "D" and r["metric"] == "balanced_accuracy"]
rows = [[f"{SHORT[r['a']]} − {SHORT[r['b']]}", f"{100 * r['diff']:.2f} [{100 * r['lo']:.2f}, {100 * r['hi']:.2f}]", pfmt(r["p"]), pfmt(r["p_holm"])] for r in pw]
add("A6", "Pairwise Comparisons of Balanced Accuracy in Arm D",
    ["Comparison", "Difference (pp) [95% CI]", "p", "p (Holm)"], rows,
    "Paired corrected resampled t on identical folds; Holm adjustment over the 28 comparisons.", section="appendix")

s3 = sens["S3_outcomes"]
ONAME = {"three_class": "Three classes", "obese_vs_not": "Obese vs not", "bmi25_vs_not": "BMI ≥ 25 vs not"}
rows, groups = [], []
for a in ("C", "D"):
    for o in ONAME:
        groups.append(len(rows))
        for i, c in enumerate(["MAJ"] + LEARN):
            r = next(x for x in s3 if x["arm"] == a and x["outcome"] == o and x["classifier"] == c)
            rows.append([f"{a}: {ONAME[o]}" if i == 0 else "", SHORT[c], ci(r["accuracy"], r["accuracy_lo"], r["accuracy_hi"]),
                         ci(r["balanced_accuracy"], r["balanced_accuracy_lo"], r["balanced_accuracy_hi"]), f3(r["kappa"]), f3(r["auc_macro"]),
                         pfmt(r["perm_p"]) if "perm_p" in r and r.get("perm_p") is not None else "-"])
add("A7", "Sensitivity Analysis S3: Coarser Outcome Definitions on Authentic Records",
    ["Arm and outcome", "Learner", "Accuracy (%) [95% CI]", "Balanced accuracy (%) [95% CI]", "κ", "Macro AUC", "Permutation p, balanced accuracy"],
    rows, "Three classes: Insufficient or Normal Weight; Overweight Levels I-II; Obesity Types I-III. Permutation tests (1,000 permutations) were run for LR and DT.",
    section="appendix", landscape=True, group_rows=groups)

s5 = sens["S5_rf_max_features"]
rows = [[r["arm"], r["max_features"], ci(r["accuracy"], r["accuracy_lo"], r["accuracy_hi"]), ci(r["balanced_accuracy"], r["balanced_accuracy_lo"], r["balanced_accuracy_hi"]),
         f3(r["kappa"])] for r in s5]
add("A8", "Sensitivity Analysis S5: Random-Forest Feature Subsampling",
    ["Arm", "max_features", "Accuracy (%) [95% CI]", "Balanced accuracy (%) [95% CI]", "κ"], rows,
    "max_features = 1.0 considers every predictor at every split, which reduces the forest to bagged trees. 300 trees, 10 × 10 cross-validation.",
    section="appendix")

s6 = sens["S6_nested_tuning"]
rows = [[r["arm"] if i_ % 4 == 0 else "", SHORT[r["classifier"]], f"{100 * r['balanced_accuracy']:.2f} ({100 * r['balanced_accuracy_sd']:.2f})",
         f"{100 * r['balanced_accuracy_fixed_all_repeats']:.2f}", f"{100 * r['accuracy']:.2f} ({100 * r['accuracy_sd']:.2f})",
         f"{100 * r['accuracy_fixed_all_repeats']:.2f}", r["modal_params"].replace("clf__", "").replace("None", "unlimited").replace("{", "").replace("}", "").replace("'", ""), str(r["n_distinct_params"])] for i_, r in enumerate(s6)]
add("A9", "Sensitivity Analysis S6: Nested Cross-Validation With Hyperparameter Tuning",
    ["Arm", "Learner", "Tuned balanced accuracy (%), M (SD)", "Fixed settings (%)", "Tuned accuracy (%), M (SD)", "Fixed settings (%)", "Modal selected settings", "Distinct selections"],
    rows, "Outer stratified 10-fold partition (seed 2001), inner 5-fold grid search maximising balanced accuracy. 'Fixed settings' are the primary 10 × 10 means.",
    section="appendix", landscape=True)

cells = rmr["cells"]
rows, groups = [], []


def RC(a_, c_, m_):
    return next(x for x in cells if x["arm"] == a_ and x["classifier"] == c_ and x["metric"] == m_)


for a_ in ARMS:
    groups.append(len(rows))
    for i, c_ in enumerate(cfg["classifiers"]["primary"]):
        row = [a_ if i == 0 else "", SHORT[c_]]
        for m_, d in (("accuracy", 2), ("balanced_accuracy", 2), ("kappa", 3)):
            x = RC(a_, c_, m_)
            row += [f"{x['rapidminer']:.{d}f} ({x['rapidminer_sd']:.{d}f})", f"{x['python']:.{d}f} [{x['python_lo']:.{d}f}, {x['python_hi']:.{d}f}]",
                    f"{x['difference']:+.{d}f}"]
        rows.append(row)
ra = rmr["rank_agreement"]
add("A10", "Reconciliation With the Antecedent RapidMiner Studio 7.1 Results",
    ["Arm", "Learner", "Accuracy (%), RapidMiner M (SD)", "Accuracy (%), Python [95% CI]", "\u0394", "Macro recall (%), RapidMiner M (SD)",
     "Macro recall (%), Python [95% CI]", "\u0394", "\u03ba, RapidMiner M (SD)", "\u03ba, Python [95% CI]", "\u0394"], rows,
    "RapidMiner: one stratified 10-fold partition (seed 2001), population SD across folds; Arms C and D used the antecedent 496-record rule, so they are compared with "
    f"Python runs on the same 496 records. Rank agreement across the 16 cells (Spearman): accuracy {ra['accuracy']['spearman_rho']:.2f}, "
    f"κ {ra['kappa']['spearman_rho']:.2f}, macro recall {ra['balanced_accuracy']['spearman_rho']:.2f}, macro precision {ra['macro_precision']['spearman_rho']:.2f}.",
    section="appendix", landscape=True, group_rows=groups)

rows = []
for c in ["MAJ"] + LEARN + cfg["classifiers"]["leakage_probes"]:
    row = [SHORT[c]]
    for a in ARMS:
        if c in est[a]:
            row.append(f"{1000 * est[a][c]['fit_s_mean']:.1f} / {1000 * est[a][c]['predict_s_mean']:.1f}")
        else:
            row.append("-")
    rows.append(row)
add("A11", "Computational Cost per Fold (Milliseconds, Fit / Predict)", ["Learner"] + [f"Arm {a}" for a in ARMS], rows,
    f"Wall-clock means over 100 folds on {platform.machine()} hardware with {cfg['cv']['n_jobs']} parallel workers; values depend on hardware and are reported for relative comparison.",
    section="appendix")

rows, groups = [], []
for a in ARMS:
    groups.append(len(rows))
    for i, c in enumerate(("RF", "LR")):
        top = sorted([r for r in imp if r["arm"] == a and r["classifier"] == c], key=lambda r: -r["importance_mean"])[:5]
        rows.append([a if i == 0 else "", SHORT[c]] + [f"{r['attribute'].replace('family_history_with_overweight', 'Family history')} ({100 * r['importance_mean']:.1f})" for r in top])
add("A12", "Most Important Attributes by Held-Out Permutation Importance",
    ["Arm", "Learner", "1st", "2nd", "3rd", "4th", "5th"], rows,
    "Values in parentheses are mean drops in balanced accuracy (percentage points) when the attribute is permuted in the test fold (10 permutations, one stratified 10-fold partition).",
    section="appendix", landscape=True, group_rows=groups)

import sklearn, scipy, matplotlib, joblib  # noqa: E401
rows = [["Language", f"Python {platform.python_version()}"],
        ["Core libraries", f"scikit-learn {sklearn.__version__}; NumPy {np.__version__}; pandas {pd.__version__}; SciPy {scipy.__version__}; "
                           f"matplotlib {matplotlib.__version__}; joblib {joblib.__version__}"],
        ["Package", f"obaudit {__version__} (this repository)"],
        ["Random seed", str(cfg["study"]["seed"])],
        ["Cross-validation", f"{cfg['cv']['n_repeats']} × {cfg['cv']['n_splits']} repeated stratified; identical partitions within record sets"],
        ["Preprocessing", "One-hot encoding (nominal) and range scaling to [0, 1] (numeric), fitted on training folds only"],
        ["Uncertainty", f"Corrected resampled t for fold metrics; {cfg['statistics']['bootstrap']:,} bootstrap resamples for pooled metrics; "
                        f"{cfg['statistics']['permutations']:,} label permutations"],
        ["Antecedent software", f"{rmr['rapidminer_source']}; {rmr['rapidminer_validation']}"],
        ["Data", "UCI Machine Learning Repository dataset 544 (DOI 10.24432/C5H31Z), CC BY 4.0"],
        ["Entry point", "python run_all.py (stages 01-15)"]]
add("A13", "Computational Environment and Reproducibility Record", ["Item", "Specification"], rows,
    "Every number in the tables and figures is regenerated by the stage scripts from the raw data with these settings.", section="appendix")

rows, groups = [], []
for label, key in (("S1 Antecedent rule", "S1_discrete_rule"), ("S2 Deduplicated", "S2_deduplicated"), ("S4 Class-weighted", "S4_class_weighted")):
    for a in ("C", "D") if key != "S2_deduplicated" else ARMS:
        groups.append(len(rows))
        rr = [r for r in sens[key] if r["arm"] == a]
        for i, r in enumerate(rr):
            rows.append([f"{label}, Arm {a} (n = {r['n_records']})" if i == 0 else "", SHORT[r["classifier"]],
                         ci(r["accuracy"], r["accuracy_lo"], r["accuracy_hi"]), ci(r["balanced_accuracy"], r["balanced_accuracy_lo"], r["balanced_accuracy_hi"]),
                         f3(r["kappa"]), f3(r["auc_macro"])])
add("A14", "Sensitivity Analyses S1, S2 and S4 in Full",
    ["Analysis", "Learner", "Accuracy (%) [95% CI]", "Balanced accuracy (%) [95% CI]", "κ", "Macro AUC"], rows,
    "10 × 10 stratified cross-validation with the primary settings unless stated. S4 sets class weights inversely proportional to class frequency.",
    section="appendix", landscape=True, group_rows=groups)

save_json("display_tables", TABLES)
out = cfg["paths"]["tables"] / "display"
out.mkdir(exist_ok=True)
for t in TABLES:
    pd.DataFrame(t["rows"], columns=t["columns"]).to_csv(out / f"{t['id']}.csv", index=False)
print(f"{len(TABLES)} display tables:", [t["id"] for t in TABLES])
