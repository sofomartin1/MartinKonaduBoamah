"""Stage 9 - learning curves: performance on fixed held-out folds as the training fold is
subsampled (stratified) to a fraction of its size. A flat curve on authentic records says
that more records of the same kind would not rescue behaviour-only prediction."""
import _common  # noqa: F401
import warnings

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.model_selection import train_test_split

from obaudit.config import load_config
from obaudit.cv import splits
from obaudit.data import arm_data, feature_columns, load_dataset
from obaudit.metrics import fold_metrics
from obaudit.models import make_model
from obaudit.store import save_json, save_table

cfg = load_config()
SEED = cfg["study"]["seed"]
FR = cfg["sensitivity"]["learning_curve_fractions"]
REP = cfg["sensitivity"]["learning_curve_repeats"]
df = load_dataset()


def job(name, X, y, num, nom, tr, te, frac, r):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if frac < 1.0:
            try:
                tr, _ = train_test_split(tr, train_size=frac, stratify=y[tr], random_state=SEED + r)
            except ValueError:  # a class too small to stratify at this fraction
                tr, _ = train_test_split(tr, train_size=frac, random_state=SEED + r)
        m = make_model(name, num, nom)
        m.fit(X.iloc[tr], y[tr])
        res = fold_metrics(y[te], np.asarray(m.predict(X.iloc[te])))
    res["n_train"] = len(tr)
    return res


rows = []
for arm in cfg["arms"]:
    X, y, _ = arm_data(df, arm)
    num, nom = feature_columns(cfg["arms"][arm]["attributes"])
    sp = splits(y, n_repeats=REP)
    for name in ("LR", "DT", "RF", "MAJ"):
        for frac in FR:
            res = Parallel(n_jobs=cfg["cv"]["n_jobs"])(
                delayed(job)(name, X, y, num, nom, tr, te, frac, r) for (r, f, tr, te) in sp)
            R = pd.DataFrame(res)
            row = {"arm": arm, "classifier": name, "fraction": frac, "n_train_mean": R.n_train.mean()}
            for met in ("accuracy", "balanced_accuracy", "kappa"):
                row[met + "_mean"] = R[met].mean()
                row[met + "_sd"] = R[met].std(ddof=1)
            rows.append(row)
        print(arm, name, "done", flush=True)
tab = pd.DataFrame(rows)
save_table("learning_curves", tab)
save_json("learning_curves", tab.to_dict(orient="records"))
