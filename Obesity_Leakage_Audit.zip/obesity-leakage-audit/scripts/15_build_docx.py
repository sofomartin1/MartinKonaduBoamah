"""Stage 15 - assemble every display table and figure into one Word document.

Formatting: Times New Roman; table text 9 pt; table and figure labels bold 9 pt, titles regular
9 pt; notes 8 pt italic with 'Note.' bold italic; APA three-line tables (rule above and below the
header, rule below the last row, no vertical rules); header rows repeat across pages; wide
tables in landscape sections."""
import _common  # noqa: F401
import re
import sys

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from obaudit.config import load_config
from obaudit.store import load_json

cfg = load_config()
FIG = cfg["paths"]["figures"]
T = {t["id"]: t for t in load_json("display_tables")}
FD = load_json("figure_data")
audit = load_json("data_audit")
prov = load_json("provenance_validation")
est = load_json("estimates")
perm = load_json("permutation")
FONT = "Times New Roman"


def pf(p):
    return "p < .001" if p < 0.001 else f"p = {p:.3f}".replace("0.", ".", 1)


# ------------------------------------------------------------------- figure captions
def P(arm, c, s):
    return next(r for r in perm["summary"] if r["arm"] == arm and r["classifier"] == c and r["statistic"] == s)


FIGS = [
    ("1", "fig01_workflow.png", "Study Workflow From Provenance Audit to Leakage-Controlled Evaluation",
     f"The two audits run before any model is fitted. Arm sizes: A and B n = {audit['n_records']:,}; C and D n = {audit['n_authentic']}.", "main", 16.5),
    ("2", "fig02_label_provenance.png", "The Published Label Is a Function of Height and Weight",
     f"(a) BMI of every record by published class; dashed lines are the cut-points {', '.join(f'{c:g}' for c in cfg['data']['bmi_cutpoints'])} kg/m². "
     f"(b) Cut-points applied to Weight/Height² against the published label; cell values are counts and shading is the row percentage. "
     f"The rule reproduces {audit['bmi_rule_agreement_pct']:.2f}% of labels ({audit['bmi_rule_agreement_authentic_pct']:.2f}% of authentic and "
     f"{audit['bmi_rule_agreement_synthetic_pct']:.2f}% of synthetic records), and every disagreement falls in an adjacent class.", "main", 16.5),
    ("3", "fig03_record_provenance.png", "Record Provenance Recovered From the Structure of the Distributed File",
     f"(a) Class of each record against its row position: rows 1-{audit['n_authentic']} interleave all seven classes, and rows {audit['n_authentic'] + 1}-{audit['n_records']:,} "
     f"form class-sorted runs with no Normal Weight run. (b) Authentic / synthetic counts by class. (c) Class shares in the distributed file and among authentic records.",
     "main", 16.5),
    ("4", "fig04_provenance_geometry.png", "Geometric Signatures of Synthetic Oversampling",
     f"(a) Height and weight of Obesity Type II and III records: large markers are authentic, small markers synthetic, dashed rectangles the authentic bounding boxes; "
     f"{prov['box_containment_total']['in_own_box']:,} of {prov['box_containment_total']['n_synthetic']:,} synthetic records lie inside the box of their class. "
     f"(b) Share of values off the survey scale (integers; height to 0.01 m; weight to 0.1 kg). (c) Cumulative distribution of distance to the nearest other record "
     "in the scaled, encoded attribute space (log scale).", "main", 16.5),
    ("5", "fig05_performance.png", "Cross-Validated Performance of Eight Learners in the Four Arms",
     "Points are means over 10 × 10 stratified cross-validation folds; bars are corrected resampled-t 95% CIs. Dotted lines are the majority-class baseline in the arm of the same colour "
     f"(accuracy {100 * est['A']['MAJ']['accuracy']['mean']:.2f}% in Arms A and B and {100 * est['C']['MAJ']['accuracy']['mean']:.2f}% in Arms C and D).", "main", 15.5),
    ("6", "fig06_decomposition.png", "Performance Attributable to the Circular Label, the Synthetic Records and Their Interaction",
     "Percentage-point loss when a defect is removed, with 95% CIs. A − B is paired on identical folds; A − C and A − D combine the corrected variances of two record sets; "
     "the interaction contrasts the label effect on full and authentic records.", "main", 16.5),
    ("7", "fig07_permutation_D.png", "Label-Permutation Tests in Arm D (Authentic Records, Behaviour-Only Attributes)",
     f"Histograms show {cfg['statistics']['permutations']:,} cross-validated statistics under randomly permuted labels; vertical lines are the observed values on one stratified "
     f"10-fold partition. Balanced accuracy: NB {pf(P('D', 'NB', 'balanced_accuracy')['p'])}, LR {pf(P('D', 'LR', 'balanced_accuracy')['p'])}, "
     f"DT {pf(P('D', 'DT', 'balanced_accuracy')['p'])}, BT {pf(P('D', 'BT', 'balanced_accuracy')['p'])}.", "main", 16.5),
    ("8", "fig08_provenance_aware.png", "Balanced Accuracy on Authentic Records Under Six Training Regimes",
     "Bars are means with 95% CIs, all scored on authentic test records; hatched bars are anchor-purged regimes, which drop every synthetic record whose nearest same-class "
     "authentic record is in the test fold. The dotted line is the majority-class baseline. Random cross-validation on the full file lets synthetic "
     "siblings of a test record sit in the training fold.", "main", 16.0),
    ("9", "fig09_per_class_recall.png", "Per-Class Recall by Arm and Learner",
     "Recall (%) from confusion matrices summed over 10 repetitions; n is the number of records of the class in the arm.", "main", 16.5),
    ("10", "fig10_importance.png", "Held-Out Permutation Importance of the Random Forest",
     "Mean drop in balanced accuracy (percentage points) when an attribute is permuted in the test fold, with 95% CIs over 10 folds; the eight most important attributes per arm. "
     "Red bars mark Height and Weight.", "main", 16.5),
    ("11", "fig11_calibration.png", "Reliability of Top-Label Confidence",
     "Observed accuracy against mean predicted confidence in 10 equal-width bins, pooled over repetitions. ECE = expected calibration error. The dashed diagonal is perfect calibration.",
     "main", 16.5),
    ("12", "fig12_learning_curves.png", "Learning Curves on Fixed Test Folds",
     "Balanced accuracy as the training fold is subsampled from 10% to 100% (3 × 10-fold cross-validation); shaded bands are ±1 SD across folds.", "main", 16.5),
    ("13", "fig13_context.png", "Published Accuracies on the Benchmark Against This Study's Arms",
     "Diamonds are published values as reported by their authors; circles are the best learner in each arm of this study. Letters in brackets give the arm whose setting "
     "the published study matches. The dotted line is the majority-class accuracy on authentic records.", "main", 16.5),
    ("A1", "figA1_confusion.png", "Row-Normalised Confusion Matrices for the Bagged Tree and Logistic Regression",
     "Percentages of each true class assigned to each predicted class, summed over 10 repetitions; cells below 0.5% are blank.", "appendix", 16.5),
    ("A2", "figA2_fold_distributions.png", "Fold-Level Distributions of Balanced Accuracy",
     "Boxes span the interquartile range of the 100 fold values; whiskers extend to 1.5 × IQR; outliers are omitted.", "appendix", 16.5),
    ("A3", "figA3_attribute_distributions.png", "Distributions of Numeric Attributes by Provenance",
     "Density-normalised histograms over 30 equal-width bins. Authentic values concentrate on the survey scale; synthetic values fill the gaps between levels.", "appendix", 16.5),
    ("A4", "figA4_rf_max_features.png", "Random-Forest Accuracy Across Feature-Subsampling Settings",
     "Means and 95% CIs over 10 × 10 cross-validation; max_features = 1.0 is equivalent to bagged trees.", "appendix", 11.0),
    ("A5", "figA5_sensitivity.png", "Balanced Accuracy on Authentic Records Across Sensitivity Analyses",
     "Primary analysis with S1 (antecedent provenance rule), S2 (duplicates removed), S4 (class weights) and S6 (nested tuning; 95% CI from 10 outer folds). "
     "Dotted lines are the majority-class baseline.", "appendix", 16.5),
    ("A6", "figA6_outcomes.png", "Balanced Accuracy for Coarser Outcome Definitions on Authentic Records",
     "Means and 95% CIs; dotted lines are majority-class baselines for Arm C (orange) and Arm D (pink).", "appendix", 16.5),
    ("A7", "figA7_rapidminer.png", "Agreement Between the Antecedent RapidMiner 7.1 Results and the Python Re-Estimation",
     "Each point is one arm-learner cell; the dashed line is equality. Arms C and D compare like with like on the 496 records of the antecedent rule.", "appendix", 14.5),
    ("A8", "figA8_pairwise.png", "Pairwise Differences in Balanced Accuracy on Authentic Records",
     "Cell values are row minus column (percentage points); * Holm-adjusted p < .05 over 28 comparisons per arm (paired corrected resampled t).", "appendix", 16.5),
    ("A9", "figA9_permutation_C.png", "Label-Permutation Tests in Arm C (Authentic Records, All Attributes)",
     f"As for Figure 7, with Height and Weight available. Balanced accuracy: NB {pf(P('C', 'NB', 'balanced_accuracy')['p'])}, LR {pf(P('C', 'LR', 'balanced_accuracy')['p'])}, "
     f"DT {pf(P('C', 'DT', 'balanced_accuracy')['p'])}, BT {pf(P('C', 'BT', 'balanced_accuracy')['p'])}.", "appendix", 16.5),
]

PLACEMENT = {
    "T1": "Methods: dataset", "T2": "Results: provenance audit", "T3": "Results: provenance audit", "T4": "Methods: experimental design",
    "T5": "Methods: learners", "T6": "Results: principal performance", "T7": "Results: principal performance", "T8": "Results: defect decomposition",
    "T9": "Results: chance and baseline tests", "T10": "Results: provenance-aware evaluation", "T11": "Results: calibration",
    "T12": "Discussion: relation to published results", "T13": "Results: robustness",
    "1": "Methods: overview", "2": "Results: label provenance", "3": "Results: record provenance", "4": "Results: record provenance",
    "5": "Results: principal performance", "6": "Results: defect decomposition", "7": "Results: chance tests", "8": "Results: provenance-aware evaluation",
    "9": "Results: per-class behaviour", "10": "Results: attribute importance", "11": "Results: calibration", "12": "Results: sample size",
    "13": "Discussion: relation to published results",
}


# --------------------------------------------------------------------- docx helpers
def set_cell_border(cell, **kw):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = tcPr.find(qn("w:tcBorders"))
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tcPr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = borders.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            borders.append(el)
        val = kw.get(edge)
        if val:
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), str(val))
            el.set(qn("w:space"), "0")
            el.set(qn("w:color"), "000000")
        else:
            el.set(qn("w:val"), "nil")


def cell_margins(table, top=30, bottom=30, left=60, right=60):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        e = OxmlElement(f"w:{k}")
        e.set(qn("w:w"), str(v))
        e.set(qn("w:type"), "dxa")
        mar.append(e)
    tblPr.append(mar)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    h = OxmlElement("w:tblHeader")
    h.set(qn("w:val"), "true")
    trPr.append(h)


def no_split(row):
    trPr = row._tr.get_or_add_trPr()
    c = OxmlElement("w:cantSplit")
    c.set(qn("w:val"), "true")
    trPr.append(c)


def run(p, text, size, bold=False, italic=False):
    r = p.add_run(text)
    r.font.name = FONT
    r._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    r.font.size = Pt(size)
    r.bold = bold
    r.italic = italic
    r.font.color.rgb = RGBColor(0, 0, 0)
    return r


def para(doc_or_cell, space_before=0, space_after=0, align=None, keep=False):
    p = doc_or_cell.add_paragraph()
    pf_ = p.paragraph_format
    pf_.space_before = Pt(space_before)
    pf_.space_after = Pt(space_after)
    pf_.line_spacing = 1.0
    if align:
        p.alignment = align
    if keep:
        pf_.keep_with_next = True
    return p


def new_section(doc, landscape):
    sec = doc.add_section()
    if landscape:
        sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width, sec.page_height = Cm(29.7), Cm(21.0)
    else:
        sec.orientation = WD_ORIENT.PORTRAIT
        sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    for m in ("left_margin", "right_margin"):
        setattr(sec, m, Cm(2.0))
    sec.top_margin = sec.bottom_margin = Cm(2.0)
    return sec


def label_for(tid):
    return f"Table {tid[1:]}" if tid.startswith("T") else f"Table {tid}"


def add_table(doc, t, label=None):
    p = para(doc, 6, 0, keep=True)
    run(p, label or label_for(t["id"]), 9, bold=True)
    p = para(doc, 0, 3, keep=True)
    run(p, t["title"], 9)
    cols, rows = t["columns"], t["rows"]
    tab = doc.add_table(rows=1 + len(rows), cols=len(cols))
    tab.alignment = WD_TABLE_ALIGNMENT.CENTER
    tab.autofit = True
    cell_margins(tab)
    groups = set(t.get("group_rows", []))
    for j, c in enumerate(cols):
        cell = tab.rows[0].cells[j]
        cell.text = ""
        pp = cell.paragraphs[0]
        pp.paragraph_format.space_after = Pt(0)
        run(pp, c, 9, bold=False)
        set_cell_border(cell, top=8, bottom=6)
    repeat_header(tab.rows[0])
    for i, r in enumerate(rows):
        row = tab.rows[i + 1]
        no_split(row)
        last = i == len(rows) - 1
        for j, v in enumerate(r):
            cell = row.cells[j]
            cell.text = ""
            pp = cell.paragraphs[0]
            pp.paragraph_format.space_after = Pt(0)
            pp.paragraph_format.space_before = Pt(2 if (i in groups and i > 0) else 0)
            v = re.sub(r"(?<![\w.])-(?=\d)", "\u2212", str(v))
            run(pp, v, 9)
            if j >= 1 and re.fullmatch(r"[\u2212\-+<>=\d.,\s\[\]()/%*pn]+|[A-Za-z]{1,3}(kNN)? \d+\.\d+|-", v):
                pp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_cell_border(cell, bottom=8 if last else None)
    p = para(doc, 3, 8)
    run(p, "Note. ", 8, bold=True, italic=True)
    run(p, t["note"], 8, italic=True)


def add_figure(doc, fid, fname, title, note, width_cm):
    p = para(doc, 6, 0, align=WD_ALIGN_PARAGRAPH.CENTER, keep=True)
    p.add_run().add_picture(str(FIG / fname), width=Cm(width_cm))
    p = para(doc, 3, 0, keep=True)
    run(p, f"Figure {fid}", 9, bold=True)
    p = para(doc, 0, 0, keep=True)
    run(p, title, 9)
    p = para(doc, 2, 8)
    run(p, "Note. ", 8, bold=True, italic=True)
    run(p, note, 8, italic=True)


# --------------------------------------------------------------------------- build
doc = Document()
st = doc.styles["Normal"]
st.font.name = FONT
st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
st.font.size = Pt(10)
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
    setattr(sec, m, Cm(2.0))

p = para(doc, 0, 6, align=WD_ALIGN_PARAGRAPH.CENTER)
run(p, cfg["study"]["title"], 10, bold=True)
p = para(doc, 0, 10, align=WD_ALIGN_PARAGRAPH.CENTER)
run(p, "Tables and Figures", 10, bold=True)

# display plan
plan_rows = []
for tid in [k for k in T if k.startswith("T")]:
    plan_rows.append([label_for(tid), T[tid]["title"], PLACEMENT.get(tid, "")])
for f in FIGS:
    if f[4] == "main":
        plan_rows.append([f"Figure {f[0]}", f[2], PLACEMENT.get(f[0], "")])
plan_rows.append(["Tables A1-A14, Figures A1-A9", "Supplementary displays", "Appendix"])
add_table(doc, {"id": "Plan", "title": "Tables and Figures in Suggested Order of Citation", "columns": ["Display", "Title", "Manuscript location"],
                "rows": plan_rows, "group_rows": [],
                "note": "Main-text displays in suggested order of first citation; appendix displays follow in the order they should be cited."},
          label="Display Plan")

order_main = [("T", "T1"), ("F", "1"), ("T", "T2"), ("T", "T3"), ("F", "2"), ("F", "3"), ("F", "4"), ("T", "T4"), ("T", "T5"),
              ("T", "T6"), ("T", "T7"), ("F", "5"), ("T", "T8"), ("F", "6"), ("T", "T9"), ("F", "7"), ("T", "T10"), ("F", "8"),
              ("F", "9"), ("F", "10"), ("T", "T11"), ("F", "11"), ("F", "12"), ("T", "T13"), ("T", "T12"), ("F", "13")]
order_app = [("T", f"A{i}") for i in range(1, 15)] + [("F", f"A{i}") for i in range(1, 10)]
FIGMAP = {f[0]: f for f in FIGS}
landscape_now = False
for kind, key in order_main + order_app:
    if kind == "T":
        t = T[key]
        want = bool(t["landscape"])
        new_section(doc, want)
        add_table(doc, t)
    else:
        f = FIGMAP[key]
        new_section(doc, False)
        add_figure(doc, f[0], f[1], f[2], f[3], f[5])

missing = set(T) - {k for _, k in order_main + order_app}
if missing:
    sys.exit(f"tables not placed: {missing}")
out = cfg["paths"]["results"] / "Obesity_Leakage_Audit_Tables_and_Figures.docx"
doc.save(out)
print("wrote", out)

# ------------------------------------------------ verify the saved document itself
chk = Document(out)
doc_tables = chk.tables[1:]                      # first table is the display plan
expected = [T[k] for kind, k in order_main + order_app if kind == "T"]
problems = []
if len(doc_tables) != len(expected):
    problems.append(f"{len(doc_tables)} tables in document, {len(expected)} expected")
for dt, t in zip(doc_tables, expected):
    rows = [[c.text for c in r.cells] for r in dt.rows]
    if rows[0] != t["columns"]:
        problems.append(f"{t['id']}: header differs")
    for r_doc, r_src in zip(rows[1:], t["rows"]):
        src = [re.sub(r"(?<![\w.])-(?=\d)", "−", str(v)) for v in r_src]
        if r_doc != src:
            problems.append(f"{t['id']}: row differs {r_src[:2]}")
    if len(rows) - 1 != len(t["rows"]):
        problems.append(f"{t['id']}: row count")
n_pics = len(chk.inline_shapes)
if n_pics != len(FIGS):
    problems.append(f"{n_pics} figures embedded, {len(FIGS)} expected")
captions = [p.text for p in chk.paragraphs if re.fullmatch(r"(Table|Figure) A?\d+", p.text)]
if len(captions) != len(expected) + len(FIGS) or len(set(captions)) != len(captions):
    problems.append("caption labels missing or duplicated")
if problems:
    sys.exit("document verification failed: " + "; ".join(problems[:10]))
print(f"document verified: {len(expected)} tables cell-for-cell, {n_pics} figures, {len(captions)} unique captions")
