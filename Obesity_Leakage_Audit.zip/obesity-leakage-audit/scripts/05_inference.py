"""Stage 5 - inference: defect decomposition, comparison with the majority-class baseline,
and pairwise classifier comparisons within each arm."""
import _common  # noqa: F401
import itertools

import numpy as np
import pandas as pd

from obaudit.config import load_config
from obaudit.stats import (combined_diff, corrected_ci, corrected_paired_test, holm,
                           independent_diff)
from obaudit.store import load_folds, run_key, save_json, save_table

cfg = load_config()
LEARNERS = cfg["classifiers"]["primary"] + cfg["classifiers"]["extended"]
METRICS = ["accuracy", "balanced_accuracy", "kappa", "macro_f1"]


def F(arm, m):
    return load_folds(run_key(arm, m))


def ratio(f):
    return float((f.n_test / f.n_train).mean())


# ------------------------------------------------------------------ defect decomposition
rows = []
for clf in LEARNERS:
    fa, fb, fc, fd = (F(a, clf) for a in "ABCD")
    for met in METRICS:
        ab = corrected_paired_test(fa[met], fb[met], ratio(fa))
        cd = corrected_paired_test(fc[met], fd[met], ratio(fc))
        ac = independent_diff(fa[met], ratio(fa), fc[met], ratio(fc))
        bd = independent_diff(fb[met], ratio(fb), fd[met], ratio(fd))
        ad = independent_diff(fa[met], ratio(fa), fd[met], ratio(fd))
        inter = combined_diff([(1, ab), (-1, cd)])
        for name, r in (("label_full", ab), ("label_authentic", cd), ("synthetic_all", ac),
                        ("synthetic_behaviour", bd), ("both", ad), ("interaction", inter)):
            rows.append({"classifier": clf, "metric": met, "contrast": name, **r})
dec = pd.DataFrame(rows)
dec["p_holm"] = np.nan
for met in METRICS:
    m = dec.metric == met
    dec.loc[m, "p_holm"] = holm(dec.loc[m, "p"].to_numpy())
save_table("decomposition", dec)

# ------------------------------------------------------------- versus majority baseline
rows = []
for arm in cfg["arms"]:
    fm = F(arm, "MAJ")
    for clf in LEARNERS:
        f = F(arm, clf)
        for met in ("accuracy", "balanced_accuracy"):
            r = corrected_paired_test(f[met], fm[met], ratio(f))
            rows.append({"arm": arm, "classifier": clf, "metric": met, **r})
        mean, lo, hi, se = corrected_ci(f["kappa"].to_numpy(), ratio(f))
        from scipy import stats
        t = mean / se
        rows.append({"arm": arm, "classifier": clf, "metric": "kappa", "diff": mean, "lo": lo, "hi": hi,
                     "se": se, "t": t, "p": 2 * stats.t.sf(abs(t), len(f) - 1)})
vm = pd.DataFrame(rows)
vm["p_holm"] = np.nan
for (arm, met), g in vm.groupby(["arm", "metric"]):
    vm.loc[g.index, "p_holm"] = holm(g.p.to_numpy())
save_table("vs_majority", vm)

# -------------------------------------------------------------- pairwise within each arm
rows = []
for arm in cfg["arms"]:
    folds = {c: F(arm, c) for c in LEARNERS}
    for a, b in itertools.combinations(LEARNERS, 2):
        for met in ("balanced_accuracy", "accuracy"):
            r = corrected_paired_test(folds[a][met], folds[b][met], ratio(folds[a]))
            rows.append({"arm": arm, "a": a, "b": b, "metric": met, **r})
pw = pd.DataFrame(rows)
pw["p_holm"] = np.nan
for (arm, met), g in pw.groupby(["arm", "metric"]):
    pw.loc[g.index, "p_holm"] = holm(g.p.to_numpy())
save_table("pairwise", pw)

save_json("inference", {"decomposition": dec.to_dict(orient="records"),
                        "vs_majority": vm.to_dict(orient="records"),
                        "pairwise": pw.to_dict(orient="records")})
show = dec[(dec.metric == "accuracy")].pivot(index="classifier", columns="contrast", values="diff") * 100
print(show.round(2).to_string())
print(vm[(vm.arm.isin(["C", "D"])) & (vm.metric != "kappa")].round(4).to_string())
