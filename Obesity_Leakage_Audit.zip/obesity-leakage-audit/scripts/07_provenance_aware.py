"""Stage 7 - provenance-aware evaluation: how well do models trained on the distributed file
predict *authentic* records?

Every scheme is scored on the same authentic test folds as arms C and D (identical labels and
seed give identical partitions), so all comparisons with C and D are paired.
  synth_plus : training = authentic training fold + all synthetic records
  synth_only : training = synthetic records only (one fit per repetition)
  synth_plus_purged / synth_only_purged : as above, but every synthetic record whose nearest
      same-class authentic record (its anchor) lies in the test fold is removed from training,
      so no oversampled descendant of a test record can inform its prediction
  (authentic-only training is arm C / arm D itself; random CV on the full file scored on
   authentic test records is taken from the stage-3 subgroup output)
"""
import _common  # noqa: F401
import warnings

import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from obaudit.config import load_config
from obaudit.cv import splits
from obaudit.data import feature_columns, label_codes, load_dataset, provenance
from obaudit.metrics import fold_metrics
from obaudit.models import make_model
from obaudit.stats import corrected_ci, corrected_paired_test
from obaudit.store import load_folds, load_subgroups, run_key, save_json, save_table

cfg = load_config()
df = load_dataset()
y_all = label_codes(df[cfg["data"]["label"]])
auth = provenance(df, "file_order")
ia, isyn = np.where(auth)[0], np.where(~auth)[0]
LEARNERS = ["MAJ"] + cfg["classifiers"]["primary"] + cfg["classifiers"]["extended"]

# anchor of each synthetic record: nearest same-class authentic record in the range-scaled,
# one-hot-encoded space of all attributes (fold-independent, label-defined, no model fitting)
from sklearn.compose import ColumnTransformer
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
_pre = ColumnTransformer([("n", MinMaxScaler(), cfg["data"]["numeric"]),
                          ("c", OneHotEncoder(sparse_output=False), cfg["data"]["nominal"])])
_Z = _pre.fit_transform(df)
anchor = np.full(len(df), -1)
for k in np.unique(y_all):
    a_k = ia[y_all[ia] == k]
    s_k = isyn[y_all[isyn] == k]
    if len(s_k):
        nn = NearestNeighbors(n_neighbors=1).fit(_Z[a_k])
        anchor[s_k] = a_k[nn.kneighbors(_Z[s_k])[1][:, 0]]
pos_in_auth = {g: i for i, g in enumerate(ia)}
anchor_pos = np.array([pos_in_auth.get(g, -1) for g in anchor[isyn]])   # anchor as index into ia


def fold_job(name, X, scheme, tr, te):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        num, nom = X.attrs["num"], X.attrs["nom"]
        keep = np.ones(len(isyn), bool)
        if scheme.endswith("_purged"):
            keep = ~np.isin(anchor_pos, te)
        syn = isyn[keep]
        train = np.r_[ia[tr], syn] if scheme.startswith("synth_plus") else syn
        m = make_model(name, num, nom)
        m.fit(X.iloc[train], y_all[train])
        pred = np.asarray(m.predict(X.iloc[ia[te]]))
    return fold_metrics(y_all[ia[te]], pred)


rows = []
sp = splits(y_all[ia])
for attrs, arm_auth, arm_full in (("all", "C", "A"), ("behaviour", "D", "B")):
    num, nom = feature_columns(attrs)
    X = df[num + nom].copy()
    X.attrs["num"], X.attrs["nom"] = num, nom
    for name in LEARNERS:
        for scheme in ("synth_plus", "synth_only", "synth_plus_purged", "synth_only_purged"):
            if scheme == "synth_only":
                # training set does not depend on the fold: fit once, score every fold
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    m = make_model(name, num, nom)
                    m.fit(X.iloc[isyn], y_all[isyn])
                    pred_all = np.asarray(m.predict(X.iloc[ia]))
                recs = [fold_metrics(y_all[ia[te]], pred_all[te]) for (_, _, tr, te) in sp]
            else:
                recs = Parallel(n_jobs=cfg["cv"]["n_jobs"])(
                    delayed(fold_job)(name, X, scheme, tr, te) for (_, _, tr, te) in sp)
            f = pd.DataFrame(recs)
            ref = load_folds(run_key(arm_auth, name))
            r = float((ref.n_test / ref.n_train).mean())
            for met in ("accuracy", "balanced_accuracy", "kappa", "macro_f1"):
                mean, lo, hi, _ = corrected_ci(f[met].to_numpy(), r)
                d = corrected_paired_test(f[met].to_numpy(), ref[met].to_numpy(), r)
                rows.append({"attributes": attrs, "classifier": name, "scheme": scheme, "metric": met,
                             "mean": mean, "lo": lo, "hi": hi,
                             "diff_vs_authentic_only": d["diff"], "diff_lo": d["lo"], "diff_hi": d["hi"],
                             "p": d["p"]})
        # reference rows: authentic-only (arm C/D) and random full-file CV scored on authentic records
        ref = load_folds(run_key(arm_auth, name))
        r = float((ref.n_test / ref.n_train).mean())
        sg = load_subgroups(run_key(arm_full, name))
        sga = sg[sg.subgroup == "authentic"]
        for met in ("accuracy", "balanced_accuracy", "kappa", "macro_f1"):
            mean, lo, hi, _ = corrected_ci(ref[met].to_numpy(), r)
            rows.append({"attributes": attrs, "classifier": name, "scheme": "authentic_only", "metric": met,
                         "mean": mean, "lo": lo, "hi": hi})
            mean, lo, hi, _ = corrected_ci(sga[met].to_numpy(), 1 / 9)
            rows.append({"attributes": attrs, "classifier": name, "scheme": "random_cv_full_scored_authentic",
                         "metric": met, "mean": mean, "lo": lo, "hi": hi})
        print(attrs, name, "done", flush=True)
tab = pd.DataFrame(rows)
save_table("provenance_aware", tab)
save_json("provenance_aware", tab.to_dict(orient="records"))
print(tab[tab.metric == "balanced_accuracy"].pivot_table(index=["attributes", "classifier"], columns="scheme",
                                                          values="mean").round(3).to_string())
save_json("synthetic_anchors", {"n_synthetic": int(len(isyn)),
                                "anchors_per_authentic": np.bincount(anchor_pos, minlength=len(ia)).tolist()})
