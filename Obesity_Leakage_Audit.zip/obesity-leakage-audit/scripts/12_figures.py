"""Stage 12 - all figures (colour, 300 dpi PNG). Every plotted number is also written to
results/figure_data.json so that the consistency gate can check figures against tables."""
import _common  # noqa: F401

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch, Rectangle

from obaudit.config import load_config
from obaudit.data import bmi, label_codes, load_dataset, provenance
from obaudit.figstyle import (ARM_COLORS, ARM_SHORT, CLASS_COLORS, CLASS_SHORT, CLF_COLORS,
                              PROV_COLORS, SCHEME_COLORS, panel_label, save, setup)
from obaudit.models import SHORT
from obaudit.store import load_json, save_json

setup()
cfg = load_config()
FIG = cfg["paths"]["figures"]
CL = cfg["data"]["classes"]
LEARN = cfg["classifiers"]["primary"] + cfg["classifiers"]["extended"]
ARMS = list(cfg["arms"])
df = load_dataset()
y = label_codes(df[cfg["data"]["label"]])
auth = provenance(df, "file_order")
B = bmi(df).to_numpy()
audit = load_json("data_audit")
prov = load_json("provenance_validation")
est = load_json("estimates")
inf = load_json("inference")
perm = load_json("permutation")
pa = load_json("provenance_aware")
imp = load_json("importance")
lc = load_json("learning_curves")
sens = load_json("sensitivity")
rmr = load_json("rapidminer_reconciliation")
FD = {}


def E(arm, m, met, k="mean"):
    return est[arm][m][met][k]


# ------------------------------------------------------------------ Figure 1: workflow
def fig_workflow():
    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    ax.set_axis_off()
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 74)

    def box(x, y_, w, h, text, fc, ec="#333333", fs=7.0, bold_first=True):
        ax.add_patch(FancyBboxPatch((x, y_), w, h, boxstyle="round,pad=0.3,rounding_size=1.0", fc=fc, ec=ec, lw=0.9))
        lines = text.split("\n")
        n_ = len(lines)
        for i, ln in enumerate(lines):
            ax.text(x + w / 2, y_ + h / 2 + (n_ - 1) * 1.55 - i * 3.1, ln, ha="center", va="center", fontsize=fs,
                    fontweight="bold" if (bold_first and i == 0) else "normal")

    def arrow(x1, y1, x2, y2):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="-|>", color="#444444", lw=0.9, shrinkA=0, shrinkB=0))

    n, na, ns = audit["n_records"], audit["n_authentic"], audit["n_synthetic"]
    box(2, 57, 26, 15, f"UCI benchmark\nEstimation of Obesity Levels\n{n:,} records\n16 attributes, 7 classes", "#EAF2FB")
    box(36, 64.5, 62, 7.5, f"Label-provenance audit\nBMI cut-points on Height and Weight reproduce {audit['bmi_rule_agreement_pct']:.2f}% of labels", "#FDF0E6")
    box(36, 54, 62, 8.5, f"Record-provenance audit\nfile structure, value discreteness, bounding boxes, nearest neighbours\n{na} authentic / {ns:,} synthetic records", "#E8F6F0")
    arrow(28.5, 66.5, 35.5, 68)
    arrow(28.5, 62, 35.5, 58.5)
    xs = [2, 26.5, 51, 75.5]
    texts = {"A": "All records\nall 16 attributes", "B": "All records\nbehaviour only", "C": "Authentic records\nall 16 attributes",
             "D": "Authentic records\nbehaviour only"}
    ax.plot([13, 86.5], [49, 49], color="#444444", lw=0.9)
    arrow(67, 53.6, 67, 49)
    for x, a in zip(xs, ARMS):
        box(x, 33, 22.5, 12, f"Arm {a}\n{texts[a]}\nn = {est[a]['MAJ']['n_records']:,}", ARM_COLORS[a] + "33", ec=ARM_COLORS[a])
        arrow(x + 11.25, 49, x + 11.25, 45.6)
        arrow(x + 11.25, 32.6, x + 11.25, 27.6)
    box(2, 17, 96, 10, "Leakage-controlled evaluation\n10 \u00d7 10 repeated stratified cross-validation (seed 2001); encoding and scaling fitted inside training folds\n"
        "8 learners, majority and prior baselines, BMI leakage probes", "#F3F3F3")
    arrow(50, 16.6, 50, 13.4)
    box(2, 1, 96, 12, "Analyses\ndefect decomposition; majority-class and label-permutation tests; provenance-aware training regimes\n"
        "calibration; permutation importance; learning curves; sensitivity analyses S1-S6\nreconciliation with RapidMiner 7.1; comparison with published results", "#F3F3F3")
    save(fig, FIG / "fig01_workflow.png")
    FD["fig01"] = {"n": n, "authentic": na, "synthetic": ns, "bmi_agree": audit["bmi_rule_agreement_pct"],
                   "arm_n": {a: est[a]["MAJ"]["n_records"] for a in ARMS}}


# --------------------------------------------------------- Figure 2: label provenance
def fig_label():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.1), gridspec_kw={"width_ratios": [1.35, 1]})
    ax = axs[0]
    rng = np.random.default_rng(1)
    for k in range(7):
        for prov_name, m in (("synthetic", ~auth), ("authentic", auth)):
            sel = (y == k) & m
            if sel.any():
                ax.scatter(k + rng.uniform(-0.28, 0.28, sel.sum()), B[sel], s=3.5, alpha=0.55 if prov_name == "synthetic" else 0.9,
                           color=PROV_COLORS[prov_name], lw=0, label=prov_name.capitalize() if k == 6 or (k == 1 and prov_name == "authentic") else None)
    for c in cfg["data"]["bmi_cutpoints"]:
        ax.axhline(c, color="#555555", ls="--", lw=0.7)
        ax.text(6.62, c, f"{c:g}", fontsize=6.5, va="center", color="#555555")
    ax.set_xticks(range(7), CLASS_SHORT)
    ax.set_ylabel("Body mass index (kg/m$^2$)")
    ax.set_xlim(-0.6, 6.95)
    h, l = ax.get_legend_handles_labels()
    ax.legend(h[:2], l[:2], loc="upper left", markerscale=3)
    panel_label(ax, "a")
    ax = axs[1]
    C = np.array(audit["bmi_rule_confusion"], float)
    Cn = C / C.sum(1, keepdims=True)
    im = ax.imshow(Cn * 100, cmap="Blues", vmin=0, vmax=100)
    for i in range(7):
        for j in range(7):
            if C[i, j] > 0:
                ax.text(j, i, f"{int(C[i, j])}", ha="center", va="center", fontsize=6.3,
                        color="white" if Cn[i, j] > 0.55 else "#222222")
    ax.set_xticks(range(7), CLASS_SHORT, rotation=45, ha="right")
    ax.set_yticks(range(7), CLASS_SHORT)
    ax.set_xlabel("Class assigned by BMI cut-points")
    ax.set_ylabel("Published class")
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
    cb.set_label("Row %", fontsize=7)
    panel_label(ax, "b", x=-0.3)
    fig.tight_layout()
    save(fig, FIG / "fig02_label_provenance.png")
    FD["fig02"] = {"confusion": audit["bmi_rule_confusion"], "agree_pct": audit["bmi_rule_agreement_pct"],
                   "n_agree": int(np.trace(C))}


# -------------------------------------------------------- Figure 3: record provenance
def fig_record():
    fig = plt.figure(figsize=(7.2, 5.4))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05], hspace=0.45, wspace=0.32)
    ax = fig.add_subplot(gs[0, :])
    rows = np.arange(len(df)) + 1
    for name, m in (("authentic", auth), ("synthetic", ~auth)):
        ax.scatter(rows[m], y[m] + np.random.default_rng(2).uniform(-0.25, 0.25, m.sum()), s=1.6,
                   color=PROV_COLORS[name], lw=0, label=f"{name.capitalize()} (n = {m.sum():,})")
    start = prov["synthetic_block_start_row_1based"]
    ax.axvline(start - 0.5, color="#333333", lw=0.8, ls="--")
    ax.text(start + 15, 6.55, f"synthetic block begins at row {start}", fontsize=7)
    ax.set_yticks(range(7), CLASS_SHORT)
    ax.set_xlabel("Row position in the distributed file")
    ax.set_xlim(0, len(df) + 10)
    ax.legend(loc="lower right", markerscale=5, ncol=2)
    panel_label(ax, "a", x=-0.07)
    ax = fig.add_subplot(gs[1, 0])
    comp = prov["composition"][:7]
    a_ = np.array([c["authentic"] for c in comp])
    s_ = np.array([c["synthetic"] for c in comp])
    ax.barh(range(7), a_, color=PROV_COLORS["authentic"], label="Authentic")
    ax.barh(range(7), s_, left=a_, color=PROV_COLORS["synthetic"], label="Synthetic")
    for i in range(7):
        ax.text(a_[i] + s_[i] + 6, i, f"{a_[i]} / {s_[i]}", va="center", fontsize=6.5)
    ax.set_yticks(range(7), CLASS_SHORT)
    ax.invert_yaxis()
    ax.set_xlabel("Records")
    ax.set_xlim(0, 470)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=2)
    panel_label(ax, "b", x=-0.25)
    ax = fig.add_subplot(gs[1, 1])
    full = np.array([c["total"] for c in comp]) / audit["n_records"] * 100
    au = a_ / a_.sum() * 100
    x = np.arange(7)
    ax.bar(x - 0.2, full, 0.4, color="#9AA5B1", label="Distributed file")
    ax.bar(x + 0.2, au, 0.4, color=PROV_COLORS["authentic"], label="Authentic records")
    ax.set_xticks(x, CLASS_SHORT, rotation=45, ha="right")
    ax.set_ylabel("Share of records (%)")
    ax.legend(loc="upper right")
    panel_label(ax, "c", x=-0.2)
    save(fig, FIG / "fig03_record_provenance.png")
    FD["fig03"] = {"authentic": a_.tolist(), "synthetic": s_.tolist(), "start_row": start,
                   "share_full": full.round(2).tolist(), "share_authentic": au.round(2).tolist()}


# ------------------------------------------------ Figure 4: provenance validation geometry
def fig_geometry():
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.7), gridspec_kw={"width_ratios": [1.1, 1, 1]})
    ax = axs[0]
    for k, mk in ((6, "o"), (5, "s")):
        A = df[(y == k) & auth]
        S = df[(y == k) & ~auth]
        col = CLASS_COLORS[k]
        ax.scatter(S.Height, S.Weight, s=3, color=col, alpha=0.35, lw=0)
        ax.scatter(A.Height, A.Weight, s=26, color=col, edgecolor="black", lw=0.6, marker=mk,
                   label=f"{CLASS_SHORT[k]}: {len(A)} authentic, {len(S)} synthetic")
        ax.add_patch(Rectangle((A.Height.min(), A.Weight.min()), A.Height.max() - A.Height.min(),
                               A.Weight.max() - A.Weight.min(), fill=False, ec=col, lw=1.0, ls="--"))
    ax.set_xlabel("Height (m)")
    ax.set_ylabel("Weight (kg)")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.27), fontsize=6.0)
    panel_label(ax, "a", x=-0.22)
    ax = axs[1]
    fr = prov["nonintegral"]
    names = [f["attribute"] for f in fr]
    syn = [f["nonintegral_synthetic_pct"] for f in fr]
    au = [f["nonintegral_authentic_pct"] for f in fr]
    yy = np.arange(len(names))
    ax.barh(yy + 0.2, syn, 0.4, color=PROV_COLORS["synthetic"], label="Synthetic")
    ax.barh(yy - 0.2, au, 0.4, color=PROV_COLORS["authentic"], label="Authentic")
    ax.set_yticks(yy, names)
    ax.invert_yaxis()
    ax.set_xlabel("Values off the survey scale (%)")
    ax.set_xlim(0, 112)
    for i_, v_ in enumerate(au):
        ax.text(v_ + 1.5, yy[i_] - 0.2, f"{v_:.0f}", va="center", fontsize=6, color=PROV_COLORS["authentic"])
        ax.text(syn[i_] + 1.5, yy[i_] + 0.2, f"{syn[i_]:.0f}", va="center", fontsize=6, color="#8A5A00")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
    panel_label(ax, "b", x=-0.3)
    ax = axs[2]
    z = np.load(cfg["paths"]["raw"] / "nn_distances.npz")
    d1, a_ = z["d1"], z["authentic"]
    for name, m in (("authentic", a_), ("synthetic", ~a_)):
        v = np.sort(np.maximum(d1[m], 1e-3))
        ax.plot(v, np.arange(1, len(v) + 1) / len(v), color=PROV_COLORS[name], lw=1.6, label=name.capitalize())
    ax.set_xscale("log")
    ax.set_xlabel("Distance to nearest other record")
    ax.set_ylabel("Cumulative proportion")
    nn = {r["provenance"]: r for r in prov["nearest_neighbour"]}
    ax.text(0.03, 0.97, f"same-class neighbour\nauthentic {nn['authentic']['nn_same_class_pct']:.1f}%\n"
            f"synthetic {nn['synthetic']['nn_same_class_pct']:.1f}%", transform=ax.transAxes, va="top", fontsize=6.5)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
    panel_label(ax, "c", x=-0.25)
    fig.tight_layout()
    save(fig, FIG / "fig04_provenance_geometry.png")
    FD["fig04"] = {"nonintegral_synthetic": syn, "nonintegral_authentic": au,
                   "nn_same_class": {k: v["nn_same_class_pct"] for k, v in nn.items()},
                   "nn_median": {k: v["nn_distance_median"] for k, v in nn.items()}}


# ------------------------------------------------------ Figure 5: performance across arms
def fig_performance():
    mets = [("accuracy", "Accuracy (%)", 100), ("balanced_accuracy", "Balanced accuracy (%)", 100), ("kappa", "Cohen's kappa", 1)]
    fig, axs = plt.subplots(3, 1, figsize=(7.2, 7.0), sharex=True)
    x = np.arange(len(LEARN))
    off = {"A": -0.27, "B": -0.09, "C": 0.09, "D": 0.27}
    data = {}
    for ax, (met, lab, sc) in zip(axs, mets):
        for a in ARMS:
            m = np.array([E(a, c, met) for c in LEARN]) * sc
            lo = np.array([E(a, c, met, "lo") for c in LEARN]) * sc
            hi = np.array([E(a, c, met, "hi") for c in LEARN]) * sc
            ax.errorbar(x + off[a], m, yerr=[m - lo, hi - m], fmt="o", ms=3.6, color=ARM_COLORS[a],
                        ecolor=ARM_COLORS[a], elinewidth=0.9, capsize=1.5, label=ARM_SHORT[a])
            base = E(a, "MAJ", met) * sc
            ax.hlines(base, -0.5, len(LEARN) - 0.5, colors=ARM_COLORS[a], linestyles=":", lw=1.0)
            data[f"{met}_{a}"] = {"mean": m.round(4).tolist(), "majority": round(base, 4)}
        ax.set_ylabel(lab)
        ax.set_xlim(-0.5, len(LEARN) - 0.5)
    axs[0].legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.22))
    axs[-1].set_xticks(x, [SHORT[c] for c in LEARN])
    for ax, lab in zip(axs, "abc"):
        panel_label(ax, lab, x=-0.08)
    fig.tight_layout()
    save(fig, FIG / "fig05_performance.png")
    FD["fig05"] = data


# ------------------------------------------------------- Figure 6: defect decomposition
def fig_decomposition():
    dec = [r for r in inf["decomposition"]]
    contrasts = [("label_full", "Circular label\n(A - B)"), ("synthetic_all", "Synthetic records\n(A - C)"),
                 ("both", "Both defects\n(A - D)"), ("interaction", "Interaction\n(A - B) - (C - D)")]
    mets = [("accuracy", "Accuracy (pp)"), ("balanced_accuracy", "Balanced accuracy (pp)")]
    fig, axs = plt.subplots(2, 4, figsize=(7.2, 4.6), sharey=True)
    data = {}
    for i, (met, mlab) in enumerate(mets):
        for j, (con, clab) in enumerate(contrasts):
            ax = axs[i, j]
            vals = []
            for k, c in enumerate(LEARN):
                r = next(d for d in dec if d["classifier"] == c and d["metric"] == met and d["contrast"] == con)
                ax.errorbar(100 * r["diff"], k, xerr=[[100 * (r["diff"] - r["lo"])], [100 * (r["hi"] - r["diff"])]],
                            fmt="o", ms=3.5, color=CLF_COLORS[c], elinewidth=1, capsize=1.5)
                vals.append(round(100 * r["diff"], 4))
            ax.axvline(0, color="#555555", lw=0.7)
            if i == 0:
                ax.set_title(clab, fontsize=7.8)
            if j == 0:
                ax.set_yticks(range(len(LEARN)), [SHORT[c] for c in LEARN])
                ax.set_ylabel(mlab)
            data[f"{met}_{con}"] = vals
    axs[0, 0].invert_yaxis()
    fig.tight_layout()
    save(fig, FIG / "fig06_decomposition.png")
    FD["fig06"] = data


# ------------------------------------------------------------ Figure 7: permutation tests
def fig_permutation(arm, fname, key):
    clfs = cfg["statistics"]["permutation_classifiers"]
    fig, axs = plt.subplots(2, len(clfs), figsize=(7.2, 3.8))
    data = {}
    for i, (stat, lab) in enumerate((("balanced_accuracy", "Balanced accuracy"), ("kappa", "Cohen's kappa"))):
        for j, c in enumerate(clfs):
            ax = axs[i, j]
            null = np.array(perm["null"][f"{arm}__{c}"][stat])
            s = next(r for r in perm["summary"] if r["arm"] == arm and r["classifier"] == c and r["statistic"] == stat)
            sc = 100 if stat == "balanced_accuracy" else 1
            ax.hist(null * sc, bins=30, color="#B8C4D0", edgecolor="white", lw=0.3)
            ax.axvline(s["observed"] * sc, color=CLF_COLORS[c], lw=1.8)
            ptxt = f"p = {s['p']:.3f}" if s["p"] >= 0.001 else "p < 0.001"
            ax.text(0.97, 0.95, ptxt, transform=ax.transAxes, ha="right", va="top", fontsize=6.8)
            if i == 0:
                ax.set_title(SHORT[c])
            if j == 0:
                ax.set_ylabel(f"{lab}\n(count)")
            ax.set_xlabel(lab + (" (%)" if sc == 100 else ""), fontsize=7)
            ax.xaxis.set_major_locator(plt.MaxNLocator(4))
            data[f"{stat}_{c}"] = {"observed": s["observed"], "p": s["p"]}
    fig.tight_layout()
    save(fig, FIG / fname)
    FD[key] = data


# --------------------------------------------------- Figure 8: provenance-aware evaluation
def fig_provenance_aware():
    schemes = [("random_cv_full_scored_authentic", "Random CV on full file"),
               ("synth_plus", "Authentic + synthetic"),
               ("synth_plus_purged", "Authentic + synthetic, purged"),
               ("synth_only", "Synthetic only"),
               ("synth_only_purged", "Synthetic only, purged"),
               ("authentic_only", "Authentic only")]
    fig, axs = plt.subplots(2, 1, figsize=(7.2, 5.0), sharex=True)
    x = np.arange(len(LEARN))
    data = {}
    for ax, attrs, ttl in ((axs[0], "all", "All attributes"), (axs[1], "behaviour", "Behaviour-only attributes")):
        for s_i, (s, slab) in enumerate(schemes):
            rows = [next(r for r in pa if r["attributes"] == attrs and r["classifier"] == c and r["scheme"] == s
                         and r["metric"] == "balanced_accuracy") for c in LEARN]
            m = np.array([r["mean"] for r in rows]) * 100
            lo = np.array([r["lo"] for r in rows]) * 100
            hi = np.array([r["hi"] for r in rows]) * 100
            w = 0.135
            ax.bar(x + (s_i - 2.5) * w, m, w, color=SCHEME_COLORS[s], label=slab, edgecolor="white", lw=0.3,
                   hatch="////" if s.endswith("purged") else None)
            ax.errorbar(x + (s_i - 2.5) * w, m, yerr=[m - lo, hi - m], fmt="none", ecolor="#333333", elinewidth=0.5, capsize=0.8)
            data[f"{attrs}_{s}"] = m.round(4).tolist()
        maj = next(r for r in pa if r["attributes"] == attrs and r["classifier"] == "MAJ" and r["scheme"] == "authentic_only" and r["metric"] == "balanced_accuracy")
        ax.axhline(maj["mean"] * 100, color="#222222", ls=":", lw=1)
        ax.set_ylabel("Balanced accuracy on\nauthentic records (%)")
        ax.set_title(ttl, loc="left")
        ax.set_ylim(0, 105)
        data[f"{attrs}_majority"] = maj["mean"] * 100
    axs[0].legend(ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.42), fontsize=6.8)
    axs[1].set_xticks(x, [SHORT[c] for c in LEARN])
    for ax, lab in zip(axs, "ab"):
        panel_label(ax, lab, x=-0.09)
    fig.tight_layout()
    save(fig, FIG / "fig08_provenance_aware.png")
    FD["fig08"] = data


# ---------------------------------------------------------- Figure 9: per-class recall
def fig_per_class():
    fig, axs = plt.subplots(1, 4, figsize=(7.2, 3.1), sharey=True)
    data = {}
    for ax, a in zip(axs, ARMS):
        M = np.array([est[a][c]["per_class_recall"] for c in LEARN], float) * 100
        im = ax.imshow(M, cmap="viridis", vmin=0, vmax=100, aspect="auto")
        for i in range(M.shape[0]):
            for j in range(7):
                ax.text(j, i, f"{M[i, j]:.0f}", ha="center", va="center", fontsize=5.6,
                        color="white" if M[i, j] < 55 else "black")
        sup = est[a][LEARN[0]]["class_support"]
        ax.set_xticks(range(7), [f"{s}\n(n={n})" for s, n in zip(CLASS_SHORT, sup)], rotation=90, fontsize=6)
        ax.set_title(f"Arm {a}")
        ax.grid(False)
        data[a] = M.round(4).tolist()
    axs[0].set_yticks(range(len(LEARN)), [SHORT[c] for c in LEARN])
    cb = fig.colorbar(im, ax=axs, fraction=0.025, pad=0.02)
    cb.set_label("Recall (%)", fontsize=7)
    save(fig, FIG / "fig09_per_class_recall.png")
    FD["fig09"] = data


# --------------------------------------------------------- Figure 10: importance (RF)
def fig_importance():
    fig, axs = plt.subplots(1, 4, figsize=(7.2, 3.3))
    data = {}
    for ax, a in zip(axs, ARMS):
        rows = sorted([r for r in imp if r["arm"] == a and r["classifier"] == "RF"], key=lambda r: -r["importance_mean"])[:8]
        v = np.array([r["importance_mean"] for r in rows]) * 100
        lo = np.array([r["importance_lo"] for r in rows]) * 100
        hi = np.array([r["importance_hi"] for r in rows]) * 100
        yy = np.arange(len(rows))
        cols = ["#B2182B" if r["attribute"] in ("Height", "Weight") else ARM_COLORS[a] for r in rows]
        ax.barh(yy, v, color=cols)
        ax.errorbar(v, yy, xerr=[v - lo, hi - v], fmt="none", ecolor="#333333", elinewidth=0.6, capsize=1)
        ax.set_yticks(yy, [r["attribute"].replace("family_history_with_overweight", "Family history") for r in rows], fontsize=6.6)
        ax.invert_yaxis()
        ax.axvline(0, color="#555555", lw=0.6)
        ax.set_title(f"Arm {a}")
        ax.set_xlabel("Drop in balanced\naccuracy (pp)", fontsize=7)
        data[a] = {r["attribute"]: round(100 * r["importance_mean"], 4) for r in rows}
    fig.tight_layout()
    save(fig, FIG / "fig10_importance.png")
    FD["fig10"] = data


# --------------------------------------------------------------- Figure 11: calibration
def fig_calibration():
    clfs = ["LR", "BT", "RF", "GB"]
    fig, axs = plt.subplots(1, 4, figsize=(7.2, 2.4), sharey=True)
    data = {}
    for ax, a in zip(axs, ARMS):
        ax.plot([0, 1], [0, 1], color="#999999", lw=0.8, ls="--")
        for c in clfs:
            rel = np.array(est[a][c]["reliability"], float)
            ax.plot(rel[:, 1], rel[:, 2], marker="o", ms=2.5, lw=1.1, color=CLF_COLORS[c], label=SHORT[c])
            data[f"{a}_{c}_ece"] = est[a][c]["ece"]["mean"]
        ax.set_title(f"Arm {a}")
        ax.set_xlabel("Predicted confidence")
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.text(0.98, 0.03, "ECE\n" + "\n".join(f"{SHORT[c]} {est[a][c]['ece']['mean']:.3f}" for c in clfs),
                transform=ax.transAxes, ha="right", va="bottom", fontsize=5.6)
    axs[0].set_ylabel("Observed accuracy")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout()
    save(fig, FIG / "fig11_calibration.png")
    FD["fig11"] = data


# ----------------------------------------------------------- Figure 12: learning curves
def fig_learning():
    fig, axs = plt.subplots(1, 4, figsize=(7.2, 2.4), sharey=True)
    data = {}
    for ax, a in zip(axs, ARMS):
        for c in ("LR", "DT", "RF", "MAJ"):
            rows = sorted([r for r in lc if r["arm"] == a and r["classifier"] == c], key=lambda r: r["fraction"])
            n = np.array([r["n_train_mean"] for r in rows])
            m = np.array([r["balanced_accuracy_mean"] for r in rows]) * 100
            s = np.array([r["balanced_accuracy_sd"] for r in rows]) * 100
            ax.plot(n, m, marker="o", ms=2.5, color=CLF_COLORS[c], label=SHORT[c], lw=1.1)
            ax.fill_between(n, m - s, m + s, color=CLF_COLORS[c], alpha=0.12, lw=0)
            data[f"{a}_{c}"] = m.round(4).tolist()
        ax.set_title(f"Arm {a}")
        ax.set_xlabel("Training records")
    axs[0].set_ylabel("Balanced accuracy (%)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout()
    save(fig, FIG / "fig12_learning_curves.png")
    FD["fig12"] = data


# ---------------------------------------------------- Figure 13: contextual comparison
LIT = [
    {"study": "Maulana et al. (2024)", "model": "CatBoost", "accuracy": 95.98, "arm_like": "A",
     "setting": "Full file, height and weight included"},
    {"study": "Gandhi et al. (2026)", "model": "Gradient boosting", "accuracy": 95.93, "arm_like": "A",
     "setting": "Full file, 80/20 split, SMOTE applied"},
    {"study": "Görmez et al. (2025)", "model": "CatBoost", "accuracy": 93.67, "arm_like": "C",
     "setting": "498 participants, height and weight included"},
    {"study": "Haggouni et al. (2026)", "model": "XGBoost", "accuracy": 87.00, "arm_like": "B",
     "setting": "Full file, height and weight excluded"},
]


def best_learner(a):
    return max(LEARN, key=lambda c: E(a, c, "accuracy"))


def fig_context():
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    labels, vals, cols, kinds = [], [], [], []
    for r in LIT:
        labels.append(f"{r['study']}: {r['model']} [{r['arm_like']}-type setting]")
        vals.append(r["accuracy"])
        cols.append(ARM_COLORS[r["arm_like"]])
        kinds.append("published")
    for a in ARMS:
        c = best_learner(a)
        labels.append(f"This study, Arm {a}: best learner ({SHORT[c]})")
        vals.append(100 * E(a, c, "accuracy"))
        cols.append(ARM_COLORS[a])
        kinds.append("this study")
    yy = np.arange(len(labels))
    for i in yy:
        ax.scatter(vals[i], i, s=48, color=cols[i], marker="D" if kinds[i] == "published" else "o",
                   edgecolor="black", lw=0.5, zorder=3)
        ax.text(vals[i] + 0.8, i, f"{vals[i]:.2f}", va="center", fontsize=6.8)
    ax.axvline(audit["majority_baseline_authentic_pct"], color="#222222", ls=":", lw=1)
    ax.text(audit["majority_baseline_authentic_pct"] - 0.8, 1.5,
            f"majority class,\nauthentic records\n({audit['majority_baseline_authentic_pct']:.2f}%)", fontsize=6.3, va="center", ha="right")
    ax.set_yticks(yy, labels, fontsize=7)
    ax.invert_yaxis()
    ax.set_xlabel("Accuracy (%)")
    ax.set_xlim(45, 103)
    fig.tight_layout()
    save(fig, FIG / "fig13_context.png")
    FD["fig13"] = {"labels": labels, "values": [round(v, 4) for v in vals]}


# ========================================================================= appendix
def figA_confusion():
    fig, axs = plt.subplots(2, 4, figsize=(7.2, 4.2))
    data = {}
    for i, c in enumerate(("BT", "LR")):
        for j, a in enumerate(ARMS):
            ax = axs[i, j]
            C = np.array(est[a][c]["confusion_sum"], float)
            Cn = C / np.maximum(C.sum(1, keepdims=True), 1)
            ax.imshow(Cn * 100, cmap="Blues", vmin=0, vmax=100)
            for r_ in range(7):
                for k in range(7):
                    if Cn[r_, k] >= 0.005:
                        ax.text(k, r_, f"{100 * Cn[r_, k]:.0f}", ha="center", va="center", fontsize=5,
                                color="white" if Cn[r_, k] > 0.55 else "#222222")
            ax.set_xticks(range(7), CLASS_SHORT if i == 1 else [], rotation=90, fontsize=5.8)
            ax.set_yticks(range(7), CLASS_SHORT if j == 0 else [], fontsize=5.8)
            ax.grid(False)
            ax.set_title(f"{SHORT[c]}, Arm {a}", fontsize=7.5)
            data[f"{c}_{a}"] = (100 * np.diag(Cn)).round(4).tolist()
    fig.supxlabel("Predicted class", fontsize=7.5)
    fig.supylabel("True class", fontsize=7.5)
    fig.tight_layout()
    save(fig, FIG / "figA1_confusion.png")
    FD["figA1"] = data


def figA_folds():
    from obaudit.store import load_folds, run_key
    fig, axs = plt.subplots(1, 4, figsize=(7.2, 2.6), sharey=True)
    data = {}
    for ax, a in zip(axs, ARMS):
        vals = [load_folds(run_key(a, c))["balanced_accuracy"].to_numpy() * 100 for c in LEARN]
        bp = ax.boxplot(vals, patch_artist=True, widths=0.6, showfliers=False, medianprops=dict(color="black", lw=0.8))
        for patch, c in zip(bp["boxes"], LEARN):
            patch.set_facecolor(CLF_COLORS[c])
            patch.set_alpha(0.8)
        ax.set_xticks(range(1, len(LEARN) + 1), [SHORT[c] for c in LEARN], rotation=90, fontsize=6.5)
        ax.set_title(f"Arm {a}")
        data[a] = [round(float(np.median(v)), 4) for v in vals]
    axs[0].set_ylabel("Fold balanced accuracy (%)")
    fig.tight_layout()
    save(fig, FIG / "figA2_fold_distributions.png")
    FD["figA2"] = data


def figA_attributes():
    num = cfg["data"]["numeric"]
    fig, axs = plt.subplots(2, 4, figsize=(7.2, 3.8))
    for ax, c in zip(axs.ravel(), num):
        lo, hi = df[c].min(), df[c].max()
        bins = np.linspace(lo, hi, 31)
        ax.hist(df.loc[~auth, c], bins=bins, color=PROV_COLORS["synthetic"], alpha=0.75, density=True, label="Synthetic")
        ax.hist(df.loc[auth, c], bins=bins, color=PROV_COLORS["authentic"], alpha=0.65, density=True, label="Authentic")
        ax.set_title(c, fontsize=7.5)
        ax.tick_params(labelsize=6)
        ax.set_yticks([])
    axs[0, 0].legend(fontsize=6)
    fig.tight_layout()
    save(fig, FIG / "figA3_attribute_distributions.png")


def figA_rf():
    rows = sens["S5_rf_max_features"]
    fig, ax = plt.subplots(figsize=(4.6, 2.6))
    data = {}
    for a in ("A", "B"):
        rr = [r for r in rows if r["arm"] == a]
        labs = [r["max_features"] for r in rr]
        m = np.array([r["accuracy"] for r in rr]) * 100
        lo = np.array([r["accuracy_lo"] for r in rr]) * 100
        hi = np.array([r["accuracy_hi"] for r in rr]) * 100
        xx = np.arange(len(labs))
        ax.errorbar(xx, m, yerr=[m - lo, hi - m], marker="o", ms=4, color=ARM_COLORS[a], capsize=2, label=f"Arm {a}")
        data[a] = dict(zip(labs, m.round(4).tolist()))
    ax.set_xticks(xx, ["sqrt", "log2", "0.33", "0.5", "1.0\n(bagging)"])
    ax.set_xlabel("Random forest max_features")
    ax.set_ylabel("Accuracy (%)")
    ax.legend()
    fig.tight_layout()
    save(fig, FIG / "figA4_rf_max_features.png")
    FD["figA4"] = data


def figA_sensitivity():
    """Arm D balanced accuracy for the primary learners under each analysis variant."""
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), sharey=True)
    data = {}
    for ax, a in zip(axs, ("C", "D")):
        for k, c in enumerate(LEARN):
            pts = [("Primary", E(a, c, "balanced_accuracy"), E(a, c, "balanced_accuracy", "lo"), E(a, c, "balanced_accuracy", "hi"), "#000000")]
            s1 = next(r for r in sens["S1_discrete_rule"] if r["arm"] == a and r["classifier"] == c)
            pts.append(("S1 antecedent rule", s1["balanced_accuracy"], s1["balanced_accuracy_lo"], s1["balanced_accuracy_hi"], "#E69F00"))
            s2 = next(r for r in sens["S2_deduplicated"] if r["arm"] == a and r["classifier"] == c)
            pts.append(("S2 deduplicated", s2["balanced_accuracy"], s2["balanced_accuracy_lo"], s2["balanced_accuracy_hi"], "#56B4E9"))
            s4 = [r for r in sens["S4_class_weighted"] if r["arm"] == a and r["classifier"] == c]
            if s4:
                pts.append(("S4 class-weighted", s4[0]["balanced_accuracy"], s4[0]["balanced_accuracy_lo"], s4[0]["balanced_accuracy_hi"], "#009E73"))
            s6 = [r for r in sens["S6_nested_tuning"] if r["arm"] == a and r["classifier"] == c]
            if s6:
                sd = s6[0]["balanced_accuracy_sd"]
                pts.append(("S6 nested tuning", s6[0]["balanced_accuracy"], s6[0]["balanced_accuracy"] - 2.262 * sd / np.sqrt(10),
                            s6[0]["balanced_accuracy"] + 2.262 * sd / np.sqrt(10), "#CC79A7"))
            for q, (nm, m, lo, hi, col) in enumerate(pts):
                yv = k + (q - 2) * 0.15
                ax.errorbar(100 * m, yv, xerr=[[100 * (m - lo)], [100 * (hi - m)]], fmt="o", ms=2.8, color=col,
                            elinewidth=0.8)
                data[f"{a}_{c}_{nm}"] = round(100 * m, 4)
        maj = E(a, "MAJ", "balanced_accuracy") * 100
        ax.axvline(maj, color="#222222", ls=":", lw=1)
        ax.set_title(f"Arm {a}")
        ax.set_xlabel("Balanced accuracy (%)")
    axs[0].set_yticks(range(len(LEARN)), [SHORT[c] for c in LEARN])
    axs[0].invert_yaxis()
    from matplotlib.lines import Line2D
    hh = [Line2D([], [], marker="o", color=c_, ls="", label=n_) for n_, c_ in
          (("Primary", "#000000"), ("S1 antecedent rule", "#E69F00"), ("S2 deduplicated", "#56B4E9"),
           ("S4 class-weighted", "#009E73"), ("S6 nested tuning", "#CC79A7"))]
    fig.legend(handles=hh, loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.05), fontsize=6.5)
    fig.tight_layout()
    save(fig, FIG / "figA5_sensitivity.png")
    FD["figA5"] = data


def figA_outcomes():
    rows = sens["S3_outcomes"]
    outs = [("three_class", "Three classes"), ("obese_vs_not", "Obese vs not"), ("bmi25_vs_not", "BMI >= 25 vs not")]
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.7), sharey=True)
    data = {}
    for ax, (o, ttl) in zip(axs, outs):
        for a, sh in (("C", -0.18), ("D", 0.18)):
            rr = [next(r for r in rows if r["arm"] == a and r["outcome"] == o and r["classifier"] == c) for c in LEARN]
            m = np.array([r["balanced_accuracy"] for r in rr]) * 100
            lo = np.array([r["balanced_accuracy_lo"] for r in rr]) * 100
            hi = np.array([r["balanced_accuracy_hi"] for r in rr]) * 100
            ax.errorbar(np.arange(len(LEARN)) + sh, m, yerr=[m - lo, hi - m], fmt="o", ms=3, color=ARM_COLORS[a],
                        elinewidth=0.8, capsize=1, label=f"Arm {a}")
            maj = next(r for r in rows if r["arm"] == a and r["outcome"] == o and r["classifier"] == "MAJ")
            ax.axhline(100 * maj["balanced_accuracy"], color=ARM_COLORS[a], ls=":", lw=0.9)
            data[f"{a}_{o}"] = m.round(4).tolist()
        ax.set_title(ttl)
        ax.set_xticks(range(len(LEARN)), [SHORT[c] for c in LEARN], rotation=90, fontsize=6.5)
    axs[0].set_ylabel("Balanced accuracy (%)")
    axs[0].legend(fontsize=6.5)
    fig.tight_layout()
    save(fig, FIG / "figA6_outcomes.png")
    FD["figA6"] = data


def figA_rapidminer():
    cells = rmr["cells"]
    fig, axs = plt.subplots(1, 2, figsize=(6.4, 2.9))
    data = {}
    for ax, met, lab in ((axs[0], "accuracy", "Accuracy (%)"), (axs[1], "kappa", "Cohen's kappa")):
        cc = [c for c in cells if c["metric"] == met]
        for c in cc:
            ax.scatter(c["rapidminer"], c["python"], color=ARM_COLORS[c["arm"]], s=22,
                       marker={"NB": "s", "LR": "^", "DT": "o", "BT": "D"}[c["classifier"]], edgecolor="black", lw=0.4)
        lim = [min(min(c["rapidminer"] for c in cc), min(c["python"] for c in cc)) * 0.9,
               max(max(c["rapidminer"] for c in cc), max(c["python"] for c in cc)) * 1.05]
        ax.plot(lim, lim, color="#999999", ls="--", lw=0.8)
        ax.set_xlabel(f"RapidMiner 7.1 {lab}")
        ax.set_ylabel(f"Python {lab}")
        rho = rmr["rank_agreement"][met]["spearman_rho"]
        ax.text(0.04, 0.95, f"Spearman rho = {rho:.2f}", transform=ax.transAxes, va="top", fontsize=7)
        data[met] = rho
    from matplotlib.lines import Line2D
    h = [Line2D([], [], marker=m, ls="", color="#777777", label=SHORT[k]) for k, m in (("NB", "s"), ("LR", "^"), ("DT", "o"), ("BT", "D"))]
    h += [Line2D([], [], marker="o", ls="", color=ARM_COLORS[a], label=f"Arm {a}") for a in ARMS]
    axs[1].legend(handles=h, fontsize=6, loc="lower right", ncol=2)
    fig.tight_layout()
    save(fig, FIG / "figA7_rapidminer.png")
    FD["figA7"] = data


def figA_pairwise():
    pw = [r for r in inf["pairwise"] if r["metric"] == "balanced_accuracy"]
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3))
    data = {}
    for ax, a in zip(axs, ("C", "D")):
        M = np.full((len(LEARN), len(LEARN)), np.nan)
        S = np.full_like(M, np.nan)
        for r in pw:
            if r["arm"] != a:
                continue
            i, j = LEARN.index(r["a"]), LEARN.index(r["b"])
            M[i, j], M[j, i] = 100 * r["diff"], -100 * r["diff"]
            S[i, j] = S[j, i] = r["p_holm"]
        lim = np.nanmax(np.abs(M))
        im = ax.imshow(M, cmap="RdBu_r", vmin=-lim, vmax=lim)
        for i in range(len(LEARN)):
            for j in range(len(LEARN)):
                if i != j:
                    star = "*" if S[i, j] < 0.05 else ""
                    ax.text(j, i, f"{M[i, j]:.1f}{star}", ha="center", va="center", fontsize=5.4)
        ax.set_xticks(range(len(LEARN)), [SHORT[c] for c in LEARN], rotation=90, fontsize=6.5)
        ax.set_yticks(range(len(LEARN)), [SHORT[c] for c in LEARN], fontsize=6.5)
        ax.grid(False)
        ax.set_title(f"Arm {a}: row minus column (pp)", fontsize=7.5)
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
        data[a] = int(np.nansum(S < 0.05) / 2)
    fig.tight_layout()
    save(fig, FIG / "figA8_pairwise.png")
    FD["figA8"] = data


for fn in (fig_workflow, fig_label, fig_record, fig_geometry, fig_performance, fig_decomposition,
           lambda: fig_permutation("D", "fig07_permutation_D.png", "fig07"), fig_provenance_aware,
           fig_per_class, fig_importance, fig_calibration, fig_learning, fig_context,
           figA_confusion, figA_folds, figA_attributes, figA_rf, figA_sensitivity, figA_outcomes,
           figA_rapidminer, figA_pairwise,
           lambda: fig_permutation("C", "figA9_permutation_C.png", "figA9")):
    fn()
FD["literature"] = LIT
save_json("figure_data", FD)
print("figures:", sorted(p.name for p in FIG.glob("*.png")))
