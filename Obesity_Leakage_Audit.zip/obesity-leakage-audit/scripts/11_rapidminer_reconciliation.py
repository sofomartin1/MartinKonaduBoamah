"""Stage 11 - reconciliation with the antecedent RapidMiner Studio 7.1 results.

RapidMiner arms C and D used the antecedent discrete-value rule (496 records), so they are
compared with the Python S1 sensitivity runs on the same 496 records. Arms A and B are
compared with the primary Python runs. RapidMiner's 'weighted mean recall/precision' with
equal class weights is the macro average. Algorithms differ in implementation (RapidMiner's
logistic regression is a kernel logistic regression fitted one-against-all; its decision tree
uses gain ratio with pessimistic pruning), so agreement is expected in direction and ordering
rather than to the decimal."""
import _common  # noqa: F401
import json

import pandas as pd

from obaudit.config import ROOT
from obaudit.stats import corrected_ci
from obaudit.store import load_folds, run_key, save_json, save_table

rm = json.load(open(ROOT / "rapidminer" / "antecedent_results" / "rapidminer_authoritative_results.json"))
MAP = {"NaiveBayes": "NB", "LogisticRegression": "LR", "DecisionTree": "DT", "BaggedTree": "BT"}
rows = []
for r in rm["aggregate"]:
    arm = r["arm"][-1]
    clf = MAP[r["classifier"]]
    key = run_key(arm, clf, "main" if arm in "AB" else "discrete")
    f = load_folds(key)
    ratio = float((f.n_test / f.n_train).mean())
    for rm_name, py_name, scale in (("acc", "accuracy", 100), ("kappa", "kappa", 1),
                                    ("wmr", "balanced_accuracy", 100), ("wmp", "macro_precision", 100)):
        mean, lo, hi, _ = corrected_ci(f[py_name].to_numpy() * scale, ratio)
        rows.append({"arm": arm, "classifier": clf, "metric": py_name,
                     "rapidminer": r[rm_name], "rapidminer_sd": r[rm_name + "_sd"],
                     "python": mean, "python_lo": lo, "python_hi": hi,
                     "difference": mean - r[rm_name],
                     "rm_inside_python_ci": bool(lo <= r[rm_name] <= hi)})
tab = pd.DataFrame(rows)
# ordering agreement: Spearman correlation across the 16 cells, per metric
from scipy.stats import spearmanr
agree = {}
for met, g in tab.groupby("metric"):
    rho, p = spearmanr(g.rapidminer, g.python)
    agree[met] = {"spearman_rho": rho, "p": p}
save_table("rapidminer_reconciliation", tab)
save_json("rapidminer_reconciliation", {"cells": tab.to_dict(orient="records"), "rank_agreement": agree,
                                        "rapidminer_source": rm["source"], "rapidminer_validation": rm["validation"]})
print(tab[tab.metric == "accuracy"].round(2).to_string())
print(agree)
