"""Stage 8 - held-out permutation importance by original attribute (one-hot columns are
permuted together because the raw attribute is permuted before encoding).

For every test fold of one stratified 10-fold partition, each attribute is shuffled
``importance_repeats`` times and the drop in balanced accuracy is recorded."""
import _common  # noqa: F401
import warnings

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.metrics import recall_score

from obaudit.config import load_config
from obaudit.cv import splits
from obaudit.data import arm_data, feature_columns, load_dataset
from obaudit.models import make_model
from obaudit.store import save_json, save_table

cfg = load_config()
SEED = cfg["study"]["seed"]
NREP = cfg["sensitivity"]["importance_repeats"]
df = load_dataset()


def bal(y, p):
    return recall_score(y, p, labels=np.unique(y), average="macro", zero_division=0)


def fold(name, X, y, num, nom, tr, te, f):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        m = make_model(name, num, nom)
        m.fit(X.iloc[tr], y[tr])
        Xt, yt = X.iloc[te].reset_index(drop=True), y[te]
        base = bal(yt, m.predict(Xt))
        rng = np.random.default_rng(SEED + f)
        out = {}
        for c in X.columns:
            drops = []
            for _ in range(NREP):
                Xp = Xt.copy()
                Xp[c] = rng.permutation(Xp[c].to_numpy())
                drops.append(base - bal(yt, m.predict(Xp)))
            out[c] = float(np.mean(drops))
    return out


rows = []
for arm in cfg["arms"]:
    X, y, _ = arm_data(df, arm)
    num, nom = feature_columns(cfg["arms"][arm]["attributes"])
    for name in ("RF", "LR", "DT"):
        res = Parallel(n_jobs=cfg["cv"]["n_jobs"])(
            delayed(fold)(name, X, y, num, nom, tr, te, f) for (_, f, tr, te) in splits(y, n_repeats=1, seed=SEED))
        R = pd.DataFrame(res)
        for c in R.columns:
            rows.append({"arm": arm, "classifier": name, "attribute": c,
                         "importance_mean": R[c].mean(), "importance_sd": R[c].std(ddof=1),
                         "importance_lo": R[c].mean() - 2.262 * R[c].std(ddof=1) / np.sqrt(len(R)),
                         "importance_hi": R[c].mean() + 2.262 * R[c].std(ddof=1) / np.sqrt(len(R))})
        top = sorted(((r["importance_mean"], r["attribute"]) for r in rows
                      if r["arm"] == arm and r["classifier"] == name), reverse=True)[:4]
        print(arm, name, [(a, round(v, 3)) for v, a in top], flush=True)
tab = pd.DataFrame(rows)
save_table("importance", tab)
save_json("importance", tab.to_dict(orient="records"))
