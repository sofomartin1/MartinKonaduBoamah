"""Stage 2 - record-provenance validation.

Evidence assembled:
  (a) concordance between the file-structure rule and the discrete-value rules;
  (b) the run structure of the synthetic block (class-sorted, no majority-class block);
  (c) bounding-box containment: SMOTE as implemented in Weka draws an independent gap per
      attribute, so a synthetic record must lie inside the axis-aligned box spanned by the
      authentic records of its own class (but not necessarily inside their convex hull);
  (d) the share of non-integral values per attribute by provenance;
  (e) nearest-neighbour geometry: how close each record is to its nearest other record and
      whether that neighbour shares its class and provenance.
"""
import _common  # noqa: F401
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder

from obaudit.config import load_config
from obaudit.data import label_codes, load_dataset, provenance
from obaudit.store import save_json, save_table

cfg = load_config()
CL = cfg["data"]["classes"]
df = load_dataset()
y = label_codes(df[cfg["data"]["label"]])
fo = provenance(df, "file_order")
dr = provenance(df, "discrete")
dr1 = provenance(df, "discrete_0.1kg")
num = cfg["data"]["numeric"]

out = {}
# (a) concordance ---------------------------------------------------------------------
def conc(rule):
    return {"both_authentic": int((fo & rule).sum()), "file_authentic_rule_synthetic": int((fo & ~rule).sum()),
            "file_synthetic_rule_authentic": int((~fo & rule).sum()), "both_synthetic": int((~fo & ~rule).sum()),
            "agreement_pct": 100 * float(np.mean(fo == rule))}
out["concordance_discrete"] = conc(dr)
out["concordance_discrete_0.1kg"] = conc(dr1)
# characterise disagreements
w_dec = ~np.isclose(df["Weight"], df["Weight"].round(0))
out["survey_flagged_synthetic_weight_one_decimal"] = int((fo & ~dr & w_dec).sum())
out["survey_flagged_synthetic_by_class"] = {CL[k]: int(((y == k) & fo & ~dr).sum()) for k in range(7)}
dup_extra_or_copy = df.duplicated(keep=False).to_numpy()
out["synthetic_flagged_authentic_are_exact_duplicates"] = int((~fo & dr & dup_extra_or_copy).sum())
out["synthetic_flagged_authentic_by_class"] = {CL[k]: int(((y == k) & ~fo & dr).sum()) for k in range(7)}

# (b) synthetic block run structure ------------------------------------------------------
start = int((~fo).argmax())
runs, s = [], start
lab = y
for i in range(start + 1, len(df) + 1):
    if i == len(df) or lab[i] != lab[s]:
        runs.append({"first_row_1based": s + 1, "last_row_1based": i, "class": CL[lab[s]], "n": i - s})
        s = i
out["synthetic_block_start_row_1based"] = start + 1
out["synthetic_block_runs"] = runs
out["survey_block_label_runs"] = int(1 + np.count_nonzero(lab[1:start] != lab[:start - 1]))
out["generation_ratio"] = {CL[k]: (float(((y == k) & ~fo).sum() / ((y == k) & fo).sum())
                                   if ((y == k) & fo).sum() else None) for k in range(7)}

# (c) bounding-box containment ----------------------------------------------------------
X = df[num].to_numpy(float)
box_rows = []
for k in range(7):
    A = X[(y == k) & fo]
    lo, hi = A.min(0), A.max(0)
    S = X[(y == k) & ~fo]
    own = ((S >= lo - 1e-9) & (S <= hi + 1e-9)).all(1) if len(S) else np.array([])
    # specificity: synthetic records of *other* classes inside this class's box
    So = X[(y != k) & ~fo]
    other = ((So >= lo - 1e-9) & (So <= hi + 1e-9)).all(1)
    # authentic records of other classes inside this box
    Ao = X[(y != k) & fo]
    oth_a = ((Ao >= lo - 1e-9) & (Ao <= hi + 1e-9)).all(1)
    box_rows.append({"class": CL[k], "n_authentic": len(A), "n_synthetic": len(S),
                     "synthetic_in_own_box": int(own.sum()) if len(S) else None,
                     "synthetic_in_own_box_pct": 100 * own.mean() if len(S) else None,
                     "other_synthetic_in_box_pct": 100 * other.mean(),
                     "other_authentic_in_box_pct": 100 * oth_a.mean()})
box = pd.DataFrame(box_rows)
out["box_containment"] = box_rows
tot_syn = int(box["n_synthetic"].sum())
tot_in = int(box["synthetic_in_own_box"].fillna(0).sum())
out["box_containment_total"] = {"n_synthetic": tot_syn, "in_own_box": tot_in, "pct": 100 * tot_in / tot_syn}
# same test under the antecedent discrete rule, for comparison
tot_in_d, tot_d = 0, 0
for k in range(7):
    A = X[(y == k) & dr]
    S = X[(y == k) & ~dr]
    if len(S):
        tot_in_d += int(((S >= A.min(0) - 1e-9) & (S <= A.max(0) + 1e-9)).all(1).sum())
        tot_d += len(S)
out["box_containment_total_discrete_rule"] = {"n_synthetic": tot_d, "in_own_box": tot_in_d, "pct": 100 * tot_in_d / tot_d}
save_table("box_containment", box)

# (d) non-integral share --------------------------------------------------------------
frac_rows = []
prec = {"Height": 2, "Weight": 1}
for c in num:
    dp = prec.get(c, 0)
    nonint = ~np.isclose(df[c], df[c].round(dp))
    frac_rows.append({"attribute": c, "precision_dp": dp,
                      "nonintegral_authentic_pct": 100 * nonint[fo].mean(),
                      "nonintegral_synthetic_pct": 100 * nonint[~fo].mean()})
frac = pd.DataFrame(frac_rows)
out["nonintegral"] = frac_rows
out["synthetic_with_any_nonintegral_pct"] = 100 * float(np.mean(~dr1[~fo]))
save_table("nonintegral_share", frac)

# (e) nearest-neighbour geometry ---------------------------------------------------------
pre = ColumnTransformer([("n", MinMaxScaler(), num),
                         ("c", OneHotEncoder(sparse_output=False), cfg["data"]["nominal"])])
Z = pre.fit_transform(df)
nn = NearestNeighbors(n_neighbors=2).fit(Z)
dist, ind = nn.kneighbors(Z)
d1, j1 = dist[:, 1], ind[:, 1]
same_class = y[j1] == y
nn_rows = []
for name, m in (("authentic", fo), ("synthetic", ~fo)):
    nn_rows.append({"provenance": name, "n": int(m.sum()),
                    "nn_distance_median": float(np.median(d1[m])),
                    "nn_distance_q1": float(np.percentile(d1[m], 25)),
                    "nn_distance_q3": float(np.percentile(d1[m], 75)),
                    "nn_same_class_pct": 100 * float(same_class[m].mean()),
                    "nn_is_synthetic_pct": 100 * float((~fo[j1])[m].mean()),
                    "nn_distance_zero_pct": 100 * float((d1[m] == 0).mean())})
# authentic-only geometry (what a model trained on authentic data sees)
Za = Z[fo]
dA, iA = NearestNeighbors(n_neighbors=2).fit(Za).kneighbors(Za)
ya = y[fo]
nn_rows.append({"provenance": "authentic (authentic-only space)", "n": int(fo.sum()),
                "nn_distance_median": float(np.median(dA[:, 1])),
                "nn_distance_q1": float(np.percentile(dA[:, 1], 25)),
                "nn_distance_q3": float(np.percentile(dA[:, 1], 75)),
                "nn_same_class_pct": 100 * float((ya[iA[:, 1]] == ya).mean()),
                "nn_is_synthetic_pct": 0.0,
                "nn_distance_zero_pct": 100 * float((dA[:, 1] == 0).mean())})
out["nearest_neighbour"] = nn_rows
np.savez_compressed(cfg["paths"]["raw"] / "nn_distances.npz", d1=d1, same=same_class, authentic=fo, y=y)
save_table("nearest_neighbour", pd.DataFrame(nn_rows))

# composition by class under each rule ---------------------------------------------------
comp = []
for k in range(7):
    m = y == k
    comp.append({"class": CL[k], "total": int(m.sum()),
                 "authentic": int((m & fo).sum()), "synthetic": int((m & ~fo).sum()),
                 "synthetic_pct": 100 * (m & ~fo).sum() / m.sum(),
                 "authentic_discrete_rule": int((m & dr).sum()),
                 "synthetic_discrete_rule": int((m & ~dr).sum())})
comp.append({"class": "Total", "total": len(df), "authentic": int(fo.sum()), "synthetic": int((~fo).sum()),
             "synthetic_pct": 100 * (~fo).mean(), "authentic_discrete_rule": int(dr.sum()),
             "synthetic_discrete_rule": int((~dr).sum())})
out["composition"] = comp
save_table("composition", pd.DataFrame(comp))
save_json("provenance_validation", out)
print("concordance", out["concordance_discrete"])
print("box", out["box_containment_total"], "discrete-rule box", out["box_containment_total_discrete_rule"])
print(pd.DataFrame(nn_rows).round(3).to_string())
print(box.round(1).to_string())
