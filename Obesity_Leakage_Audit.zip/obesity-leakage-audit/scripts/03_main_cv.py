"""Stage 3 - primary experiment: four arms x all classifiers under 10 x 10 repeated stratified
cross-validation. In the full-record arms, every fold is additionally scored separately on its
authentic and its synthetic test records."""
import _common  # noqa: F401
import argparse
import time

from obaudit.config import load_config
from obaudit.cv import run_cv
from obaudit.data import arm_data, feature_columns, load_dataset, provenance
from obaudit.models import valid_for_arm
from obaudit.store import exists, run_key, save_run

ap = argparse.ArgumentParser()
ap.add_argument("--force", action="store_true", help="recompute runs that already exist")
args = ap.parse_args()

cfg = load_config()
df = load_dataset()
auth = provenance(df, "file_order")
models = (cfg["classifiers"]["baselines"] + cfg["classifiers"]["primary"]
          + cfg["classifiers"]["extended"] + cfg["classifiers"]["leakage_probes"])

for arm in cfg["arms"]:
    X, y, idx = arm_data(df, arm)
    num, nom = feature_columns(cfg["arms"][arm]["attributes"])
    if cfg["arms"][arm]["attributes"] == "all":
        X = df.iloc[idx][num + nom].reset_index(drop=True)
    sub = None
    if cfg["arms"][arm]["records"] == "all":
        sub = {"authentic": auth[idx], "synthetic": ~auth[idx]}
    for m in models:
        if not valid_for_arm(m, arm):
            continue
        key = run_key(arm, m)
        if exists(key) and not args.force:
            continue
        t0 = time.time()
        # leakage probes read the raw Height and Weight columns
        res = run_cv(m, X, y, num, nom, subgroups=sub)
        save_run(key, res, idx, y)
        f = res["folds"]
        print(f"{arm} {m:8s} acc {100 * f.accuracy.mean():6.2f}  bal {100 * f.balanced_accuracy.mean():6.2f}  "
              f"kappa {f.kappa.mean():.3f}  [{time.time() - t0:.0f}s]", flush=True)
