"""Stage 1 - data audit: completeness, duplicates, class distribution, descriptive statistics
by provenance, and the label-provenance (BMI) audit."""
import _common  # noqa: F401
import numpy as np
import pandas as pd

from obaudit.config import load_config
from obaudit.data import bmi, bmi_rule, label_codes, load_dataset, provenance
from obaudit.metrics import confusion
from obaudit.store import save_json, save_table

cfg = load_config()
CL = cfg["data"]["classes"]
df = load_dataset()
y = label_codes(df[cfg["data"]["label"]])
auth = provenance(df, "file_order")
auth_disc = provenance(df, "discrete")

feat = df.drop(columns=[cfg["data"]["label"]])
dup_all = df.duplicated(keep=False).to_numpy()
dup_extra = df.duplicated(keep="first").to_numpy()

# exact duplicates: where they sit
dup_groups = df[dup_all].groupby(list(df.columns), sort=False).apply(lambda g: list(g.index), include_groups=False)
dup_detail = []
for rows in dup_groups:
    dup_detail.append({"rows_1based": [r + 1 for r in rows],
                       "n_copies": len(rows),
                       "n_in_survey_block": int(auth[rows].sum()),
                       "n_in_synthetic_block": int((~auth[rows]).sum()),
                       "class": df.loc[rows[0], cfg["data"]["label"]]})

b = bmi(df).to_numpy()
rule = bmi_rule(b)
agree = rule == y

audit = {
    "n_records": len(df), "n_attributes": feat.shape[1],
    "n_numeric": len(cfg["data"]["numeric"]), "n_nominal": len(cfg["data"]["nominal"]),
    "missing_cells": int(df.isna().sum().sum()),
    "exact_duplicate_rows_extra": int(dup_extra.sum()),
    "exact_duplicate_rows_all_copies": int(dup_all.sum()),
    "duplicate_groups": dup_detail,
    "duplicates_extra_in_survey_block": int((dup_extra & auth).sum()),
    "duplicates_extra_in_synthetic_block": int((dup_extra & ~auth).sum()),
    "class_counts_full": {c: int((y == k).sum()) for k, c in enumerate(CL)},
    "class_counts_authentic": {c: int(((y == k) & auth).sum()) for k, c in enumerate(CL)},
    "class_counts_synthetic": {c: int(((y == k) & ~auth).sum()) for k, c in enumerate(CL)},
    "n_authentic": int(auth.sum()), "n_synthetic": int((~auth).sum()),
    "authentic_pct": 100 * auth.mean(), "synthetic_pct": 100 * (~auth).mean(),
    "n_authentic_discrete_rule": int(auth_disc.sum()),
    "authentic_pct_discrete_rule": 100 * auth_disc.mean(),
    "published_authentic_pct": cfg["data"]["published_authentic_pct"],
    "majority_baseline_full_pct": 100 * np.bincount(y).max() / len(y),
    "majority_baseline_authentic_pct": 100 * np.bincount(y[auth]).max() / auth.sum(),
    "majority_baseline_authentic_discrete_pct": 100 * np.bincount(y[auth_disc]).max() / auth_disc.sum(),
    "bmi_min": float(b.min()), "bmi_max": float(b.max()),
    "bmi_rule_agreement_pct": 100 * agree.mean(),
    "bmi_rule_agreement_authentic_pct": 100 * agree[auth].mean(),
    "bmi_rule_agreement_synthetic_pct": 100 * agree[~auth].mean(),
    "bmi_rule_n_agree": int(agree.sum()),
    "bmi_rule_n_disagree_authentic": int((~agree & auth).sum()),
    "bmi_rule_n_disagree_synthetic": int((~agree & ~auth).sum()),
    "bmi_rule_disagreements_adjacent_pct": 100 * float(np.mean(np.abs(rule[~agree] - y[~agree]) == 1)),
    "bmi_rule_confusion": confusion(y, rule).tolist(),
}
# BMI statistics by class and provenance
rows = []
for k, c in enumerate(CL):
    m = y == k
    rows.append({"class": c, "n": int(m.sum()),
                 "bmi_mean": b[m].mean(), "bmi_sd": b[m].std(ddof=1),
                 "bmi_min": b[m].min(), "bmi_max": b[m].max(),
                 "agree_pct": 100 * agree[m].mean(),
                 "agree_pct_authentic": 100 * agree[m & auth].mean() if (m & auth).any() else np.nan,
                 "agree_pct_synthetic": 100 * agree[m & ~auth].mean() if (m & ~auth).any() else np.nan,
                 "n_authentic": int((m & auth).sum()), "n_synthetic": int((m & ~auth).sum())})
bmi_tab = pd.DataFrame(rows)
audit["bmi_by_class"] = bmi_tab.to_dict(orient="records")
save_table("bmi_by_class", bmi_tab)

# descriptive statistics by provenance
desc = []
for c in cfg["data"]["numeric"]:
    v = df[c].to_numpy()
    from scipy import stats
    d = (v[auth].mean() - v[~auth].mean()) / np.sqrt((v[auth].var(ddof=1) + v[~auth].var(ddof=1)) / 2)
    desc.append({"attribute": c, "type": "numeric",
                 "full": f"{v.mean():.2f} ({v.std(ddof=1):.2f})",
                 "authentic": f"{v[auth].mean():.2f} ({v[auth].std(ddof=1):.2f})",
                 "synthetic": f"{v[~auth].mean():.2f} ({v[~auth].std(ddof=1):.2f})",
                 "full_mean": v.mean(), "auth_mean": v[auth].mean(), "syn_mean": v[~auth].mean(),
                 "effect": d, "effect_name": "Cohen d",
                 "n_unique_authentic": int(len(np.unique(v[auth]))),
                 "n_unique_synthetic": int(len(np.unique(v[~auth]))),
                 "p": stats.mannwhitneyu(v[auth], v[~auth]).pvalue})
for c in cfg["data"]["nominal"]:
    v = df[c]
    top = v.value_counts().index[0]
    ct = pd.crosstab(auth, v)
    chi2, p, dof, _ = stats.chi2_contingency(ct)
    cramer = np.sqrt(chi2 / (ct.to_numpy().sum() * (min(ct.shape) - 1)))
    desc.append({"attribute": c, "type": "nominal", "level": top,
                 "full": f"{100 * (v == top).mean():.1f}%",
                 "authentic": f"{100 * (v[auth] == top).mean():.1f}%",
                 "synthetic": f"{100 * (v[~auth] == top).mean():.1f}%",
                 "full_mean": 100 * (v == top).mean(), "auth_mean": 100 * (v[auth] == top).mean(),
                 "syn_mean": 100 * (v[~auth] == top).mean(),
                 "effect": cramer, "effect_name": "Cramer V",
                 "n_unique_authentic": int(v[auth].nunique()),
                 "n_unique_synthetic": int(v[~auth].nunique()), "p": p})
desc = pd.DataFrame(desc)
save_table("descriptives_by_provenance", desc)
audit["descriptives"] = desc.to_dict(orient="records")
audit["bmi_values"] = None  # raw BMI values are recomputed where needed
save_json("data_audit", audit)
print(f"records {audit['n_records']}  authentic {audit['n_authentic']} ({audit['authentic_pct']:.2f}%)  "
      f"BMI rule {audit['bmi_rule_agreement_pct']:.2f}%  duplicates {audit['exact_duplicate_rows_extra']}")
