"""Shared bootstrap for the numbered scripts: puts src/ on the import path."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

import warnings  # noqa: E402

warnings.filterwarnings("ignore")
