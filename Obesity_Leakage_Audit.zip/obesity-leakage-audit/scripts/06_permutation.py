"""Stage 6 - label-permutation tests (Ojala & Garriga, 2010) for the authentic-record arms.

For each permutation the labels are shuffled, stratified 10-fold cross-validation is re-run,
and the fold-mean statistic is recorded. The p-value is (1 + #{null >= observed}) / (N + 1).
A significant result means the attributes carry information about the label beyond what a
classifier exploiting the class frequencies alone could achieve."""
import _common  # noqa: F401
import warnings

import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from obaudit.config import load_config
from obaudit.cv import splits
from obaudit.data import arm_data, feature_columns, load_dataset
from obaudit.metrics import fold_metrics
from obaudit.models import make_model
from obaudit.stats import perm_pvalue
from obaudit.store import save_json, save_table

cfg = load_config()
SEED = cfg["study"]["seed"]
NPERM = cfg["statistics"]["permutations"]
STATS = ["accuracy", "balanced_accuracy", "kappa", "macro_f1"]
df = load_dataset()


def cv_stat(name, X, y, num, nom):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        vals = []
        for _, _, tr, te in splits(y, n_repeats=1, seed=SEED):
            m = make_model(name, num, nom)
            m.fit(X.iloc[tr], y[tr])
            vals.append(fold_metrics(y[te], np.asarray(m.predict(X.iloc[te]))))
    return {s: float(np.mean([v[s] for v in vals])) for s in STATS}


def chunk(name, X, y, num, nom, seeds):
    out = []
    for s in seeds:
        yp = np.random.default_rng(s).permutation(y)
        out.append(cv_stat(name, X, yp, num, nom))
    return out


rows, nulls = [], {}
for arm in ("C", "D"):
    X, y, _ = arm_data(df, arm)
    num, nom = feature_columns(cfg["arms"][arm]["attributes"])
    for name in cfg["statistics"]["permutation_classifiers"]:
        obs = cv_stat(name, X, y, num, nom)
        seeds = [SEED * 1000 + i for i in range(NPERM)]
        parts = np.array_split(seeds, cfg["cv"]["n_jobs"] * 4)
        res = Parallel(n_jobs=cfg["cv"]["n_jobs"])(delayed(chunk)(name, X, y, num, nom, list(p)) for p in parts)
        null = [r for part in res for r in part]
        nulls[f"{arm}__{name}"] = {s: [n[s] for n in null] for s in STATS}
        for s in STATS:
            nv = np.array([n[s] for n in null])
            rows.append({"arm": arm, "classifier": name, "statistic": s, "observed": obs[s],
                         "null_mean": nv.mean(), "null_sd": nv.std(ddof=1),
                         "null_q95": np.percentile(nv, 95), "p": perm_pvalue(obs[s], nv),
                         "n_perm": NPERM})
        print(arm, name, {k: round(v, 4) for k, v in obs.items()},
              "p(bal)", rows[-3]["p"], flush=True)
tab = pd.DataFrame(rows)
save_table("permutation", tab)
save_json("permutation", {"summary": tab.to_dict(orient="records"), "null": nulls})
