"""Stage 10 - sensitivity analyses.

S1  antecedent provenance rule (discrete values, 496 records) for arms C and D
S2  exact duplicates removed, all arms
S3  coarser outcomes on authentic records: three classes, obese vs not, BMI >= 25 vs not
    (with permutation tests for logistic regression and the decision tree)
S4  class-weighted learners on authentic records
S5  random-forest feature-subsampling sweep (max_features) in arms A and B
S6  nested cross-validation with hyperparameter tuning (inner 5-fold, balanced accuracy)
"""
import _common  # noqa: F401
import argparse
import warnings

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from sklearn.model_selection import GridSearchCV, StratifiedKFold

from obaudit.config import load_config
from obaudit.cv import run_cv, splits
from obaudit.data import arm_data, feature_columns, load_dataset
from obaudit.metrics import fold_metrics, pooled_metrics
from obaudit.models import make_model
from obaudit.stats import corrected_ci, perm_pvalue
from obaudit.store import exists, load_folds, load_oof, run_key, save_json, save_run, save_table

ap = argparse.ArgumentParser()
ap.add_argument("--only", nargs="*", default=None, help="subset of S1..S6 to run")
args = ap.parse_args()
cfg = load_config()
SEED = cfg["study"]["seed"]
LEARNERS = cfg["classifiers"]["primary"] + cfg["classifiers"]["extended"]
df = load_dataset()
OUT = {}


def todo(s):
    return args.only is None or s in args.only


def summary(key, extra=None):
    f = load_folds(key)
    z = load_oof(key)
    r = float((f.n_test / f.n_train).mean())
    row = {"key": key, "n_records": int(len(z["y"]))}
    for met in ("accuracy", "balanced_accuracy", "kappa", "macro_f1"):
        mean, lo, hi, _ = corrected_ci(f[met].to_numpy(), r)
        row.update({met: mean, met + "_lo": lo, met + "_hi": hi})
    P, y = z["proba"].astype(float), z["y"].astype(int)
    row["auc_macro"] = float(np.mean([pooled_metrics(y, P[i])["auc_macro"] for i in range(P.shape[0])]))
    row["majority_pct"] = 100 * np.bincount(y).max() / len(y)
    if extra:
        row.update(extra)
    return row


def run(tag, arm, model, X, y, num, nom, **kw):
    key = run_key(arm, model, tag)
    if not exists(key):
        res = run_cv(model, X, y, num, nom, **kw)
        save_run(key, res, np.arange(len(y)), y)
    return key


# S1 -------------------------------------------------------------------------------------
if todo("S1"):
    rows = []
    for arm in ("C", "D"):
        X, y, idx = arm_data(df, arm, rule="discrete")
        num, nom = feature_columns(cfg["arms"][arm]["attributes"])
        for m in ["MAJ"] + LEARNERS:
            rows.append(summary(run("discrete", arm, m, X, y, num, nom), {"arm": arm, "classifier": m}))
    OUT["S1_discrete_rule"] = rows
    save_table("sens_S1_discrete_rule", pd.DataFrame(rows))
    print("S1 done", flush=True)

# S2 -------------------------------------------------------------------------------------
if todo("S2"):
    rows = []
    for arm in cfg["arms"]:
        X, y, idx = arm_data(df, arm, deduplicate=True)
        num, nom = feature_columns(cfg["arms"][arm]["attributes"])
        for m in ["MAJ"] + LEARNERS:
            rows.append(summary(run("dedup", arm, m, X, y, num, nom), {"arm": arm, "classifier": m}))
    OUT["S2_deduplicated"] = rows
    save_table("sens_S2_deduplicated", pd.DataFrame(rows))
    print("S2 done", flush=True)

# S3 -------------------------------------------------------------------------------------
OUTCOMES = {"three_class": {0: 0, 1: 0, 2: 1, 3: 1, 4: 2, 5: 2, 6: 2},
            "obese_vs_not": {0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 1, 6: 1},
            "bmi25_vs_not": {0: 0, 1: 0, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1}}


def perm_job(name, X, y, num, nom, seeds):
    out = []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for s in seeds:
            yp = np.random.default_rng(s).permutation(y)
            vals = []
            for _, _, tr, te in splits(yp, n_repeats=1, seed=SEED):
                mdl = make_model(name, num, nom)
                mdl.fit(X.iloc[tr], yp[tr])
                vals.append(fold_metrics(yp[te], np.asarray(mdl.predict(X.iloc[te])))["balanced_accuracy"])
            out.append(float(np.mean(vals)))
    return out


if todo("S3"):
    rows = []
    for arm in ("C", "D"):
        X, y7, idx = arm_data(df, arm)
        num, nom = feature_columns(cfg["arms"][arm]["attributes"])
        for oname, mp in OUTCOMES.items():
            y = np.vectorize(mp.get)(y7)
            for m in ["MAJ"] + LEARNERS:
                key = run(f"outcome-{oname}", arm, m, X, y, num, nom)
                extra = {"arm": arm, "classifier": m, "outcome": oname, "n_classes": int(len(np.unique(y)))}
                if m in ("LR", "DT"):
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        vals = []
                        for _, _, tr, te in splits(y, n_repeats=1, seed=SEED):
                            mdl = make_model(m, num, nom)
                            mdl.fit(X.iloc[tr], y[tr])
                            vals.append(fold_metrics(y[te], np.asarray(mdl.predict(X.iloc[te])))["balanced_accuracy"])
                    obs = float(np.mean(vals))
                    seeds = [SEED * 1000 + i for i in range(cfg["statistics"]["permutations"])]
                    parts = np.array_split(seeds, cfg["cv"]["n_jobs"] * 4)
                    null = [v for p in Parallel(n_jobs=cfg["cv"]["n_jobs"])(
                        delayed(perm_job)(m, X, y, num, nom, list(p)) for p in parts) for v in p]
                    extra.update({"perm_observed_bal": obs, "perm_null_mean": float(np.mean(null)),
                                  "perm_null_q95": float(np.percentile(null, 95)),
                                  "perm_p": perm_pvalue(obs, null)})
                rows.append(summary(key, extra))
            print("S3", arm, oname, flush=True)
    OUT["S3_outcomes"] = rows
    save_table("sens_S3_outcomes", pd.DataFrame(rows))

# S4 -------------------------------------------------------------------------------------
if todo("S4"):
    rows = []
    for arm in ("C", "D"):
        X, y, idx = arm_data(df, arm)
        num, nom = feature_columns(cfg["arms"][arm]["attributes"])
        for m in ("LR", "DT", "RF", "GB", "SVM"):
            key = run("balanced", arm, m, X, y, num, nom, model_kwargs={"class_weight": "balanced"})
            rows.append(summary(key, {"arm": arm, "classifier": m}))
    OUT["S4_class_weighted"] = rows
    save_table("sens_S4_class_weighted", pd.DataFrame(rows))
    print("S4 done", flush=True)

# S5 -------------------------------------------------------------------------------------
if todo("S5"):
    rows = []
    for arm in ("A", "B"):
        X, y, idx = arm_data(df, arm)
        num, nom = feature_columns(cfg["arms"][arm]["attributes"])
        for mf in cfg["sensitivity"]["rf_max_features"]:
            key = run(f"rfmf-{mf}", arm, "RF", X, y, num, nom, model_kwargs={"overrides": {"max_features": mf}})
            rows.append(summary(key, {"arm": arm, "classifier": "RF", "max_features": str(mf)}))
    OUT["S5_rf_max_features"] = rows
    save_table("sens_S5_rf_max_features", pd.DataFrame(rows))
    print("S5 done", flush=True)

# S6 -------------------------------------------------------------------------------------
def nested_fold(name, X, y, num, nom, tr, te, grid):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        inner = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
        gs = GridSearchCV(make_model(name, num, nom), grid, cv=inner, scoring="balanced_accuracy",
                          n_jobs=1, refit=True)
        gs.fit(X.iloc[tr], y[tr])
        res = fold_metrics(y[te], np.asarray(gs.predict(X.iloc[te])))
    res["best_params"] = str(gs.best_params_)
    return res


if todo("S6"):
    rows, chosen = [], []
    for arm in cfg["arms"]:
        X, y, idx = arm_data(df, arm)
        num, nom = feature_columns(cfg["arms"][arm]["attributes"])
        for m, grid in cfg["sensitivity"]["tuning_grid"].items():
            res = Parallel(n_jobs=cfg["cv"]["n_jobs"])(
                delayed(nested_fold)(m, X, y, num, nom, tr, te, grid)
                for (_, _, tr, te) in splits(y, n_repeats=1, seed=SEED))
            R = pd.DataFrame(res)
            fixed = load_folds(run_key(arm, m))
            fixed1 = fixed[fixed.repeat == 0]
            row = {"arm": arm, "classifier": m}
            for met in ("accuracy", "balanced_accuracy", "kappa", "macro_f1"):
                row[met] = R[met].mean()
                row[met + "_sd"] = R[met].std(ddof=1)
                row[met + "_fixed_all_repeats"] = fixed[met].mean()
            row["modal_params"] = R.best_params.mode().iloc[0]
            row["n_distinct_params"] = int(R.best_params.nunique())
            rows.append(row)
            print("S6", arm, m, round(row["balanced_accuracy"], 4), flush=True)
    OUT["S6_nested_tuning"] = rows
    save_table("sens_S6_nested_tuning", pd.DataFrame(rows))

# merge with any previously saved sensitivity results
try:
    from obaudit.store import load_json
    prev = load_json("sensitivity")
except FileNotFoundError:
    prev = {}
prev.update(OUT)
save_json("sensitivity", prev)
