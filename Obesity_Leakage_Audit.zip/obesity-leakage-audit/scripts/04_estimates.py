"""Stage 4 - point estimates and uncertainty for every primary run.

Fold-level metrics: mean, SD across the 100 folds, and corrected resampled-t 95% CI.
Pooled metrics (AUC, Brier, log loss, ECE, and hard metrics on the complete out-of-fold set):
mean and SD across the 10 repetitions, with a percentile bootstrap CI (records resampled,
the same resample applied to every repetition, metric averaged over repetitions)."""
import _common  # noqa: F401
import glob
import os

import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from obaudit.config import load_config
from obaudit.data import load_dataset, provenance
from obaudit.metrics import (FOLD_METRICS, bootstrap_pooled, confusion, fold_metrics, per_class_recall,
                             pooled_metrics, reliability_curve)
from obaudit.stats import bootstrap_ci, corrected_ci
from obaudit.store import load_folds, load_oof, save_json

cfg = load_config()
B = cfg["statistics"]["bootstrap"]
SEED = cfg["study"]["seed"]
df = load_dataset()
auth_full = provenance(df, "file_order")


def summarise(key):
    tag, arm, model = key.split("__")
    f = load_folds(key)
    ratio = float((f.n_test / f.n_train).mean())
    res = {"arm": arm, "model": model, "n_records": int(f.n_test.sum() / f.repeat.nunique()),
           "test_train_ratio": ratio}
    for m in FOLD_METRICS:
        mean, lo, hi, se = corrected_ci(f[m].to_numpy(), ratio)
        res[m] = {"mean": mean, "sd": float(f[m].std(ddof=1)), "lo": lo, "hi": hi,
                  "sd_pop_repeat1": float(f.loc[f.repeat == 0, m].std(ddof=0))}
    res["fit_s_mean"] = float(f.fit_s.mean())
    res["predict_s_mean"] = float(f.predict_s.mean())
    z = load_oof(key)
    P, pred, y = z["proba"].astype(float), z["pred"].astype(int), z["y"].astype(int)
    R = P.shape[0]
    pooled = [pooled_metrics(y, P[r]) for r in range(R)]
    hard = [fold_metrics(y, pred[r]) for r in range(R)]
    for m in pooled[0]:
        v = np.array([p[m] for p in pooled])
        res[m] = {"mean": float(v.mean()), "sd": float(v.std(ddof=1))}
    for m in hard[0]:
        v = np.array([p[m] for p in hard])
        res["pooled_" + m] = {"mean": float(v.mean()), "sd": float(v.std(ddof=1))}
    # bootstrap CI for pooled metrics (vectorised; identical replicates to the naive loop)
    boots = bootstrap_pooled(y, P, B, SEED, cfg["statistics"]["ece_bins"])
    for m in boots:
        lo, hi = bootstrap_ci(boots[m])
        res[m]["lo"], res[m]["hi"] = float(lo), float(hi)
    C = sum(confusion(y, pred[r]) for r in range(R))
    res["confusion_sum"] = C.tolist()
    res["per_class_recall"] = per_class_recall(np.tile(y, R), pred.ravel()).tolist()
    res["per_class_precision"] = [float(C[k, k] / C[:, k].sum()) if C[:, k].sum() else None for k in range(7)]
    res["class_support"] = np.bincount(y, minlength=7).tolist()
    res["reliability"] = reliability_curve(np.tile(y, R), P.reshape(-1, 7), cfg["statistics"]["ece_bins"])
    # provenance subgroups (full-record arms only)
    idx = z["index"]
    if len(idx) == len(df):
        a = auth_full[idx]
        for g, m_ in (("authentic", a), ("synthetic", ~a)):
            vals = [fold_metrics(y[m_], pred[r][m_]) for r in range(R)]
            res["subgroup_" + g] = {k: {"mean": float(np.mean([v[k] for v in vals])),
                                        "sd": float(np.std([v[k] for v in vals], ddof=1))} for k in vals[0]}
            res["subgroup_" + g]["n"] = int(m_.sum())
            res["subgroup_" + g]["auc_macro"] = float(np.mean([pooled_metrics(y[m_], P[r][m_])["auc_macro"] for r in range(R)]))
            res["subgroup_" + g]["per_class_recall"] = per_class_recall(np.tile(y[m_], R), pred[:, m_].ravel()).tolist()
    return key, res


keys = sorted(os.path.basename(p).replace("__oof.npz", "")
              for p in glob.glob(str(cfg["paths"]["raw"] / "main__*__oof.npz")))
out = Parallel(n_jobs=cfg["cv"]["n_jobs"])(delayed(summarise)(k) for k in keys)
est = {}
for key, res in out:
    est.setdefault(res["arm"], {})[res["model"]] = res
save_json("estimates", est)
rows = []
for arm in est:
    for m, r in est[arm].items():
        rows.append({"arm": arm, "model": m, "acc": 100 * r["accuracy"]["mean"],
                     "bal": 100 * r["balanced_accuracy"]["mean"], "kappa": r["kappa"]["mean"],
                     "auc": r["auc_macro"]["mean"], "brier": r["brier"]["mean"]})
print(pd.DataFrame(rows).round(3).to_string())
