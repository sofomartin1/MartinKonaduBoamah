"""Stage 14 - consistency gate.

Independently re-derives the numbers shown in the display tables and figures from the raw
outputs (fold CSVs, out-of-fold arrays, the dataset itself) and checks every cross-display
identity. Writes results/consistency_report.json and exits non-zero on any failure, which
stops run_all.py before the Word document is built."""
import _common  # noqa: F401
import re
import sys

import numpy as np

from obaudit.config import load_config
from obaudit.cv import splits
from obaudit.data import arm_data, bmi, bmi_rule, label_codes, load_dataset, provenance
from obaudit.metrics import fold_metrics, per_class_recall
from obaudit.models import SHORT
from obaudit.stats import corrected_ci, perm_pvalue
from obaudit.store import load_folds, load_json, load_oof, load_subgroups, run_key, save_json

cfg = load_config()
CL = cfg["data"]["classes"]
LEARN = cfg["classifiers"]["primary"] + cfg["classifiers"]["extended"]
ARMS = list(cfg["arms"])
df = load_dataset()
y = label_codes(df[cfg["data"]["label"]])
auth = provenance(df, "file_order")
audit, prov, est = load_json("data_audit"), load_json("provenance_validation"), load_json("estimates")
inf, perm, pa = load_json("inference"), load_json("permutation"), load_json("provenance_aware")
sens, rmr, FD = load_json("sensitivity"), load_json("rapidminer_reconciliation"), load_json("figure_data")
TT = {t["id"]: t for t in load_json("display_tables")}
CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "pass": bool(ok), "detail": str(detail)})


def close(a, b, tol=1e-9):
    return abs(float(a) - float(b)) <= tol


def cell(tid, row_pred, col):
    t = TT[tid]
    j = t["columns"].index(col)
    return [r[j] for r in t["rows"] if row_pred(r)]


def num(s):
    return float(re.match(r"\s*([-+]?\d[\d,]*\.?\d*)", s).group(1).replace(",", ""))


# ---------------------------------------------------------------- 1 data and provenance
check("records = 2111", len(df) == 2111 == audit["n_records"])
check("authentic + synthetic = total", audit["n_authentic"] + audit["n_synthetic"] == len(df))
check("authentic count identical across audit, provenance, arms",
      audit["n_authentic"] == int(auth.sum()) == prov["composition"][7]["authentic"] == est["C"]["MAJ"]["n_records"]
      == est["D"]["MAJ"]["n_records"] == FD["fig01"]["authentic"] == sum(FD["fig03"]["authentic"]))
check("full-record arm sizes", est["A"]["MAJ"]["n_records"] == est["B"]["MAJ"]["n_records"] == len(df))
for k, c in enumerate(CL):
    comp = prov["composition"][k]
    check(f"composition row sums ({c})", comp["authentic"] + comp["synthetic"] == comp["total"] == int((y == k).sum()))
    check(f"class support in arm C equals authentic count ({c})", est["C"]["LR"]["class_support"][k] == comp["authentic"])
c3 = TT["T3"]
for r in c3["rows"][:7]:
    check(f"T3 row totals ({r[0]})", num(r[1]) + num(r[2]) == num(r[3]))
check("T3 grand total", num(c3["rows"][7][3]) == len(df) and num(c3["rows"][7][1]) == audit["n_authentic"])
cd = prov["concordance_discrete"]
check("concordance cells sum to n", sum(cd[k] for k in ("both_authentic", "file_authentic_rule_synthetic",
                                                        "file_synthetic_rule_authentic", "both_synthetic")) == len(df))
check("concordance file-authentic margin", cd["both_authentic"] + cd["file_authentic_rule_synthetic"] == audit["n_authentic"])
check("discrete-rule count", cd["both_authentic"] + cd["file_synthetic_rule_authentic"] == audit["n_authentic_discrete_rule"]
      == int(provenance(df, "discrete").sum()))
b = bmi(df).to_numpy()
rule = bmi_rule(b)
check("BMI agreement recomputed", close(100 * np.mean(rule == y), audit["bmi_rule_agreement_pct"]))
check("BMI confusion trace = agreements", int(np.trace(np.array(audit["bmi_rule_confusion"]))) == audit["bmi_rule_n_agree"] == FD["fig02"]["n_agree"])
check("BMI-rule probe accuracy in arm A equals audit agreement (to fold averaging)",
      abs(100 * est["A"]["BMIRULE"]["pooled_accuracy"]["mean"] - audit["bmi_rule_agreement_pct"]) < 1e-9)
check("box containment totals", sum(x["synthetic_in_own_box"] or 0 for x in prov["box_containment"]) == prov["box_containment_total"]["in_own_box"])
check("synthetic block runs sum to synthetic count", sum(r["n"] for r in prov["synthetic_block_runs"]) == audit["n_synthetic"])
check("duplicates split", audit["duplicates_extra_in_survey_block"] + audit["duplicates_extra_in_synthetic_block"] == audit["exact_duplicate_rows_extra"])
check("majority baseline (authentic) = Normal Weight share",
      close(audit["majority_baseline_authentic_pct"], 100 * prov["composition"][1]["authentic"] / audit["n_authentic"]))
check("majority classifier accuracy in C close to Normal Weight share",
      abs(100 * est["C"]["MAJ"]["accuracy"]["mean"] - audit["majority_baseline_authentic_pct"]) < 0.05,
      f"{100 * est['C']['MAJ']['accuracy']['mean']:.4f} vs {audit['majority_baseline_authentic_pct']:.4f}")

# -------------------------------------------------------------- 2 partitions are shared
sa = splits(arm_data(df, "A")[1])
sb = splits(arm_data(df, "B")[1])
check("arms A and B share partitions", all(np.array_equal(x[3], z[3]) for x, z in zip(sa, sb)))
sc_ = splits(arm_data(df, "C")[1])
sd_ = splits(arm_data(df, "D")[1])
check("arms C and D share partitions", all(np.array_equal(x[3], z[3]) for x, z in zip(sc_, sd_)))

# -------------------------------------------------- 3 estimates re-derived from raw files
bad = []
for a in ARMS:
    for m, r in est[a].items():
        f = load_folds(run_key(a, m))
        z = load_oof(run_key(a, m))
        if len(f) != cfg["cv"]["n_splits"] * cfg["cv"]["n_repeats"]:
            bad.append(f"{a}/{m}: folds {len(f)}")
        if (z["pred"] < 0).any():
            bad.append(f"{a}/{m}: missing OOF prediction")
        ratio = float((f.n_test / f.n_train).mean())
        for met in ("accuracy", "balanced_accuracy", "kappa", "macro_f1", "mcc", "macro_precision"):
            mean, lo, hi, _ = corrected_ci(f[met].to_numpy(), ratio)
            if not (close(mean, r[met]["mean"]) and close(lo, r[met]["lo"]) and close(hi, r[met]["hi"])):
                bad.append(f"{a}/{m}/{met}")
        # fold metrics re-scored from the stored out-of-fold predictions
        for rep, fo, tr, te in splits(z["y"])[:10]:
            fm = fold_metrics(z["y"][te], z["pred"][rep][te])
            row = f[(f.repeat == rep) & (f.fold == fo)].iloc[0]
            if not close(fm["accuracy"], row.accuracy) or not close(fm["kappa"], row.kappa):
                bad.append(f"{a}/{m}: OOF vs fold record r{rep}f{fo}")
        C = np.array(r["confusion_sum"])
        if C.sum() != z["pred"].size:
            bad.append(f"{a}/{m}: confusion total")
        pcr = per_class_recall(np.tile(z["y"], z["pred"].shape[0]), z["pred"].ravel())
        if not np.allclose(np.nan_to_num(pcr, nan=-1), np.nan_to_num(np.array(r["per_class_recall"], float), nan=-1)):
            bad.append(f"{a}/{m}: per-class recall")
        with np.errstate(invalid="ignore"):
            rc = np.diag(C) / C.sum(1)
        if not np.allclose(np.nan_to_num(rc, nan=-1), np.nan_to_num(np.array(r["per_class_recall"], float), nan=-1)):
            bad.append(f"{a}/{m}: recall vs confusion")
check("all estimates re-derived from raw fold and OOF files", not bad, bad[:10])

# --------------------------------------------------------- 4 performance tables T6/T7
bad = []
for tid, arms in (("T6", "AB"), ("T7", "CD")):
    t = TT[tid]
    arm = None
    for r in t["rows"]:
        arm = r[0] or arm
        m = next(k for k, v in SHORT.items() if v == r[1])
        e = est[arm][m]
        exp = [f"{100 * e['accuracy']['mean']:.2f} [{100 * e['accuracy']['lo']:.2f}, {100 * e['accuracy']['hi']:.2f}]",
               f"{100 * e['balanced_accuracy']['mean']:.2f} [{100 * e['balanced_accuracy']['lo']:.2f}, {100 * e['balanced_accuracy']['hi']:.2f}]",
               f"{100 * e['macro_f1']['mean']:.2f}", f"{e['kappa']['mean']:.3f} [{e['kappa']['lo']:.3f}, {e['kappa']['hi']:.3f}]",
               f"{e['mcc']['mean']:.3f}", f"{e['auc_macro']['mean']:.3f}"]
        if r[2:] != exp:
            bad.append(f"{tid} {arm} {m}")
check("T6/T7 cells match estimates", not bad, bad)
check("T6 lists every run in arms A and B", len(TT["T6"]["rows"]) == len(est["A"]) + len(est["B"]))
check("T7 lists every run in arms C and D", len(TT["T7"]["rows"]) == len(est["C"]) + len(est["D"]))
for a in ARMS:
    check(f"T4 majority accuracy arm {a}", cell("T4", lambda r: r[0] == a, "Majority-class accuracy (%)")[0] == f"{100 * est[a]['MAJ']['accuracy']['mean']:.2f}")
    check(f"T4 n arm {a}", num(cell("T4", lambda r: r[0] == a, "n")[0]) == est[a]["MAJ"]["n_records"])

# ---------------------------------------------------------------- 5 decomposition
bad = []
for c in LEARN:
    for met in ("accuracy", "balanced_accuracy", "kappa"):
        D = {d["contrast"]: d for d in inf["decomposition"] if d["classifier"] == c and d["metric"] == met}
        mA, mB, mC, mD = (est[a][c][met]["mean"] for a in "ABCD")
        for con, val in (("label_full", mA - mB), ("label_authentic", mC - mD), ("synthetic_all", mA - mC),
                         ("synthetic_behaviour", mB - mD), ("both", mA - mD), ("interaction", (mA - mB) - (mC - mD))):
            if not close(D[con]["diff"], val, 1e-12):
                bad.append(f"{c}/{met}/{con}")
            if not (D[con]["lo"] <= D[con]["diff"] <= D[con]["hi"]):
                bad.append(f"{c}/{met}/{con} CI")
check("decomposition contrasts equal differences of arm means", not bad, bad)
bad = []
for c_i, c in enumerate(LEARN):
    for met in ("accuracy", "balanced_accuracy"):
        for con in ("label_full", "synthetic_all", "both", "interaction"):
            d = next(x for x in inf["decomposition"] if x["classifier"] == c and x["metric"] == met and x["contrast"] == con)
            if not close(FD["fig06"][f"{met}_{con}"][c_i], round(100 * d["diff"], 4), 1e-9):
                bad.append(f"fig06 {c} {met} {con}")
check("Figure 6 values equal decomposition", not bad, bad)
bad = []
t8 = TT["T8"]
met = None
for r in t8["rows"]:
    met = {"Accuracy": "accuracy", "Balanced accuracy": "balanced_accuracy"}.get(r[0], met)
    c = next(k for k, v in SHORT.items() if v == r[1])
    for j, con in enumerate(("label_full", "label_authentic", "synthetic_all", "synthetic_behaviour", "both", "interaction")):
        d = next(x for x in inf["decomposition"] if x["classifier"] == c and x["metric"] == met and x["contrast"] == con)
        if num(r[2 + j]) != round(100 * d["diff"], 2) and f"{100 * d['diff']:.2f}" != r[2 + j].split("*")[0].split(" ")[0]:
            bad.append(f"T8 {c} {con}")
        if ("*" in r[2 + j]) != (d["p_holm"] < 0.05):
            bad.append(f"T8 star {c} {con}")
check("T8 cells and significance marks match inference", not bad, bad)

# -------------------------------------------------------------------- 6 figure 5 / 9 / 11
bad = []
for met, sc in (("accuracy", 100), ("balanced_accuracy", 100), ("kappa", 1)):
    for a in ARMS:
        exp = [round(est[a][c][met]["mean"] * sc, 4) for c in LEARN]
        if not np.allclose(FD["fig05"][f"{met}_{a}"]["mean"], exp, atol=1e-9):
            bad.append(f"{met}{a}")
        if not close(FD["fig05"][f"{met}_{a}"]["majority"], round(est[a]["MAJ"][met]["mean"] * sc, 4), 1e-9):
            bad.append(f"{met}{a} majority")
check("Figure 5 values equal estimates", not bad, bad)
check("Figure 9 values equal per-class recall", all(np.allclose(np.nan_to_num(np.array(FD["fig09"][a], float), nan=-1),
      np.nan_to_num(np.round(np.array([est[a][c]["per_class_recall"] for c in LEARN], float) * 100, 4), nan=-1)) for a in ARMS))
check("Figure 11 ECE equals T11", all(close(FD["fig11"][f"{a}_{c}_ece"], est[a][c]["ece"]["mean"]) for a in ARMS for c in ("LR", "BT", "RF", "GB")))
bad = []
arm = None
for r in TT["T11"]["rows"]:
    arm = r[0] or arm
    c = next(k for k, v in SHORT.items() if v == r[1])
    if r[2] != f"{est[arm][c]['auc_macro']['mean']:.3f} [{est[arm][c]['auc_macro']['lo']:.3f}, {est[arm][c]['auc_macro']['hi']:.3f}]":
        bad.append(f"T11 {arm} {c}")
    if not (est[arm][c]["brier"]["lo"] <= est[arm][c]["brier"]["mean"] <= est[arm][c]["brier"]["hi"]):
        bad.append(f"Brier CI {arm} {c}")
check("T11 matches estimates and CIs bracket estimates", not bad, bad)
check("T6 AUC = T11 AUC (shared runs)", all(f"{est[a][c]['auc_macro']['mean']:.3f}" in [x[7] for x in TT['T6' if a in 'AB' else 'T7']['rows'] if x[1] == SHORT[c]]
                                          for a in ARMS for c in ("LR", "BT", "RF", "GB")))

# ---------------------------------------------------------------- 7 baseline and permutation
bad = []
for v in inf["vs_majority"]:
    if v["metric"] == "kappa":
        if not close(v["diff"], est[v["arm"]][v["classifier"]]["kappa"]["mean"]):
            bad.append(f"kappa {v['arm']} {v['classifier']}")
    else:
        if not close(v["diff"], est[v["arm"]][v["classifier"]][v["metric"]]["mean"] - est[v["arm"]]["MAJ"][v["metric"]]["mean"], 1e-12):
            bad.append(f"{v['metric']} {v['arm']} {v['classifier']}")
check("vs-majority differences equal differences of means", not bad, bad)
bad = []
for s in perm["summary"]:
    null = np.array(perm["null"][f"{s['arm']}__{s['classifier']}"][s["statistic"]])
    if len(null) != cfg["statistics"]["permutations"] or not close(perm_pvalue(s["observed"], null), s["p"]):
        bad.append(f"{s['arm']} {s['classifier']} {s['statistic']}")
check("permutation p-values recomputed from nulls", not bad, bad)
bad = []
for k, v in FD["fig07"].items():
    stat, c = k.rsplit("_", 1)
    s = next(x for x in perm["summary"] if x["arm"] == "D" and x["classifier"] == c and x["statistic"] == stat)
    if not (close(v["observed"], s["observed"]) and close(v["p"], s["p"])):
        bad.append(k)
check("Figure 7 annotations equal permutation summary", not bad, bad)
check("T9 lists both authentic arms for all learners", len(TT["T9"]["rows"]) == 2 * len(LEARN))

# ---------------------------------------------------------------- 8 provenance-aware
bad = []
for r in pa:
    if r["scheme"] == "authentic_only":
        arm = "C" if r["attributes"] == "all" else "D"
        if not close(r["mean"], est[arm][r["classifier"]][r["metric"]]["mean"]):
            bad.append(f"{r['attributes']} {r['classifier']} {r['metric']}")
    if r["scheme"] == "random_cv_full_scored_authentic":
        arm = "A" if r["attributes"] == "all" else "B"
        sg = load_subgroups(run_key(arm, r["classifier"]))
        if not close(r["mean"], sg[sg.subgroup == "authentic"][r["metric"]].mean()):
            bad.append(f"subgroup {arm} {r['classifier']}")
check("provenance-aware references equal arm C/D estimates and A/B subgroups", not bad, bad)
bad = []
for attrs in ("all", "behaviour"):
    for s in ("random_cv_full_scored_authentic", "synth_plus", "synth_plus_purged", "synth_only", "synth_only_purged", "authentic_only"):
        exp = [round(100 * next(r for r in pa if r["attributes"] == attrs and r["classifier"] == c and r["scheme"] == s
                                and r["metric"] == "balanced_accuracy")["mean"], 4) for c in LEARN]
        if not np.allclose(FD["fig08"][f"{attrs}_{s}"], exp):
            bad.append(f"{attrs} {s}")
check("Figure 8 values equal T10 source", not bad, bad)
bad = []
grp = None
for r in TT["T10"]["rows"]:
    grp = {"All attributes": "all", "Behaviour only": "behaviour"}.get(r[0], grp)
    c = next(k for k, v in SHORT.items() if v == r[1])
    ao = next(x for x in pa if x["attributes"] == grp and x["classifier"] == c and x["scheme"] == "authentic_only" and x["metric"] == "balanced_accuracy")
    if r[3] != f"{100 * ao['mean']:.2f}":
        bad.append(f"T10 {grp} {c}")
    arm = "C" if grp == "all" else "D"
    if r[3] != f"{100 * est[arm][c]['balanced_accuracy']['mean']:.2f}":
        bad.append(f"T10 vs T7 {grp} {c}")
check("T10 authentic-only column equals T7 balanced accuracy", not bad, bad)

# ---------------------------------------------------------------- 9 sensitivity and RM
check("S1 uses the 496-record antecedent subset", all(r["n_records"] == audit["n_authentic_discrete_rule"] for r in sens["S1_discrete_rule"]))
n_dedup_full = len(df) - audit["exact_duplicate_rows_extra"]
n_dedup_auth = audit["n_authentic"] - audit["duplicates_extra_in_survey_block"]
check("S2 record counts", all(r["n_records"] == (n_dedup_full if r["arm"] in "AB" else n_dedup_auth) for r in sens["S2_deduplicated"]),
      f"expected {n_dedup_full}/{n_dedup_auth}")
check("S5 max_features = sqrt reproduces the primary random forest",
      all(close(next(r for r in sens["S5_rf_max_features"] if r["arm"] == a and r["max_features"] == "sqrt")["accuracy"],
                est[a]["RF"]["accuracy"]["mean"]) for a in "AB"))
bad = []
rm_src = load_json("rapidminer_reconciliation")
import json
from obaudit.config import ROOT
raw_rm = json.load(open(ROOT / "rapidminer" / "antecedent_results" / "rapidminer_authoritative_results.json"))
MAP = {"NaiveBayes": "NB", "LogisticRegression": "LR", "DecisionTree": "DT", "BaggedTree": "BT"}
for r in raw_rm["aggregate"]:
    for key, met in (("acc", "accuracy"), ("kappa", "kappa"), ("wmr", "balanced_accuracy"), ("wmp", "macro_precision")):
        c_ = next(x for x in rm_src["cells"] if x["arm"] == r["arm"][-1] and x["classifier"] == MAP[r["classifier"]] and x["metric"] == met)
        if not close(c_["rapidminer"], r[key]):
            bad.append(f"RM {r['arm']} {r['classifier']} {met}")
        if r["arm"][-1] in "AB":
            sc = 1 if met == "kappa" else 100
            if not close(c_["python"], sc * est[r["arm"][-1]][MAP[r["classifier"]]][met]["mean"], 1e-9):
                bad.append(f"PY {r['arm']} {r['classifier']} {met}")
check("RapidMiner reconciliation uses the source values and the primary Python estimates", not bad, bad)

# ------------------------------------------------------------- 10 literature and context
bad = []
for i, a in enumerate(ARMS):
    best = max(LEARN, key=lambda c: est[a][c]["accuracy"]["mean"])
    if not close(FD["fig13"]["values"][len(FD["literature"]) + i], round(100 * est[a][best]["accuracy"]["mean"], 4)):
        bad.append(a)
check("Figure 13 best-learner values equal estimates", not bad, bad)
check("T12 reported accuracies equal Figure 13", all(f"{lit['accuracy']:.2f}" == TT["T12"]["rows"][i][4] for i, lit in enumerate(FD["literature"])))

# ------------------------------------------------------------------ 11 presentation rules
forbidden = re.compile(r"\b(hypothetical|edited|modified|placeholder|watermark|TBD|TODO)\b", re.I)
bad = []
for t in TT.values():
    blob = " ".join([t["title"], t["note"]] + [" ".join(map(str, r)) for r in t["rows"]] + t["columns"])
    if forbidden.search(blob):
        bad.append(t["id"])
    if re.search(r"\bnan\b|None", blob):
        bad.append(t["id"] + " nan/None")
    if any(len(r) != len(t["columns"]) for r in t["rows"]):
        bad.append(t["id"] + " ragged")
check("tables: no forbidden labels, no missing values, rectangular", not bad, bad)
figs = sorted(p.name for p in cfg["paths"]["figures"].glob("*.png"))
check("22 figure files present and non-empty", len(figs) == 22 and all((cfg["paths"]["figures"] / f).stat().st_size > 20000 for f in figs), figs)
check("27 display tables present", len(TT) == 27, sorted(TT))
check("majority baseline quoted in T7 note equals audit", f"{audit['majority_baseline_authentic_pct']:.2f}%" in TT["T7"]["note"])

npass = sum(c["pass"] for c in CHECKS)
save_json("consistency_report", {"n_checks": len(CHECKS), "n_pass": npass, "checks": CHECKS})
for c in CHECKS:
    if not c["pass"]:
        print("FAIL:", c["check"], c["detail"])
print(f"consistency gate: {npass}/{len(CHECKS)} checks passed")
sys.exit(0 if npass == len(CHECKS) else 1)
